"""Fixed-boundary proposal test; never publishes orders to the live game."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys

BASE = Path(__file__).parent
REPO = Path.home() / "civvis-science-writing-before-luxury-b66e"
sys.path.insert(0, str(REPO / "tools"))
from civ6_captured_read_replay import expanded_reads
from civ6_ladder import decider_genome
from native_build_artifact import verify as verify_native_artifact

parser = argparse.ArgumentParser()
parser.add_argument("--binary", type=Path, required=True)
parser.add_argument("--build-receipt", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
root = args.output.resolve()
root.mkdir()  # Preserve every attempt; never replace an earlier result.
sha = lambda data: hashlib.sha256(data).hexdigest()
tag = "science-writing-before-the-luxury"

try:
    source_root = BASE / "writing-precedence-native-034948-t18"
    source = json.loads((source_root / "source.json").read_text())
    data = (source_root / "events.jsonl").read_bytes()
    assert sha(data) == source["sha256"]
    seat = next(json.loads(line) for line in data.splitlines()
                if json.loads(line).get("kind") == "seat")
    assert seat["civ"] == "CIVILIZATION_KOREA"
    assert seat["leader"] == "LEADER_SEONDEOK"
    assert seat["difficulty"] == "DIFFICULTY_DEITY"
    (root / "events.jsonl").write_bytes(data)
    (root / "source.json").write_text(json.dumps(source, indent=2) + "\n")
    build = json.loads(args.build_receipt.read_text())
    binary_sha = sha(args.binary.read_bytes())
    protocol = json.loads((BASE / "writing-new-experiment-protocol.json").read_text())
    expected_source = protocol["formatted_candidate_commit"]
    if build.get("schema") == 1:
        tests = {"lib": ["ai::advanced::science_writing_before_the_luxury::tests"]}
        verified = verify_native_artifact(REPO, args.build_receipt.parent,
                                         expected_source, json.dumps(tests), "1.97.1")
        assert verified == build
        assert build["binaries"]["civvis_orders"] == binary_sha
        focused = [t for t in build["tests"] if t["target"] == "lib"
                   and t["filter"] == tests["lib"][0]]
        assert len(focused) == 1 and focused[0]["passed"] == 8
        source_commit = build["source"]["sha"]
    else:
        assert build["binary_sha256"] == binary_sha
        assert build["exit_code"] == 0 and build["source_clean_before_and_after"] is True
        source_commit = build["source_commit"]
    assert source_commit == expected_source
    # Artifact downloads may remove executable mode; the verified bytes stay exact.
    args.binary.chmod(args.binary.stat().st_mode | 0o100)
    shutil.copy2(args.binary, root / "probe-binary")
    assert sha((root / "probe-binary").read_bytes()) == binary_sha
    (root / "build-receipt.json").write_text(json.dumps(build, indent=2) + "\n")
    genome = source["native_genome"]
    assert tag not in genome["forced"] and tag not in genome["treatments"]
    common_capture = root / "current-capture"
    all_pairs = []
    references = {}
    for repeat in range(2):
        pair_root = root / f"repeat-{repeat + 1}"
        pair_root.mkdir()
        arms = []
        for arm in ("off", "on"):
            directory = pair_root / arm
            directory.mkdir()
            (directory / "events.jsonl").write_bytes(data)
            assert not common_capture.exists()
            command = [str(root / "probe-binary"), "--mirror", str(directory),
                       "--turn", "18", "--victory", "science", "--civ",
                       "CIVILIZATION_KOREA", "--explain", "--serve", "--fresh-board",
                       "--capture-inputs", str(common_capture)]
            for gene in genome["forced"]:
                command += ["--with", gene]
            if arm == "on":
                command += ["--with", tag]
            process = subprocess.run(command, cwd=REPO, input="18\n", text=True,
                                     capture_output=True, timeout=180)
            (directory / "stdout.json").write_text(process.stdout)
            (directory / "stderr.log").write_text(process.stderr)
            assert process.returncode == 0, (arm, process.returncode, process.stderr[-2000:])
            payload = json.loads(process.stdout)
            assert payload["turn"] == 18
            assert (payload["decision"]["turn"], payload["decision"]["frame"]) == (18, 0)
            assert payload["decision"]["victory_portfolio"]["assigned_target"] == "science"
            capture = payload["input_capture"]
            assert capture["complete"] is True
            reads = expanded_reads(capture)
            assert reads and all(observed == data for observed in reads)
            observed_genome = decider_genome(directory / "stderr.log")
            assert observed_genome is not None
            if arm == "off":
                assert observed_genome == genome, "OFF genome differs from native source"
            research = [order for order in payload["orders"] if order["kind"] == "research"]
            expected = "TECH_IRRIGATION" if arm == "off" else "TECH_WRITING"
            assert len(research) == 1 and research[0]["verb"] == expected, research
            stable = {key: payload[key] for key in ("orders", "decision")}
            if repeat == 0:
                references[arm] = stable
            else:
                assert stable == references[arm], f"{arm} full reply differs across repeats"
            shutil.move(str(common_capture), str(directory / "input-capture"))
            arms.append({"arm": arm, "exit": process.returncode, "argv": command,
                         "genome": observed_genome, "payload": payload,
                         "binary_sha256": binary_sha, "actual_read_count": len(reads),
                         "capture_relocated_to": str(directory / "input-capture")})
            print(f"repeat {repeat + 1} {arm}: {len(reads)} exact reads, {research[0]['verb']}", flush=True)
        off, on = arms
        assert off["actual_read_count"] == on["actual_read_count"]
        for field in ("forced", "treatments"):
            assert set(on["genome"][field]) - set(off["genome"][field]) == {tag}
            assert not set(off["genome"][field]) - set(on["genome"][field])
        for field in genome.keys() - {"forced", "treatments"}:
            assert off["genome"][field] == on["genome"][field], field
        assert off["payload"]["orders"] != on["payload"]["orders"]
        record = {"complete": True, "binary_commit": source_commit,
                  "binary_sha256": binary_sha, "source": source,
                  "scope": "Fresh-board proposals from unchanged native captured bytes; not original private-state replay, host execution, survival or strength evidence.",
                  "reads": [{"complete": True, "sha256": sha(data), "bytes": len(data), "arms": arms}]}
        (pair_root / "pair.json").write_text(json.dumps(record, indent=2) + "\n")
        all_pairs.append(str(pair_root / "pair.json"))
    assert sha((root / "probe-binary").read_bytes()) == binary_sha
    (root / "result.json").write_text(json.dumps({"complete": True, "pairs": all_pairs,
        "binary_sha256": binary_sha, "source_commit": source_commit,
        "scope": "Two fixed-boundary OFF/ON proposal repetitions only; no win-rate estimate."}, indent=2) + "\n")
except BaseException as error:
    (root / "failure.json").write_text(json.dumps({"complete": False,
        "error": repr(error), "scope": "Failed attempt retained; no activation claim."}, indent=2) + "\n")
    raise
