"""Same-observation, same-binary Seowon treatment probes; no live input/output.
Every byte read is checked; these are fresh-board proposals, not strength tests.
"""
from pathlib import Path
import json,sys,subprocess,hashlib,shutil,argparse
repo=Path('/Users/martbot-mbp-m5-max-128/civvis-districts-protect-seowon-science-4bf1')
sys.path.insert(0,str(repo/'tools'))
from civ6_captured_read_replay import expanded_reads
from civ6_ladder import decider_genome
parser=argparse.ArgumentParser();parser.add_argument('--binary',type=Path,required=True);parser.add_argument('--limit',type=int,default=34);parser.add_argument('--case');args=parser.parse_args()
root=Path(__file__).parent;tag='districts-protect-seowon-science'
binary=root/'probe-binary';digest=lambda b:hashlib.sha256(b).hexdigest()
if binary.exists():assert digest(binary.read_bytes())==digest(args.binary.read_bytes()),'refuse to replace a frozen probe binary'
else:shutil.copy2(args.binary,binary)
binsha=digest(binary.read_bytes());manifest=json.loads((root/'probe-inputs.json').read_text());results=[]
if args.case:manifest=[r for r in manifest if Path(r['prefix']).parent.name==args.case]
# Try the directly observed Sangju Theater start first.
manifest.sort(key=lambda r:(not(r['run']=='civvis-20261105T000603Z' and r['turn']==69),r['run'],r['turn']))
for index,row in enumerate(manifest[:args.limit]):
 name=Path(row['prefix']).parent.name;case=root/'pairs'/name
 if case.exists():raise SystemExit('refuse to overwrite '+str(case))
 case.mkdir(parents=True);source=Path(row['prefix']).read_bytes();assert digest(source)==row['sha256']
 arms=[];common=root/'current-capture'
 for arm in ['off','on']:
  directory=case/arm;directory.mkdir();(directory/'events.jsonl').write_bytes(source)
  command=[str(binary),'--mirror',str(directory),'--turn',str(row['turn']),'--victory','science','--civ','CIVILIZATION_KOREA','--explain','--serve','--fresh-board','--capture-inputs',str(common)]
  for gene in row['forced']:
   assert gene!=tag;command+=['--with',gene]
  for gene in row['withheld']:
   assert gene!=tag;command+=['--without',gene]
  if arm=='on':command+=['--with',tag]
  assert not common.exists()
  process=subprocess.run(command,cwd=repo,text=True,input=str(row["turn"])+"\n",capture_output=True,timeout=180)
  (directory/'stdout.json').write_text(process.stdout);(directory/'stderr.log').write_text(process.stderr)
  assert process.returncode==0,(name,arm,process.returncode,process.stderr[-2000:])
  payload=json.loads(process.stdout);capture=payload['input_capture'];assert capture['complete'],capture
  reads=expanded_reads(capture);assert reads and all(data==source for data in reads),(name,arm,'read bytes differ')
  assert payload['turn']==row['turn'],(name,arm,'wrong turn')
  genome=decider_genome(directory/'stderr.log');assert genome is not None
  arms.append({'arm':arm,'exit':process.returncode,'argv':command,'genome':genome,'payload':payload,'binary_sha256':binsha,'actual_read_count':len(reads)})
  shutil.move(str(common),str(directory/'input-capture'))
  print(name,arm,'requests bytes checked',len(reads),'orders',len(payload['orders']),flush=True)
 off,on=arms;changed=off['payload']['orders']!=on['payload']['orders']
 production=lambda arm:[a for a in arm['payload'].get('decision',{}).get('native_actions',[]) if a.get('type')=='produce']
 production_changed=production(off)!=production(on)
 record={'complete':True,'scope':row['scope'],'source':row,'binary_sha256':binsha,'reads':[{'complete':True,'sha256':row['sha256'],'bytes':len(source),'arms':arms}]}
 (case/'pair.json').write_text(json.dumps(record,indent=2)+'\n')
 result={'case':name,'changed':changed,'production_changed':production_changed,'record':str(case/'pair.json'),'binary_sha256':binsha};results.append(result)
 (root/'pair-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(result),flush=True)
 if production_changed:break
