#!/usr/bin/env python3
"""Paired native decider queries for nusantara-reads-the-coast.

Live run civvis-20261105T165539Z (Indonesia/Gitarja, Deity Online science),
turn 78, queried with the run's own forced genome (tags this binary carries),
off vs on `--with nusantara-reads-the-coast`. Writes native-queries-01/0000/result.json.
"""
import hashlib, json, os, subprocess, sys, time
BIN, RUN, TURN, TAG = sys.argv[1], sys.argv[2], int(sys.argv[3]), "nusantara-reads-the-coast"
OUT = sys.argv[4]
known = subprocess.run([BIN, "--mirror", RUN, "--with", "zz-not-a-gene"], capture_output=True, text=True).stderr
known = set(t.strip() for t in known.split("this binary can force: ", 1)[1].split(",")) if "this binary can force: " in known else set()
forced = [t for t in json.load(open(os.path.join(RUN, "summary.json")))["forced"] if t in known]
base = [BIN, "--explain", "--mirror", RUN, "--victory", "science", "--turn", str(TURN), "--resumed"]
for t in forced:
    base += ["--with", t]
arms = []
for arm in ("off", "on"):
    argv = base + (["--with", TAG] if arm == "on" else [])
    start = time.time()
    p = subprocess.run(argv, capture_output=True, text=True)
    lines = p.stderr.splitlines()
    genome = json.loads(lines[0])
    arms.append({"arm": arm, "argv": argv, "exit": p.returncode, "genome": genome,
                 "journal": [l for l in lines if l.startswith("[why]")],
                 "payload": json.loads(p.stdout), "wall_seconds": round(time.time() - start, 3)})
    os.makedirs(OUT, exist_ok=True)
    open(os.path.join(OUT, f"{arm}.stdout"), "w").write(p.stdout)
blob = json.dumps(arms, sort_keys=True).encode()
district = lambda a: [o for o in a["payload"]["orders"] if o["kind"] in ("produce", "produce_next") and "DISTRICT" in (o.get("verb") or "")]
record = {"case": {"run": os.path.basename(RUN), "turn": TURN, "city": 131073, "city_name": "Jambi",
                   "live_built": "DISTRICT_INDUSTRIAL_ZONE at civ6 (62,9) (final state), 0 adjacent Coast; on-arm site (63,11) has 2"},
          "complete": True, "index": 0,
          "reads": [{"arms": arms, "bytes": len(blob), "complete": True,
                     "descriptor": {"run": os.path.basename(RUN), "turn": TURN},
                     "orders_changed": arms[0]["payload"]["orders"] != arms[1]["payload"]["orders"],
                     "off_district_orders": district(arms[0]), "on_district_orders": district(arms[1]),
                     "sha256": hashlib.sha256(blob).hexdigest()}]}
json.dump(record, open(os.path.join(OUT, "result.json"), "w"), indent=1)
print(json.dumps({"changed": record["reads"][0]["orders_changed"], "off": district(arms[0]), "on": district(arms[1])}))
