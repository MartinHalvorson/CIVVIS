"""summarize.py OUT: per read, the original capital's head each arm leaves (its last produce order on city
65536, or the board's head when it gives none), classified; and the counts the PR reports."""
import collections
import json
import sys
from pathlib import Path

OUT = Path(sys.argv[1])
SHOOTERS = ('ARCHER', 'CROSSBOWMAN', 'FIELD_CANNON', 'MACHINE_GUN', 'SLINGER')
WALLS = ('BUILDING_WALLS', 'BUILDING_CASTLE', 'BUILDING_STAR_FORT', 'BUILDING_TSIKHE')
CIVILIAN = ('BUILDER', 'SETTLER', 'TRADER', 'SCOUT', 'MISSIONARY', 'APOSTLE', 'SPY', 'ARCHAEOLOGIST',
            'NATURALIST', 'ROCK_BAND', 'MEDIC', 'MILITARY_ENGINEER', 'INQUISITOR', 'GURU')


def classify(verb):
    if verb is None:
        return 'kept'
    if verb in WALLS:
        return 'walls'
    if verb == 'PROJECT_REPAIR_OUTER_DEFENSES':
        return 'repair'
    if verb.startswith('UNIT_'):
        name = verb[5:]
        if name in SHOOTERS:
            return 'shooter'
        if name in CIVILIAN:
            return 'peacetime'
        return 'military'
    return 'peacetime'


def head(arm):
    verbs = [o.get('verb') for o in arm['payload']['orders']
             if o.get('kind') == 'produce' and o.get('subject') == 65536]
    return verbs[-1] if verbs else None


rows, totals = [], collections.Counter()
for path in sorted(OUT.glob('*/result.json')):
    r = json.loads(path.read_text())
    if not r.get('complete'):
        totals['incomplete'] += 1
        print(r['case']['run'][-15:], r['case']['turn'], 'INCOMPLETE', r.get('error'))
        continue
    for read in r['reads']:
        off, on = (next(a for a in read['arms'] if a['arm'] == k) for k in ('off', 'on'))
        h_off, h_on = head(off), head(on)
        c_off, c_on = classify(h_off), classify(h_on)
        changed = h_off != h_on
        why = read['descriptor']['why']
        totals['reads'] += 1
        totals['reads_' + why] += 1
        totals['orders_changed'] += read['orders_changed']
        totals['journal_on'] += bool(on['journal_gene'])
        if changed:
            totals['head_changed'] += 1
            totals['head_changed_' + why] += 1
            totals[f'{c_off}->{c_on}'] += 1
        rows.append((r['case']['run'][-15:], r['case']['turn'], why, h_off, h_on, changed, len(on['journal_gene'])))
        print(f"{r['case']['run'][-15:]} t{r['case']['turn']:<3} {why:12} off {h_off or '(board head)':32} "
              f"on {h_on or '(board head)':32} {'CHANGED' if changed else 'same'} journal {len(on['journal_gene'])}")
print(json.dumps(dict(totals), indent=1))
(OUT / 'summary.json').write_text(json.dumps({'totals': dict(totals), 'rows': rows}, indent=1))
