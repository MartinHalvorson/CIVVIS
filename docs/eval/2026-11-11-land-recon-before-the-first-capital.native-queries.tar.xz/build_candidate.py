"""Build and test one immutable local proposal candidate; never deploys it."""
import subprocess, os, json, time, hashlib, shutil, re, sys
from pathlib import Path
out = Path(__file__).parent
prefix = sys.argv[1]
commit = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
env = dict(os.environ, CARGO_PROFILE_CI_OPT_LEVEL='0', CARGO_BUILD_JOBS='2', CIVVIS_COMMIT=commit)
receipt = {'source_commit':commit,'profile':'ci, opt-level0, 16codegen, debug assertions on',
 'rustc':subprocess.check_output(['rustc','-vV'],text=True),'started':time.time(),
 'env_overrides':{k:env[k] for k in ['CARGO_PROFILE_CI_OPT_LEVEL','CARGO_BUILD_JOBS','CIVVIS_COMMIT']},
 'driver_pid':os.getpid(),'source_clean_before':True,'steps':[]}
f = out/f'{prefix}-build.json'
def save(): f.write_text(json.dumps(receipt,indent=2)+'\n')
commands = [('focused',['cargo','test','--profile','ci','--locked','--lib','first_capital_recon','--','--test-threads=2']),
 ('binary',['cargo','build','--profile','ci','--locked','--bin','civvis_orders'])]
save()
for name, cmd in commands:
 log_path = out/f'{prefix}-{name}.log'
 step = {'name':name,'command':cmd,'started':time.time()};receipt['steps'].append(step)
 with log_path.open('w') as log:
  proc = subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  step['cargo_pid']=proc.pid;save()
  while proc.poll() is None:
   for row in subprocess.check_output(['ps','-axo','pid,ppid,pri,command'],text=True).splitlines():
    parts = row.strip().split(None,3)
    if len(parts)==4:
     pid,ppid,pri,command=parts
     if ppid==str(proc.pid) and 'rustc --crate-name civvis' in command and int(pri)<10:
      subprocess.run(['taskpolicy','-B','-p',pid],check=True)
   time.sleep(1)
 step.update(exit_code=proc.returncode,seconds=time.time()-step['started'],log_sha256=hashlib.sha256(log_path.read_bytes()).hexdigest());save()
 if proc.returncode:
  receipt['exit_code']=proc.returncode;save();raise SystemExit(proc.returncode)
 if name=='focused': assert re.search(r'test result: ok\. 10 passed; 0 failed;',log_path.read_text())
receipt.update(exit_code=0,seconds=time.time()-receipt['started'],source_clean_after=not subprocess.check_output(['git','status','--porcelain'],text=True),source_head_after=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
assert receipt['source_clean_after'] and receipt['source_head_after']==commit
binary=out/f'civvis_orders-opt0-{commit}'
shutil.copy2('target/ci/civvis_orders',binary)
receipt.update(binary=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest());save()
print(json.dumps({'source':commit,'binary':str(binary),'seconds':receipt['seconds'],'tests':10}))
