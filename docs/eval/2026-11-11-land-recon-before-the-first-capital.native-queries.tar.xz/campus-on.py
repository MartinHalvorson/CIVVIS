#!/usr/bin/env python3
import os,sys
a=sys.argv[1:]
a[a.index("--civ")+1]="CIVILIZATION_MACEDON"
a += ["--with","land-recon-before-the-first-capital"]
os.execv('/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/first-capital-land-recon/civvis_orders-opt0-e2c53f391106cbd59c87d45b79e59c207788b5c2', ['/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/first-capital-land-recon/civvis_orders-opt0-e2c53f391106cbd59c87d45b79e59c207788b5c2']+a)
