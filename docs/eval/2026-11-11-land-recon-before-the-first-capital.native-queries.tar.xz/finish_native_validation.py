"""Read-only validation pipeline for a fixed experimental worker; no deployment."""
from pathlib import Path
import os,sys,json,time,subprocess,hashlib
root=Path(__file__).parent
repo=Path('/Users/martbot-mbp-m5-max-128/civvis-land-recon-before-the-first-capital-20d2')
source='e2c53f391106cbd59c87d45b79e59c207788b5c2'
state={'driver_pid':os.getpid(),'source':source,'started':time.time(),'step':'await_build','steps':[]}
f=root/'final-validation-pipeline.json'
def save(): f.write_text(json.dumps(state,indent=2)+'\n')
def run(name, command):
 state['step']=name;entry={'name':name,'command':command,'started':time.time()};state['steps'].append(entry);save()
 with (root/f'{name}.log').open('w') as log:
  proc=subprocess.Popen(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
  entry['pid']=proc.pid;save();code=proc.wait()
 entry.update(exit_code=code,seconds=time.time()-entry['started']);save()
 if code: raise RuntimeError((name,code))
save()
try:
 while True:
  receipt=json.loads((root/'campus-retention-build.json').read_text())
  assert receipt['source_commit']==source
  if 'exit_code' in receipt:break
  observed=subprocess.check_output(['ps','-p',str(receipt['driver_pid']),'-o','command='],text=True)
  assert 'build_candidate.py campus-retention' in observed
  time.sleep(2)
 assert receipt['exit_code']==0 and receipt['source_clean_after']
 binary=Path(receipt['binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==receipt['sha256']
 run('captured-queries-5',[sys.executable,str(root/'probe_captured.py'),'--binary',str(binary),'--source-sha',source,'--out',str(root/'retention-queries-5')])
 for arm in ['off','on']:
  wrapper=root/f'campus-{arm}.py';assert not wrapper.exists()
  wrapper.write_text('#!/usr/bin/env python3\nimport os,sys\na=sys.argv[1:]\na[a.index("--civ")+1]="CIVILIZATION_MACEDON"\n'+('a += ["--with","land-recon-before-the-first-capital"]\n' if arm=='on' else '')+f'os.execv({str(binary)!r}, [{str(binary)!r}]+a)\n');wrapper.chmod(0o755)
 common=[sys.executable,str(repo/'tools/native_city_route_replay.py'),'--run',str(root.parent/'macedon-policy-pairs/native-prefix'),'--force-file',str(root.parent/'macedon-policy-pairs/forced-baseline.txt'),'--through-turn','65']
 run('campus-off-control',common+['--baseline',str(root.parent/'macedon-policy-pairs/clock-off.py'),'--candidate',str(root/'campus-off.py'),'--out',str(root/'campus-off-control')])
 run('campus-on-replay',common+['--baseline',str(root/'campus-off.py'),'--candidate',str(root/'campus-on.py'),'--out',str(root/'campus-on-replay'),'--explain'])
 state.update(step='complete',exit_code=0,seconds=time.time()-state['started']);save();print(json.dumps(state))
except BaseException as error:
 state.update(step='failed',exit_code=1,error=repr(error));save();raise
