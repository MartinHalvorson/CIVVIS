"""Same-input policy proposals only; never sends orders to the host."""
import argparse, hashlib, json, shutil, subprocess, sys
from pathlib import Path
REPO = Path('/Users/martbot-mbp-m5-max-128/civvis-land-recon-before-the-first-capital-20d2')
BASE = Path(__file__).parent
sys.path.insert(0, str(REPO / 'tools'))
from civ6_captured_read_replay import expanded_reads
from civ6_ladder import decider_genome
sha = lambda b: hashlib.sha256(b).hexdigest()
tag = 'land-recon-before-the-first-capital'
p = argparse.ArgumentParser()
p.add_argument('--binary', type=Path, required=True)
p.add_argument('--source-sha', required=True)
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
a.out.mkdir()
forced = (BASE.parent / 'macedon-policy-pairs/forced-baseline.txt').read_text().strip().split(',')
assert tag not in forced and len(forced) == len(set(forced)) == 498
binary = a.binary.resolve()
binary.chmod(binary.stat().st_mode | 0o100)
binary_sha = sha(binary.read_bytes())
changed = []
try:
 for turn in (30, 40, 60):
  original = BASE / 'captured-inputs' / f't{turn}'
  source = json.loads((original/'source.json').read_text())
  data = (original/'events.jsonl').read_bytes()
  assert sha(data) == source['sha256']
  seat = next(json.loads(l) for l in data.splitlines() if json.loads(l).get('kind') == 'seat')
  assert seat['civ'] == 'CIVILIZATION_MACEDON' and seat['leader'] == 'LEADER_ALEXANDER'
  assert seat['difficulty'] == 'DIFFICULTY_DEITY'
  case = a.out / f't{turn}'
  case.mkdir()
  shutil.copy2(original/'source.json', case/'source.json')
  (case/'events.jsonl').write_bytes(data)
  arms = []
  common_capture = a.out / 'current-capture'
  for arm in ('off', 'on'):
   directory = case / arm
   directory.mkdir()
   (directory/'events.jsonl').write_bytes(data)
   cmd = [str(binary), '--mirror', str(directory), '--turn', str(turn),
          '--victory', 'domination', '--civ', 'CIVILIZATION_MACEDON',
          '--explain', '--serve', '--fresh-board', '--capture-inputs', str(common_capture)]
   for gene in forced: cmd += ['--with', gene]
   if arm == 'on': cmd += ['--with', tag]
   r = subprocess.run(cmd, cwd=REPO, input=f'{turn}\n', text=True,
                      capture_output=True, timeout=180)
   (directory/'stdout.json').write_text(r.stdout)
   (directory/'stderr.log').write_text(r.stderr)
   assert r.returncode == 0, (arm, r.returncode, r.stderr[-2000:])
   payload = json.loads(r.stdout)
   assert (payload['decision']['turn'], payload['decision']['frame']) == (turn, source['frame'])
   assert payload['decision']['victory_portfolio']['assigned_target'] == 'domination'
   capture = payload['input_capture']
   assert capture['complete']
   reads = expanded_reads(capture)
   assert reads and all(b == data for b in reads)
   genome = decider_genome(directory/'stderr.log')
   assert genome
   shutil.move(str(common_capture), str(directory/'input-capture'))
   arms.append({'arm':arm, 'exit':r.returncode, 'argv':cmd, 'genome':genome,
                'payload':payload, 'binary_sha256':binary_sha, 'actual_read_count':len(reads)})
  off, on = arms
  for field in ('forced', 'treatments'):
   assert set(on['genome'][field]) - set(off['genome'][field]) == {tag}
   assert not set(off['genome'][field]) - set(on['genome'][field])
  for field in off['genome'].keys() - {'forced','treatments'}:
   assert off['genome'][field] == on['genome'][field]
  different = off['payload']['orders'] != on['payload']['orders']
  if turn == 30:
   production = lambda arm: [o['verb'] for o in arm['payload']['orders'] if o['kind'] == 'produce' and o['subject'] == 65536]
   assert production(off) == ['UNIT_SETTLER'], production(off)
   assert production(on) == ['UNIT_SCOUT'], ('The new policy must finish with a Scout, not merely any changed order', production(on))
  record = {'complete':True, 'source_commit':a.source_sha, 'binary_sha256':binary_sha,
            'scope':'Fresh-board proposals from unchanged captured native bytes; not original private-state replay, host execution, survival or strength evidence.',
            'source':source, 'reads':[{'complete':True,'sha256':sha(data),'bytes':len(data),'arms':arms}]}
  (case/'pair.json').write_text(json.dumps(record,indent=2)+'\n')
  if different: changed.append(f't{turn}/pair.json')
  print(json.dumps({'turn':turn,'orders_changed':different,'reads':[x['actual_read_count'] for x in arms]}),flush=True)
 assert changed, 'No native proposal activation; no evidence claimed'
 assert sha(binary.read_bytes()) == binary_sha
 (a.out/'result.json').write_text(json.dumps({'complete':True,'changed_members':changed,
     'source_commit':a.source_sha,'binary_sha256':binary_sha,'scope':'Activation only; no win-rate estimate'},indent=2)+'\n')
except BaseException as e:
 (a.out/'failure.json').write_text(json.dumps({'complete':False,'error':repr(e)},indent=2)+'\n')
 raise
