"""Paired one-frame decider replays of live Lv 8 Deity frames (6 players, Small
Continents, Online), 2026-11-19 12:00Z to 11-20: the first captured frame of
each of the ten turns before 27 wars declared on us whose attacker was within
one gift's reach or read Friendly ("case" frames), and 120 ordinary frames
drawn with a fixed seed from 24 other games of the same window ("control").

`tribute-and-friendship-land` is the only bit that varies. Each arm is one
`civvis_orders --mirror DIR --explain --resumed` process built from the branch
(profile ci), with the run's own requested genome (why.log line 1 `forced`,
each as `--with`), `--victory` and `--civ`; the on arm adds `--with
tribute-and-friendship-land`. DIR holds the exact events.jsonl bytes the live
decider read for that frame (`decisions.jsonl` `input_capture`, the last
read).

Read per frame and arm: the orders (`payload`: the reply's turn, orders and
note; its `decision` block is left out); the tribute orders among them (`aid_gift`
verb `TRIBUTE`), the friendship orders, the delegation and embassy orders, and
the order list with those three kinds removed, which must be identical in the
two arms.

What this does NOT show. Each replay is a fresh agent and a fresh bridge: it
carries no memory of earlier frames, so the third change (a struck-out
friendship order is still sent) cannot show here: a fresh bridge has struck
nothing out. Whether a gift lands, an ask is accepted, or a war is avoided is
not measured: no frame is played forward and nothing is executed in Civ VI.
"""
import concurrent.futures
import hashlib
import json
import random
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
CASES = Path(sys.argv[3])
OUT = Path(sys.argv[4])
JOBS = int(sys.argv[5]) if len(sys.argv) > 5 else 3
GENE = 'tribute-and-friendship-land'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_decision_trace import captured_input  # noqa: E402
from civ6_ladder import decider_genome  # noqa: E402

CONTROL_RUNS = 24
CONTROL_PER_RUN = 5
WATCHED = ('aid_gift', 'friendship', 'delegation')


def frames(run, turn=None):
    """(turn, frame, input_capture) of every decision, or of one turn."""
    out = []
    for line in open(RUNS / run / 'decisions.jsonl'):
        row = json.loads(line)
        d = row['decision']
        if turn is None or d.get('turn') == turn:
            out.append((d.get('turn'), d.get('frame', 0), row['input_capture']))
    return out


def plan(cases):
    """The case frames, then the control frames."""
    picks = []
    seen = set()
    for case in cases:
        for turn in range(case['war_turn'] - 10, case['war_turn']):
            first = [f for f in frames(case['run'], turn) if f[1] == 0][:1]
            for t, f, _ in first:
                if (case['run'], t, f) not in seen:
                    seen.add((case['run'], t, f))
                    picks.append({'set': 'case', 'run': case['run'], 'turn': t, 'frame': f,
                                  'war_turn': case['war_turn'], 'rival': case['rival_player'],
                                  'kind': case['kind']})
    case_runs = {c['run'] for c in cases}
    pool = sorted(p.name for p in RUNS.glob('civvis-2026112*') if (p / 'summary.json').is_file())
    pool += sorted(p.name for p in RUNS.glob('civvis-20261119T1[2-9]*') if (p / 'summary.json').is_file())
    pool += sorted(p.name for p in RUNS.glob('civvis-20261119T2*') if (p / 'summary.json').is_file())
    pool = sorted({r for r in pool if r not in case_runs and (RUNS / r / 'why.log').is_file()})
    rng = random.Random(20261120)
    for run in rng.sample(pool, CONTROL_RUNS):
        firsts = [f for f in frames(run) if f[1] == 0 and 15 <= f[0] <= 160]
        for t, f, _ in rng.sample(firsts, min(CONTROL_PER_RUN, len(firsts))):
            picks.append({'set': 'control', 'run': run, 'turn': t, 'frame': f})
    return picks


def frame_bytes(run, turn, frame):
    for t, f, cap in frames(run, turn):
        if f == frame:
            return captured_input(cap, cap['reads'][-1]['snapshot_id'])
    raise ValueError(f'no captured frame {run} t{turn} f{frame}')


def arm(root, name, data, header, civ, extra):
    workdir = root / name
    workdir.mkdir(parents=True)
    (workdir / 'events.jsonl').write_bytes(data)
    argv = [str(BINARY), '--mirror', str(workdir), '--explain', '--resumed',
            '--victory', header['victory'], '--civ', civ]
    for tag in header['forced'] + extra:
        argv += ['--with', tag]
    started = time.monotonic()
    p = subprocess.run(argv, capture_output=True, timeout=1200)
    why = workdir / 'why.log'
    why.write_bytes(p.stderr)
    payload = json.loads(p.stdout) if p.returncode == 0 else {}
    orders = payload.get('orders') or []
    note = payload.get('note') or ''
    bits = [b.strip() for b in note.split(';')
            if any(k in b for k in ('tribute', 'mission_held', 'friendship_ask', 'withheld_refused'))]
    return {'arm': name, 'argv': argv, 'exit': p.returncode, 'genome': decider_genome(why),
            'payload': {'turn': payload.get('turn'), 'orders': orders, 'note': note},
            'note_bits': bits,
            'tribute': [o for o in orders if o.get('kind') == 'aid_gift' and o.get('verb') == 'TRIBUTE'],
            'friendship': [o for o in orders if o.get('kind') == 'friendship'],
            'delegation': [o for o in orders if o.get('kind') == 'delegation'],
            'rest': [o for o in orders if o.get('kind') not in WATCHED],
            'wall_seconds': round(time.monotonic() - started, 2)}


def one(pick):
    run, turn, frame = pick['run'], pick['turn'], pick['frame']
    root = OUT / 'work' / run / f't{turn:03d}f{frame}'
    root.mkdir(parents=True, exist_ok=True)
    record = {'descriptor': {**pick, 'cut': 'the last captured events.jsonl read of the frame'}}
    try:
        header = json.loads((RUNS / run / 'why.log').open().readline())
        if GENE in header['forced']:
            raise ValueError('the live genome already carried the gene')
        civ = json.loads((RUNS / run / 'summary.json').read_text())['seat']['civ']
        civ = civ.removeprefix('CIVILIZATION_').title()
        data = frame_bytes(run, turn, frame)
        record['bytes'] = len(data)
        record['sha256'] = hashlib.sha256(data).hexdigest()
        off = arm(root, 'off', data, header, civ, [])
        on = arm(root, 'on', data, header, civ, [GENE])
        record['arms'] = [off, on]
        record['orders_changed'] = off['payload']['orders'] != on['payload']['orders']
        record['tribute_changed'] = off['tribute'] != on['tribute']
        record['friendship_changed'] = off['friendship'] != on['friendship']
        record['delegation_changed'] = off['delegation'] != on['delegation']
        record['rest_changed'] = off['rest'] != on['rest']
        record['complete'] = all(a['exit'] == 0 and a['genome'] for a in record['arms'])
    except Exception as exc:  # retained, never hidden
        record.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    for name in ('off', 'on'):
        events = root / name / 'events.jsonl'
        if events.exists():
            events.unlink()
    return record


def main():
    cases = json.loads(CASES.read_text())
    OUT.mkdir(parents=True)
    picks = plan(cases)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': len(cases), 'frames': len(picks),
        'picks': picks,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=1))
    started = time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(JOBS) as pool:
        records = list(pool.map(one, picks))
    by_run = {}
    for r in records:
        by_run.setdefault(r['descriptor']['run'], []).append(r)
    index = []
    for i, (run, reads) in enumerate(sorted(by_run.items())):
        member = OUT / f'{i:04d}'
        member.mkdir()
        result = {'index': i, 'run': run, 'reads': [r for r in reads if r.get('complete')],
                  'failed': [r for r in reads if not r.get('complete')]}
        result['complete'] = bool(result['reads'])
        (member / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=1))
        index.append({'index': i, 'run': run, 'reads': len(result['reads']),
                      'failed': len(result['failed'])})
    (OUT / 'results-index.json').write_text(json.dumps(index, indent=1))
    print(json.dumps({'frames': len(picks), 'complete': sum(bool(r.get('complete')) for r in records),
                      'wall_seconds': round(time.monotonic() - started)}))


if __name__ == '__main__':
    main()
