"""Summarize the paired one-frame replays (run-tribute-friendship-queries.py)."""
import collections
import json
import sys
from pathlib import Path

OUT = Path(sys.argv[1])
reads = []
failed = 0
for member in sorted(OUT.glob('[0-9][0-9][0-9][0-9]/result.json')):
    r = json.loads(member.read_text())
    reads += r['reads']
    failed += len(r['failed'])


def gifts(arm):
    return {(o.get('subject'), o.get('x')) for o in arm['tribute']}


summary = {}
for name in ('case', 'control', 'all'):
    rows = [r for r in reads if name == 'all' or r['descriptor']['set'] == name]
    c = collections.Counter()
    amounts = []
    for r in rows:
        off, on = r['arms']
        c['frames'] += 1
        c['off: tribute sent'] += bool(off['tribute'])
        c['on: tribute sent'] += bool(on['tribute'])
        c['tribute changed'] += r['tribute_changed']
        c['on: tribute where off sent none'] += bool(on['tribute']) and not off['tribute']
        c['on: no tribute where off sent one'] += bool(off['tribute']) and not on['tribute']
        c['both sent, amount changed'] += bool(off['tribute']) and bool(on['tribute']) and gifts(off) != gifts(on)
        for o in off['tribute']:
            match = [p for p in on['tribute'] if p.get('subject') == o.get('subject')]
            if match:
                amounts.append((o.get('x'), match[0].get('x')))
        c['friendship changed'] += r['friendship_changed']
        c['off: friendship + mission to the same rival'] += any(
            d.get('subject') == f.get('subject') for f in off['friendship'] for d in off['delegation'])
        c['on: friendship + mission to the same rival'] += any(
            d.get('subject') == f.get('subject') for f in on['friendship'] for d in on['delegation'])
        c['mission dropped'] += len(off['delegation']) - len(on['delegation'])
        c['other orders changed'] += r['rest_changed']
        if r['descriptor']['set'] == 'case':
            rival = r['descriptor']['rival']
            c['case: off tribute to the attacker'] += any(o.get('subject') == rival for o in off['tribute'])
            c['case: on tribute to the attacker'] += any(o.get('subject') == rival for o in on['tribute'])
    summary[name] = dict(c)
    summary[name + '_amounts_off_on'] = sorted(amounts)
summary['failed'] = failed
print(json.dumps(summary, indent=1))
(OUT / 'summary.json').write_text(json.dumps(summary, indent=1))
