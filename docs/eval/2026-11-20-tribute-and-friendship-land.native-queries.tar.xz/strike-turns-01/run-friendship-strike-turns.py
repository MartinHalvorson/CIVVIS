"""Paired multi-turn replays of the live Deity games in which the attacker read
Friendly before its war and the friendship order was withheld by the bridge's
refused-order rule (three `not_friends` failures withhold an order for ten
turns): 20261119T180708Z (Netherlands), 20261119T205955Z (Brazil),
20261120T031624Z (Aztec), 20261120T053354Z (France), 20261120T073344Z (Egypt)
and 20261120T085149Z (India).

One-frame replays cannot show this change: a fresh bridge has struck nothing
out. Here each arm is ONE persistent `civvis_orders --mirror DIR` process (the
live server mode, `--serve`: one turn number in on stdin, one reply out), fed every turn
from a few turns before the attacker first read Friendly to the turn before
its war, so the bridge's strike ledger builds up from its own orders exactly
as it did live. DIR holds the run's events.jsonl through the war turn; the
order verdicts are read from it, so an ask the live rival refused fails in
both arms. Arms differ only by `--with tribute-and-friendship-land`; both
carry the run's requested genome (why.log line 1 `forced`), `--victory` and
`--civ`.

Read per turn and arm: the friendship orders sent to the attacker, and the
reply's note (`withheld_refused`, `friendship_ask_spared`,
`mission_held_for_friendship`). What this does NOT show: whether a re-ask
would have been accepted. The live rival was never asked on those turns, so
the verdict read here is "not friends" either way.
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

BINARY = Path(sys.argv[1])
OUT = Path(sys.argv[2])
GENE = 'tribute-and-friendship-land'
RUNS = Path.home() / 'civvis-civ6-runs/control'
CASES = [
    ('civvis-20261119T180708Z', 1, 98, 114),
    ('civvis-20261119T205955Z', 5, 110, 128),
    ('civvis-20261120T031624Z', 5, 100, 112),
    ('civvis-20261120T053354Z', 3, 104, 114),
    ('civvis-20261120T073344Z', 4, 48, 62),
    ('civvis-20261120T085149Z', 3, 145, 156),
]


def cut(run, war):
    """events.jsonl through the last row of the war turn."""
    out = []
    for line in open(RUNS / run / 'events.jsonl', 'rb'):
        if b'"kind": "state"' in line:
            state = json.loads(line)
            if state.get('kind') == 'state' and state['turn'] > war:
                break
        out.append(line)
    return b''.join(out)


def arm(workdir, header, civ, extra, turns):
    argv = [str(BINARY), '--mirror', str(workdir), '--serve', '--victory', header['victory'], '--civ', civ]
    for tag in header['forced'] + extra:
        argv += ['--with', tag]
    proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=open(workdir / 'why.log', 'wb'))
    replies = []
    for turn in turns:
        proc.stdin.write(f'{turn}\n'.encode())
        proc.stdin.flush()
        line = proc.stdout.readline()
        replies.append(json.loads(line) if line.strip() else {})
    proc.stdin.close()
    proc.wait(timeout=600)
    return argv, proc.returncode, replies


def main():
    OUT.mkdir(parents=True)
    results = []
    for run, rival, start, war in CASES:
        header = json.loads((RUNS / run / 'why.log').open().readline())
        civ = json.loads((RUNS / run / 'summary.json').read_text())['seat']['civ']
        civ = civ.removeprefix('CIVILIZATION_').title()
        data = cut(run, war)
        turns = list(range(start, war))
        record = {'run': run, 'rival': rival, 'turns': turns, 'war_turn': war,
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        for name, extra in (('off', []), ('on', [GENE])):
            workdir = OUT / 'work' / run / name
            workdir.mkdir(parents=True)
            (workdir / 'events.jsonl').write_bytes(data)
            started = time.monotonic()
            argv, code, replies = arm(workdir, header, civ, extra, turns)
            per_turn = []
            for turn, reply in zip(turns, replies):
                orders = reply.get('orders') or []
                note = reply.get('note') or ''
                per_turn.append({
                    'turn': turn, 'reply_turn': reply.get('turn'),
                    'friendship_to_rival': [o for o in orders
                                            if o.get('kind') == 'friendship' and o.get('subject') == rival],
                    'missions_to_rival': [o for o in orders
                                          if o.get('kind') == 'delegation' and o.get('subject') == rival],
                    'note_bits': [b.strip() for b in note.split(';')
                                  if any(k in b for k in ('withheld_refused', 'friendship_ask_spared',
                                                          'mission_held_for_friendship'))],
                    'orders': len(orders)})
            (workdir / 'events.jsonl').unlink()
            record['arms'].append({'arm': name, 'argv': argv, 'exit': code, 'turns': per_turn,
                                   'wall_seconds': round(time.monotonic() - started, 1)})
        results.append(record)
        off, on = record['arms']
        print(run, 'asks off', sum(bool(t['friendship_to_rival']) for t in off['turns']),
              'on', sum(bool(t['friendship_to_rival']) for t in on['turns']), flush=True)
    (OUT / 'result.json').write_text(json.dumps({'scope': __doc__, 'gene': GENE,
                                                  'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
                                                  'results': results}, indent=1))


if __name__ == '__main__':
    main()
