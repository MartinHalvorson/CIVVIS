"""Paired decider queries on live policy-window frames of six Deity
Culture-seat games of 2026-11-18/19.

`culture-deck-seats-the-great-person-cards` is the only bit that varies.
Each case is a live run's own events.jsonl cut right after the turn's first
state row whose policy window is open (`policy_change.made == false` and
`unlock_cost == 0`, the frame the live decider answered), replayed at that
turn. Both arms run one frozen `civvis_orders --resumed` built from the
branch, with that run's own requested genome (why.log line 1 `forced`, each as
`--with`, and its `civ`, null in all six, so no `--civ`); the on arm adds
`--with culture-deck-seats-the-great-person-cards`.

Cases: every open window from Drama and Poetry to t160 in
civvis-20261118T171747Z (Catherine, 0 visitors at t180),
-T210202Z (Eleanor of England, 0), -T220255Z (Mvemba, 0),
-T122047Z (Gorgo, 532 of 556 at t188), -T092341Z (Pericles, won t166) and
-T20261119T024425Z (Lady Six Sky, won t179), at most ten a game, spread.

Read per arm: the policy orders and the gene's own journal lines. Per case:
whether any order changed.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import re
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
JOBS = int(sys.argv[4]) if len(sys.argv) > 4 else 2
GENE = 'culture-deck-seats-the-great-person-cards'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

GAMES = [
    ('civvis-20261118T171747Z', 'CIVILIZATION_FRANCE'),
    ('civvis-20261118T210202Z', 'CIVILIZATION_ENGLAND'),
    ('civvis-20261118T220255Z', 'CIVILIZATION_KONGO'),
    ('civvis-20261118T122047Z', 'CIVILIZATION_GREECE'),
    ('civvis-20261118T092341Z', 'CIVILIZATION_GREECE'),
    ('civvis-20261119T024425Z', 'CIVILIZATION_MAYA'),
]
PER_GAME = 10


def windows(run):
    """Open policy-window turns from Drama and Poetry to t160."""
    turns = []
    with open(RUNS / run / 'events.jsonl', 'rb') as f:
        for line in f:
            if b'"kind": "state"' not in line:
                continue
            m = re.search(rb'"policy_change": (\{[^}]*\})', line)
            t = re.search(rb'"turn": (\d+), "unit_', line)
            if not (m and t):
                continue
            pc = json.loads(m.group(1))
            turn = int(t.group(1))
            if (pc.get('made') is False and pc.get('unlock_cost') == 0 and turn <= 160
                    and b'"CIVIC_DRAMA_POETRY"' in line and turn not in turns):
                turns.append(turn)
    if len(turns) > PER_GAME:
        step = len(turns) / PER_GAME
        turns = [turns[int(i * step)] for i in range(PER_GAME)]
    return turns


def cut(run, turn):
    """Rows through the turn's first state row with an open policy window, and that row."""
    rows, last = [], None
    with open(RUNS / run / 'events.jsonl', errors='replace') as f:
        for line in f:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > turn:
                break
            rows.append(line)
            pc = e.get('policy_change') or {}
            if (e.get('kind') == 'state' and e.get('turn') == turn and pc.get('made') is False
                    and pc.get('unlock_cost') == 0):
                last = e
                break
    return ''.join(rows).encode(), last


def policy_orders(row):
    return sorted(f"{o.get('kind')}:{o.get('verb')}" for o in row.get('payload', {}).get('orders', [])
                  if 'polic' in str(o.get('kind', '')))


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data, last = cut(case['run'], case['turn'])
        if last is None:
            raise ValueError('no open-window state row in the turn')
        museums = sum(1 for c in last['cities'] for b in c.get('buildings') or [] if b == 'BUILDING_MUSEUM_ART')
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'],
                                 'cut': "after the turn's first state row with an open policy window"},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                  'board': {'government': last.get('government'), 'policies': last.get('policies'),
                            'policy_slots': last.get('policy_slots'),
                            'literary_tradition_offered': 'POLICY_LITERARY_TRADITION' in (last.get('available_policies') or []),
                            'frescoes_offered': 'POLICY_FRESCOES' in (last.get('available_policies') or []),
                            'art_museums': museums, 'cities': len(last['cities'])},
                  'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', 'culture']
            if header.get('civ'):
                cmd += ['--civ', header['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if GENE + ':' in line]
            row['journal_slotted'] = [line for line in journal if 'Policies/Decision' in line]
            row['policy'] = policy_orders(row)
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['policy_changed'] = off['policy'] != on['policy']
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    cases = [{'run': r, 'civ': c, 'turn': t} for r, c in GAMES for t in windows(r)]
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': cases,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    with ThreadPoolExecutor(JOBS) as pool:
        results = list(pool.map(lambda ic: one(*ic), enumerate(cases)))
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': 0, 'changed_policy_reads': 0, 'on_gene_lines': 0, 'off_gene_lines': 0}
    for r in results:
        c = r['case']
        if r.get('error'):
            print(c['run'], c['turn'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            off, on = v['arms']
            total['changed_order_reads'] += bool(v['orders_changed'])
            total['changed_policy_reads'] += bool(v['policy_changed'])
            total['on_gene_lines'] += len(on['journal_gene'])
            total['off_gene_lines'] += len(off['journal_gene'])
            b = v['board']
            print(f"{c['run'][-16:]} t{c['turn']:<3} {str(b['government'])[11:]:<18} LT {int(b['literary_tradition_offered'])} "
                  f"Fr {int(b['frescoes_offered'])} museums {b['art_museums']} "
                  f"{'CHANGED' if v['orders_changed'] else 'same   '} off {off['policy']} on {on['policy']}")
            for line in on['journal_slotted']:
                if 'literary' in line or 'frescoes' in line:
                    print('      ', line[:200])
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
