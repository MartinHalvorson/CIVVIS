from pathlib import Path
import json,sys,subprocess,hashlib,tarfile,io,datetime,shutil
root=Path(__file__).parent;repo=Path.home()/'civvis-spies-price-the-science-head-5a23'
sys.path.insert(0,str(repo/'tools'))
from civ6_decision_trace import captured_input
from civ6_captured_read_replay import request_reply,expanded_reads
from civ6_ladder import decider_genome
from native_city_route_replay import request_identity_errors,control_payload
sha=lambda b:hashlib.sha256(b).hexdigest()
plan=json.loads((root/'probe-plan.json').read_text());build=json.loads((root/'build-process.json').read_text());binary=root.parent/'candidate/civvis_orders';tag=plan['gene']
assert build['exit']==0 and build['source_unchanged'] and build['source_revision']==plan['source']
assert sha(binary.read_bytes())==build['binary_sha256']
source_blob=subprocess.check_output(['git','archive',plan['source'],'src','data','deploy','Cargo.toml','Cargo.lock','build.rs'],cwd=repo)
with tarfile.open(fileobj=io.BytesIO(source_blob)) as frozen:
 source_hashes={m.name:sha(frozen.extractfile(m).read()) for m in frozen.getmembers() if m.isfile()}
assert source_hashes==build['source_manifest'], 'Frozen source content differs from the build receipt'
runtime=root/'probe-runtime';runtime.mkdir()
blob=subprocess.check_output(['git','archive',plan['source'],'data','deploy'],cwd=repo)
with tarfile.open(fileobj=io.BytesIO(blob)) as archive:archive.extractall(runtime)
cases=[]
for i,case in enumerate(plan['cases']):
 source=Path.home()/'civvis-civ6-runs/control'/case['run'];genome=decider_genome(source/'why.log');assert genome and tag not in genome['treatments']
 rows=[json.loads(l) for l in (source/'decisions.jsonl').open()];r=next(r for r in rows if r['decision']['turn']==case['turn'] and r['decision']['frame']==0)
 capture=r['input_capture'];assert capture['complete'] and capture['reads'];data=captured_input(capture,capture['reads'][-1]['snapshot_id']);p=root/f'input-{i}-{case["turn"]}.jsonl';p.write_bytes(data)
 cases.append({**case,'case':i,'input':str(p),'input_sha256':sha(data),'genome':genome,'original_decision_sha256':r['sha256']})
intent={'source_revision':plan['source'],'binary_sha256':build['binary_sha256'],'harness_sha256':sha(Path(__file__).read_bytes()),'runtime_manifest':{str(p.relative_to(runtime)):sha(p.read_bytes()) for p in runtime.rglob('*') if p.is_file()},'arm_order':plan['arm_order'],'cases':cases,'scope':plan['scope'],'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(root/'probe-intent.json').write_text(json.dumps(intent,indent=2)+'\n');results=[]
for idx,arm in enumerate(plan['arm_order']):
 for case in cases:
  turn=case['turn'];out=root/f'query-{idx}-{case["case"]}-{arm}';out.mkdir();fixed=Path(case['input']).read_bytes();assert sha(fixed)==case['input_sha256'];(out/'events.jsonl').write_bytes(fixed)
  args=[str(binary),'--mirror',str(out),'--serve','--fresh-board','--explain','--resumed','--victory','science','--civ','CIVILIZATION_INDONESIA','--capture-inputs',str(root/'capture-current')]
  for flag in case['genome']['forced']:args+=['--with',flag]
  if arm=='on':args+=['--with',tag]
  with (out/'stderr.log').open('w') as err:
   p=subprocess.Popen(args,cwd=runtime,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1)
   try:
    p.stdin.write(str(turn)+'\n');p.stdin.flush();reply=request_reply(p,120);assert not request_identity_errors(reply,turn,0)
    actual=expanded_reads(reply['input_capture']);assert actual and all(b==fixed for b in actual)
    p.stdin.close();code=p.wait(timeout=15);assert code==0
   finally:
    if p.poll() is None:p.terminate();p.wait(timeout=5)
    p.stdout.close()
  captured_directory=Path(reply['input_capture']['directory']);relative=captured_directory.relative_to(root/'capture-current');archived=out/'recaptured';shutil.move(root/'capture-current',archived)
  effective=decider_genome(out/'stderr.log');assert effective and (tag in effective['treatments'])==(arm=='on')
  result={'capture_directory_map':{str(captured_directory):str(archived/relative)},'round':idx,'arm':arm,'case':case['case'],'run':case['run'],'turn':turn,'argv':args,'exit':code,'genome':effective,'actual_reads':len(actual),'actual_read_sha256':[sha(b) for b in actual],'input_sha256':case['input_sha256'],'binary_sha256':sha(binary.read_bytes()),'payload':reply}
  (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result)
  print(json.dumps({'round':idx,'arm':arm,'case':case['case'],'turn':turn,'reads':len(actual),'production':[o for o in reply['orders'] if o['kind'].startswith('produce')]}),flush=True)
comparisons=[]
for case in cases:
 rs=[r for r in results if r['case']==case['case']];off=[r for r in rs if r['arm']=='off'];on=[r for r in rs if r['arm']=='on']
 for pair in [off,on]:assert control_payload(pair[0]['payload'])==control_payload(pair[1]['payload'])
 a,b=off[0]['genome'],on[0]['genome']
 for field in ['forced','treatments']:assert set(b[field])-{tag}==set(a[field]) and tag not in a[field] and tag in b[field]
 for field in set(a)-{'forced','treatments'}:assert a[field]==b[field]
 comparisons.append({'case':case['case'],'run':case['run'],'turn':case['turn'],'orders_changed':off[0]['payload']['orders']!=on[0]['payload']['orders'],'off_production':[o for o in off[0]['payload']['orders'] if o['kind'].startswith('produce')],'on_production':[o for o in on[0]['payload']['orders'] if o['kind'].startswith('produce')]})
assert source_hashes==build['source_manifest']
assert sha(binary.read_bytes())==build['binary_sha256']
assert all(sha((runtime/p).read_bytes())==h for p,h in intent['runtime_manifest'].items())
(root/'probe-completed.json').write_text(json.dumps({'queries':len(results),'actual_reads':sum(r['actual_reads'] for r in results),'all_actual_reads_equal_fixed_frontier':True,'same_arm_full_payload_repeats':True,'effective_genomes_one_gene_only':True,'comparisons':comparisons,'scope':plan['scope']},indent=2)+'\n');print(json.dumps(comparisons),flush=True)
