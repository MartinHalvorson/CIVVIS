"""Fresh disposable actual-adapter queries at the first observed live activation."""
from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys
BASE=Path('/tmp/civvis-capital-watch-slinger-native-trial-2315')
REPO=Path('/Users/martbot-mbp-m5-max-128/civvis-capital-watch-slinger-native-trial-2315')
sys.path.insert(0,str(REPO/'tools'))
from civ6_decision_trace import captured_input
from civ6_ladder import decider_genome
TAG='capital-watch-arms-the-slinger'
run=Path.home()/'civvis-civ6-runs/control/civvis-20261026T013313Z'
OUT=BASE/'activation-08-queries-01';OUT.mkdir()
original=[json.loads(s) for s in (run/'decisions.jsonl').read_text().splitlines() if s.strip()]
selected=[d for d in original if (d['decision']['turn'],d['decision']['frame'])==(24,1)]
if len(selected)!=1:raise ValueError('actual frame not unique')
actual=selected[0];capture=actual['input_capture'];binary=Path(actual['binary'])
if hashlib.sha256(binary.read_bytes()).hexdigest()!=actual['binary_on_disk_sha256']:raise ValueError('actual adapter changed')
if not capture['complete'] or len(capture['reads'])!=1:raise ValueError('expected one complete distinct input')
data=captured_input(capture,capture['reads'][0]['snapshot_id'])
with (run/'why.log').open() as stream:genome=json.loads(stream.readline())
summary=json.loads((run/'summary.json').read_text());results=[]
for label,on in [('off',False),('on',True),('on-repeat',True)]:
 root=OUT/label;root.mkdir();(root/'events.jsonl').write_bytes(data)
 cmd=[str(binary),'--explain','--mirror',str(root),'--victory','domination','--turn','24']
 for tag in genome['forced']:
  if tag!=TAG:cmd+=['--with',tag]
 for tag in summary.get('withheld',[]):
  if tag!=TAG:cmd+=['--without',tag]
 cmd += ['--with' if on else '--without',TAG]
 with (root/'stdout').open('wb') as out,(root/'stderr').open('wb') as err:
  p=subprocess.run(cmd,stdout=out,stderr=err,timeout=300)
 played=decider_genome(root/'stderr');expected=set(genome['treatments'])-({TAG} if not on else set())
 row={'label':label,'argv':cmd,'exit':p.returncode,'observed_genome':played,'expected_treatments':sorted(expected),'genome_matches':played is not None and set(played['treatments'])==expected}
 if p.returncode==0:row['payload']=json.loads((root/'stdout').read_text())
 row['journal']=[s for s in (root/'stderr').read_text().splitlines() if s.startswith('[why]')]
 results.append(row)
(OUT/'result.json').write_text(json.dumps({'scope':__doc__+' No Native execution or historical-controller replay.','actual_decision':actual,'binary_sha256':actual['binary_on_disk_sha256'],'input_sha256':hashlib.sha256(data).hexdigest(),'input_bytes':len(data),'actual_read_descriptor':capture['reads'][0],'actual_genome':genome,'results':results,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
print(json.dumps({'all_complete':all(r['exit']==0 and r['genome_matches'] for r in results),'off_matches_historical_orders':results[0].get('payload',{}).get('orders')==actual['orders'],'on_matches_historical_orders':results[1].get('payload',{}).get('orders')==actual['orders'],'changed_orders':results[0].get('payload',{}).get('orders')!=results[1].get('payload',{}).get('orders'),'on_repeat_orders_equal':results[1].get('payload',{}).get('orders')==results[2].get('payload',{}).get('orders')},indent=2))
