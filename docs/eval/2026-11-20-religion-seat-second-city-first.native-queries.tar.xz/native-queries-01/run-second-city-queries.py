"""Paired chained decider replays of the opening (turns 3-30) of five live
Religion-lane Lv 8 Deity games (6 players, Small Continents, Online), 2026-11-19/20:
four whose first Settler was displaced (Russia civvis-20261119T195219Z, Arabia
civvis-20261120T003425Z, Mali civvis-20261120T005009Z, Russia
civvis-20261120T015835Z) and one where it was not (Russia
civvis-20261119T235505Z).

`religion-seat-second-city-first` is the only bit that varies. Each arm is ONE
persistent `civvis_orders --serve --fresh-board` process (the live bridge's own
mode, so the opening book and the agent's memory carry from turn to turn as
they did live), built from the branch (profile ci), with that run's own
requested genome (why.log line 1 `forced`, each as `--with`); the on arm adds
`--with religion-seat-second-city-first`. The process is fed turns 1-30; before
each turn its mirror's events.jsonl is replaced by the live log cut after the
FIRST state row of that turn (the board the seat saw at the start of its turn).
Turns 3-30 are recorded.

Read per turn and arm: the produce orders for the capital (the last one is the
head it leaves; with none, the board's own head stays), and the journal lines
of the capital's production. The off arm is checked against what the live seat
had at the head on the next state row.

What this does NOT show. The board each turn is the LIVE board, so once the on
arm's choice differs from what was played, later turns still show the off
history (a Holy Site or Prayers the live seat started, with the Settler's
progress banked): no turn here reflects a Settler the on arm kept the turn
before. Replays never reach the founding, so whether a religion is still
founded is not measured here. Nothing is executed in Civ VI.
"""
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'religion-seat-second-city-first'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CASES = [
    {'run': 'civvis-20261119T195219Z', 'why': 'Russia: Settler t10, Lavra over it t11, second city t33'},
    {'run': 'civvis-20261120T003425Z', 'why': 'Arabia: Settler displaced t8 and t11, second city t35'},
    {'run': 'civvis-20261120T005009Z', 'why': 'Mali: no Settler before t24, first Settler t29, no second city'},
    {'run': 'civvis-20261119T235505Z', 'why': 'Russia (good): Settler t5-t10, second city t13'},
    {'run': 'civvis-20261120T015835Z', 'why': 'Russia: Settler t9, Lavra over it by t11, second city t40, eliminated t73'},
]
LO, HI = 3, 30
TURN_RE = re.compile(r'"turn": (\d+), "unit_maintenance_discount"')


def cuts(run, hi):
    """{turn: (bytes through the first state row of that turn, that row)}."""
    out, rows, states = {}, [], {}
    with open(RUNS / run / 'events.jsonl', errors='replace') as f:
        for line in f:
            if '"kind": "state"' in line:
                m = TURN_RE.search(line)
                t = int(m.group(1)) if m else 0
                if t > hi + 1:
                    break
                rows.append(line)
                states.setdefault(t, []).append(json.loads(line))
                if t not in out and t <= hi:
                    out[t] = (''.join(rows).encode(), states[t][0])
                continue
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > hi + 1:
                break
            rows.append(line)
    return out, states


def head_name(item):
    if not item:
        return None
    (kind, value), = [(k, v) for k, v in item.items() if k != 'pos']
    return f'{kind}:{value}'


def live_head(producing):
    """The host's item name, in the decider's terms where the opening needs it."""
    if not producing:
        return None
    table = {'PROJECT_ENHANCE_DISTRICT_HOLY_SITE': 'project:holy_site_prayers',
             'DISTRICT_LAVRA': 'district:lavra'}
    if producing in table:
        return table[producing]
    kind, _, rest = producing.partition('_')
    return f'{kind.lower()}:{rest.lower()}'


def arm(run, forced, civ, frames, extra):
    workdir = OUT / 'work' / run / ('on' if extra else 'off')
    workdir.mkdir(parents=True)
    events = workdir / 'events.jsonl'
    events.write_bytes(frames[min(frames)][0])
    argv = [str(BINARY), '--mirror', str(workdir), '--serve', '--fresh-board', '--explain',
            '--victory', 'religious', '--civ', civ]
    for tag in forced + extra:
        argv += ['--with', tag]
    why = workdir / 'why.log'
    started = time.monotonic()
    with why.open('wb') as err:
        process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err)
        replies = {}
        for turn in range(1, HI + 1):
            if turn not in frames:
                continue
            tmp = workdir / 'events.jsonl.tmp'
            tmp.write_bytes(frames[turn][0])
            os.replace(tmp, events)
            process.stdin.write(f'{turn}\n'.encode())
            process.stdin.flush()
            replies[turn] = json.loads(process.stdout.readline())
        process.stdin.close()
        code = process.wait(timeout=120)
    lines = why.read_text(errors='replace').splitlines()
    genome = decider_genome(why)
    events.unlink()
    return {'argv': argv, 'exit': code, 'genome': genome, 'replies': replies, 'why': lines,
            'wall_seconds': time.monotonic() - started}


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        summary = json.loads((RUNS / case['run'] / 'summary.json').read_text())
        civ = summary['seat']['civ'].removeprefix('CIVILIZATION_').title()
        frames, states = cuts(case['run'], HI)
        arms = {'off': arm(case['run'], forced, civ, frames, []),
                'on': arm(case['run'], forced, civ, frames, [GENE])}
        for turn in range(LO, HI + 1):
            if turn not in frames:
                continue
            data, state = frames[turn]
            capital = next((c for c in state['cities'] if c.get('capital')), None)
            if capital is None:
                continue
            nxt = states.get(turn + 1, [None])[0]
            nxt_cap = nxt and next((c for c in nxt['cities'] if c.get('id') == capital['id']), None)
            record = {'descriptor': {'run': case['run'], 'turn': turn,
                                     'cut': 'through the first state row of the turn'},
                      'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                      'capital': {k: capital.get(k) for k in ('id', 'name', 'pop', 'producing',
                                                              'production_progress', 'production_cost')},
                      'cities': len(state['cities']),
                      'religions_founded': len(state['founded_religions']),
                      'live_head_next_row': live_head(nxt_cap and nxt_cap.get('producing')),
                      'arms': []}
            for name in ('off', 'on'):
                a = arms[name]
                payload = a['replies'][turn]
                produce = [o for o in (payload.get('decision', {}).get('native_actions') or [])
                           if o.get('type') == 'produce']
                prefix = f'[why] t{turn} '
                journal = [line for line in a['why'] if line.startswith(prefix) and (
                    GENE in line or 'Cities/' in line or 'Faith/Decision' in line
                    or 'Economy/Decision' in line or 'delays its opening' in line)
                    and 'Saved work' not in line]
                head = head_name(produce[-1]['item']) if produce else live_head(capital.get('producing'))
                record['arms'].append({'arm': name, 'argv': a['argv'], 'exit': a['exit'],
                                       'genome': a['genome'], 'payload': payload,
                                       'capital_produce': [o['item'] for o in produce],
                                       'head_left': head, 'journal': journal})
            off, on = record['arms']
            record['orders_changed'] = off['payload'].get('orders') != on['payload'].get('orders')
            record['complete'] = all(x['exit'] == 0 and x['genome'] for x in record['arms'])
            result['reads'].append(record)
        result['wall_seconds'] = {k: v['wall_seconds'] for k, v in arms.items()}
        result['complete'] = bool(result['reads']) and all(r['complete'] for r in result['reads'])
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES, 'turns': [LO, HI],
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    (OUT / 'results-index.json').write_text(json.dumps(
        [{'index': r['index'], 'complete': r.get('complete'), 'error': r.get('error')} for r in results]))
    print(json.dumps({'cases': len(results), 'complete': sum(bool(r.get('complete')) for r in results)}))


if __name__ == '__main__':
    main()
