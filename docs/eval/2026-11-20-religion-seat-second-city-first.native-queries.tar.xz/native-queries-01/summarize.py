"""Summarize the paired chained replays: per game and arm, the head each turn
leaves the capital, the first turn that head is a Settler, the turns the arms
differ, and how often the off arm leaves what the live seat had at the head on
the next state row (the replay's fidelity to the game that was played).

The first turn the arms differ is the clean read: until then both processes
saw the same boards and made the same choices. After it the live board keeps
following the off arm, and the on process also reads the host's item as
foreign production it did not ask for (`release_foreign_production`), so a
later change can come from another writer filling the released queue. Each
changed turn names the on arm's writer from its journal."""
import json
import re
import sys
from pathlib import Path

OUT = Path(sys.argv[1])
GENE = 'religion-seat-second-city-first'


def short(head):
    if not head:
        return '-'
    kind, _, name = head.partition(':')
    return {'district:holy_site': 'HolySite', 'district:lavra': 'Lavra',
            'project:holy_site_prayers': 'Prayers', 'building:shrine': 'Shrine'}.get(head, name.title())


TAG = re.compile(r'\b[a-z]+(?:-[a-z0-9]+){2,}\b')


def on_writer(arm, head):
    """The on arm's production writer this turn, read from its journal."""
    lines = [line for line in arm['journal'] if '| ' in line]
    if any(GENE in line for line in lines):
        return GENE
    if not arm['capital_produce'] and head == 'unit:settler':
        return 'no order: the Settler keeps the head (founds-first waits for it)'
    for line in reversed(lines):
        found = TAG.search(line.split('| ', 1)[1])
        if found:
            return found.group(0)
    return 'unlabelled'


def main():
    games = []
    for result_path in sorted(OUT.glob('[0-9][0-9][0-9][0-9]/result.json')):
        result = json.loads(result_path.read_text())
        rows, first, agree, compared = [], {'off': None, 'on': None}, 0, 0
        for read in result['reads']:
            turn = read['descriptor']['turn']
            heads = {a['arm']: a['head_left'] for a in read['arms']}
            if read['cities'] == 1:
                for arm in ('off', 'on'):
                    if first[arm] is None and heads[arm] == 'unit:settler':
                        first[arm] = turn
            live = read['live_head_next_row']
            if live is not None:
                compared += 1
                agree += heads['off'] == live
            on_arm = next(a for a in read['arms'] if a['arm'] == 'on')
            writer = None
            if heads['off'] != heads['on']:
                writer = on_writer(on_arm, heads['on'])
            rows.append({'turn': turn, 'cities': read['cities'], 'pop': read['capital']['pop'],
                         'board_head': read['capital']['producing'], 'live_next': short(live),
                         'off': short(heads['off']), 'on': short(heads['on']),
                         'orders_changed': read['orders_changed'], 'on_writer': writer,
                         'gene_journal': [line for line in on_arm['journal'] if GENE in line]})
        differs = [r['turn'] for r in rows if r['off'] != r['on']]
        for r in rows:
            r['after_first_divergence'] = bool(differs) and r['turn'] > differs[0]
        games.append({'run': result['case']['run'], 'why': result['case']['why'],
                      'complete': result.get('complete'), 'error': result.get('error'),
                      'first_settler_head_turn': first,
                      'turns_orders_changed': [r['turn'] for r in rows if r['orders_changed']],
                      'turns_head_differs': differs,
                      'first_divergence': next(({'turn': r['turn'], 'off': r['off'], 'on': r['on'],
                                                 'on_writer': r['on_writer']} for r in rows
                                                if r['off'] != r['on']), None),
                      'off_matches_live_next_row': f'{agree}/{compared}',
                      'turns': rows})
    summary = {'gene': GENE, 'games': games}
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    for g in games:
        print(g['run'], g['why'])
        print('  complete', g['complete'], g['error'] or '', '| first Settler head off/on:',
              g['first_settler_head_turn'], '| off = live next row', g['off_matches_live_next_row'])
        print('  first divergence (clean read):', g['first_divergence'])
        print('  head differs on turns', g['turns_head_differs'])
        for r in g['turns']:
            mark = '*' if r['off'] != r['on'] else ' '
            print(f"   t{r['turn']:>2} c{r['cities']} p{r['pop']} board={r['board_head']} live_next={r['live_next']:<9}"
                  f" off={r['off']:<9} on={r['on']:<9}{mark} {r['on_writer'] or ''}")


if __name__ == '__main__':
    main()
