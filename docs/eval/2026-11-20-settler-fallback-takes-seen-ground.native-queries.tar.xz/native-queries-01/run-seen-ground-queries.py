"""Paired one-frame decider replays of live Lv 8 Deity frames (6 players, Small
Continents, Online), 2026-11-19 12:00Z to 11-20, on every turn whose live
journal has `settler-never-idles`' exhaustion fallback name a site ("Settler
takes a site the preferred search refused"), and whose site was later dropped:
"fog" turns, where the Settler's next change of destination dropped it as
water or impassable (a plot the board marked unknown when it was named), and
"control" turns, where it was dropped for any other reason.

`settler-fallback-takes-seen-ground` is the only bit that varies. Each arm is
one `civvis_orders --mirror DIR --explain` process built from the branch
(profile ci), with the run's own requested genome (why.log line 1 `forced`,
each as `--with`), `--victory` and `--civ`; the on arm adds `--with
settler-fallback-takes-seen-ground`. DIR holds the exact events.jsonl bytes the
live decider read for that frame (`decisions.jsonl` `input_capture`, the last
read). One read per turn: its first captured frame.

Read per frame and arm: the orders, the Settler orders among them (units the
frame's last state row lists as UNIT_SETTLER), and the Settler journal lines
of the exhaustion fallback ("takes a site the preferred search refused",
"takes the safest reachable legal site", "takes the nearest legal site",
"takes seen ground before the fog") and "Settler marching to". The off arm's
fallback site is checked against the plots the board had revealed
(`--dump-mirror`).

What this does NOT show. Each replay is a fresh agent on one live board: it
carries none of the live agent's memory (sites set aside, a cached target),
so a frame can name a different site than the live seat did. No frame is
played forward: whether a Settler founds sooner is not measured here. Nothing
is executed in Civ VI.
"""
import concurrent.futures
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
CASES = Path(sys.argv[3])
OUT = Path(sys.argv[4])
JOBS = int(sys.argv[5]) if len(sys.argv) > 5 else 3
GENE = 'settler-fallback-takes-seen-ground'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_decision_trace import captured_input  # noqa: E402
from civ6_ladder import decider_genome  # noqa: E402

LINES = ('Settler takes a site the preferred search refused',
         'Settler takes the safest reachable legal site',
         'Settler takes the nearest legal site',
         'Settler takes seen ground before the fog',
         'Settler skips a doomed',
         'Settler marching to')


def frame_bytes(run, turn, frame):
    for line in open(RUNS / run / 'decisions.jsonl'):
        row = json.loads(line)
        d = row['decision']
        if d.get('turn') == turn and d.get('frame') == frame:
            cap = row['input_capture']
            return captured_input(cap, cap['reads'][-1]['snapshot_id'])
    raise ValueError(f'no captured frame {run} t{turn} f{frame}')


def settler_ids(data):
    last = None
    for line in data.decode(errors='replace').splitlines():
        if '"kind": "state"' in line:
            last = line
    if last is None:
        return set(), None
    state = json.loads(last)
    return ({u['id'] for u in state.get('units') or [] if u.get('kind') == 'UNIT_SETTLER'},
            state.get('turn'))


def revealed_axial(workdir, victory):
    """Axial positions of every plot the board has revealed."""
    p = subprocess.run([str(BINARY), '--mirror', str(workdir), '--dump-mirror', '--victory', victory],
                       capture_output=True, timeout=600)
    rows = p.stdout.decode(errors='replace').splitlines()
    board = json.loads(rows[-1])
    return {(pl['x'] - pl['y'] // 2, pl['y']) for pl in board['plots']}, board['width']


def arm(root, name, data, header, civ, extra):
    workdir = root / name
    workdir.mkdir(parents=True)
    (workdir / 'events.jsonl').write_bytes(data)
    argv = [str(BINARY), '--mirror', str(workdir), '--explain', '--victory', header['victory'], '--civ', civ]
    for tag in header['forced'] + extra:
        argv += ['--with', tag]
    started = time.monotonic()
    p = subprocess.run(argv, capture_output=True, timeout=1200)
    why = workdir / 'why.log'
    why.write_bytes(p.stderr)
    payload = json.loads(p.stdout) if p.returncode == 0 else {}
    lines = [line for line in p.stderr.decode(errors='replace').splitlines()
             if any(k in line for k in LINES)]
    return {'arm': name, 'argv': argv, 'exit': p.returncode, 'genome': decider_genome(why),
            'payload': payload, 'settler_journal': lines,
            'wall_seconds': round(time.monotonic() - started, 2)}


def parse_site(line, headline):
    import re
    m = re.search(re.escape(headline) + r'.*?\((-?\d+), (-?\d+)\)', line)
    return (int(m[1]), int(m[2])) if m else None


def one(case):
    run, turn, frame = case['run'], case['turn'], case['frames'][0]
    root = OUT / 'work' / run / f't{turn:03d}'
    root.mkdir(parents=True, exist_ok=True)
    record = {'descriptor': {'run': run, 'turn': turn, 'frame': frame,
                             'cut': 'the last captured events.jsonl read of the frame'},
              'live': {'fallback_site': case['live_site'],
                       'fallback_site_dropped_as': case['live_site_dropped_as']}}
    try:
        header = json.loads((RUNS / run / 'why.log').open().readline())
        if GENE in header['forced']:
            raise ValueError('the live genome already carried the gene')
        civ = json.loads((RUNS / run / 'summary.json').read_text())['seat']['civ']
        civ = civ.removeprefix('CIVILIZATION_').title()
        data = frame_bytes(run, turn, frame)
        record['bytes'] = len(data)
        record['sha256'] = hashlib.sha256(data).hexdigest()
        settlers, state_turn = settler_ids(data)
        record['state_turn'] = state_turn
        off = arm(root, 'off', data, header, civ, [])
        on = arm(root, 'on', data, header, civ, [GENE])
        revealed, _ = revealed_axial(root / 'off', header['victory'])
        record['arms'] = [off, on]
        for a in record['arms']:
            orders = a['payload'].get('orders') or []
            a['settler_orders'] = [o for o in orders if o.get('subject') in settlers]
            fallback = [parse_site(l, 'Settler takes a site the preferred search refused')
                        for l in a['settler_journal'] if 'preferred search refused' in l]
            a['fallback_sites'] = [list(s) for s in fallback if s]
            a['fallback_sites_unseen'] = [list(s) for s in fallback if s and s not in revealed]
            a['seen_ground_lines'] = [l for l in a['settler_journal'] if 'seen ground before the fog' in l]
            marching = [parse_site(l, 'Settler marching to') for l in a['settler_journal']
                        if 'Settler marching to' in l]
            a['marching_to'] = [list(s) for s in marching if s]
            a['marching_to_unseen'] = [list(s) for s in marching if s and s not in revealed]
        record['orders_changed'] = off['payload'].get('orders') != on['payload'].get('orders')
        record['settler_orders_changed'] = off['settler_orders'] != on['settler_orders']
        record['complete'] = all(a['exit'] == 0 and a['genome'] for a in record['arms'])
    except Exception as exc:  # retained, never hidden
        record.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    for name in ('off', 'on'):
        events = root / name / 'events.jsonl'
        if events.exists():
            events.unlink()
    return record


def main():
    cases = json.loads(CASES.read_text())
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': len(cases),
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    started = time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(JOBS) as pool:
        records = list(pool.map(one, cases))
    by_run = {}
    for r in records:
        by_run.setdefault(r['descriptor']['run'], []).append(r)
    index = []
    for i, (run, reads) in enumerate(sorted(by_run.items())):
        member = OUT / f'{i:04d}'
        member.mkdir()
        result = {'index': i, 'run': run, 'reads': [r for r in reads if r.get('complete')],
                  'failed': [r for r in reads if not r.get('complete')]}
        result['complete'] = bool(result['reads'])
        (member / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=1))
        index.append({'index': i, 'run': run, 'reads': len(result['reads']),
                      'failed': len(result['failed'])})
    (OUT / 'results-index.json').write_text(json.dumps(index, indent=1))
    print(json.dumps({'cases': len(cases), 'complete': sum(bool(r.get('complete')) for r in records),
                      'wall_seconds': round(time.monotonic() - started)}))


if __name__ == '__main__':
    main()
