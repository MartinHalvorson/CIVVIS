"""Summarize the paired seen-ground replays: per group (fog / control turns),
how many frames the off arm's exhaustion fallback named an unseen plot, how
many frames the Settler orders changed, and what the on arm named instead."""
import collections
import json
import re
import sys
from pathlib import Path

OUT = Path(sys.argv[1])
WORTH = re.compile(r'worth (-?[\d.]+) \((-?[\d.]+) after visible threats\)')
TILES = re.compile(r'names \((-?\d+), (-?\d+)\), seen, (\d+) tiles away')
FOG = re.compile(r'the best \((-?\d+), (-?\d+)\) \(worth (-?[\d.]+), (\d+) tiles away\)')
groups = collections.defaultdict(collections.Counter)
examples = []
reads = 0
for result in sorted(OUT.glob('[0-9]*/result.json')):
    record = json.loads(result.read_text())
    for r in record['reads']:
        reads += 1
        group = 'fog' if r['live']['fallback_site_dropped_as'] != 'other' else 'control'
        c = groups[group]
        off, on = r['arms']
        c['frames'] += 1
        c['off fallback named a site'] += bool(off['fallback_sites'])
        c['off fallback named an unseen plot'] += bool(off['fallback_sites_unseen'])
        c['on fallback named an unseen plot'] += bool(on['fallback_sites_unseen'])
        c['off Settler marching to an unseen plot'] += bool(off['marching_to_unseen'])
        c['on Settler marching to an unseen plot'] += bool(on['marching_to_unseen'])
        c['orders changed'] += r['orders_changed']
        c['Settler destination changed'] += off['marching_to'] != on['marching_to']
        c['Settler orders changed'] += r['settler_orders_changed']
        c['on journalled seen ground before the fog'] += bool(on['seen_ground_lines'])
        if r['settler_orders_changed'] and not on['seen_ground_lines']:
            c['Settler orders changed without the gene line'] += 1
        for line in on['seen_ground_lines'][:1]:
            tier = 'ranked tier' if 'the wider ranking' in line else 'legal-site tier'
            c['seen site from the ' + tier] += 1
            w, f, t = WORTH.search(line), FOG.search(line), TILES.search(line)
            ex = {'run': r['descriptor']['run'], 'turn': r['descriptor']['turn'], 'tier': tier,
                  'fog_plot': [int(f[1]), int(f[2])], 'fog_worth': float(f[3]), 'fog_tiles': int(f[4]),
                  'seen_site': [int(t[1]), int(t[2])], 'seen_tiles': int(t[3]),
                  'seen_worth': float(w[1]), 'seen_worth_visible': float(w[2]),
                  'off_marching_to': off['marching_to'], 'on_marching_to': on['marching_to'],
                  'settler_orders_changed': r['settler_orders_changed']}
            examples.append(ex)
summary = {'reads': reads, 'groups': {k: dict(v) for k, v in groups.items()}}
if examples:
    def med(xs):
        xs = sorted(xs)
        return xs[len(xs) // 2]
    summary['passed_over'] = {
        'frames': len(examples),
        'median_fog_worth': med([e['fog_worth'] for e in examples]),
        'median_fog_tiles': med([e['fog_tiles'] for e in examples]),
        'median_seen_worth': med([e['seen_worth'] for e in examples]),
        'median_seen_worth_visible': med([e['seen_worth_visible'] for e in examples]),
        'median_seen_tiles': med([e['seen_tiles'] for e in examples]),
        'seen_tiles_le_fog_tiles': sum(e['seen_tiles'] <= e['fog_tiles'] for e in examples),
    }
summary['examples'] = examples
(OUT / 'summary.json').write_text(json.dumps(summary, indent=1))
print(json.dumps({k: v for k, v in summary.items() if k != 'examples'}, indent=1))
