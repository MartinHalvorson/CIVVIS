"""Candidate live frames for the fires replays: every turn on which the live
exhaustion fallback named a site that the Settler's next change of destination
dropped as water or impassable (a plot unseen when named), plus, as a control,
turns whose fallback site was dropped for any other reason."""
import json, re, glob, os, collections, sys
RUNS = os.path.expanduser('~/civvis-civ6-runs/control')
pick = re.compile(r'^\[why\] t(\d+) Expansion/Detail Settler takes a site the preferred search refused \| nothing passed every filter, so \((-?\d+), (-?\d+)\)')
chg = re.compile(r'^\[why\] t(\d+) Expansion/Detail Settler changes its destination from \((-?\d+), (-?\d+)\) to \((-?\d+), (-?\d+)\) \| settler-keeps-its-named-site: (.*?); the new site')
dirs = sorted(set(glob.glob(RUNS + '/civvis-2026112*') + glob.glob(RUNS + '/civvis-20261119T1[2-9]*') + glob.glob(RUNS + '/civvis-20261119T2*')))
out = []
for d in dirs:
    w = os.path.join(d, 'why.log'); dec = os.path.join(d, 'decisions.jsonl')
    if not (os.path.exists(w) and os.path.exists(dec) and os.path.exists(os.path.join(d, 'summary.json'))):
        continue
    try:
        h = json.loads(open(w).readline())
    except Exception:
        continue
    if h.get('kind') != 'genome' or 'settler-fallback-takes-seen-ground' in h.get('forced', []):
        continue
    last = {}; cases = {}
    for line in open(w, errors='replace'):
        m = pick.match(line)
        if m:
            last[(int(m[2]), int(m[3]))] = int(m[1]); continue
        m = chg.match(line)
        if m:
            old = (int(m[2]), int(m[3]))
            if old in last:
                t = last.pop(old)
                fog = any(k in m[6] for k in ('is water', 'is impassable'))
                cases.setdefault(t, {'turn': t, 'site': list(old), 'fog': fog})
                cases[t]['fog'] = cases[t]['fog'] or fog
    if not cases:
        continue
    frames = collections.defaultdict(list)
    for line in open(dec):
        try:
            r = json.loads(line)
        except ValueError:
            continue
        cap = r.get('input_capture') or {}
        t = r['decision'].get('turn')
        if t in cases and cap.get('complete') and cap.get('reads'):
            frames[t].append(r['decision'].get('frame'))
    for t, c in sorted(cases.items()):
        if frames.get(t):
            out.append({'run': os.path.basename(d), 'turn': t, 'frames': sorted(set(frames[t])),
                        'live_site': c['site'], 'live_site_dropped_as': 'water or impassable' if c['fog'] else 'other'})
json.dump(out, open(sys.argv[1], 'w'), indent=1)
print(len(out), 'turns;', sum(len(c['frames']) for c in out), 'frames;',
      sum(c['live_site_dropped_as'] != 'other' for c in out), 'fog turns;', len({c['run'] for c in out}), 'runs')
