import datetime,hashlib,json,os,pathlib,resource,shutil,subprocess,time
repo=pathlib.Path('/Users/martbot-mbp-m5-max-128/civvis-declarable-racer-priority-5684')
root=pathlib.Path('/tmp/civvis-declarable-racer-priority-5684')
proof=json.loads((root/'final-policy-source.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,want in proof['source_sha256'].items():assert sha(repo/name)==want,name
assert not subprocess.check_output(['git','status','--porcelain','--','src','data','Cargo.toml','Cargo.lock','build.rs'],cwd=repo,text=True)
log=(root/'final-local-ci-tests.log').read_text();assert 'test result: FAILED' not in log
gh=json.loads((root/'1bc-github-rust-step.json').read_text());assert gh['headSha']==proof['source_head'];job=next(j for j in gh['jobs'] if j['name']=='cargo-test');assert all(next(s for s in job['steps'] if s['name']==name)['conclusion']=='success' for name in ['Run Rust tests','Validate Rust documentation examples'])
out=root/'final-build';out.mkdir()
deps=repo/'target/ci/deps';lib=deps/'libcivvis-e26cdcfa7a10e4e6.rlib';frozen=out/lib.name
assert lib.is_file();shutil.copy2(lib,frozen)
base={'source_commit':proof['source_head'],'source_proof_sha256':sha(root/'final-policy-source.json'),'library_sha256':sha(frozen),'library_path':str(frozen),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rustc':subprocess.check_output(['rustc','-vV'],text=True),'fingerprint':json.loads((repo/'target/ci/.fingerprint/civvis-e26cdcfa7a10e4e6/lib-civvis.json').read_text()),'build_script_outputs':{str(p):p.read_text() for p in (repo/'target/ci/build').glob('civvis-*/output')},'local_test_log_sha256_at_link':sha(root/'final-local-ci-tests.log'),'local_full_suite_pending_at_link': 'Doc-tests civvis' not in log,'github_rust_step_receipt_sha256':sha(root/'1bc-github-rust-step.json')}
genome=repo/'docs/eval/2026-10-25-declarable-racer-priority.genome.json'
def build(name,source,dependencies):
 binary=out/name
 command=['rustc','--edition=2021','-C','opt-level=3','-C','debug-assertions=yes','-C','overflow-checks=off','-C','codegen-units=16','-L',f'dependency={deps}','--extern',f'civvis={frozen}']
 for dep in dependencies:
  found=list(deps.glob(f'lib{dep}-*.rlib'));assert len(found)==1,(dep,found)
  command+=['--extern',f'{dep}={found[0]}']
 command+=['--crate-name',name.replace('-','_'),str(source),'-o',str(binary)]
 env=dict(os.environ,CARGO_MANIFEST_DIR=str(repo))
 with (out/f'{name}.build.log').open('wb') as stream: result=subprocess.run(command,cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT)
 meta={**base,'command':command,'environment':{'CARGO_MANIFEST_DIR':str(repo)},'driver_sha256':sha(source),'driver_path':str(source),'genome_sha256':sha(genome),'build_exit_code':result.returncode}
 if result.returncode:
  (out/f'{name}.build.json').write_text(json.dumps(meta,indent=2)+'\n');raise RuntimeError((out/f'{name}.build.log').read_text())
 meta['binary_sha256']=sha(binary);(out/f'{name}.build.json').write_text(json.dumps(meta,indent=2)+'\n')
 print('built',name,meta['binary_sha256'],flush=True)
 return binary,meta
query,qbuild=build('native-query',repo/'docs/eval/2026-10-25-declarable-racer-priority.native-query.rs',['serde_json'])
compare,cbuild=build('compare',repo/'docs/eval/2026-10-25-declarable-racer-priority.compare.rs',['serde_json'])
screen,sbuild=build('gene-screen',repo/'src/bin/gene_screen.rs',['serde','serde_json','libm'])
manifest=root/'mission-inputs/manifest.json';cases=json.loads(manifest.read_text())['cases']
queries=root/'final-native-queries';queries.mkdir();records=[]
ledger={'scope':'fresh controller queries on all 18 frozen observational prefixes; no native execution or persistent replay','build':qbuild,'manifest_sha256':sha(manifest),'records':records,'status':'running','started_at':time.time()}
def save():(queries/'ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
save()
for i,case in enumerate(cases):
 assert case['status']=='prefix_frozen';p=pathlib.Path(case['path']);assert sha(p)==case['input_sha256'] and p.stat().st_size==case['input_bytes']
 for arm in ['off','v1','v2']:
  name=f'{i:02d}-{arm}';command=[str(query),str(manifest),str(genome),str(i),arm]
  rec={'index':i,'tag':case['tag'],'turn':case['turn'],'arm':arm,'command':command,'started_at':time.time()};before=resource.getrusage(resource.RUSAGE_CHILDREN)
  with (queries/f'{name}.json').open('wb') as stdout,(queries/f'{name}.log').open('wb') as stderr:
   try:
    result=subprocess.run(command,cwd=repo,stdout=stdout,stderr=stderr,timeout=120);rec.update(exit_code=result.returncode,status='complete' if result.returncode==0 else 'failed')
   except subprocess.TimeoutExpired:rec.update(exit_code=None,status='timeout')
  after=resource.getrusage(resource.RUSAGE_CHILDREN);rec.update(finished_at=time.time(),user_cpu_seconds=after.ru_utime-before.ru_utime,system_cpu_seconds=after.ru_stime-before.ru_stime,output_sha256=sha(queries/f'{name}.json'),stderr_sha256=sha(queries/f'{name}.log'))
  if rec['status']=='complete':
   data=json.loads((queries/f'{name}.json').read_text());rec.update(plan=data['plan'],interception_counters={k:v for k,v in data['counters'].items() if 'elimination-yields-to-a-launch-2:' in k})
  records.append(rec);save();print(json.dumps({k:rec[k] for k in ['index','turn','arm','status']}),flush=True)
ledger.update(status='complete',finished_at=time.time());save()
print('All fixed queries retained.',flush=True)
