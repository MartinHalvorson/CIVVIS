import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path.cwd()
EVIDENCE = Path("/tmp/civvis-airfield-slot-memo-cc3b")
STATE = EVIDENCE / "hoisted-validation.json"
SOURCE_PATHS = ["src", "data", "Cargo.toml", "Cargo.lock", "build.rs", ".cargo"]


def output(command):
    return subprocess.check_output(command, cwd=ROOT, text=True).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_tree():
    raw = subprocess.check_output(["git", "ls-tree", "-r", "HEAD", "--", *SOURCE_PATHS], cwd=ROOT)
    return hashlib.sha256(raw).hexdigest()


manifest = json.loads(STATE.read_text())
assert manifest["status"] == "failed" and manifest["error"] == "AssertionError()"
assert [(r["stage"], r["exit_code"]) for r in manifest["stages"]] == [("check", 0), ("library", 0)]
manifest.setdefault("instrument_events", []).append({
    "at": time.time(), "reason": "both cargo-check and cargo-build library fingerprints exist; select the build fingerprint by its compiled rlib suffix",
    "prior_state": str(EVIDENCE / "hoisted-validation-initial.json"),
    "repeated_cargo_stages": []})
manifest.pop("error")
manifest["status"] = "running"



def save():
    temp = STATE.with_suffix(".json.tmp")
    temp.write_text(json.dumps(manifest, indent=2) + "\n")
    os.replace(temp, STATE)


def unchanged():
    assert source_tree() == manifest["source_tree_sha256"]
    assert not output(["git", "status", "--porcelain", "--untracked-files=all", "--", *SOURCE_PATHS])


save()
try:
    unchanged()
    deps = ROOT / "target/ci/deps"
    libs = list(deps.glob("libcivvis-*.rlib"))
    assert len(libs) == 1
    suffix = libs[0].stem.split("-", 1)[1]
    fp = ROOT / "target/ci/.fingerprint" / ("civvis-" + suffix) / "lib-civvis.json"
    fingerprint = json.loads(fp.read_text())
    parent_fps = list((EVIDENCE / "parent-source/target/ci/.fingerprint").glob("civvis-*/lib-civvis.json"))
    assert len(parent_fps) == 1
    parent_fp = json.loads(parent_fps[0].read_text())
    for key in ("rustc", "features", "profile", "target", "rustflags"):
        assert fingerprint[key] == parent_fp[key], key
    frozen_dir = EVIDENCE / ("hoisted-library-" + manifest["source_commit"][:12])
    frozen_dir.mkdir(exist_ok=False)
    frozen = frozen_dir / libs[0].name
    shutil.copy2(libs[0], frozen)
    info = {"source_commit": manifest["source_commit"],
            "source_tree_sha256": manifest["source_tree_sha256"],
            "library_path": str(frozen), "library_sha256": sha(frozen),
            "fingerprint": fingerprint, "fingerprint_path": str(fp),
            "rustc": output(["rustc", "-Vv"]), "command": manifest["stages"][1]["command"]}
    (frozen_dir / "build.json").write_text(json.dumps(info, indent=2) + "\n")
    with (EVIDENCE / "hoisted-library-build.json").open("x") as handle:
        json.dump(info, handle, indent=2)
        handle.write("\n")
    manifest["instrument_events"][-1]["selected_fingerprint"] = str(fp)
    save()
    stages = [
        ("orders", ["cargo", "build", "--profile", "ci", "--locked", "--bin", "civvis_orders"]),
        ("focused", ["cargo", "test", "--profile", "ci", "--locked", "ai::advanced::air_surge"]),
        ("full", ["cargo", "test", "--profile", "ci", "--locked"]),
    ]
    for name, command in stages:
        unchanged()
        log_path = EVIDENCE / f"hoisted-{name}.log"
        env = os.environ.copy()
        if name == "full":
            env["RUST_TEST_THREADS"] = "1"
        record = {"stage": name, "command": command, "log": str(log_path),
                  "started_at": time.time(), "environment_override":
                  {"RUST_TEST_THREADS": "1"} if name == "full" else {}}
        manifest["stages"].append(record)
        with log_path.open("xb") as log:
            process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log,
                                       stderr=subprocess.STDOUT)
            record["pid"] = process.pid
            save()
            record["exit_code"] = process.wait()
        record.update(finished_at=time.time(), log_sha256=sha(log_path))
        save()
        print(name, record["exit_code"], flush=True)
        if record["exit_code"]:
            raise RuntimeError(f"{name} failed; keep the complete raw log")
        unchanged()
        if name == "library":
            deps = ROOT / "target/ci/deps"
            libs = list(deps.glob("libcivvis-*.rlib"))
            fps = list((ROOT / "target/ci/.fingerprint").glob("civvis-*/lib-civvis.json"))
            assert len(libs) == len(fps) == 1
            frozen_dir = EVIDENCE / ("hoisted-library-" + manifest["source_commit"][:12])
            frozen_dir.mkdir(exist_ok=False)
            frozen = frozen_dir / libs[0].name
            shutil.copy2(libs[0], frozen)
            info = {"source_commit": manifest["source_commit"],
                    "source_tree_sha256": manifest["source_tree_sha256"],
                    "library_path": str(frozen), "library_sha256": sha(frozen),
                    "fingerprint": json.loads(fps[0].read_text()),
                    "rustc": output(["rustc", "-Vv"]), "command": command}
            (frozen_dir / "build.json").write_text(json.dumps(info, indent=2) + "\n")
            pointer = EVIDENCE / "hoisted-library-build.json"
            with pointer.open("x") as handle:
                json.dump(info, handle, indent=2)
                handle.write("\n")
        if name == "orders":
            binary = ROOT / "target/ci/civvis_orders"
            fps = list((ROOT / "target/ci/.fingerprint").glob("civvis-*/bin-civvis_orders.json"))
            assert len(fps) == 1
            frozen_dir = EVIDENCE / "hoisted-bin"
            frozen_dir.mkdir(exist_ok=False)
            frozen = frozen_dir / binary.name
            shutil.copy2(binary, frozen)
            fp_dir = frozen_dir / ".fingerprint/civvis-hoisted"
            fp_dir.mkdir(parents=True)
            shutil.copy2(fps[0], fp_dir / "bin-civvis_orders.json")
            info = {"source_commit": manifest["source_commit"], "path": str(frozen),
                    "sha256": sha(frozen), "fingerprint": json.loads(fps[0].read_text())}
            (EVIDENCE / "hoisted-orders-build.json").write_text(json.dumps(info, indent=2) + "\n")
    manifest["status"] = "complete"
    save()
except Exception as error:
    manifest.update(status="failed", error=repr(error))
    save()
    raise
