"""Paired decider queries on the captured live inputs of two live Deity games of 2026-11-18.

`four-faces-bars-the-surprise` is the only bit that varies. Each case is the turn-start decision of
one turn of one run: the exact bytes of `events.jsonl` the live decider had read when it answered,
taken from the run's own input capture (`decisions.jsonl` names the snapshot,
`input-captures/*/reads/snapshots.jsonl` its length; the capture's `bytes.bin` prefix is checked
against the log). The frame is queried with `--turn T --resumed` (the live seat's past-turn-one
agent) on one `civvis_orders` built from the PR branch. Both arms carry the run's own requested
genome (every tag the live brain passed as `--with`, from `brain.log`), victory lane and
civilization; the on arm adds the gene. The off arm is the live seat's genome on its own input; the
on arm is the gene's proposal on the same bytes.

Runs: civvis-20261118T045850Z (we are Kongo, Canada is the neighbour) and civvis-20261118T051842Z
(we are Canada). No war was declared in either game and no major denounced the seat.

This records proposal activation on captured live input only. It does not execute in Civ VI and
makes no strength claim. A one-frame query starts with no memory of earlier turns: the capital and
frontier watches read only the soldiers in sight on that frame, where the live agent remembered
sightings for ten turns, so the off arm arms those watches on fewer frames than the live game did.
`surprise_lines` counts, per arm, the journal lines of the peacetime surprise readers.
"""
import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
SPANS = [(Path(a), int(b), int(c)) for a, b, c in (s.rsplit(':', 2) for s in sys.argv[4:])]  # RUNDIR:FIRST:LAST
GENE = 'four-faces-bars-the-surprise'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

PRODUCE = ('produce', 'produce_next', 'purchase')
READERS = ('near-rival-deterrence', 'near-rival-deterrence-opens-early', 'near-rival-deterrence-holds-late',
           'capital-archers-before-the-surprise', 'capital-walls-before-the-surprise',
           'frontier-walls-before-the-surprise', 'garrison-before-the-surprise',
           'surprise-watch-holds-its-ratio', 'capital-walls-at-any-ratio', 'capital-watch-arms-the-slinger',
           'capital-keeps-its-defender-3')
TAGGED = re.compile(r'\| ([a-z0-9-]+): ')


def live_setup(run):
    brain = (run / 'brain.log').read_text()
    head = brain[:brain.index('\n')]
    forced = re.findall(r"'([^']+)'", head[head.index('forced=['):head.index('] withheld=')])
    assert 'withheld=none' in head, 'the live arm withheld something'
    civ = re.search(r'civ=(CIVILIZATION_\w+)', brain).group(1)
    genome = json.loads((run / 'why.log').open().readline())
    return forced, civ, genome


def decisions(run, first, last):
    captures = sorted((run / 'input-captures').glob('*/reads'))
    assert len(captures) == 1, 'one decider process, one capture'
    lengths = {}
    for line in (captures[0] / 'snapshots.jsonl').open():
        row = json.loads(line)
        lengths[row['id']] = row['total_bytes']
    rows, skipped = [], []
    for line in (run / 'decisions.jsonl').open():
        row = json.loads(line)
        turn, frame = row['decision']['turn'], row['decision']['frame']
        if frame != 0 or not first <= turn <= last:
            continue
        capture = row['input_capture']
        assert capture['complete']
        if len(capture['reads']) != 1:
            # The live decider read the growing log at more than one length, so no
            # single prefix is its input. Left out, and listed in the registration.
            skipped.append([turn, frame, [lengths[r['snapshot_id']] for r in capture['reads']]])
            continue
        rows.append({'turn': turn, 'frame': frame, 'bytes': lengths[capture['reads'][0]['snapshot_id']],
                     'live_orders': row['orders']})
    return captures[0] / 'bytes.bin', rows, skipped


def production(orders):
    return sorted((o['kind'], o['subject'], o['verb']) for o in orders if o['kind'] in PRODUCE)


def research(orders):
    return sorted((o['kind'], o['verb']) for o in orders if o['kind'] in ('research', 'civic'))


def board(data):
    at = data.rindex(b'"kind": "state"')
    line = data[data.rindex(b'\n', 0, at) + 1:data.index(b'\n', at)]
    state = json.loads(line)
    cities = {c['id']: c['name'] for c in state['cities']}
    return {'turn': state['turn'], 'frame': state.get('frame', 0), 'gold': state['gold'],
            'gold_per_turn': state['gold_per_turn'], 'cities': len(cities),
            'military_power': state.get('military'), 'units': len(state['units']),
            'rivals': {r['civ']: {'military': r.get('military'), 'at_war': r.get('at_war'),
                                  'their_denounce_turn': r.get('their_denounce_turn'),
                                  'our_denounce_turn': r.get('our_denounce_turn')}
                       for r in state['rivals']}}, cities


def surprise_lines(journal):
    counts = collections.Counter()
    for line in journal:
        tag = TAGGED.search(line)
        if tag and tag.group(1) in READERS:
            counts[tag.group(1)] += 1
    return dict(sorted(counts.items()))


def one(index, run, case, log, captured, forced, civ, victory):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    descriptor = {'run': run.name, 'turn': case['turn'], 'frame': case['frame'],
                  'cut': 'events.jsonl prefix the live decider had read (input capture)'}
    result = {'index': index, 'case': {'run': run.name, 'turn': case['turn'], 'frame': case['frame']}, 'reads': []}
    try:
        data = log[:case['bytes']]
        if captured[:case['bytes']] != data:
            raise ValueError('the capture and the log disagree on this prefix')
        seat, cities = board(data)
        if (seat['turn'], seat['frame']) != (case['turn'], case['frame']):
            raise ValueError(f'the newest board is {seat["turn"]}/{seat["frame"]}')
        record = {'descriptor': descriptor, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                  'board': seat, 'seat_civ': civ, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', victory, '--civ', civ]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': round(time.monotonic() - started, 2), 'genome': decider_genome(stderr)}
            if process.returncode == 0:
                payload = json.loads(stdout.read_text())
                row['payload'] = {'turn': payload.get('turn'), 'orders': payload['orders']}
            why = [line for line in stderr.read_text().splitlines() if line.startswith('[why]')]
            row['surprise_lines'] = surprise_lines(why)
            row['journal'] = [line for line in why if (TAGGED.search(line) or [None, ''])[1] in READERS]
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            mirror.rmdir()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        if record['complete']:
            a, b = off['payload']['orders'], on['payload']['orders']
            record['orders_changed'] = a != b
            pa, pb = production(a), production(b)
            name = lambda o: [o[0], cities.get(o[1], str(o[1])), o[2]]  # noqa: E731
            record['production_off_only'] = [name(o) for o in pa if o not in pb]
            record['production_on_only'] = [name(o) for o in pb if o not in pa]
            record['research_off_only'] = [list(o) for o in research(a) if o not in research(b)]
            record['research_on_only'] = [list(o) for o in research(b) if o not in research(a)]
            record['live_production_match'] = pa == production(case['live_orders'])
            kinds = lambda orders: collections.Counter(o['kind'] for o in orders)  # noqa: E731
            record['order_kinds_changed'] = sorted(
                k for k in set(kinds(a)) | set(kinds(b))
                if [o for o in a if o['kind'] == k] != [o for o in b if o['kind'] == k])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=1))
    return result


def main():
    OUT.mkdir(parents=True)
    registration = {'scope': __doc__, 'gene': GENE, 'runs': [],
                    'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
                    'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    results, index = [], 0
    by_run = {}
    for run, first, last in SPANS:
        forced, civ, genome = live_setup(run)
        if GENE in forced or GENE in genome.get('treatments', []):
            raise SystemExit('the live genome already carried the gene')
        capture, cases, skipped = decisions(run, first, last)
        registration['runs'].append({'run': run.name, 'turns': [first, last], 'civ': civ,
                                     'victory': genome['victory'], 'live_forced': len(forced),
                                     'cases': [[c['turn'], c['frame'], c['bytes']] for c in cases],
                                     'skipped_read_at_two_lengths': skipped})
        longest = max(c['bytes'] for c in cases)
        with (run / 'events.jsonl').open('rb') as f:
            log = f.read(longest)
        with capture.open('rb') as f:
            captured = f.read(longest)
        live = set(genome['treatments'])
        for case in cases:
            r = one(index, run, case, log, captured, forced, civ, genome['victory'])
            r['_live'] = live
            results.append(r)
            by_run.setdefault(run.name, []).append(r)
            index += 1
    (OUT / 'registration.json').write_text(json.dumps(registration, indent=1))
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results), 'runs': {}}
    for name, rs in by_run.items():
        reads = [v for r in rs for v in r['reads'] if v.get('complete')]
        live = rs[0]['_live']
        lines = {arm: collections.Counter() for arm in ('off', 'on')}
        frames = {arm: collections.Counter() for arm in ('off', 'on')}
        for v in reads:
            for i, arm in enumerate(('off', 'on')):
                for tag, n in v['arms'][i]['surprise_lines'].items():
                    lines[arm][tag] += n
                    frames[arm][tag] += 1
        replaced = collections.Counter()
        for v in reads:
            for _, _, verb in v['production_on_only']:
                replaced[verb] += 1
        summary['runs'][name] = {
            'cases': len(rs), 'complete_cases': len(reads),
            'changed_order_reads': sum(v['orders_changed'] for v in reads),
            'changed_turns': [v['board']['turn'] for v in reads if v['orders_changed']],
            'off_genome_is_the_live_genome': all(set(v['arms'][0]['genome']['treatments']) == live for v in reads),
            'off_production_matches_live': sum(v['live_production_match'] for v in reads),
            'surprise_reader_lines': {arm: dict(sorted(lines[arm].items())) for arm in ('off', 'on')},
            'surprise_reader_frames': {arm: dict(sorted(frames[arm].items())) for arm in ('off', 'on')},
            'production_changed_frames': sum(bool(v['production_off_only'] or v['production_on_only']) for v in reads),
            'research_changed_frames': sum(bool(v['research_off_only'] or v['research_on_only']) for v in reads),
            'on_arm_production_in_place': dict(replaced.most_common()),
        }
    for r in results:
        r.pop('_live', None)
        if r.get('error'):
            print(r['case'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            b = v['board']
            print(r['case']['run'][7:22], 't%d' % b['turn'], 'CHG ' if v['orders_changed'] else 'same',
                  'live=' + ('y' if v['live_production_match'] else 'n'),
                  '| off', v['arms'][0]['surprise_lines'], '| on', v['arms'][1]['surprise_lines'],
                  '| prod off', [o[1] + ':' + o[2] for o in v['production_off_only']],
                  'on', [o[1] + ':' + o[2] for o in v['production_on_only']],
                  '| research off', v['research_off_only'], 'on', v['research_on_only'],
                  '| kinds', v['order_kinds_changed'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=1))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
