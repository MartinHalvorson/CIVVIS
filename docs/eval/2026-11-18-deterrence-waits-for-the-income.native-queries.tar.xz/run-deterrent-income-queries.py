"""Paired decider queries on the captured live inputs of Deity Kongo civvis-20261118T045850Z.

`deterrence-waits-for-the-income` is the only bit that varies. Each case is one live decision of
the run (a turn and a replan frame): the exact bytes of `events.jsonl` the live decider had read
when it answered, taken from the run's own input capture (`decisions.jsonl` names the snapshot,
`input-captures/*/reads/snapshots.jsonl` its length; the capture's `bytes.bin` prefix is checked
against the log). The frame is queried with `--turn T --resumed` (the live seat's past-turn-one
agent) on one `civvis_orders` built from the PR branch. Both arms carry the run's own requested
genome (every tag the live brain passed as `--with`, from `brain.log`), victory lane and
civilization; the on arm adds the gene. The off arm is the live seat's genome on its own input; the
on arm is the gene's proposal on the same bytes.

This records proposal activation on captured live input only. It does not execute in Civ VI and
makes no strength claim. A one-frame query starts with no memory of earlier turns, so an off arm
can differ from the live answer where the live agent remembered something; `live_production_match`
records, per case, whether the off arm's production orders equal the ones the live decider sent, and
`live_deterrent_match` whether the deterrent the off arm trains (city and unit) is one the live
journal (`why.log`) trained on that turn.
"""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
RUN = Path(sys.argv[4])  # a copy of the live run directory
FIRST, LAST = int(sys.argv[5]), int(sys.argv[6])
GENE = 'deterrence-waits-for-the-income'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

PRODUCE = ('produce', 'produce_next', 'purchase')
SOLDIERS = ('UNIT_WARRIOR', 'UNIT_ARCHER', 'UNIT_SLINGER', 'UNIT_SPEARMAN', 'UNIT_HORSEMAN',
            'UNIT_HEAVY_CHARIOT', 'UNIT_SWORDSMAN', 'UNIT_KONGO_SHIELD_BEARER')


def live_setup():
    brain = (RUN / 'brain.log').read_text()
    head = brain[:brain.index('\n')]
    forced = re.findall(r"'([^']+)'", head[head.index('forced=['):head.index('] withheld=')])
    assert 'withheld=none' in head, 'the live arm withheld something'
    civ = re.search(r'civ=(CIVILIZATION_\w+)', brain).group(1)
    live_deterrents = {}
    with (RUN / 'why.log').open() as why:
        genome = json.loads(why.readline())
        for line in why:
            found = DETERRENT.search(line)
            if found:
                live_deterrents.setdefault(int(found.group(1)), set()).add(found.group(2, 3))
    return forced, civ, genome, live_deterrents


DETERRENT = re.compile(r't(\d+) Military/Decision (.+?) trains a deterrent against \w+ \| [\w-]+: ([\w ]+?) for ')


def decisions():
    captures = sorted((RUN / 'input-captures').glob('*/reads'))
    assert len(captures) == 1, 'one decider process, one capture'
    lengths = {}
    for line in (captures[0] / 'snapshots.jsonl').open():
        row = json.loads(line)
        lengths[row['id']] = row['total_bytes']
    rows = []
    for line in (RUN / 'decisions.jsonl').open():
        row = json.loads(line)
        turn, frame = row['decision']['turn'], row['decision']['frame']
        if not FIRST <= turn <= LAST:
            continue
        capture = row['input_capture']
        assert capture['complete'] and len(capture['reads']) == 1
        rows.append({'turn': turn, 'frame': frame, 'bytes': lengths[capture['reads'][0]['snapshot_id']],
                     'live_orders': row['orders']})
    return captures[0] / 'bytes.bin', rows


def production(orders):
    return sorted((o['kind'], o['subject'], o['verb']) for o in orders if o['kind'] in PRODUCE)


def board(data):
    """The newest state line of the input: what the seat held when it decided."""
    at = data.rindex(b'"kind": "state"')
    line = data[data.rindex(b'\n', 0, at) + 1:data.index(b'\n', at)]
    state = json.loads(line)
    cities = {c['id']: c['name'] for c in state['cities']}
    return {'turn': state['turn'], 'frame': state.get('frame', 0), 'gold': state['gold'],
            'gold_per_turn': state['gold_per_turn'], 'unit_maintenance': state['unit_maintenance_total'],
            'cities': len(cities), 'military_power': state.get('military'),
            'units': len(state['units'])}, cities


def one(index, case, log, captured, forced, civ, victory, live_deterrents):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    descriptor = {'run': RUN.name, 'turn': case['turn'], 'frame': case['frame'],
                  'cut': 'events.jsonl prefix the live decider had read (input capture)'}
    result = {'index': index, 'case': {'turn': case['turn'], 'frame': case['frame']}, 'reads': []}
    try:
        data = log[:case['bytes']]
        if captured[:case['bytes']] != data:
            raise ValueError('the capture and the log disagree on this prefix')
        seat, cities = board(data)
        if (seat['turn'], seat['frame']) != (case['turn'], case['frame']):
            raise ValueError(f'the newest board is {seat["turn"]}/{seat["frame"]}')
        record = {'descriptor': descriptor, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                  'board': seat, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', victory, '--civ', civ]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': round(time.monotonic() - started, 2), 'genome': decider_genome(stderr)}
            if process.returncode == 0:
                payload = json.loads(stdout.read_text())
                row['payload'] = {'turn': payload.get('turn'), 'orders': payload['orders']}
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]') and (
                                  'deterren' in line or 'first Campus' in line or 'Campus' in line
                                  or 'bankruptcy' in line or '/Decision' in line and ' starts ' in line)]
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            mirror.rmdir()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        if record['complete']:
            a, b = off['payload']['orders'], on['payload']['orders']
            record['orders_changed'] = a != b
            pa, pb = production(a), production(b)
            name = lambda o: [o[0], cities.get(o[1], str(o[1])), o[2]]  # noqa: E731
            record['production_off_only'] = [name(o) for o in pa if o not in pb]
            record['production_on_only'] = [name(o) for o in pb if o not in pa]
            record['live_production_match'] = pa == production(case['live_orders'])
            record['deterrent_trained'] = {
                arm['arm']: [l.split('] ', 1)[1] for l in arm['journal'] if 'trains a deterrent' in l]
                for arm in (off, on)}
            trained = {DETERRENT.search(l).group(2, 3) for l in record['deterrent_trained']['off']}
            record['live_deterrent_match'] = trained <= live_deterrents.get(case['turn'], set())
            record['gene_journal'] = [l.split('] ', 1)[1] for l in on['journal'] if GENE + ':' in l]
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=1))
    return result


def main():
    forced, civ, genome, live_deterrents = live_setup()
    if GENE in forced or GENE in genome.get('treatments', []):
        raise SystemExit('the live genome already carried the gene')
    capture, cases = decisions()
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'run': RUN.name, 'turns': [FIRST, LAST],
        'cases': [[c['turn'], c['frame'], c['bytes']] for c in cases],
        'live_forced': len(forced), 'civ': civ, 'victory': genome['victory'],
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=1))
    longest = max(c['bytes'] for c in cases)
    with (RUN / 'events.jsonl').open('rb') as f:
        log = f.read(longest)
    with capture.open('rb') as f:
        captured = f.read(longest)
    results = [one(i, c, log, captured, forced, civ, genome['victory'], live_deterrents)
               for i, c in enumerate(cases)]
    reads = [v for r in results for v in r['reads'] if v.get('complete')]
    live = set(genome['treatments'])
    summary = {
        'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
        'changed_order_reads': sum(v['orders_changed'] for v in reads),
        'off_genome_is_the_live_genome': all(
            set(v['arms'][0]['genome']['treatments']) == live for v in reads),
        'off_production_matches_live': sum(v['live_production_match'] for v in reads),
        'first_frames': sum(v['board']['frame'] == 0 for v in reads),
        'first_frames_off_production_matches_live': sum(
            v['live_production_match'] for v in reads if v['board']['frame'] == 0),
        'off_deterrent_frames_matching_the_live_journal': sum(
            v['live_deterrent_match'] for v in reads if v['deterrent_trained']['off']),
        'frames_at_negative_income': sum(v['board']['gold_per_turn'] < 0 for v in reads),
        'deterrent_frames_at_negative_income': {
            arm: sum(bool(v['deterrent_trained'][arm]) for v in reads if v['board']['gold_per_turn'] < 0)
            for arm in ('off', 'on')},
        'deterrent_decisions': {arm: sum(len(v['deterrent_trained'][arm]) for v in reads)
                                for arm in ('off', 'on')},
        'frames_with_a_deterrent': {arm: sum(bool(v['deterrent_trained'][arm]) for v in reads)
                                    for arm in ('off', 'on')},
        'gene_journal_frames': sum(bool(v['gene_journal']) for v in reads),
    }
    for r in results:
        if r.get('error'):
            print(r['case'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            b = v['board']
            print('t%d/%d' % (b['turn'], b['frame']), 'gold %3.0f %+5.1f bill %2.0f' % (
                b['gold'], b['gold_per_turn'], b['unit_maintenance']),
                'CHG ' if v['orders_changed'] else 'same', 'live=' + ('y' if v['live_production_match'] else 'n'),
                '| off', [o[1] + ':' + o[2] for o in v['production_off_only']],
                '| on', [o[1] + ':' + o[2] for o in v['production_on_only']])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=1))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
