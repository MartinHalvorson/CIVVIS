"""Compare host orders until their first divergence on a qualified native prefix.

The variants allow decision metadata to differ, while preserving frame identity
and every ordered input-read byte. They stop before replaying a changed world.
"""
from pathlib import Path
import hashlib,json,sys,datetime
repo=Path('/Users/martbot-mbp-m5-max-128/civvis-main-managed')
sys.path.insert(0,str(repo/'tools'))
import civ6_captured_read_replay as replay
from civ6_ladder import decider_genome
root=Path('/Users/martbot-mbp-m5-max-128/civvis-runs/2026-11-02-native-process-context/civvis-20261102T232731Z')
q=root/'qualify-60';proof=json.loads((q/'qualification.json').read_text());assert proof['passed'] and len(proof['controls'])==2
assert all(c['passed'] for c in proof['controls']) and proof['through_turn']==60
raw=(q/'native-decisions.jsonl').read_bytes();assert replay.sha(raw)==proof['native_decisions_sha256'];records=[json.loads(x) for x in raw.splitlines()];by_key={tuple(replay.frame_key(r)):r for r in records}
context=json.loads((root/'observed-context.json').read_text());base=context['processes'][0]['argv'];new=Path(base[0]);old=Path('/Users/martbot-mbp-m5-max-128/civvis-civ6-runs/decider-snapshots/civvis-20261102T225146Z/civvis_orders')
assert replay.sha(new.read_bytes())==context['binary_sha256']=='3a26064884da5f21285c279a3e8105b05fa99c6e880376f6849c24fb99514d6d'
assert replay.sha(old.read_bytes())=='b9d62c14b78aedb46d5d8461b1392e2c19b6b3d371c0c4650310187414cba205'
flag='religion-lane-hands-over';index=base.index(flag);assert base[index-1]=='--with' and base.count(flag)==1
out=root/'order-counterfactual';out.mkdir(exist_ok=False)
(out/'intent.json').write_bytes((root/'order-counterfactual-intent.json').read_bytes())
mapping={r['source']:Path(r['sealed_directory']) for r in proof['sealed_captures']}
source_genome=decider_genome(q/'control-0/stderr.log');assert source_genome and flag in source_genome['treatments']
# This changes ONLY the compared payload for these counterfactual runs. The
# original full-payload qualifications above stay separate and unmodified;
# run_control still enforces exact frame identities and ordered read bytes.
replay.control_payload=lambda record: {'orders':record['orders']}
results=[]
for label,binary,enabled in [('original-on-orders-control',new,True),('old-on-0',old,True),('old-on-1',old,True),('new-off',new,False)]:
 command=base.copy();command[0]=str(binary)
 if not enabled:del command[index-1:index+1]
 digest=replay.sha(binary.read_bytes());variant={'binary_sha256':digest,'provenance':{'sha256':digest,'source':'shadow variant, not a second observed host process'},'processes':[{'argv':command,'cwd':context['processes'][0]['cwd']}]}
 r=replay.run_control(variant,records,mapping,out/label,60)
 for request in r['requests']:request['orders_match']=request.pop('native_payload_matches')
 r['all_orders_match_through_endpoint']=r.pop('passed');summary={'variant':label,'all_orders_match_through_endpoint':r['all_orders_match_through_endpoint'],'requests':len(r['requests']),'stopped_request':r.get('failed_request'),'driver_error':r.get('error'),'comparison_scope':'Host orders only; non-actuation decision metadata may differ.'}
 g=decider_genome(out/label/'stderr.log');expected=sorted(t for t in source_genome['treatments'] if enabled or t!=flag);profile_matches=bool(g) and sorted(g['treatments'])==expected
 summary['realized_profile_matches']=profile_matches
 comparisons=r['requests'];valid_reads=all(not c['identity_errors'] and c['read_sequence_matches'] for c in comparisons)
 expected_stop=bool(r.get('failed_request') and comparisons and not comparisons[-1]['orders_match'] and all(c['orders_match'] for c in comparisons[:-1]) and valid_reads and (r.get('error') or '').startswith('ValueError: original-binary control differs'))
 summary['stopped_at_first_different_order']=expected_stop
 summary['valid_order_prefix_comparison']=profile_matches and valid_reads and (r['all_orders_match_through_endpoint'] or expected_stop)
 if expected_stop:
  key=tuple(r['failed_request']);native=by_key[key];reply=json.loads((out/label/'replies.jsonl').read_bytes().splitlines()[-1]);summary.update({'observed_primary':native['decision']['victory_portfolio']['primary'],'variant_primary':reply['decision']['victory_portfolio']['primary'],'observed_orders':native['orders'],'variant_orders':reply['orders']})
 results.append({'summary':summary,'driver_result':r,'realized_genome':g})
 report={'scope':'Qualified captured-world first action divergence, not full-payload equality of variants, native counterfactual execution, saved yields or a strength estimate.','native_full_payload_qualification_sha256':replay.sha((q/'qualification.json').read_bytes()),'native_decisions_sha256':proof['native_decisions_sha256'],'original_context_sha256':replay.sha((root/'observed-context.json').read_bytes()),'comparison_driver_source_sha256':replay.sha((repo/'tools/civ6_captured_read_replay.py').read_bytes()),'results':results,'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in summary.items() if k not in ['observed_orders','variant_orders']}),flush=True)
 if not summary['valid_order_prefix_comparison']:raise SystemExit(2)
