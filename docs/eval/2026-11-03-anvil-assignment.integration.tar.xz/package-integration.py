"""Seal the pinned main integration only after its full Rust suite passes."""
from pathlib import Path
import datetime
import hashlib
import io
import json
import re
import shutil
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/martbot-mbp-m5-max-128/civvis-anvil-follows-the-defense-e936')
sha = lambda data: hashlib.sha256(data).hexdigest()
tests = json.loads((root / 'integration-full-rust-retry.json').read_text())
assert tests['exit'] == 0
binary = json.loads((root / 'integrated-binary.json').read_text())
assert tests['head'] == binary['source_commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == tests['head']
assert all(sha((repo / path).read_bytes()) == digest for path, digest in binary['source_sha256'].items())
assert sha((root / 'frozen-integrated-ci-orders').read_bytes()) == binary['binary_sha256']
subprocess.run(['python3', str(root / 'verify-integration.py')], check=True, stdout=subprocess.DEVNULL)
text = (root / 'integration-full-rust-retry.log').read_text()
results = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
assert results and all(int(failed) == 0 for _, failed, _ in results)
assert len(re.findall(r'^test ai::advanced::anvil_assignment::tests::\S+ \.\.\. ok$', text, re.M)) == 9

out = root / 'integration-evidence'
out.mkdir(exist_ok=False)
def copy(source, relative):
    target = out / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)

for name in ('helpers', 'contexts', 'native-qualified-01', 'native-qualified-khmer-01',
             'native-qualified-korea-01', 'queries-integration', 'prefix-comparisons-integration'):
    for path in (root / name).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:
            copy(path, Path(name) / path.relative_to(root / name))
for name in ('verify-integration.py', 'query.py', 'compare-prefix-integration.py',
             'validate-integration.py', 'package-integration.py', 'integration-target-04.json',
             'integration-resolution-04.json', 'merge-attempt-04.log', 'fmt-merged-04.log',
             'fmt-merged-04-corrected.log', 'manifest-merged-04.log', 'genes-merged-04.log',
             'integrated-binary.json', 'integration-build.log', 'integration-build.json',
             'integration-full-rust-tests.log', 'integration-full-rust-tests.json',
             'integration-full-rust-retry.log', 'integration-full-rust-retry.json',
             'isolated-latency-retries.json',
             'a_mid_turn_victory_wakes_the_waiting_state_request_immediately-isolated.log',
             'an_arriving_page_is_not_held_up_by_another_viewers_paint-isolated.log',
             'validate-integration.log', 'query-integration.log', 'compare-prefix-integration.log',
             'prefix-intent-integration.json', 'verify-integration-01.log',
             'integration-independent-verification.json'):
    copy(root / name, name)
for path in binary['source_sha256']:
    copy(repo / path, Path('source') / path)
main = json.loads((root / 'integration-target-04.json').read_text())['main']
(out / 'source.patch').write_bytes(subprocess.check_output(['git', 'diff', main, tests['head'], '--',
    'src/ai/advanced.rs', 'src/ai/advanced/genes.rs', 'src/ai/advanced/treatment_flags.rs',
    'src/ai/advanced/siege_train.rs', 'src/ai/advanced/anvil_assignment.rs',
    'src/ai/advanced/anvil_assignment/tests.rs'], cwd=repo))
verification = json.loads((root / 'integration-independent-verification.json').read_text())
report = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope': 'Integration conformance and proposal activation. No native execution, saved-city outcome, held-out confirmation or strength estimate.',
          'source_commit': tests['head'], 'main_parent': main,
          'candidate_binary_sha256': binary['binary_sha256'],
          'anvil_module_and_tests_unchanged_from': '9b5a17bd8c08b4b608168a059a2ba2f6a77aca7d',
          'prior_evidence_archive_sha256': '525c1678935ea8d7a1592f288afe788e0f585734839ebc41721b290212380b0d',
          'main_registry_order_preserved': True,
          'local_rust': {'command': tests['command'], 'passed': sum(int(n) for n, _, _ in results),
                         'failed': 0, 'ignored': sum(int(n) for _, _, n in results), 'routing_tests': 9},
          'verification': verification,
          'integration_note': 'Retain main Deck and CityStateHarvest entries before Anvil. Both main additions remain opt-in. Regenerate combined coverage counts; retain the ledger and selected deployment genome. Fix the merged city-state module declaration order for rustfmt.',
          'retained_full_suite_failures': 'Initial integrated suite:6363 passed,2 latency assertions failed,52 ignored. Both latency tests passed in isolation; complete four-thread retry is the validation reported above. No threshold or source changes.',
          'no_native_treatment_armed': True}
(out / 'adjudication.json').write_text(json.dumps(report, indent=2) + '\n')
subprocess.run(['python3', str(out / 'verify-integration.py')], check=True, stdout=subprocess.DEVNULL)
files = {p.relative_to(out).as_posix(): p.read_bytes() for p in out.rglob('*')
         if p.is_file() and '__pycache__' not in p.parts}
manifest = {'members': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(files.items())}}
files['SHA256SUMS.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive = repo / 'docs/eval/2026-11-03-anvil-assignment.integration.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as tar:
    for name, raw in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        member.mtime = 0
        member.mode = 0o644
        tar.addfile(member, io.BytesIO(raw))
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(files)
    for name, raw in files.items():
        assert tar.extractfile(name).read() == raw
report['archive'] = {'path': str(archive.relative_to(repo)), 'bytes': archive.stat().st_size,
                     'sha256': sha(archive.read_bytes()), 'members': len(files)}
(repo / 'docs/eval/2026-11-03-anvil-assignment.integration.json').write_text(json.dumps(report, indent=2) + '\n')
p = repo / 'docs/gene_screens/fires/anvil-follows-the-defense.json'
fire = json.loads(p.read_text())
fire['archive'] = {key: report['archive'][key] for key in ('path', 'sha256')}
cases = json.loads((root / 'queries-integration/results.json').read_text())['cases']
fire['members'] = [f"queries-integration/{case['run']}-{case['turn']}/result.json" for case in cases]
p.write_text(json.dumps(fire, indent=2) + '\n')
print(json.dumps({'archive': report['archive'], 'local_rust': report['local_rust']}), flush=True)
