"""Paired decider queries on captured live Domination frames for
`gun-resource-buys-the-tile`.

`gun-resource-buys-the-tile` is the only bit that varies. Each case is a live
Emperor Domination run of 2026-11-16 (Gilgamesh, 6p Small Continents) whose
events.jsonl is cut after the FIRST agent state row of turn T (the board the
decider saw before it played T; `--turn T` alone would read the turn's last
state row, the replan after the live orders). Both arms run one frozen
ci-profile `civvis_orders --resumed --explain` built from the branch with the
run's own requested genome (`summary.json` `forced`, each as `--with`); the on
arm adds `--with gun-resource-buys-the-tile`. The live game bought no Niter or
Oil tile on these turns; the off arm is checked to propose none either.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'gun-resource-buys-the-tile'
CONTROL = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

# (run, turn, the deposit in Civ VI offset coordinates, why the frame)
CASES = (
    # Every turn the Niter deposit (21,33) lay unowned in Akshak's third ring
    # after Metal Casting (t75-103; a rival took it at t104).
    [{'run': 'civvis-20261116T035719Z', 'turn': t, 'deposit': [21, 33],
      'note': 'Niter-starved; deposit unowned in Akshak ring 3, step (21,32)'} for t in range(75, 104)]
    # The land Oil deposit (22,30) on Lagash's menu at 125, Steel at 142.
    + [{'run': 'civvis-20261116T024741Z', 'turn': t, 'deposit': [22, 30],
        'note': 'Oil-starved; desert Oil on Lagash menu at 125; our only Oil offshore'} for t in (142, 143, 144)]
    # Niter-starved with the nearest free Niter 5 tiles out, then Isin founded beside it.
    + [{'run': 'civvis-20261116T054247Z', 'turn': t, 'deposit': [69, 18],
        'note': 'Niter-starved; no deposit within a city reach (Isin founded beside (69,18) at 164)'} for t in (145, 150, 155, 160, 165)]
    # Ur's menu quoted an OFFSHORE Oil deposit (1,20): not workable before Plastics.
    + [{'run': 'civvis-20261116T023139Z', 'turn': t, 'deposit': [1, 20],
        'note': 'Oil-starved; the deposit within reach is offshore (coast)'} for t in (177, 187)]
    # Control: Niter drawn from t67, Steel not yet researched.
    + [{'run': 'civvis-20261116T052047Z', 'turn': 120, 'deposit': None,
        'note': 'control: Niter drawn from t67 and no Oil technology; the gene must stay silent'}]
)


def cut(run, turn):
    """The run's events up to and including turn T's first agent state row."""
    lines = []
    with (CONTROL / run / 'events.jsonl').open('rb') as src:
        for line in src:
            lines.append(line)
            if b'"kind": "state"' in line and f'"turn": {turn},'.encode() in line:
                row = json.loads(line)
                if row.get('ctx') == 'agent' and row.get('turn') == turn:
                    return b''.join(lines)
    raise ValueError(f'{run} has no agent state row for turn {turn}')


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        summary = json.loads((CONTROL / case['run'] / 'summary.json').read_text())
        forced = list(summary['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data = cut(case['run'], case['turn'])
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'],
                                 'cut': 'events.jsonl through the first agent state row of the turn'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', 'domination',
                   '--turn', str(case['turn']), '--resumed']
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=600)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text().strip().splitlines()[-1])
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if GENE in line]
            row['buy_plot'] = [o for o in row.get('payload', {}).get('orders', [])
                               if o.get('kind') == 'buy_plot']
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
        off, on = record['arms']
        record['off_buys_no_gun_tile'] = not off['journal'] and not any(
            o for o in off['buy_plot']
            if case['deposit'] and abs(o['x'] - case['deposit'][0]) + abs(o['y'] - case['deposit'][1]) <= 2)
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        for v in r['reads']:
            for a in v['arms']:
                print(r['case']['run'][15:], r['case']['turn'], a['arm'], 'exit', a['exit'],
                      [(o.get('subject'), o.get('x'), o.get('y'), o.get('verb')) for o in a['buy_plot']],
                      a['journal'][:2])
        if r.get('error'):
            print(r['case']['run'], 'ERROR', r['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
