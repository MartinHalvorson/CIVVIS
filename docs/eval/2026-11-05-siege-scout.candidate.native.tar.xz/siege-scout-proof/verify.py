from pathlib import Path
import json,sys,hashlib,copy,datetime
b=Path(__file__).parent
repo=Path.home()/'civvis-siege-does-not-wait-for-a-scout-594f';r=Path(sys.argv[1]).resolve();tools=r/'verification-tools'
if not tools.exists():tools=repo/'tools'
sys.path.insert(0,str(tools));from civ6_decision_trace import captured_input,validate_input_capture
def expanded_reads(capture):
 validate_input_capture(capture);assert capture['complete'];return [captured_input(capture,x['snapshot_id']) for x in capture['reads'] for _ in range(x['count'])]
read=lambda p:json.loads(p.read_text());sha=lambda x:hashlib.sha256(x).hexdigest();protocol=read(r/'protocol.json');old=r/'original-source-proposals'
if not old.exists():old=Path(protocol['source_witness'])
source=read(old/'source.json');native=Path(source['root']);record=read(r/'original-record.json');unsigned={k:v for k,v in record.items() if k!='sha256'};assert sha(json.dumps(unsigned,sort_keys=True,separators=(',',':'),allow_nan=False).encode())==record['sha256']=='72a09ed0e61e4b8ad473a5ab385a32016ea3363db87fb16309579165f476f460';cap=copy.deepcopy(record['input_capture']);cap['directory']=str(r/'original-capture' if (r/'original-capture').exists() else native/'native-01-on/sealed-native-captures/source-capture-0');original=expanded_reads(cap);data=(r/'events.jsonl').read_bytes();assert len(original)==18 and all(x==data for x in original);assert sha(data)==source['input_sha256'];state=[json.loads(l) for l in data.splitlines() if json.loads(l).get('kind')=='state'][-1];assert (state['turn'],state['frame'])==(31,0);city=next(c for c in state['cities'] if c['id']==196610);assert city['damage']==33;assert any(q['t']=='BUILDING_WALLS' and q['p']==12 for q in city['buildable']);assert city['producing']=='UNIT_SCOUT'
rows=[];vectors=[]
for root,roles,expected in [(old,['01-original','02-original'],None),(r,['01-candidate','02-candidate'],'BUILDING_WALLS')]:
 replies=[]
 for role in roles:
  out=root/role;d=read(out/('stdout.json'));cmd=read(out/'command.json');v=read(out/'verified.json');raw_genome=next(json.loads(l) for l in (out/'stderr.log').read_text().splitlines() if l.startswith('{') and json.loads(l).get('kind')=='genome');assert {k:raw_genome.get(k) for k in v['genome']}==v['genome'];assert 'garrison-under-fire' in v['genome']['treatments'];capture=copy.deepcopy(d['input_capture']);capture['directory']=str(out/'capture');reads=expanded_reads(capture);assert len(reads)==17 and all(x==data for x in reads);assert (d['decision']['turn'],d['decision']['frame'])==(31,0);orders=[o for o in d['orders'] if o.get('subject')==196610 and o.get('kind')=='produce'];assert orders==[] if expected is None else len(orders)==1 and orders[0]['verb']==expected
  vector=list(cmd['argv']);vector[0]='BINARY'
  for flag in ['--mirror','--capture-inputs']:vector[vector.index(flag)+1]='PATH'
  vectors.append(vector);replies.append({k:d[k] for k in ['decision','orders']});rows.append({'role':role,'actual_reads':len(reads),'target_orders':orders})
 assert replies[0]==replies[1]
assert all(v==vectors[0] for v in vectors)
receipt=read(r/'build-receipt.json');assert receipt['source']['sha']==protocol['candidate_source'];assert [t['passed'] for t in receipt['tests']]==[6,12,29];
if (r/'probe-binary').exists():assert sha((r/'probe-binary').read_bytes())==receipt['binaries']['civvis_orders']
assert read(r/'result.json')['candidate_walls_proposals_observed'];result={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verified':True,'original_actual_reads':18,'proposal_actual_reads':68,'roles':rows,'full_reply_repeats_equal':True,'normalized_cli_vectors_equal':True,'focused_native_tests':47,'scope':'Old-source and candidate-source cold proposals use the same explicit CLI profile and same actual native bytes. Source defaults may differ; this is not a source-only causal contrast, original private planner parity, native execution, earlier completion, saved city or strength.'};(r/'independent-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
