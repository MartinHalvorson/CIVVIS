from pathlib import Path
import json,copy,sys,subprocess,hashlib
sys.path.insert(0,str(Path.home()/'civvis-main-managed/tools'))
import civ6_captured_read_replay as replay
from civ6_ladder import decider_genome
from civ6_decision_trace import exact_fact
root=Path(__file__).parent.resolve();source=json.loads((root/'observed-context.json').read_text());build=json.loads((root/'candidate-build.json').read_text());gene='capital-keeps-its-governor';binary=root/'candidate-ci-orders';assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['sha256'];off=copy.deepcopy(source);off['processes'][0]['argv'][0]=str(binary);off['binary_sha256']=build['sha256'];off['provenance']=build;off['native_observed']=False;off['valid_arm_and_binary']=False;off['scope']='Constructed candidate query profile from actual native192352 argv/cwd; not observed native process.';on=copy.deepcopy(off);assert gene not in on['processes'][0]['argv'];on['processes'][0]['argv']+=['--with',gene]
for arm,c in [('off',off),('on',on)]:(root/f'candidate-{arm}-context.json').write_text(json.dumps(c,indent=2)+'\n')
def query(arm,label,expected=None,length=None):
 a=[sys.executable,'-u',str(root/'query-prefix.py'),'--context',str(root/f'candidate-{arm}-context.json'),'--out',str(root/label)]
 if expected:a+=['--expected',str(expected)]
 if length:a+=['--length',str(length)]
 subprocess.run(a,cwd=root,check=True)
reference=root/'policy-window-reference-0/replies.jsonl'
for n in range(2):
 query('off',f'candidate-off-control-{n}',reference);assert decider_genome(root/f'candidate-off-control-{n}/stderr.log')==source['actual_genome']
native=[json.loads(l) for l in (root/'native-decisions.jsonl').open()];baseline=[json.loads(l) for l in (root/'candidate-off-control-0/replies.jsonl').open()];expected=[{'turn':r['turn'],'orders':r['orders'],'decision':r['decision'],'input_capture':native[i]['input_capture']} for i,r in enumerate(baseline)];mapping={s['source']:Path(s['sealed_directory']) for s in json.loads((root/'sealed-captures.json').read_text())};report={'intent':json.loads((root/'frozen-intent.json').read_text()),'candidate_build':build,'off_controls':{'repetitions':2,'requests_each':len(native),'full_payload_matches_policy_window_reference':True},'probes':[]}
for n in range(2):
 d=root/f'candidate-on-probe-{n}';r=replay.run_control(on,expected,mapping,d,60,'hybrid');report['probes'].append(r);(root/'candidate-results.json').write_text(json.dumps(report,indent=2)+'\n');assert not r['passed'] and tuple(r['failed_request'])==(69,0);assert all(v['read_sequence_matches'] and not v['identity_errors'] for v in r['requests']);print(json.dumps({'probe':n,'first_difference':r['failed_request'],'requests':len(r['requests'])}),flush=True)
length=len(report['probes'][0]['requests']);assert len(report['probes'][1]['requests'])==length;on_expected=root/'candidate-on-probe-0/replies.jsonl';pairs=[]
for n in range(2):
 query('off',f'successful-off-{n}',reference,length);query('on',f'successful-on-{n}',on_expected,length);a=json.loads((root/f'successful-off-{n}/receipt.json').read_text());b=json.loads((root/f'successful-on-{n}/receipt.json').read_text());assert a['delivered']==b['delivered'];x,y=list(a['argv']),list(b['argv']);x[x.index('--mirror')+1]=y[y.index('--mirror')+1]='<input>';assert y[-2:]==['--with',gene];del y[-2:];assert x==y and a['cwd']==b['cwd'];x,y=copy.deepcopy(a['genome']),copy.deepcopy(b['genome'])
 for field in ['treatments','forced']:
  before,after=x.pop(field),y.pop(field);assert gene not in before and set(after)==set(before)|{gene}
 assert x==y;pairs.append({'off':a,'on':b})
a=baseline[length-1];b=json.loads(list(on_expected.open())[-1]);removed=[o for o in a['orders'] if o not in b['orders']];added=[o for o in b['orders'] if o not in a['orders']];governor={'kind':'governor_assign','subject':196609,'verb':'GOVERNOR_THE_RESOURCE_MANAGER','x':0,'y':-1};assert governor in removed and not any(o['kind']=='governor_assign' and o['verb']=='GOVERNOR_THE_RESOURCE_MANAGER' for o in b['orders']);report.update({'passed':True,'first_difference':[69,0],'prefix_requests':length,'successful_pair_repetitions':2,'actual_eof_exits':0,'removed_orders':removed,'added_orders':added,'unchanged_order_subsequence_identical':exact_fact([o for o in a['orders'] if o not in removed],[o for o in b['orders'] if o not in added]),'isolated_governor_only_change':removed==[governor] and added==[],'original_native_orders':native[length-1]['orders'],'policy_window_reference_orders':a['orders'],'candidate_on_orders':b['orders'],'scope':'Repeated successful captured-input prefixes, no continued candidate game, saved capital or strength claim. Original native controls and corrected policy-window reference are separately retained.'});(root/'candidate-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['passed','first_difference','prefix_requests','removed_orders','added_orders','isolated_governor_only_change']}),flush=True)
