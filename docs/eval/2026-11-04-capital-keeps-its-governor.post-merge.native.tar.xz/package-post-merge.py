from pathlib import Path
import json,hashlib,tarfile,lzma,subprocess,tempfile,shutil,os,datetime
outer=Path(__file__).parent;root=outer/'post-merge-ff8661349';repo=Path.home()/'civvis-capital-keeps-its-governor-e6de';subprocess.run(['taskpolicy','-B','-p',str(os.getpid())],check=True)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def same(a,b):
 with a.open('rb') as x,b.open('rb') as y:
  while True:
   u,v=x.read(1024*1024),y.read(1024*1024)
   if u!=v:return False
   if not u:return True
assert json.loads((root/'independent-verification.json').read_text())['independently_verified'];assert json.loads((root/'safe-capital-native-193444/candidate-results.json').read_text())['passed']
tests=(outer/'post-merge-tests.log').read_text();assert 'test result: ok.' in tests and '0 failed' in tests
quality=(outer/'post-merge-quality.log').read_text();assert 'the changed lines are formatted and warning-free' in quality
for n in ['post-merge-build.log','post-merge-tests.log','post-merge-quality.log','post-merge-qualification.log','post-merge-negative-retry.log','post-merge-independent-verification.log']:shutil.copy2(outer/n,root/n)
shutil.copy2(outer/'qualify-post-merge.py',root/'driver-reference.py');shutil.copy2(Path(__file__),root/'package-post-merge.py')
(root/'README.txt').write_text('''Post-merge capital Governor proposal requalification, checkpoint ff8661349.
Actual source revision, compiler/profile and frozen executable SHA are in candidate-build.json.
Run python3 verify.py --root . --repo /path/to/CIVVIS to verify native canonical records, raw reads, source exports, full reply payloads and EOF receipts.
This composite archive reuses the original immutable native controls and corrected policy reference queries. The new merged candidate repeats both OFF225 controls, first-difference ON probes, two successful OFF/ON164 pairs and the safe344 two-pair negative control. Original controls/reference queries were NOT rerun and are NOT claimed fresh.
Manifest path_aliases relocate unchanged raw records without rewriting captured paths. Binaries are identified by source/hash and are not bundled. New per-arm query captures and source exports are included.
One initial negative ON query timed out after44 replies and was preserved, excluded from successful controls. The fresh four-query retry restores scheduling on its own process without changing code or the reply deadline.
No continued ON world, saved-capital outcome or strength claim. Runtime default remains OFF.
''')
paths=[p for p in sorted(root.rglob('*')) if p.is_file() and p.name not in ['candidate-ci-orders','archive-manifest.json','archive-receipt.json','fresh-archive-audit.json'] and '__pycache__' not in p.parts];assert all(not p.is_symlink() for p in paths)
manifest={'original_root':str(root),'path_aliases':[str(outer)],'scope':'Composite raw proof after real main conflict. Original native controls and corrected reference are reused unchanged; merged candidate queries and source exports are fresh.','files':{str(p.relative_to(root)):{'sha256':digest(p),'bytes':p.stat().st_size} for p in paths}};(root/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');paths.append(root/'archive-manifest.json');archive=repo/'docs/eval/2026-11-04-capital-keeps-its-governor.post-merge.native.tar.xz';assert not archive.exists();duplicates={};links=0
with lzma.LZMAFile(archive,'w',format=lzma.FORMAT_XZ,filters=[{'id':lzma.FILTER_LZMA2,'preset':6,'dict_size':64*1024*1024}]) as compressed:
 with tarfile.open(fileobj=compressed,mode='w|') as tar:
  for p in sorted(paths):
   name=str(p.relative_to(root));info=tar.gettarinfo(str(p),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;h=digest(p);old=duplicates.get(h)
   if old and same(p,old):info.type=tarfile.LNKTYPE;info.linkname=str(old.relative_to(root));info.size=0;tar.addfile(info);links+=1
   else:
    with p.open('rb') as f:tar.addfile(info,f)
    duplicates[h]=p
receipt={'archive':str(archive),'sha256':digest(archive),'bytes':archive.stat().st_size,'members':len(paths),'exact_duplicate_hardlinks':links};(root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
with tempfile.TemporaryDirectory(prefix='civvis-governor-post-merge-audit-') as tmp:
 dest=Path(tmp)
 with tarfile.open(archive,'r:xz') as tar:tar.extractall(dest)
 for name,record in manifest['files'].items():assert digest(dest/name)==record['sha256'] and (dest/name).stat().st_size==record['bytes']
 subprocess.run(['python3',str(dest/'verify.py'),'--root',str(dest),'--repo',str(repo)],check=True)
 audit={'fresh_extraction':True,'manifest_file_hashes_verified':len(manifest['files']),'independent_verifier_exit':0,'archive_sha256':receipt['sha256']};(root/'fresh-archive-audit.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit),flush=True)
