from pathlib import Path
import json,hashlib,subprocess,shutil,time,datetime,sys
outer=Path(__file__).parent;root=outer/'post-merge-ff8661349';repo=Path.home()/'civvis-capital-keeps-its-governor-e6de';deadline=time.monotonic()+900
while time.monotonic()<deadline:
 log=(outer/'post-merge-build.log').read_text()
 if 'Finished `ci` profile' in log:break
 time.sleep(3)
else:raise SystemExit('Bounded wait for actual successful build expired')
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert revision.startswith('ff8661349');build=json.loads((outer/'candidate-build.json').read_text());build.update({'revision':revision,'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Fresh rebuilt merged candidate after resolving real main conflict, source ff8661349, default OFF. Repeats captured-input positive and negative controls; no actual native ON or continued world.'});shutil.copy2(repo/'target/ci/civvis_orders',root/'candidate-ci-orders');build['sha256']=hashlib.sha256((root/'candidate-ci-orders').read_bytes()).hexdigest();exports=root/'source-exports';exports.mkdir()
for f in build['source_files_sha256']:
 blob=subprocess.check_output(['git','show',f'{revision}:{f}'],cwd=repo);assert blob==(repo/f).read_bytes();p=exports/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(blob);build['source_files_sha256'][f]=hashlib.sha256(blob).hexdigest()
(root/'candidate-build.json').write_text(json.dumps(build,indent=2)+'\n');print(json.dumps({'build':build['revision'],'sha256':build['sha256']}),flush=True)
subprocess.run([sys.executable,'-u',str(root/'qualify-candidate.py')],check=True)
subprocess.run([sys.executable,'-u',str(root/'safe-capital-native-193444/qualify-safe-candidate.py')],check=True)
subprocess.run([sys.executable,'-u',str(root/'verify.py'),'--root',str(root),'--repo',str(repo)],check=True)
print('Post-merge positive/negative qualification and independent verification PASS',flush=True)
