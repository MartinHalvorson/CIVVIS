Post-merge capital Governor proposal requalification, checkpoint ff8661349.
Actual source revision, compiler/profile and frozen executable SHA are in candidate-build.json.
Run python3 verify.py --root . --repo /path/to/CIVVIS to verify native canonical records, raw reads, source exports, full reply payloads and EOF receipts.
This composite archive reuses the original immutable native controls and corrected policy reference queries. The new merged candidate repeats both OFF225 controls, first-difference ON probes, two successful OFF/ON164 pairs and the safe344 two-pair negative control. Original controls/reference queries were NOT rerun and are NOT claimed fresh.
Manifest path_aliases relocate unchanged raw records without rewriting captured paths. Binaries are identified by source/hash and are not bundled. New per-arm query captures and source exports are included.
One initial negative ON query timed out after44 replies and was preserved, excluded from successful controls. The fresh four-query retry restores scheduling on its own process without changing code or the reply deadline.
No continued ON world, saved-capital outcome or strength claim. Runtime default remains OFF.
