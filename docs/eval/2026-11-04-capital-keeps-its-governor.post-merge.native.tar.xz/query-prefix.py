from pathlib import Path
import json,sys,subprocess,shutil,hashlib,argparse
sys.path.insert(0,str(Path.home()/'civvis-main-managed/tools'))
import civ6_captured_read_replay as replay
from civ6_ladder import decider_genome
from civ6_decision_trace import exact_fact
from native_city_route_replay import control_payload,request_identity_errors
parser=argparse.ArgumentParser();parser.add_argument('--context',type=Path,required=True);parser.add_argument('--out',type=Path,required=True);parser.add_argument('--expected',type=Path);parser.add_argument('--length',type=int);args=parser.parse_args();root=Path(__file__).parent;context=json.loads(args.context.read_text());records=[json.loads(l) for l in (root/'native-decisions.jsonl').open()];records=records[:args.length];oracle=[json.loads(l) for l in args.expected.open()] if args.expected else None;mapping={s['source']:Path(s['sealed_directory']) for s in json.loads((root/'sealed-captures.json').read_text())};d=args.out;d.mkdir();common=root/'qualification-capture-current';a,cwd=replay.replay_command(context,d);a[a.index('--capture-inputs')+1]=str(common);captures=set();delivered=[];feeder=None;count=0;sha=lambda b:hashlib.sha256(b).hexdigest();binary_sha=sha(Path(a[0]).read_bytes());assert binary_sha==context['binary_sha256']
with (d/'stderr.log').open('w') as stderr,(d/'replies.jsonl').open('w') as replies:
 p=subprocess.Popen(a,cwd=cwd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,text=True,bufsize=1)
 try:
  for i,r in enumerate(records):
   capture=dict(r['input_capture'],directory=str(mapping[r['input_capture']['directory']]));expected=replay.expanded_reads(capture);path=d/'events.jsonl'
   if path.exists():path.unlink()
   feeder=replay.deliver_reads(path,expected,60,'hybrid');key=[r['decision']['turn'],r['decision']['frame']];p.stdin.write(str(key[0])+'\n');p.stdin.flush();reply=replay.request_reply(p,60);feeder.finish();feeder=None;assert not request_identity_errors(reply,*key);actual=replay.expanded_reads(reply['input_capture']);assert actual==expected
   if oracle is not None:assert exact_fact(control_payload(reply),control_payload(oracle[i])),key
   replies.write(json.dumps(reply,sort_keys=True)+'\n');replies.flush();captures.add(reply['input_capture']['directory']);delivered.append({'request':key,'reads':[{'sha256':sha(b),'bytes':len(b)} for b in actual]});count+=1
  p.stdin.close();code=p.wait(timeout=10);assert code==0
 finally:
  if feeder is not None:feeder.close()
  if p.poll() is None:p.terminate();p.wait(timeout=5)
  p.stdout.close()
genome=decider_genome(d/'stderr.log');capture_map={old:str(d/'recaptured'/Path(old).relative_to(common)) for old in captures};shutil.move(str(common),str(d/'recaptured'));receipt={'argv':a,'cwd':cwd,'binary_sha256':binary_sha,'exit':code,'genome':genome,'capture_directory_map':capture_map,'delivered':delivered,'requests':count,'complete_expected_payload_checked':oracle is not None,'expected_payload_source':str(args.expected) if args.expected else None,'scope':'Captured-input query, actual read bytes/count/order and identities; constructed process profile, not observed native deployment.'};(d/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'query':str(d),'requests':count,'exit':code,'oracle_checked':oracle is not None}),flush=True)
