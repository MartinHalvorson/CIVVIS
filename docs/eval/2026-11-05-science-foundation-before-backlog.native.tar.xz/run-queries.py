from pathlib import Path
import subprocess,sys,json,hashlib,datetime
r=Path(__file__).parent;source=Path.home()/'civvis-science-foundation-before-backlog-5042';sys.path.insert(0,str(source/'tools'))
from civ6_decision_trace import exact_fact
from native_city_route_replay import control_payload
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
assert not (r/'query-binding.json').exists(),'Inspect existing queries; never duplicate a bound experiment'
binding={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{n:sha((r/n).read_bytes()) for n in ['intent.json','native-build.json','source-manifest.json','off-context.json','on-context.json','query-prefix.py','native-decisions.jsonl','sealed-captures.json','run-queries.py']},'scope':'Same current-source executable, one named bit. Historical native captures supply inputs; current OFF is the full-payload oracle.'}
(r/'query-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
def query(arm,out,oracle=None,length=None,discover=False):
 a=[sys.executable,'-u',str(r/'query-prefix.py'),'--context',str(r/(arm+'-context.json')),'--out',str(r/out)]
 if oracle:a+=['--expected',str(r/oracle)]
 if length is not None:a+=['--length',str(length)]
 if discover:a+=['--discover-orders']
 subprocess.run(a,check=True)
 return read(r/out/'receipt.json'),[json.loads(l) for l in (r/out/'replies.jsonl').open()]
off,offrows=query('off','off-control-0');assert off['exit']==0 and off['requests']==249
(r/'off-oracle.jsonl').write_bytes((r/'off-control-0/replies.jsonl').read_bytes())
off2,_=query('off','off-control-1','off-oracle.jsonl');assert off2['requests']==249 and exact_fact(off['genome'],off2['genome'])
on,rows=query('on','on-discovery','off-oracle.jsonl',discover=True);assert on['exit']==0
n=len(rows);first=n-1;reports=[]
if on['first_order_difference'] is None:
 (r/'no-order-effect.json').write_text(json.dumps({'requests':n,'scope':'No action effect on complete captured prefix; retain without claiming strength.'},indent=2)+'\n');raise SystemExit('No order effect')
for a,b in zip(offrows[:first],rows[:first]):assert exact_fact(control_payload(a),control_payload(b))
(r/'on-oracle.jsonl').write_bytes((r/'on-discovery/replies.jsonl').read_bytes())
for i,name in enumerate(['on-discovery','on-repeat-0','on-repeat-1']):
 if i:on,rows=query('on',name,'on-oracle.jsonl',n)
 assert on['exit']==0 and on['requests']==n and on['delivered']==off['delivered'][:n] and on['binary_sha256']==off['binary_sha256']
 differences={}
 for key in set(on['genome'])|set(off['genome']):
  x,y=off['genome'].get(key),on['genome'].get(key)
  if not exact_fact(x,y):
   assert key in ['treatments','forced'];assert set(y)-set(x)=={'science-foundation-before-backlog'} and not set(x)-set(y);differences[key]=True
 assert set(differences)=={'treatments','forced'}
 reports.append({'query':name,'requests':n,'exit':on['exit'],'genome_changed_fields':list(differences),'replies_sha256':sha((r/name/'replies.jsonl').read_bytes())})
report={'qualification_passed':True,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'first_changed_order':on['delivered'][first]['request'],'first_changed_index':first,'off_orders':offrows[first]['orders'],'on_orders':rows[first]['orders'],'off_complete_requests':249,'on_prefix_requests':n,'on_queries':reports,'scope':'One-bit current-source query comparison on recorded native inputs. Actual read equality, two complete OFF controls and three ON prefixes with own full-payload oracle; independent verification pending. No historical current-source parity, native deployment or strength claim.'}
(r/'queries.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
