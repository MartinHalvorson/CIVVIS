from pathlib import Path
import json,hashlib,copy,sys,datetime
r=Path(__file__).parent;source=Path.home()/'civvis-science-foundation-before-backlog-5042';sys.path.insert(0,str(source/'tools'));import civ6_captured_read_replay as replay
from civ6_decision_trace import exact_fact
from native_city_route_replay import control_payload
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();summary=read(r/'queries.json');binding=read(r/'query-binding.json');assert summary['qualification_passed'];assert all(sha((r/n).read_bytes())==v for n,v in binding['files'].items());build=read(r/'native-build.json');digest=build['provenance']['sha256'];assert sha((r/'civvis_orders').read_bytes())==digest;manifest=read(r/'source-manifest.json');assert manifest['revision']==build['provenance']['revision'];assert sha((r/'source-manifest.json').read_bytes())==build['provenance']['source_manifest_sha256']
native=[json.loads(l) for l in (r/'native-decisions.jsonl').open()];off=[json.loads(l) for l in (r/'off-oracle.jsonl').open()];on=[json.loads(l) for l in (r/'on-oracle.jsonl').open()];assert len(off)==len(native)==249;assert len(on)==summary['on_prefix_requests'];first=len(on)-1;assert first==summary['first_changed_index'];assert [on[first]['decision']['turn'],on[first]['decision']['frame']]==summary['first_changed_order'];gene='science-foundation-before-backlog';seals=read(r/'sealed-captures.json');mapping={e['source']:e['sealed_directory'] for e in seals}
for e in seals:
 p=Path(e['sealed_directory']);assert sha((p/'bytes.bin').read_bytes())==e['archive_sha256'];assert sha((p/'snapshots.jsonl').read_bytes())==e['index_sha256']
base=read(r/'off-control-0/receipt.json');reports=[]
for label,armed in [('off-control-0',False),('off-control-1',False),('on-discovery',True),('on-repeat-0',True),('on-repeat-1',True)]:
 out=r/label;c=read(out/'receipt.json');rows=[json.loads(l) for l in (out/'replies.jsonl').open()];oracle=on if armed else off;assert c['requests']==len(rows)==len(oracle)==len(c['delivered']);assert c['exit']==0 and c['binary_sha256']==digest;assert c['cwd']==base['cwd'];a,b=list(base['argv']),list(c['argv'])
 for v in [a,b]:
  for flag in ['--mirror','--capture-inputs']:v[v.index(flag)+1]='<private path>'
 if armed:
  j=next(i for i in range(len(b)-1) if b[i:i+2]==['--with',gene]);del b[j:j+2]
 assert a==b;g0,g1=copy.deepcopy(base['genome']),copy.deepcopy(c['genome'])
 for field in ['treatments','forced']:
  x,y=g0.pop(field),g1.pop(field);assert len(set(x))==len(x) and len(set(y))==len(y)
  assert set(y)==set(x)|({gene} if armed else set());assert gene not in x
 assert exact_fact(g0,g1);read_count=0
 for i,(reply,expected,delivery) in enumerate(zip(rows,oracle,c['delivered'])):
  assert exact_fact(control_payload(reply),control_payload(expected));key=[native[i]['decision']['turn'],native[i]['decision']['frame']];assert key==delivery['request']==[reply['decision']['turn'],reply['decision']['frame']]
  src=copy.deepcopy(native[i]['input_capture']);src['directory']=mapping[src['directory']];actual=copy.deepcopy(reply['input_capture']);actual['directory']=c['capture_directory_map'][actual['directory']];x,y=replay.expanded_reads(src),replay.expanded_reads(actual);assert x==y;assert delivery['reads']==[{'bytes':len(blob),'sha256':sha(blob)} for blob in y];read_count+=len(y)
  if armed and i<first:assert exact_fact(control_payload(reply),control_payload(off[i]))
 if armed:assert not exact_fact(rows[first]['orders'],off[first]['orders'])
 reports.append({'query':label,'requests':len(rows),'actual_reads':read_count,'exit':c['exit'],'receipt_sha256':sha((out/'receipt.json').read_bytes()),'replies_sha256':sha((out/'replies.jsonl').read_bytes())})
report={'independently_verified':True,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'gene':gene,'binary_sha256':digest,'source_revision':manifest['revision'],'first_changed_order':summary['first_changed_order'],'off_orders':off[first]['orders'],'on_orders':on[first]['orders'],'queries':reports,'scope':'Two current-source full249 OFF controls and three ON prefixes, full own payloads, every actual captured byte/order/count, one-bit measured genomes/argv, cwd and EOF0. Historical native input supply only; no current-source historical parity or native strength claim.'};(r/'independent-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
