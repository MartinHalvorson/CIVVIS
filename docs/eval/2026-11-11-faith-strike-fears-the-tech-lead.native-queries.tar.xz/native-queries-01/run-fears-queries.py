"""Paired decider queries on the turns a live Culture seat struck a rival faith.

`faith-strike-fears-the-tech-lead` edition.

`faith-strike-fears-the-tech-lead` is the only bit that varies; both arms
carry the run's own requested genome (`summary.json` `forced`, or the
`forced` list on why.log's first line when the summary is partial), which
includes `faith-strike-wipes-the-spreaders` and none of the runs carried
`faith-strike-spares-the-stages`. Each case is a turn on which the live seat
declared a heretic strike, cut at that turn's first state frame. The gap is
the host's public tech count for the rival against ours on that frame: at
10 or more the on arm must hold, below it both arms must strike.
Both arms run one frozen ci-profile `civvis_orders --resumed` built from the
branch.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'faith-strike-fears-the-tech-lead'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

RUNS = Path.home() / 'civvis-civ6-runs/control'
CASES = [
    {"run": "civvis-20261110T201752Z", "turn": 95, "rival": "Sumeria", "expect": "hold: leads by 23 (42 to 19)"},
    {"run": "civvis-20261110T214026Z-cont2", "turn": 115, "rival": "Aztec", "expect": "hold: leads by 16 (45 to 29)"},
    {"run": "civvis-20261110T232642Z", "turn": 127, "rival": "India", "expect": "unchanged: leads by 9 (50 to 41)"},
    {"run": "civvis-20261110T220038Z", "turn": 133, "rival": "France", "expect": "hold: leads by 13 (45 to 32)"},
    {"run": "civvis-20261110T204138Z", "turn": 130, "rival": "Egypt", "expect": "unchanged: leads by 9 (42 to 33)"},
    {"run": "civvis-20261110T192354Z", "turn": 115, "rival": "Mapuche", "expect": "hold: leads by 17 (44 to 27)"},
    {"run": "civvis-20261110T171451Z", "turn": 106, "rival": "Khmer", "expect": "hold: leads by 12 (39 to 27)"},
    {"run": "civvis-20261110T212836Z", "turn": 121, "rival": "Maori", "expect": "hold: leads by 15 (44 to 29)"},
    {"run": "civvis-20261110T232642Z", "turn": 87, "rival": "India", "expect": "unchanged: leads by 2 (33 to 31)"},
    {"run": "civvis-20261110T173750Z", "turn": 105, "rival": "Portugal", "expect": "hold: leads by 10 (37 to 27)"},
]


def cut(src, dst, turn):
    """The run's log up to and including the turn's first state frame."""
    with open(src, 'rb') as f, open(dst, 'wb') as g:
        for line in f:
            g.write(line)
            if b'"kind": "state"' in line:
                try:
                    if json.loads(line).get('turn') == turn:
                        return
                except Exception:
                    pass
    raise ValueError('no state frame for that turn')


def requested(run):
    summary = json.loads((run / 'summary.json').read_text())
    if summary.get('forced'):
        return summary['forced'], summary.get('victory_target') or 'culture', 'summary.json'
    with open(run / 'why.log') as f:
        header = json.loads(f.readline())
    return header['forced'], summary.get('victory_target') or header.get('victory') or 'culture', 'why.log header'


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        run = RUNS / case['run']
        forced, victory, source = requested(run)
        forced = [t for t in forced if t != GENE]
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'victory': victory,
                                 'genome_source': source}, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            for f in run.iterdir():
                if f.name != 'events.jsonl' and f.suffix != '.png' and f.is_file():
                    (mirror / f.name).symlink_to(f)
            cut(run / 'events.jsonl', mirror / 'events.jsonl', case['turn'])
            data = (mirror / 'events.jsonl').read_bytes()
            record['bytes'] = len(data)
            record['sha256'] = hashlib.sha256(data).hexdigest()
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', victory,
                   '--turn', str(case['turn']), '--resumed']
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=600)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': decider_genome(stderr)}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]') and ('heretic' in line.lower()
                                                               or 'faith-strike' in line
                                                               or 'Striking' in line
                                                               or ('war' in line.lower() and case['rival'] in line))]
            record['arms'].append(row)
            for f in mirror.iterdir():
                f.unlink()
            mirror.rmdir()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['planned_actions_changed'] = (off.get('payload', {}).get('decision', {}).get('native_actions')
                                             != on.get('payload', {}).get('decision', {}).get('native_actions'))
        record['journal_changed'] = off['journal'] != on['journal']
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def verbs(arm):
    orders = arm.get('payload', {}).get('orders', [])
    out = {}
    for o in orders:
        key = o.get('verb') or o.get('kind')
        out[key] = out.get(key, 0) + 1
    return orders, out


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        print(r['case']['run'], 't', r['case']['turn'], r['case']['rival'], '|', r['case']['expect'],
              'ERROR ' + r['error'] if r.get('error') else '')
        for v in r['reads']:
            print('   orders_changed', v.get('orders_changed'))
            for a in v['arms']:
                orders, counts = verbs(a)
                wars = [o for o in orders if 'WAR' in str(o.get('verb') or '').upper()
                        or 'war' in str(o.get('kind') or '')]
                print('  ', a['arm'], 'exit', a['exit'], 'orders', len(orders),
                      'condemn', counts.get('CONDEMN_HERETIC', 0), 'war', wars[:2])
                for line in a['journal'][:4]:
                    print('     ', line[:260])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
