#!/usr/bin/env python3
import os,sys
a=sys.argv[1:]
a[a.index("--civ")+1]="CIVILIZATION_MACEDON"
a += ["--capture-inputs",'/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/first-capital-research/current-input-capture']
a += ["--with",'research-follows-the-first-capital']
open('/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/first-capital-research/on-argv.json',"w").write(__import__("json").dumps(['/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/first-capital-research/civvis_orders-opt0-1172e696da41cc1a244f517ac279852784f4b9a4']+a))
os.execv('/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/first-capital-research/civvis_orders-opt0-1172e696da41cc1a244f517ac279852784f4b9a4', ['/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/first-capital-research/civvis_orders-opt0-1172e696da41cc1a244f517ac279852784f4b9a4']+a)
