#!/usr/bin/env python3
import os,sys
a=sys.argv[1:]
a[a.index("--civ")+1]="CIVILIZATION_MACEDON"
a += ["--capture-inputs",'/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/first-capital-research/registry-repair/current-input-capture']
a += ["--with",'research-follows-the-first-capital']
open('/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/first-capital-research/registry-repair/on-argv.json',"w").write(__import__("json").dumps(['/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/first-capital-research/civvis_orders-opt0-73df6e77697a063da5202c09affc11bee15067e5']+a))
os.execv('/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/first-capital-research/civvis_orders-opt0-73df6e77697a063da5202c09affc11bee15067e5', ['/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/first-capital-research/civvis_orders-opt0-73df6e77697a063da5202c09affc11bee15067e5']+a)
