from pathlib import Path
import subprocess,json,hashlib,shutil,sys,datetime,os
r=Path(__file__).parent
repo=Path.home()/"civvis-campus-above-the-sea-a489"
sys.path.insert(0,str(repo/"tools"))
import civ6_captured_read_replay as replay
from civ6_ladder import decider_genome
from native_city_route_replay import request_identity_errors,control_payload
sha=lambda data:hashlib.sha256(data).hexdigest()
intent=json.loads((r/"intent.json").read_text());tag=intent["tag"]
assert json.loads((r.parent/"native-build-process.json").read_text())["exit"]==0
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
assert head==intent["source_head"]
assert not subprocess.check_output(["git","status","--porcelain"],cwd=repo,text=True).strip()
binary=r/"candidate-civvis_orders"
assert not binary.exists()
shutil.copy2(repo/"target/ci/civvis_orders",binary)
files=subprocess.check_output(["git","ls-files","-z","src","data","Cargo.toml","Cargo.lock","build.rs"],cwd=repo).decode().split("\0")
source_manifest={name:sha((repo/name).read_bytes()) for name in files if name}
binding={"source_head":head,"binary_sha256":sha(binary.read_bytes()),"source_manifest":source_manifest,"harness_sha256":sha(Path(__file__).read_bytes()),"intent_sha256":sha((r/"intent.json").read_bytes()),"scope":intent["scope"]}
(r/"candidate-build.json").write_text(json.dumps(binding,indent=2)+"\n")
source_genome=json.loads((r/"source-genome.json").read_text());forced=source_genome["forced"]
assert tag not in forced and len(forced)==len(set(forced))
common=r/"current-capture";results=[]
for round_index,arm in enumerate(intent["arm_order"]):
 for case in intent["cases"]:
  key=[case["turn"],case["frame"]];expected=Path(case["input"]).read_bytes()
  assert len(expected)==case["input_bytes"] and sha(expected)==case["input_sha256"]
  out=r/f"query-{round_index}-{key[0]}-{key[1]}-{arm}";out.mkdir()
  (out/"events.jsonl").write_bytes(expected);assert not common.exists()
  args=[str(binary),"--mirror",str(out),"--serve","--fresh-board","--explain","--resumed","--victory","science","--civ","CIVILIZATION_INDONESIA","--capture-inputs",str(common)]
  for flag in forced:args.extend(["--with",flag])
  if arm=="on":args.extend(["--with",tag])
  assert sha(binary.read_bytes())==binding["binary_sha256"]
  started=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with (out/"stderr.log").open("w") as err:
   p=subprocess.Popen(args,cwd=repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1)
   if sys.platform=="darwin":subprocess.run(["/usr/sbin/taskpolicy","-B","-p",str(p.pid)],check=True)
   try:
    p.stdin.write(str(key[0])+"\n");p.stdin.flush();reply=replay.request_reply(p,120)
    assert not request_identity_errors(reply,*key)
    assert reply["decision"]["victory_portfolio"]["assigned_target"]=="science"
    (out/"payload.json").write_text(json.dumps(reply,indent=2)+"\n")
    actual=replay.expanded_reads(reply["input_capture"])
    assert actual and all(data==expected for data in actual)
    p.stdin.close();code=p.wait(timeout=10);assert code==0
   finally:
    if p.poll() is None:p.terminate();p.wait(timeout=5)
    p.stdout.close()
  genome=decider_genome(out/"stderr.log");assert genome
  assert (tag in genome["treatments"])==(arm=="on")
  assert set(genome["forced"])==set(forced)|({tag} if arm=="on" else set())
  old_dir=reply["input_capture"]["directory"]
  capture_map={old_dir:str(out/"recaptured"/Path(old_dir).relative_to(common))}
  shutil.move(common,out/"recaptured")
  result={"arm":arm,"round":round_index,"request":key,"argv":args,"cwd":str(repo),"exit":code,"started_utc":started,"owned_pid":p.pid,"binary_sha256":binding["binary_sha256"],"genome":genome,"payload":reply,"actual_read_count":len(actual),"shared_input_sha256":sha(expected),"shared_input_bytes":len(expected),"actual_read_bytes_sha256":[sha(data) for data in actual],"capture_directory_map":capture_map,"scope":intent["scope"]}
  (out/"result.json").write_text(json.dumps(result,indent=2)+"\n");results.append(result)
  (r/"query-results.json").write_text(json.dumps([str(r/f"query-{v['round']}-{v['request'][0]}-{v['request'][1]}-{v['arm']}/result.json") for v in results],indent=2)+"\n")
  print(json.dumps({"round":round_index,"arm":arm,"request":key,"reads":len(actual),"campus_orders":[v for v in reply["orders"] if v.get("verb")=="DISTRICT_CAMPUS"]}),flush=True)
for case in intent["cases"]:
 selected=[v for v in results if v["request"]==[case["turn"],case["frame"]]]
 off=[v for v in selected if v["arm"]=="off"];on=[v for v in selected if v["arm"]=="on"]
 assert control_payload(off[0]["payload"])==control_payload(off[1]["payload"])
 assert control_payload(on[0]["payload"])==control_payload(on[1]["payload"])
 a,b=[dict(v[0]["genome"]) for v in [off,on]]
 for field in ["forced","treatments"]:
  before,after=a.pop(field),b.pop(field)
  assert set(after)-{tag}==set(before) and tag not in before and tag in after
 assert a==b
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()==head
assert all(sha((repo/name).read_bytes())==digest for name,digest in source_manifest.items())
assert sha(binary.read_bytes())==binding["binary_sha256"]
(r/"completed.json").write_text(json.dumps({"completed_queries":len(results),"all_actual_registered_reads_match_fixed_input":True,"same_arm_payload_repeats":True,"effective_genomes_differ_only_new_flag":True,"source_and_binary_unchanged":True,"scope":intent["scope"]},indent=2)+"\n")
print("All fixed-input queries and repeat/genome/read controls passed",flush=True)
