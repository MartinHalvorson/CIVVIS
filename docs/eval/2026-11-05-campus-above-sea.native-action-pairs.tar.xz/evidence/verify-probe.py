from pathlib import Path
import json,hashlib,sys,datetime
r=Path(__file__).parent;repo=Path.home()/"civvis-campus-above-the-sea-a489"
sys.path.insert(0,str(repo/"tools"))
import civ6_captured_read_replay as replay
from native_city_route_replay import control_payload,request_identity_errors
from civ6_ladder import decider_genome
sha=lambda data:hashlib.sha256(data).hexdigest()
intent=json.loads((r/"intent.json").read_text());tag=intent["tag"]
binding=json.loads((r/"candidate-build.json").read_text())
assert sha((r/"candidate-civvis_orders").read_bytes())==binding["binary_sha256"]
paths=[Path(p) for p in json.loads((r/"query-results.json").read_text())];results=[json.loads(p.read_text()) for p in paths]
assert len(results)==len(intent["cases"])*len(intent["arm_order"])
expected={};worlds={};count=0
for case in intent["cases"]:
 key=(case["turn"],case["frame"]);raw=Path(case["input"]).read_bytes()
 assert sha(raw)==case["input_sha256"] and len(raw)==case["input_bytes"];expected[key]=raw
 plots={};state=None
 for line in raw.splitlines():
  event=json.loads(line)
  if event.get("turn",0)>key[0]:continue
  if event.get("kind")=="tiles":
   for tile in event.get("plots",[]):plots[(tile["x"],tile["y"])]=tile
  if event.get("kind")=="state" and (event.get("turn"),event.get("frame"))==key:state=event
 assert state is not None
 worlds[key]=({city["id"]:city for city in state["cities"]},plots)
for path,result in zip(paths,results):
 assert result["exit"]==0 and result["binary_sha256"]==binding["binary_sha256"]
 assert sha(Path(result["argv"][0]).read_bytes())==binding["binary_sha256"]
 assert not request_identity_errors(result["payload"],*result["request"])
 assert decider_genome(path.parent/"stderr.log")==result["genome"]
 capture=dict(result["payload"]["input_capture"]);capture["directory"]=result["capture_directory_map"][capture["directory"]]
 actual=replay.expanded_reads(capture);raw=expected[tuple(result["request"])]
 assert actual and len(actual)==result["actual_read_count"] and all(data==raw for data in actual)
 assert result["actual_read_bytes_sha256"]==[sha(data) for data in actual]
 assert result["shared_input_sha256"]==sha(raw) and result["shared_input_bytes"]==len(raw)
 count+=len(actual)
report=[];fresh_target_changed=False
for case in intent["cases"]:
 key=[case["turn"],case["frame"]]
 a,b,c,d=sorted([x for x in results if x["request"]==key],key=lambda x:x["round"])
 assert [x["arm"] for x in [a,b,c,d]]==["off","on","on","off"]
 assert control_payload(a["payload"])==control_payload(d["payload"])
 assert control_payload(b["payload"])==control_payload(c["payload"])
 assert all(x["actual_read_bytes_sha256"]==a["actual_read_bytes_sha256"] for x in [b,c,d])
 genomes=[dict(x["genome"]) for x in [a,b]]
 for field in ["treatments","forced"]:
  off,on=[set(g.pop(field)) for g in genomes]
  assert tag not in off and on-off=={tag} and off<=on
 assert genomes[0]==genomes[1]
 def args(result):
  argv=list(result["argv"]);argv[argv.index("--mirror")+1]="<same-fixed-input>"
  if result["arm"]=="on":i=argv.index(tag);assert argv[i-1]=="--with";del argv[i-1:i+1]
  return argv
 assert args(a)==args(b)
 cities,plots=worlds[tuple(key)];changes=[]
 off_orders=a["payload"]["orders"];on_orders=b["payload"]["orders"]
 assert len(off_orders)==len(on_orders)
 for before,after in zip(off_orders,on_orders):
  if before==after:continue
  assert before["kind"] in ["produce","produce_next"] and before["verb"]=="DISTRICT_CAMPUS"
  assert {k:v for k,v in before.items() if k not in ["x","y"]}=={k:v for k,v in after.items() if k not in ["x","y"]}
  city=cities[before["subject"]];old=(before["x"],before["y"]);new=(after["x"],after["y"])
  assert not any(d["type"]=="DISTRICT_CAMPUS" for d in city["districts"])
  assert city.get("producing")!="DISTRICT_CAMPUS"
  assert "BUILDING_FLOOD_BARRIER" not in set(city["buildings"])-set(city.get("pillaged_buildings",[]))
  offers=[q for q in city["buildable"] if q["t"]=="DISTRICT_CAMPUS"];assert len(offers)==1
  legal={(p["x"],p["y"]) for p in offers[0]["s"]}
  assert old in legal and new in legal and old!=new
  assert plots[old]["cl"]>=0 and plots[new]["cl"]==-1
  assert plots[new]["flooded"] is False and plots[new]["submerged"] is False
  changes.append({"city":city["id"],"name":city["name"],"off":old,"on":new,"legal_offers":sorted(legal)})
  if key==[42,0] and city["id"]==196610:fresh_target_changed=True
 assert not any(change["city"]==196610 for change in changes) if key!=[42,0] else True
 report.append({"request":key,"changed_orders":changes,"all_other_order_fields_identical":True,"same_arm_full_payload_reproduces":True,"actual_read_sequences_match":True,"only_named_genome_bit_differs":True})
assert fresh_target_changed,"The target fresh Campus did not change; this is not firing evidence"
result={"recorded_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"queries":len(results),"verified_actual_reads":count,"candidate_source":binding["source_head"],"candidate_binary_sha256":binding["binary_sha256"],"pairs":report,"scope":intent["scope"]}
(r/"independent-verification.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
