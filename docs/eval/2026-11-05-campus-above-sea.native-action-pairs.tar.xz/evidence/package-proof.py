from pathlib import Path
import json,tarfile,hashlib,shutil
r=Path(__file__).parent;repo=Path.home()/"civvis-campus-above-the-sea-a489";sha=lambda b:hashlib.sha256(b).hexdigest()
proof=json.loads((r/"independent-verification.json").read_text());assert proof["queries"]==12 and proof["verified_actual_reads"]==204
intent=json.loads((r/"intent.json").read_text());binding=json.loads((r/"candidate-build.json").read_text())
results=[json.loads(Path(p).read_text()) for p in json.loads((r/"query-results.json").read_text())]
pairs=r/"pairs";pairs.mkdir(exist_ok=True);members=[]
for case in intent["cases"]:
 key=[case["turn"],case["frame"]]
 for repeat,off_round,on_round in [(1,0,1),(2,3,2)]:
  arms=[next(x for x in results if x["request"]==key and x["round"]==i) for i in [off_round,on_round]]
  assert arms[0]["actual_read_bytes_sha256"]==arms[1]["actual_read_bytes_sha256"]
  record={"complete":True,"request":key,"repeat":repeat,"scope":intent["scope"],"reads":[{"complete":True,"sha256":arms[0]["shared_input_sha256"],"bytes":arms[0]["shared_input_bytes"],"actual_reads_per_arm":arms[0]["actual_read_count"],"arms":[{k:a[k] for k in ["arm","exit","argv","genome","payload","binary_sha256"]} for a in arms]}]}
  name=f"pairs/{key[0]}-{key[1]}-repeat-{repeat}.json";(r/name).write_text(json.dumps(record,indent=2)+"\n");members.append(name)
capture_manifest=[]
for result in results:
 q=r/f"query-{result['round']}-{result['request'][0]}-{result['request'][1]}-{result['arm']}"
 cap=result["payload"]["input_capture"];actual=Path(result["capture_directory_map"][cap["directory"]]);blob=(actual/"bytes.bin").read_bytes()
 assert sha(blob)==result["shared_input_sha256"],"Deduplication requires exact whole capture byte identity"
 capture_manifest.append({"query":q.name,"request":result["request"],"blob":f"inputs/input-{result['request'][0]}-{result['request'][1]}/events.jsonl","blob_sha256":sha(blob),"index":f"results/{q.name}/snapshots.jsonl","index_sha256":sha((actual/"snapshots.jsonl").read_bytes())})
(r/"capture-archives.json").write_text(json.dumps(capture_manifest,indent=2)+"\n")
archive=r/"native-action-pairs.tar.xz"
with tarfile.open(archive,"w:xz",preset=6) as tar:
 for name in members:tar.add(r/name,arcname=name)
 for name in ["intent.json","candidate-build.json","source-genome.json","independent-verification.json","run-probe.py","verify-probe.py","package-proof.py","capture-archives.json","completed.json"]:tar.add(r/name,arcname="evidence/"+name)
 for name in ["native-build-intent.json","native-build-process.json","native-build.log","source-manifest.json","native-facts.json","deployment-preserved.json","registry-order-preserved.json"]:tar.add(r.parent/name,arcname="evidence/"+name)
 for case in intent["cases"]:
  folder=Path(case["input"]).parent
  for name in ["events.jsonl","source-decision.json"]:tar.add(folder/name,arcname=f"inputs/{folder.name}/{name}")
 for result,meta in zip(results,capture_manifest):
  q=r/meta["query"]
  for name in ["result.json","stderr.log","payload.json"]:tar.add(q/name,arcname=f"results/{q.name}/{name}")
  directory=Path(result["capture_directory_map"][result["payload"]["input_capture"]["directory"]])
  tar.add(directory/"snapshots.jsonl",arcname=meta["index"])
relative="docs/eval/2026-11-05-campus-above-sea.native-action-pairs.tar.xz"
shutil.copy2(archive,repo/relative)
manifest={"kind":"captured_native_action_pairs_v1","tag":intent["tag"],"scope":f"Twelve fixed-input OFF/ON/ON/OFF queries in three native states, fresh private controller per query; 204 actual registered reads independently verified. The fresh42/0Campus order changes only coordinates from known lowland17,29 to originally legal safe15,29; foundation43/0 and flooded-repair138/0 orders remain equal. Complete payload repeats and exactly one effective genotype difference verified. Source {binding['source_head']}, executable SHA256 {binding['binary_sha256']}. Recaptured bytes deduplicated losslessly against identical input blobs, with exact per-query index hashes. Proposal firing only: no original controller-history reproduction, host execution, avoided flooding, saved-turn or strength claim.","archive":{"path":relative,"sha256":sha(archive.read_bytes())},"members":members}
(repo/"docs/gene_screens/fires/campus-above-the-sea.action-pairs.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps({"archive_bytes":archive.stat().st_size,"archive_sha256":manifest["archive"]["sha256"],"paired_members":len(members)}))
