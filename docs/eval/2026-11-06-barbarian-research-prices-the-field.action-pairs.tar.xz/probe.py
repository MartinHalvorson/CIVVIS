"""Run only the prospectively bounded four-query fixed-input mechanism probe."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,sys,time
b=Path(__file__).parent
w=Path.home()/'civvis-barbarian-field-parity-5bf7'
binary=w/'target/ci/civvis_orders'
read=lambda p:json.loads(p.read_text())
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
sha=lambda v:hashlib.sha256(v).hexdigest()
protocol=read(b/'barbarian-field-parity-fixed-input/protocol.json')
receipt=read(b/'barbarian-field-parity-fixed-input/receipt.json')
blob=(b/'barbarian-field-parity-fixed-input/events-prefix-70-0.jsonl').read_bytes()
assert sha(blob)==receipt['input_sha256']==protocol['input_sha256']
assert len(blob)==receipt['input_bytes']==protocol['input_bytes']
assert not (b/'barbarian-field-parity-fixed-probe-location.json').exists()
assert subprocess.run(['git','diff','--quiet','HEAD','--','src','data','Cargo.toml','Cargo.lock'],cwd=w).returncode==0
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
assert binary.is_file()
r=b/('barbarian-field-parity-fixed-probe-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));r.mkdir()
save(b/'barbarian-field-parity-fixed-probe-location.json',{'root':str(r),'offline_only':True})
save(r/'protocol.json',protocol)
save(r/'source.json',{'head':source,'binary_sha256':sha(binary.read_bytes()),'worktree':str(w),'protocol_sha256':sha((b/'barbarian-field-parity-fixed-input/protocol.json').read_bytes()),'scope':protocol['scope'],'probe_sha256':sha(Path(__file__).read_bytes()),'source_tree':subprocess.check_output(['git','rev-parse','HEAD:src'],cwd=w,text=True).strip(),'data_tree':subprocess.check_output(['git','rev-parse','HEAD:data'],cwd=w,text=True).strip()})
sys.path.insert(0,str(b/'replay-tail-analysis-tools-d152cd119e/tools'))
import civ6_captured_read_replay as replay
from civ6_brain import Decider
from civ6_ladder import decider_genome
assert sha(Path(replay.__file__).read_bytes())=='8a9b3ac1cf12b98a1662dd8ec0e327a6171d4b0b72286183d20d3a20586f65cb'
shared=r/'capture-common'
def command(directory,on):
 d=Decider(binary,directory,'science',strategy=None,with_=protocol['shared_forced_tags']+([protocol['tag']] if on else []),capture_inputs=True)
 d.civ='CIVILIZATION_INDONESIA';d.capture_directory=shared
 return d.command()
def retain_capture(directory):
 if shared.exists():shutil.move(str(shared),str(directory/'recaptured'))

def compare_genomes(off,on):
 a=dict(off);c=dict(on)
 for field in ['treatments','forced']:
  before=set(a.pop(field));after=set(c.pop(field));assert protocol['tag'] not in before
  assert after==before|{protocol['tag']}
 assert a==c

def query(role,on):
 directory=r/role;directory.mkdir();(directory/'events.jsonl').write_bytes(blob)
 argv=command(directory,on);save(directory/'invocation.json',{'argv':argv,'cwd':str(w)})
 proc=None;footer={'complete':False};started=time.monotonic()
 try:
  with (directory/'stderr.log').open('w') as stderr:
   proc=subprocess.Popen(argv,cwd=w,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,text=True,bufsize=1)
   proc.stdin.write('70\n');proc.stdin.flush();row=replay.request_reply(proc,180)
   save(directory/'reply.json',row)
   proc.stdin.close();footer['exit']=proc.wait(timeout=15);assert footer['exit']==0
   assert time.monotonic()-started<900
  assert not replay.request_identity_errors(row,70,0)
  retain_capture(directory)
  capture=dict(row['input_capture'],directory=str(directory/'recaptured'))
  actual=replay.expanded_reads(capture);assert actual and all(x==blob for x in actual)
  genome=decider_genome(directory/'stderr.log');assert genome
  save(directory/'genome.json',genome)
  save(directory/'read-verification.json',{'complete':True,'actual_reads':len(actual),'each_read_bytes':len(blob),'each_read_sha256':sha(blob),'recorded_capture_directory':row['input_capture']['directory'],'sealed_capture_directory':str(directory/'recaptured')})
  footer['complete']=True
  print(role,'exit0',len(actual),'verified reads',flush=True)
  return {'arm':'on' if on else 'off','argv':argv,'cwd':str(w),'exit':0,'genome':genome,'payload':replay.control_payload(row),'actual_reads':len(actual)}
 finally:
  if proc is not None and proc.poll() is None:
   proc.terminate()
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:proc.kill();proc.wait()
   footer['terminated_exit']=proc.returncode
  retain_capture(directory);save(directory/'process-footer.json',footer)

try:
 cold={}
 for role,on in [('cold-off',False),('cold-on',True)]:
  directory=r/role;directory.mkdir();argv=command(directory,on)
  result=subprocess.run(argv,cwd=w,input='',text=True,capture_output=True,timeout=30)
  (directory/'stderr.log').write_text(result.stderr);(directory/'stdout.log').write_text(result.stdout)
  assert result.returncode==0 and not result.stdout
  cold[on]=decider_genome(directory/'stderr.log');assert cold[on]
  retain_capture(directory);save(directory/'metadata.json',{'argv':argv,'cwd':str(w),'exit':result.returncode,'genome':cold[on]})
 compare_genomes(cold[False],cold[True])
 assert protocol['tag'] not in cold[False]['treatments']
 arms={}
 for role,on in [('OFF-0',False),('OFF-1',False)]:arms[role]=query(role,on)
 assert replay.exact_fact(arms['OFF-0']['payload'],arms['OFF-1']['payload'])
 assert arms['OFF-0']['genome']==arms['OFF-1']['genome']==cold[False]
 for role,on in [('ON-0',True),('ON-1',True)]:arms[role]=query(role,on)
 assert replay.exact_fact(arms['ON-0']['payload'],arms['ON-1']['payload'])
 assert arms['ON-0']['genome']==arms['ON-1']['genome']==cold[True]
 compare_genomes(arms['OFF-0']['genome'],arms['ON-0']['genome'])
 assert len({x['actual_reads'] for x in arms.values()})==1
 assert sha(binary.read_bytes())==read(r/'source.json')['binary_sha256']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()==source
 for n in [0,1]:
  save(r/('pair-'+str(n)+'.json'),{'complete':True,'reads':[{'complete':True,'bytes':len(blob),'sha256':sha(blob),'arms':[arms['OFF-'+str(n)],arms['ON-'+str(n)]]}],'scope':protocol['scope']})
 off=arms['OFF-0']['payload']['orders'];on=arms['ON-0']['payload']['orders']
 report={'complete':True,'repeated_arms_identical':True,'actual_reads_per_query':arms['OFF-0']['actual_reads'],'orders_differ':off!=on,'off_research':[x for x in off if x.get('kind')=='research'],'on_research':[x for x in on if x.get('kind')=='research'],'scope':protocol['scope']}
 save(r/'result.json',report);print(json.dumps(report,indent=2),flush=True)
except BaseException as error:
 save(r/'failure-retained.json',{'error':repr(error),'no_native_game_launched':True});raise
