import pathlib,sys
from lupa.lua51 import LuaRuntime
path=pathlib.Path(sys.argv[1]).resolve();lua=LuaRuntime(unpack_returned_tuples=True);lua.globals().arg=lua.table_from({0:str(path)});lua.execute(path.read_text())
