#!/usr/bin/env python3
import os,sys
a=sys.argv[1:]
a[a.index("--civ")+1]="CIVILIZATION_MACEDON"
a += ["--capture-inputs",'/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/land-army-host-price/current-input-capture']
a += ["--with",'land-army-asks-the-host-price']
open('/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/land-army-host-price/on-argv.json',"w").write(__import__("json").dumps(['/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/land-army-host-price/civvis_orders-opt0-471ca107be439d12d85ea0edfdcc8e6fff12da1d']+a))
os.execv('/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/land-army-host-price/civvis_orders-opt0-471ca107be439d12d85ea0edfdcc8e6fff12da1d', ['/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/land-army-host-price/civvis_orders-opt0-471ca107be439d12d85ea0edfdcc8e6fff12da1d']+a)
