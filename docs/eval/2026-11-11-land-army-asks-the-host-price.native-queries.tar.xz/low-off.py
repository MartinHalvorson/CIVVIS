#!/usr/bin/env python3
import os,sys
a=sys.argv[1:]
a[a.index("--civ")+1]="CIVILIZATION_MACEDON"
os.execv('/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/land-army-host-price/civvis_orders-opt0-8e917c6ee077e1f4bb4e7e46606dd53e4ac7a013', ['/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/land-army-host-price/civvis_orders-opt0-8e917c6ee077e1f4bb4e7e46606dd53e4ac7a013']+a)
