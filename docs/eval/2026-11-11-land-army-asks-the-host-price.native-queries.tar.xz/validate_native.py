"""Persistent native controls and actual-reader proof for one fixed worker."""
from pathlib import Path
import os,sys,json,subprocess,hashlib,shutil,re,ast,time
root=Path(__file__).parent
repo=Path('/Users/martbot-mbp-m5-max-128/civvis-land-army-asks-the-host-price-59b7')
sys.path.insert(0,str(repo/'tools'))
from civ6_captured_read_replay import expanded_reads,read_sha256
from civ6_ladder import decider_genome
tag='land-army-asks-the-host-price'
receipt=json.loads((root.parent/'candidate-v3-build.json').read_text());assert receipt['exit_code']==0 and receipt['source_clean_after']
binary=Path(receipt['binary']);sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(binary.read_bytes())==receipt['sha256']
run=Path('/Users/martbot-mbp-m5-max-128/civvis-civ6-runs/control/civvis-20261111T100029Z')
frozen=root/'native-prefix';frozen.mkdir(exist_ok=True)
for name in ['events.jsonl','decisions.jsonl']:
 if not (frozen/name).exists():(frozen/name).write_bytes((run/name).read_bytes())
line=(run/'brain.log').open().readline();forced=ast.literal_eval(re.search(r'forced=(\[.*?\]) withheld=',line).group(1));assert tag not in forced
(root/'native-force.txt').write_text(','.join(forced)+'\n')
original='/Users/martbot-mbp-m5-max-128/civvis-civ6-runs/decider-snapshots/civvis-20261111T100029Z/civvis_orders'
capture=root/'current-input-capture'
for arm,exe in [('original',original),('off',str(binary)),('on',str(binary))]:
 p=root/(arm+'.py');extra=''
 if arm!='original':extra+='a += ["--capture-inputs",'+repr(str(capture))+']\n'
 if arm=='on':extra+='a += ["--with",'+repr(tag)+']\n'
 if arm!='original':extra+='open('+repr(str(root/(arm+'-argv.json')))+',"w").write(__import__("json").dumps(['+repr(exe)+']+a))\n'
 p.write_text('#!/usr/bin/env python3\nimport os,sys\na=sys.argv[1:]\na[a.index("--civ")+1]="CIVILIZATION_MACEDON"\n'+extra+'os.execv('+repr(exe)+', ['+repr(exe)+']+a)\n');p.chmod(0o755)
state={'pid':os.getpid(),'source':receipt['source_commit'],'started':time.time(),'step':'off-control','steps':[]}
def save(): (root/'native-validation-state.json').write_text(json.dumps(state,indent=2)+'\n')
def rows(arm):
 p=root/(arm+'-replay')/'candidate/decisions.jsonl';return {(x['decision']['turn'],x['decision']['frame']):x for x in map(json.loads,p.read_text().splitlines())}
signatures={};selected={};genomes={}
save()
try:
 for arm in ['off','on']:
  state['step']=arm+'-replay';save()
  command=[sys.executable,str(repo/'tools/native_city_route_replay.py'),'--run',str(frozen),'--baseline',str(root/'original.py'),'--candidate',str(root/(arm+'.py')),'--force-file',str(root/'native-force.txt'),'--out',str(root/(arm+'-replay')),'--through-turn','65','--explain']
  if not (root/(arm+'-replay/provenance.json')).exists():
   with (root/(arm+'-replay.log')).open('w') as log:
    proc=subprocess.Popen(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT);state['replay_pid']=proc.pid;save();code=proc.wait()
   assert code==0,(arm,code)
  else:
   assert all(x==0 for x in json.loads((root/(arm+'-replay/provenance.json')).read_text())['returncodes'].values())
  control=json.loads((root/(arm+'-replay/native-control.json')).read_text());assert control['gate_passed'] and control['matched_frames']==control['frames']
  if arm=='off':
   original_rows={(x['decision']['turn'],x['decision']['frame']):x for x in map(json.loads,(root/'off-replay/baseline/decisions.jsonl').read_text().splitlines())}
   candidate_rows=rows('off');assert original_rows.keys()==candidate_rows.keys()
   # The sole additional root field is requested capture audit, not planning.
   for key,payload in candidate_rows.items():
    assert {k:v for k,v in payload.items() if k!='input_capture'}==original_rows[key],key
   state['off_complete_planning_and_protocol_parity']=len(candidate_rows);save()
  replies=rows(arm);signatures[arm]={}
  for key,payload in replies.items():
   meta=payload['input_capture'];assert meta['complete']
   consumed=expanded_reads(meta);assert consumed
   signatures[arm][key]=list(zip(read_sha256(consumed),map(len,consumed)))
   if key==(50,0):selected[arm]={'payload':payload,'reads':consumed}
  genomes[arm]=decider_genome(root/(arm+'-replay/candidate/why.log'));assert genomes[arm]
  shutil.move(str(capture),str(root/(arm+'-input-capture')))
  state['steps'].append({'arm':arm,'native_controls':{k:control[k] for k in ['gate_passed','frames','matched_frames','changed_complete_reply_frames']},'reader_requests':len(signatures[arm])});save()
 assert signatures['off']==signatures['on'],'Actual consumer byte sequence/count differs'
 for field in ['forced','treatments']:
  assert set(genomes['on'][field])-set(genomes['off'][field])=={tag}
  assert not set(genomes['off'][field])-set(genomes['on'][field])
 for field in genomes['off'].keys()-{'forced','treatments'}:assert genomes['off'][field]==genomes['on'][field]
 def material_orders(a):
  return [x for x in selected[a]['payload']['orders'] if x.get('kind')=='buy' and (x.get('verb') or '').startswith('RESOURCE_IRON=')]
 assert len(material_orders('off'))==len(material_orders('on'))==1
 off,on=material_orders('off')[0],material_orders('on')[0]
 assert off['verb'].startswith('RESOURCE_IRON=2;') and on['verb']=='RESOURCE_IRON=2',(off,on)
 assert 0<=off['x']<on['x']<=230-95,(off,on)
 arms=[{'arm':a,'exit':0,'argv':json.loads((root/(a+'-argv.json')).read_text()),'genome':genomes[a],'payload':selected[a]['payload'],'binary_sha256':receipt['sha256']} for a in ['off','on']]
 unique={sha(data):data for data in selected['off']['reads']};assert selected['off']['reads']==selected['on']['reads']
 record={'complete':True,'source_commit':receipt['source_commit'],'binary_sha256':receipt['sha256'],'scope':'Persistent native query after complete warmup from turn1 through50/frame0. Actual native stock0Iron, Gold230, a quoted65Gold+2Iron Hypaspist upgrade and peaceful Iron seller. OFF emits model Horse barter; ON requests a cash-only host price capped within Gold230 minus upgrade/emergency reserve95. Full request/input/reader traces archived. Proposal activation only; no host acceptance, obtained resource, executed upgrade, counterfactual capture or win-rate claim.','source':{'run':run.name,'turn':50,'frame':0,'warmup_queries':sum(k<=(50,0) for k in signatures['off']),'reader_sequence':signatures['off'][(50,0)]},'reads':[{'complete':True,'sha256':h,'bytes':len(data),'arms':arms} for h,data in unique.items()]}
 (root/'persistent-t50-pair.json').write_text(json.dumps(record,indent=2)+'\n')
 (root/'reader-signatures.json').write_text(json.dumps({a:[{'turn':k[0],'frame':k[1],'reads':v} for k,v in d.items()] for a,d in signatures.items()},indent=2)+'\n')
 assert sha(binary.read_bytes())==receipt['sha256']
 state.update(step='complete',exit_code=0,finished=time.time(),material_orders={'off':material_orders('off'),'on':material_orders('on')},reader_requests=len(signatures['off']),captured_query_reads=len(selected['off']['reads']));save();print(json.dumps({k:state[k] for k in ['step','source','material_orders','reader_requests','captured_query_reads']}))
except BaseException as e:
 state.update(step='failed',error=repr(e),finished=time.time());save();raise
