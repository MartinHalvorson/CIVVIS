#!/usr/bin/env python3
import os,sys
a=sys.argv[1:]
a[a.index("--civ")+1]="CIVILIZATION_MACEDON"
os.execv('/Users/martbot-mbp-m5-max-128/civvis-civ6-runs/decider-snapshots/civvis-20261111T091313Z/civvis_orders', ['/Users/martbot-mbp-m5-max-128/civvis-civ6-runs/decider-snapshots/civvis-20261111T091313Z/civvis_orders']+a)
