import pathlib,json,gzip,hashlib,tarfile,copy,collections,datetime,subprocess,sys
w=pathlib.Path('/Users/martbot-mbp-m5-max-128/civvis-forward-airfield-native-trial-b35e');t=pathlib.Path('/tmp/civvis-forward-airfield-native-trial-b35e');control=pathlib.Path('/Users/martbot-mbp-m5-max-128/civvis-civ6-runs/control');experiment=pathlib.Path('/Users/martbot-mbp-m5-max-128/civvis-civ6-runs/experiments/2026-10-26-forward-airfield-native-trial-codex-1026c-root');base='2026-10-26-forward-airfield-native';d=json.loads(gzip.decompress((t/'collection-08-final.json.gz').read_bytes()));attempts=[a for s in d['assignments'] for a in s['attempts']];assert len(d['assignments'])==48 and len(attempts)==48 and all(a['game_stopped_from_summary'] for a in attempts);assert d['assignment_state']['cutoff']['action']=='removed_owned_screen' and not d['assignment_state']['overruns'];capital=json.loads(gzip.decompress((t/'capital-outcomes-01-final.json.gz').read_bytes()));assert capital['complete_registered_cohort'] and len(capital['attempts'])==48 and not capital['pending']
expected=json.loads((experiment/'profile-controls-03-civvis-20261026T063420Z/profile-controls.json').read_text())['reads'][0]['arms'][0]['genome']
def clean(g):
 g=copy.deepcopy(g)
 for key in ['treatments','forced']:g[key]=[x for x in g[key] if x!='forward-airfield-project']
 return g
assert len(expected['treatments'])==501 and len(expected['forced'])==191
profiles=[];identities=[];stable=[];files={};known={'85d5a904f8df01055d13775e5285fe41737a7a02d96abe61d3105ab0f53a09'}
# Exact qualified baseline, already sealed in activation capsule.
known={'85d5a904f8df01055d13775e5285fe41737a7a02d96abe61dfe3105ab0f53a09'}
previous=json.loads(gzip.decompress((t/'collection-06.json.gz').read_bytes()));old={a['tag'] for s in previous['assignments'] for a in s['attempts'] if a['game_stopped_from_summary']};sealed={}
for name in ['cohort-01.tar.xz','cohort-02.tar.xz','cohort-03.tar.xz']:
 p=t/name
 with tarfile.open(p) as tar:m=json.load(tar.extractfile('manifest.json'))
 for label,v in m['files'].items():sealed.setdefault((v['bytes'],v['sha256']),[]).append({'archive':name,'member':label})
coverage=[];new=[];updates=[]
for a in attempts:
 root=control/a['tag'];g=a['played_genome'];assert g is not None and clean(g)==expected,a['tag'];assert all(len(g[k])==len(set(g[k])) for k in ['treatments','forced']);profiles.append({'tag':a['tag'],'candidate':a['played_candidate'],'whole_genome_equal_after_only_candidate_removal':True,'treatments':len(g['treatments']),'forced':len(g['forced'])})
 late=False
 for name,identity in a['files'].items():
  p=root/name;before=p.stat();raw=p.read_bytes();after=p.stat();sha=hashlib.sha256(raw).hexdigest();assert sha==identity['sha256'] and len(raw)==identity['bytes'];assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns);stable.append({'tag':a['tag'],'name':name,'bytes':len(raw),'sha256':sha,'read_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});match=sealed.get((len(raw),sha),[]);coverage.append({'tag':a['tag'],'name':name,'prior_members':match,'current_identity':identity});late|=not bool(match)
 include=a['tag'] not in old or late
 if a['tag'] not in old:new.append(a['tag'])
 elif late:updates.append(a['tag'])
 if include:
  for p in sorted(root.rglob('*')):
   if p.is_file() and p.suffix.lower() not in {'.png','.jpg','.jpeg','.gif','.webp','.bmp','.mp4','.pyc'}:files['control/'+str(p.relative_to(control))]=str(p)
 for rt in a['runtime_updates']:
  p=pathlib.Path(rt['binary']);raw=p.read_bytes();sha=hashlib.sha256(raw).hexdigest();assert sha==rt['binary_sha256'];identities.append({'tag':a['tag'],'runtime':rt,'bytes':len(raw),'sha256':sha})
  if sha not in known:files['binaries/'+sha+'/civvis_orders']=str(p);known.add(sha)
(t/'final-profile-checks-01.json').write_text(json.dumps(profiles,indent=2)+'\n');(t/'final-binary-identities-01.json').write_text(json.dumps(identities,indent=2)+'\n');(t/'final-component-stability-01.json').write_text(json.dumps(stable,indent=2)+'\n');(t/'final-prior-component-coverage-01.json').write_text(json.dumps({'newly_stopped':new,'updated_previously_archived':updates,'components':coverage},indent=2)+'\n')
seats=collections.Counter(json.dumps((a['summary'] or {}).get('seat',{}),sort_keys=True) for a in attempts);seat_fields={key:dict(collections.Counter(str((a['summary'] or {}).get('seat',{}).get(key)) for a in attempts)) for key in ['difficulty','civ','leader','speed','map','size','players','local_player']}
counts={'assigned':48,'attempts':48,'candidate_on':sum(a['played_candidate'] is True for a in attempts),'candidate_off':sum(a['played_candidate'] is False for a in attempts),'operator_unknown':sum(not a['observed_host_outcome_events'] for a in attempts),'host_outcome_attempts':sum(bool(a['observed_host_outcome_events']) for a in attempts),'wins':sum(any(e.get('won') is True for e in a['observed_host_outcome_events']) for a in attempts),'seat_fields':seat_fields,'new_raw_attempts':new,'updated_old_raw_attempts':updates,'binary_counts':dict(collections.Counter(r['sha256'] for r in identities)),'capitals_complete':capital['complete_registered_cohort'],'unknown_founders':sum(bool(a['unknown_original_capital_founders']) for a in capital['attempts']),'home_capital_loss_markers':sum(len(a['observed_original_capital_losses']) for a in capital['attempts'])};(t/'final-counts-01.json').write_text(json.dumps(counts,indent=2)+'\n')
for name in ['collection-08-final.json.gz','collection-08-final.log','capital-outcomes-01-final.json.gz','capital-outcomes-01-final.log','assignment-cutoff-state-01.json','final-profile-checks-01.json','final-binary-identities-01.json','final-component-stability-01.json','final-prior-component-coverage-01.json','final-counts-01.json','construction-witness-01.json','construction-witness-01.log']:
 files['final/'+name]=str(t/name)
for p in t.glob('controls-final-04-*.log'):files['final/'+p.name]=str(p)
for name in ['state.json','observer.log','observer-process.json']:files['observer/'+name]=str(experiment/name)
for suffix in ['collect.py','collect-tests.py','observer.py','observer-tests.py','qualify-profile.py','qualify-profile-tests.py','capital-outcomes.py','construction-witness.py']:
 p=w/'docs/eval'/f'{base}.{suffix}';files['source/'+p.name]=str(p)
p=w/'docs/eval/2026-10-25-culture-air-native-screen.capital-outcomes.py';files['source/'+p.name]=str(p)
files['source/prepare-final-packet-04.py']=str(pathlib.Path(__file__));files['source/pack-evidence.py']='/tmp/civvis-forward-airfield-project-8c23/pack-evidence.py'
(t/'cohort-04-final.spec.json').write_text(json.dumps({'scope':'Complete fixed48Native forward-airfield cohort. All newly stopped attempts afterfirst30 plusanyupdatedoldraws, every nonimage raw/capture/SQLite companion. Actualnewadapterbytes retained once, old85d already activation. Fullwhole-genome/malformed/component stability/capital/controls/cutoff sourcebindings. Independentper-file readtimes/hash checks, no atomic snapshot or causalstrengthclaim.','files':files},indent=2)+'\n');print(json.dumps({'new':len(new),'updates':updates,'files':len(files),'counts':{k:v for k,v in counts.items() if k not in ['new_raw_attempts','updated_old_raw_attempts']}}),flush=True)
subprocess.run([sys.executable,'/tmp/civvis-forward-airfield-project-8c23/pack-evidence.py','--spec',str(t/'cohort-04-final.spec.json'),'--out',str(t/'cohort-04-final.tar.xz')],check=True)
