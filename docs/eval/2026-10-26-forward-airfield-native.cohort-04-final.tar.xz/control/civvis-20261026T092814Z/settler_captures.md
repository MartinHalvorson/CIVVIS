# Settler captures — civvis-20261026T092814Z

1 capture(s). Mechanism is the first match in the operator's order; every match is listed.

## t49 settler 1179658 at (31,12) — `unclassified`

- detected by: `unit_captured`, captor player 63 (barbarian)
- mechanisms matched: none
- nearest hostile: none
- guard: UNIT_WARRIOR str 20 hp 96 mv 3 at (29,13) d=2 id 131073 [escort_cap_unresolved]
- site: (31,11) — hostile seen within 3 in the last 5 turns: False; camp within 3: False

### Settler t-2..t

| turn | pos | moves | activity | hostiles within 3 | ours within 2 |
|---|---|---|---|---|---|
| t47 | (30,13) | 0 | awake | none | UNIT_WARRIOR str 20 hp 96 mv 0 at (30,13) d=0 id 131073 |
| t48 | (31,12) | 1 | awake | none | UNIT_WARRIOR str 20 hp 96 mv 1 at (29,13) d=2 id 131073 |
| t49 | (31,12) | 3 | awake | none | UNIT_WARRIOR str 20 hp 96 mv 3 at (29,13) d=2 id 131073 |

### Orders (settler and guard)

- `{"guard": 131073, "kind": "escort_cap_synced", "sent": [30, 13], "settler": 1179658, "t": 1793007039, "turn": 47, "utc": "2026-10-26T09:30:39.252Z", "want": [30, 13]}`
- `{"checked_on": 48, "kind": "order_verified", "order_kind": "unit", "subject": 1179658, "t": 1793007041, "turn": 47, "utc": "2026-10-26T09:30:41.848Z", "verb": "MOVE_TO"}`
- `{"checked_on": 48, "kind": "order_verified", "order_kind": "unit", "subject": 131073, "t": 1793007041, "turn": 47, "utc": "2026-10-26T09:30:41.848Z", "verb": "MOVE_TO"}`
- `{"candidates": 1, "guard": 131073, "kind": "escort_cap_unresolved", "reason": "guard_has_order", "sent": [31, 12], "settler": 1179658, "t": 1793007041, "turn": 48, "utc": "2026-10-26T09:30:41.823Z", "want": [31, 12]}`
- `{"checked_on": 49, "kind": "order_verified", "order_kind": "unit", "subject": 1179658, "t": 1793007043, "turn": 48, "utc": "2026-10-26T09:30:43.296Z", "verb": "MOVE_TO"}`
- `{"checked_on": 49, "kind": "order_verified", "order_kind": "unit", "subject": 131073, "t": 1793007043, "turn": 48, "utc": "2026-10-26T09:30:43.296Z", "verb": "MOVE_TO"}`
- `{"checked_on": 50, "kind": "order_failed", "order_kind": "unit", "reason": "unit_gone", "subject": 1179658, "t": 1793007044, "turn": 49, "utc": "2026-10-26T09:30:44.721Z", "verb": "MOVE_TO"}`
- `{"checked_on": 50, "kind": "order_verified", "order_kind": "produce", "subject": 131073, "t": 1793007044, "turn": 49, "utc": "2026-10-26T09:30:44.721Z", "verb": "BUILDING_SHRINE"}`
- `{"checked_on": 50, "kind": "order_verified", "order_kind": "unit", "subject": 131073, "t": 1793007044, "turn": 49, "utc": "2026-10-26T09:30:44.721Z", "verb": "MOVE_TO"}`

### why.log t-2..t

- t47 Military/Strategy Board: Defend Quito (value 80, need 27, force #23 of 1, deadline 2) · Escort settler (value 280, need 0, no force) · Siege Babylon (value 264, need 172, force #24 of 2) · Defend Guayaquil (value 20, need 27, no force, deadline 3) · Relieve Guayaquil (value 20, need 10, no force, deadline 3) | rows 11 [2 Defend, 1 Relieve, 1 Siege, 1 Escort, 6 Recon], 2 force(s), 3 reassigned, short: 1 Escort, 7 Siege, 2 Defend, 1 Relieve, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t47 Expansion/Detail Settler sets (26, 12) aside | the cached site stopped passing its checks (water); it stays out of the next picks for 6 standard turns so a threat flickering at the edge of sight cannot flip the march every frame  [civ6 (32,12) = axial (26,12)]
- t47 Expansion/Detail Settler marching to (26, 11) | 3 tiles away, the site is worth 82.4  [civ6 (31,11) = axial (26,11)]
- t47 Expansion/Decision Builder chooses more useful work | job at (16, 21) adds 139.8 after travel, versus 15.3 here; guard and route safety still apply  [civ6 (26,21) = axial (16,21)]
- t48 Military/Strategy Board: Escort settler (value 280, need 0, no force, deadline 4) · Siege Babylon (value 264, need 56, force #24 of 2, staging) · Recon sector 3 (value 30, need 0, no force) · Recon sector 4 (value 30, need 0, no force) · Recon sector 12 (value 30, need 0, no force) | rows 8 [1 Siege, 1 Escort, 6 Recon], 2 force(s), 0 reassigned, short: 1 Escort, 2 Siege, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t48 Expansion/Detail Settler sets (26, 11) aside | the cached site stopped passing its checks (water); it stays out of the next picks for 6 standard turns so a threat flickering at the edge of sight cannot flip the march every frame  [civ6 (31,11) = axial (26,11)]
- t48 Expansion/Detail The settler's guard stands down | no visible hostile within 8 tiles and this is not a long expedition; the army gets its body back
- t48 Expansion/Detail Settler marching to (26, 10) | 3 tiles away, the site is worth 72.6  [civ6 (31,10) = axial (26,10)]
- t48 Expansion/Detail Settler marching to (26, 10) | 2 tiles away, the site is worth 72.6  [civ6 (31,10) = axial (26,10)]
- t48 Expansion/Detail Settler ends its move short of (26, 10) | 2 tiles away with 1 movement left; the next tile costs 3, so it walks on next turn  [civ6 (31,10) = axial (26,10)]
- t48 Expansion/Detail Settler sets (26, 10) aside | the cached site stopped passing its checks (water); it stays out of the next picks for 6 standard turns so a threat flickering at the edge of sight cannot flip the march every frame  [civ6 (31,10) = axial (26,10)]
- t48 Expansion/Detail Settler marching to (26, 9) | 3 tiles away, the site is worth 93.4  [civ6 (30,9) = axial (26,9)]
- t48 Expansion/Detail Settler ends its move short of (26, 9) | 3 tiles away with 1 movement left; the next tile costs 3, so it walks on next turn  [civ6 (30,9) = axial (26,9)]
- t48 Expansion/Detail Settler marching to (26, 9) | 3 tiles away, the site is worth 93.4  [civ6 (30,9) = axial (26,9)]
- t48 Expansion/Detail Settler ends its move short of (26, 9) | 3 tiles away with 1 movement left; the next tile costs 3, so it walks on next turn  [civ6 (30,9) = axial (26,9)]
- t49 Military/Strategy Board: Escort settler (value 280, need 0, force #26 of 1, deadline 4) · Siege Babylon (value 264, need 56, force #24 of 2, staging) · Escort builder (value 50, need 0, no force, deadline 2) · Recon sector 3 (value 30, need 0, no force) · Recon sector 4 (value 30, need 0, no force) | rows 9 [1 Siege, 2 Escort, 6 Recon], 3 force(s), 0 reassigned, short: 2 Siege, 1 Escort, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t49 Military/Decision Task force #26: a land force of 1 will hold for Escort settler | objective (25, 12), anchor (25, 12), 100% ready, 3.00 local strength  [civ6 (31,12) = axial (25,12)]
- t49 Expansion/Detail Settler marching to (26, 9) | 3 tiles away, the site is worth 93.4  [civ6 (30,9) = axial (26,9)]

