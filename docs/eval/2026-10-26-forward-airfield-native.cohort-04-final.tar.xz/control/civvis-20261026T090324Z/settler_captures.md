# Settler captures — civvis-20261026T090324Z

1 capture(s). Mechanism is the first match in the operator's order; every match is listed.

## t42 settler 720900 at (50,23) — `site-in-barbarian-nest`

- detected by: `unit_captured`, captor player 63 (barbarian)
- mechanisms matched: site-in-barbarian-nest
- nearest hostile: UNIT_WARRIOR str 20 hp 67 mv 0 at (50,22) d=1 id 1507328
- guard: UNIT_ARCHER str 15 hp 18 mv 2 at (49,24) d=2 id 655366 [escort_cap_synced]
- site: (50,20) — hostile seen within 3 in the last 5 turns: True; camp within 3: False

### Settler t-2..t

| turn | pos | moves | activity | hostiles within 3 | ours within 2 |
|---|---|---|---|---|---|
| t40 | (50,23) | 0 | awake | UNIT_WARRIOR str 20 hp 67 mv 0 at (50,20) d=3 id 1507328 | UNIT_ARCHER str 15 hp 58 mv 0 at (50,22) d=1 id 655366 |
| t41 | (50,23) | 3 | awake | UNIT_WARRIOR str 20 hp 67 mv 0 at (49,21) d=2 id 1507328<br>UNIT_ARCHER str 15 hp 100 mv 0 at (49,20) d=3 id 3932197 | UNIT_ARCHER str 15 hp 18 mv 3 at (50,22) d=1 id 655366 |
| t42 | (50,23) | 3 | hold | UNIT_WARRIOR str 20 hp 67 mv 0 at (50,22) d=1 id 1507328 | UNIT_ARCHER str 15 hp 18 mv 2 at (49,24) d=2 id 655366<br>UNIT_ARCHER str 15 hp 100 mv 1 at (49,25) d=2 id 1048584 |

### Orders (settler and guard)

- `{"checked_on": 41, "kind": "order_verified", "order_kind": "unit", "subject": 720900, "t": 1793005522, "turn": 40, "utc": "2026-10-26T09:05:22.574Z", "verb": "MOVE_TO"}`
- `{"checked_on": 41, "kind": "order_verified", "order_kind": "unit", "subject": 655366, "t": 1793005522, "turn": 40, "utc": "2026-10-26T09:05:22.574Z", "verb": "MOVE_TO"}`
- `{"checked_on": 42, "kind": "order_verified", "order_kind": "unit", "subject": 655366, "t": 1793005523, "turn": 41, "utc": "2026-10-26T09:05:23.829Z", "verb": "MOVE_TO"}`
- `{"checked_on": 43, "kind": "order_verified", "order_kind": "unit", "subject": 655366, "t": 1793005525, "turn": 42, "utc": "2026-10-26T09:05:25.262Z", "verb": "MOVE_TO"}`

### why.log t-2..t

- t40 Expansion/Detail Settler retreats from a hostile's reach | 1 raider(s) could take (38, 23) next turn; (39, 23) is out of reach  [civ6 (50,23) = axial (39,23)]
- t41 Cities/Decision Bogotá starts builder | 29 production, about 3 turns at 13.2 a turn; the empire holds 5 military for 3 cities against a target of 1.0 each, and 1 settler, 0 builders, 0 traders  [civ6 (45,23) = axial (34,23)]
- t41 Expansion/Detail settler holds inside a barbarian's reach | 2 raider(s) could take (39, 23) and no reachable tile is better  [civ6 (50,23) = axial (39,23)]
- t41 Expansion/Detail Settler keeps (39, 20) through a blocked approach | no safe site lies within 4 tiles, and a far detour is how the last settlers spent twenty turns crossing the empire; the guard holds here until the approach clears  [civ6 (49,20) = axial (39,20)]
- t41 Expansion/Detail A guard joins the settler | it will share the settler's tile; a stacked civilian cannot be captured
- t41 Expansion/Detail Settler falls back toward its guard | its tile is threatened (risk 56) and the guard is 4 tiles away — waiting here is how the last settler was captured  [civ6 (46,23) = axial (35,23)]
- t41 Expansion/Detail Settler waits for its guard | 1 turn(s) so far; marching alone is how the last two settlers were captured
- t42 Expansion/Detail settler holds inside a barbarian's reach | 2 raider(s) could take (39, 23) and no reachable tile is better  [civ6 (50,23) = axial (39,23)]
- t42 Expansion/Detail Settler keeps (39, 20) through a blocked approach | no safe site lies within 4 tiles, and a far detour is how the last settlers spent twenty turns crossing the empire; the guard holds here until the approach clears  [civ6 (49,20) = axial (39,20)]
- t42 Expansion/Detail Settler begins an escorted expedition | the route from (39, 23) to (39, 20) is 4 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t42 Expansion/Detail Settler falls back toward its guard | its tile is threatened (risk 42) and the guard is 3 tiles away — waiting here is how the last settler was captured  [civ6 (48,24) = axial (36,24)]
- t42 Expansion/Detail Settler waits for its guard | 2 turn(s) so far; marching alone is how the last two settlers were captured
- t42 Expansion/Detail Settler begins an escorted expedition | the route from (34, 23) to (40, 20) is 8 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t42 Expansion/Detail A guard joins the settler | it will share the settler's tile; a stacked civilian cannot be captured
- t42 Expansion/Detail Settler marching to (40, 20) | 6 tiles away, the site is worth 139.7  [civ6 (50,20) = axial (40,20)]
- t42 Expansion/Detail settler holds inside a barbarian's reach | 2 raider(s) could take (39, 23) and no reachable tile is better  [civ6 (50,23) = axial (39,23)]
- t42 Expansion/Detail Settler keeps (39, 20) through a blocked approach | no safe site lies within 4 tiles, and a far detour is how the last settlers spent twenty turns crossing the empire; the guard holds here until the approach clears  [civ6 (49,20) = axial (39,20)]
- t42 Expansion/Detail Settler falls back toward its guard | its tile is threatened (risk 83) and the guard is 2 tiles away — waiting here is how the last settler was captured  [civ6 (49,25) = axial (37,25)]
- t42 Expansion/Detail Settler waits for its guard | 2 turn(s) so far; marching alone is how the last two settlers were captured
- t42 Expansion/Decision Builder chooses more useful work | job at (32, 26) adds 13.6 after travel, versus 5.3 here; guard and route safety still apply  [civ6 (45,26) = axial (32,26)]

