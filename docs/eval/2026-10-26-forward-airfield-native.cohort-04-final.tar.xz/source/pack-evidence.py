"""Seal exact evidence bytes with read times and verify every archived member."""
import argparse,datetime,hashlib,io,json,pathlib,tarfile
P=argparse.ArgumentParser();P.add_argument('--spec',required=True);P.add_argument('--out',required=True);args=P.parse_args()
spec=json.loads(pathlib.Path(args.spec).read_text());out=pathlib.Path(args.out);assert not out.exists()
files={}
for label,value in spec['files'].items():
 p=pathlib.Path(value)
 if p.is_dir():
  for f in p.rglob('*'):
   if f.is_file():files[str(pathlib.PurePosixPath(label)/f.relative_to(p))]=f
 else:files[label]=p
manifest={'scope':spec.get('scope'),'files':{}}
with tarfile.open(out,'w:xz') as tar:
 for label,p in sorted(files.items()):
  data=p.read_bytes();manifest['files'][label]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'read_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  info=tarfile.TarInfo(label);info.size=len(data);info.mode=0o755 if p.stat().st_mode&0o111 else 0o644;tar.addfile(info,io.BytesIO(data))
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('manifest.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
with tarfile.open(out) as tar:
 for label,identity in manifest['files'].items():
  data=tar.extractfile(label).read();assert len(data)==identity['bytes'] and hashlib.sha256(data).hexdigest()==identity['sha256'],label
result={'archive':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'members':len(files)+1}
pathlib.Path(str(out)+'.identity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
