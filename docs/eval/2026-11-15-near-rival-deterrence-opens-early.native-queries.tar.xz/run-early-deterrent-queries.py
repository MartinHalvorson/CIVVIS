"""Paired decider queries on captured live frames of the four 2026-11-15 Immortal capital losses.

`near-rival-deterrence-opens-early` is the only bit that varies. Each case is a live run's
`events.jsonl` cut after turn T+1 (the lane's replay recipe), queried with `--resumed` (the live
seat's past-turn-one agent) on one release `civvis_orders` built from the PR branch. Both arms carry
the run's own requested genome (the why.log header's `forced`, each as `--with`) and the run's
victory lane and civilization; the on arm adds the gene. The off arm is the live seat's own genome on
its own frame; the on arm is the gene's proposal on the same input.

This records proposal activation on captured live input only. It does not execute in Civ VI and
makes no strength claim. A one-frame query starts with no memory, so the capital watch reads only
the soldiers visible on that frame.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
CASES = [tuple(c.split(':')) for c in sys.argv[4:]]  # RUNSTAMP:TURN
GENE = 'near-rival-deterrence-opens-early'
CONTROL = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402


def cut(run, turn):
    lines = []
    with (CONTROL / run / 'events.jsonl').open('rb') as f:
        for line in f:
            if b'"kind": "state"' in line:
                try:
                    t = json.loads(line).get('turn')
                except ValueError:
                    t = None
                if t is not None and t >= turn + 2:
                    break
            lines.append(line)
    return b''.join(lines)


def one(index, run, turn):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    case = {'run': run, 'turn': turn}
    result = {'index': index, 'case': case, 'reads': []}
    try:
        head = json.loads((CONTROL / run / 'why.log').open().readline())
        summary = json.loads((CONTROL / run / 'summary.json').read_text())
        forced = list(head['forced'])
        if GENE in forced or GENE in head.get('treatments', []):
            raise ValueError('the live genome already carried the gene')
        data = cut(run, turn)
        record = {'descriptor': {'run': run, 'turn': turn, 'cut': 'events.jsonl through turn T+1'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(turn), '--resumed', '--explain',
                   '--victory', head['victory'], '--civ', summary['seat']['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]') and ('deterren' in line or 'trains a' in line)]
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['gene_journal'] = [l for l in on['journal'] if GENE + ':' in l]
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, r, int(t)) for i, (r, t) in enumerate(CASES)]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        if r.get('error'):
            print(r['case'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            print(r['case']['run'][7:], 't%d' % r['case']['turn'], 'changed' if v['orders_changed'] else 'same',
                  '|', (v['gene_journal'] or ['-'])[0][:260])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
