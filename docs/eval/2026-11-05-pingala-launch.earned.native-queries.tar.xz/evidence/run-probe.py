from pathlib import Path
import sys,json,subprocess,hashlib,datetime,shutil
root=Path(__file__).parent
repo=Path.home()/'civvis-pingala-earns-the-launch-5b93'
sys.path.insert(0,str(repo/'tools'))
from civ6_decision_trace import captured_input
from civ6_captured_read_replay import request_reply,expanded_reads
from civ6_ladder import decider_genome
from native_city_route_replay import request_identity_errors,control_payload
source=Path.home()/'civvis-civ6-runs/control/civvis-20261105T184951Z-campus-sea-pilot-v2-03-on'
binary=root/'civvis_orders'
build=json.loads((root/'build-process.json').read_text());assert build['exit']==0 and build['source_unchanged']
plan=json.loads((root/'plan.json').read_text());assert build['source_revision']==plan['source_revision']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==build['source_revision']
common=root/'current-capture'
sha=lambda b:hashlib.sha256(b).hexdigest()
tag='pingala-earns-the-launch'
genome=decider_genome(source/'why.log');assert genome and tag not in genome['treatments']
rows=[json.loads(l) for l in (source/'decisions.jsonl').open()]
cases=[]
for turn in [134,142,153]:
 record=next(r for r in rows if r['decision']['turn']==turn and r['decision']['frame']==0)
 capture=record['input_capture'];assert capture['complete'] and capture['reads']
 data=captured_input(capture,capture['reads'][-1]['snapshot_id'])
 path=root/f'input-{turn}-0.jsonl';assert not path.exists();path.write_bytes(data)
 cases.append({'turn':turn,'frame':0,'input':str(path),'input_bytes':len(data),'input_sha256':sha(data),'original_decision_sha256':record['sha256'],'original_registered_reads':capture['reads']})
 warm_turns=[105,130] if turn==134 else [117,140,(141 if turn==142 else 152)]
 cases[-1]['warmups']=[]
 for prior in warm_turns:
  r=next(r for r in rows if r['decision']['turn']==prior and r['decision']['frame']==0)
  c=r['input_capture'];assert c['complete'] and c['reads']
  b=captured_input(c,c['reads'][-1]['snapshot_id']);f=root/f'warm-{prior}-0.jsonl'
  if f.exists():assert f.read_bytes()==b
  else:f.write_bytes(b)
  cases[-1]['warmups'].append({'turn':prior,'input':str(f),'input_sha256':sha(b),'original_decision_sha256':r['sha256']})
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'harness_sha256':sha(Path(__file__).read_bytes()),'gene':tag,'source_run':source.name,'binary':str(binary),'binary_sha256':sha(binary.read_bytes()),'provenance':json.loads(binary.with_suffix('.provenance.json').read_text()),'genome':genome,'arm_order':['off','on','on','off'],'cases':cases,'scope':'Offline proposals with a fresh process per case and the same declared observation and production-ownership warmup in each arm. For target142, warmup141 selects Satellite; for target153, warmup152 selects Moon Landing. Earlier turns establish observed governor tenure. These ownership conditions must be verified from raw warmup orders before interpreting target behavior. These are bounded observation histories, not original private history or counterfactual trajectories. Every request reads one fixed captured frontier. No native game, host actuation or strength estimate.'}
(root/'intent.json').write_text(json.dumps(manifest,indent=2)+'\n')
results=[]
for idx,arm in enumerate(manifest['arm_order']):
 for case in cases:
  out=root/f'query-{idx}-{case["turn"]}-{arm}';out.mkdir();expected=Path(case['input']).read_bytes();(out/'events.jsonl').write_bytes(Path(case['warmups'][0]['input']).read_bytes())
  args=[str(binary),'--mirror',str(out),'--serve','--fresh-board','--explain','--resumed','--victory','science','--civ','CIVILIZATION_INDONESIA','--capture-inputs',str(common)]
  for flag in genome['forced']:args.extend(['--with',flag])
  if arm=='on':args.extend(['--with',tag])
  assert sha(binary.read_bytes())==manifest['binary_sha256']
  with (out/'stderr.log').open('w') as err:
   p=subprocess.Popen(args,cwd=repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1)
   try:
    warm_results=[]
    for warm in case['warmups']:
     fixed=Path(warm['input']).read_bytes();assert sha(fixed)==warm['input_sha256']
     temp=out/'next-events.jsonl';temp.write_bytes(fixed);temp.replace(out/'events.jsonl')
     p.stdin.write(str(warm['turn'])+'\n');p.stdin.flush();w=request_reply(p,120)
     assert not request_identity_errors(w,warm['turn'],0)
     reads=expanded_reads(w['input_capture']);assert reads and all(b==fixed for b in reads)
     warm_results.append({'turn':warm['turn'],'input_sha256':warm['input_sha256'],'actual_read_count':len(reads),'actual_read_sha256':[sha(b) for b in reads],'payload':w})
    temp=out/'next-events.jsonl';temp.write_bytes(expected);temp.replace(out/'events.jsonl')
    p.stdin.write(str(case['turn'])+'\n');p.stdin.flush();reply=request_reply(p,120);assert not request_identity_errors(reply,case['turn'],0)
    actual=expanded_reads(reply['input_capture']);assert actual and all(data==expected for data in actual)
    p.stdin.close();code=p.wait(timeout=15);assert code==0
   finally:
    if p.poll() is None:p.terminate();p.wait(timeout=5)
    p.stdout.close()
  effective=decider_genome(out/'stderr.log');assert effective and (tag in effective['treatments'])==(arm=='on')
  capture_directory=Path(reply['input_capture']['directory']);relative=capture_directory.relative_to(common)
  archived=out/'recaptured';shutil.move(common,archived)
  result={'binary_sha256':manifest['binary_sha256'],'capture_directory_map':{str(d):str(archived/Path(d).relative_to(common)) for d in [str(capture_directory)]+[w['payload']['input_capture']['directory'] for w in warm_results]},'warmup_results':warm_results,'request':[case['turn'],0],'shared_input_bytes':case['input_bytes'],'shared_input_sha256':case['input_sha256'],'arm':arm,'round':idx,'turn':case['turn'],'exit':code,'argv':args,'genome':effective,'actual_read_count':len(actual),'actual_read_sha256':[sha(data) for data in actual],'payload':reply,'input_sha256':case['input_sha256']}
  (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result)
  print(json.dumps({'arm':arm,'round':idx,'turn':case['turn'],'reads':len(actual),'governor_orders':[o for o in reply['orders'] if o['kind'].startswith('governor')]}),flush=True)
for turn in [134,142,153]:
 rs=[r for r in results if r['turn']==turn];off=[r for r in rs if r['arm']=='off'];on=[r for r in rs if r['arm']=='on']
 assert control_payload(off[0]['payload'])==control_payload(off[1]['payload'])
 assert control_payload(on[0]['payload'])==control_payload(on[1]['payload'])
 for arm in [off,on]:
  assert [control_payload(w['payload']) for w in arm[0]['warmup_results']]==[control_payload(w['payload']) for w in arm[1]['warmup_results']]
 assert [w['payload']['orders'] for w in off[0]['warmup_results']]==[w['payload']['orders'] for w in on[0]['warmup_results']]
 a,b=[dict(v[0]['genome']) for v in [off,on]]
 for field in ['forced','treatments']:
  before,after=a.pop(field),b.pop(field);assert set(after)-{tag}==set(before) and tag not in before and tag in after
 assert a==b
assert sha(binary.read_bytes())==manifest['binary_sha256']
assert all(sha((repo/path).read_bytes())==digest for path,digest in build['source_manifest'].items())
assert sha(Path(__file__).read_bytes())==manifest['harness_sha256']
(root/'completed.json').write_text(json.dumps({'case_queries':len(results),'warmup_queries':sum(len(r['warmup_results']) for r in results),'registered_reads':sum(r['actual_read_count']+sum(w['actual_read_count'] for w in r['warmup_results']) for r in results),'all_actual_reads_equal_fixed_input':True,'same_arm_payload_repeats':True,'effective_genomes_differ_only_gene':True,'scope':manifest['scope']},indent=2)+'\n')
print('Fixed-input diagnostic controls passed',flush=True)
