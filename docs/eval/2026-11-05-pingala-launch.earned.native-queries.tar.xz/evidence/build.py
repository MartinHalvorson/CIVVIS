from pathlib import Path
import subprocess,json,hashlib,os,datetime,shutil
root=Path(__file__).parent;work=Path.home()/'civvis-pingala-earns-the-launch-5b93'
sha=lambda data:hashlib.sha256(data).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work,text=True).strip()
paths=subprocess.check_output(['git','ls-files','-z','src','data','deploy','Cargo.toml','Cargo.lock','build.rs'],cwd=work).decode().split('\0')
sources={p:sha((work/p).read_bytes()) for p in paths if p}
env=dict(os.environ);settings={'CARGO_PROFILE_CI_LTO':'off','CARGO_PROFILE_CI_OPT_LEVEL':'0','CARGO_PROFILE_CI_CODEGEN_UNITS':'64','CARGO_PROFILE_CI_DEBUG':'0','CARGO_BUILD_JOBS':'2'};env.update(settings)
args=['cargo','build','--profile','ci','--locked','--bin','civvis_orders']
receipt={'source_revision':head,'build_argv':args,'cwd':str(work),'build_env':settings,'source_manifest':sources,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Offline captured-input proposal executable; not a native harness and not a production-throughput attestation.'}
with (root/'build.log').open('w') as out:
 p=subprocess.Popen(args,cwd=work,env=env,stdout=out,stderr=subprocess.STDOUT);receipt['owned_cargo_pid']=p.pid
 r=subprocess.run(['/usr/sbin/taskpolicy','-B','-t','0','-l','0','-p',str(p.pid)],capture_output=True,text=True);receipt['one_initial_owned_cargo_priority']={'returncode':r.returncode,'stderr':r.stderr}
 (root/'build-process.json').write_text(json.dumps(receipt,indent=2)+'\n');receipt['exit']=p.wait()
receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()==head
assert all(sha((work/p).read_bytes())==h for p,h in sources.items())
if receipt['exit']==0:
 binary=root/'civvis_orders';assert not binary.exists();shutil.copy2(work/'target/ci/civvis_orders',binary);receipt['binary_sha256']=sha(binary.read_bytes());receipt['source_unchanged']=True
 binary.with_suffix('.provenance.json').write_text(json.dumps({'kind':'offline_candidate_build','revision':head,'sha256':receipt['binary_sha256'],'source_kind':'owned-task-build','source_path':str(work)},indent=2)+'\n')
(root/'build-process.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ['source_revision','exit','finished_utc']}),flush=True)
raise SystemExit(receipt['exit'])
