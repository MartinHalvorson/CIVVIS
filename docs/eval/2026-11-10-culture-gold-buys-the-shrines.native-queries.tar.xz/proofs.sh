#!/bin/zsh
# Runs both replay proofs on the frozen combined binary.
set -e
F=/private/tmp/claude-501/-Users-martbot-mbp-m5-max-128/a2c75b83-f4e9-4f54-8ff0-cd2b93d40210/scratchpad/faith
REPO=$HOME/civvis-culture-gold-buys-the-shrines-11a6
mkdir -p $F/bin && cp $F/combo/target/ci/civvis_orders $F/bin/civvis_orders
B=$F/bin/civvis_orders
cd $F/proof
G1=culture-gold-buys-the-shrines
python3 $F/run-paired-queries.py $REPO $B nq-shrines-152217Z $G1 civvis-20261110T152217Z 78 80 102
python3 $F/run-paired-queries.py $REPO $B nq-shrines-171451Z $G1 civvis-20261110T171451Z 132 141
python3 $F/run-paired-queries.py $REPO $B nq-shrines-161648Z $G1 civvis-20261110T161648Z-cont2 137
G2=culture-bank-holds-the-counterweight
python3 $F/run-paired-queries.py $REPO $B nq-counter-171451Z $G2 civvis-20261110T171451Z 118 136
python3 $F/run-paired-queries.py $REPO $B nq-counter-173750Z $G2 civvis-20261110T173750Z 103 125 165
python3 $F/run-paired-queries.py $REPO $B nq-counter-153619Z $G2 civvis-20261110T153619Z 136 151
