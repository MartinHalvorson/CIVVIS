"""Paired decider queries on captured live Kristina boards (Shrine/Temple Gold buys, counterweight Missionary buys).

usage: run-paired-queries.py REPO BINARY OUT GENE RUN TURN [TURN...]

GENE is the only bit that varies. Each case is a turn of a live Deity Kristina
run. Both arms run one frozen ci-profile `civvis_orders` built from the branch,
on a clone of the run's own `events.jsonl` (hashed below), with that run's own
requested genome (`summary.json` `forced`, each as `--with`), `--victory
culture` and `--resumed`. The on arm adds `--with GENE`.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = sys.argv[4]
RUN = sys.argv[5]
TURNS = [int(turn) for turn in sys.argv[6:]]
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

SOURCE = Path.home() / 'civvis-civ6-runs/control' / RUN


def museum_orders(payload):
    """The purchases this gene is about among the proposed orders: Shrine or
    Temple buys (culture-gold-buys-the-shrines) or Missionary buys
    (culture-bank-holds-the-counterweight)."""
    def hit(order):
        text = json.dumps(order).upper()
        if 'BUY' not in text and 'PURCHASE' not in text:
            return False
        if GENE == 'culture-bank-holds-the-counterweight':
            return 'MISSIONARY' in text
        return 'SHRINE' in text or 'TEMPLE' in text
    return [o for o in payload.get('orders', []) if hit(o)]


def changed_orders(off, on):
    a = [json.dumps(o, sort_keys=True) for o in off.get('orders', [])]
    b = [json.dumps(o, sort_keys=True) for o in on.get('orders', [])]
    return {'off_only': [json.loads(o) for o in a if o not in b],
            'on_only': [json.loads(o) for o in b if o not in a]}


def one(index, turn, data_path, digest, size, forced):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': {'run': RUN, 'turn': turn}, 'reads': []}
    try:
        record = {'descriptor': {'run': RUN, 'file': 'events.jsonl', 'turn': turn},
                  'bytes': size, 'sha256': digest, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            subprocess.run(['cp', '-c', str(data_path), str(mirror / 'events.jsonl')], check=True)
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', 'culture',
                   '--turn', str(turn), '--resumed']
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=600)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]')]
            record['arms'].append(row)
            shutil.rmtree(mirror)
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['off_museum_orders'] = museum_orders(off.get('payload', {}))
        record['on_museum_orders'] = museum_orders(on.get('payload', {}))
        record['order_diff'] = changed_orders(off.get('payload', {}), on.get('payload', {}))
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    summary = json.loads((SOURCE / 'summary.json').read_text())
    forced = list(summary['forced'])
    if GENE in forced:
        raise SystemExit('the live genome already carried the gene')
    data_path = SOURCE / 'events.jsonl'
    data = data_path.read_bytes()
    digest, size = hashlib.sha256(data).hexdigest(), len(data)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'run': RUN, 'turns': TURNS,
        'input_sha256': digest, 'input_bytes': size,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, t, data_path, digest, size, forced) for i, t in enumerate(TURNS)]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
               'on_museum_orders': sum(len(v.get('on_museum_orders', [])) for r in results for v in r['reads']),
               'off_museum_orders': sum(len(v.get('off_museum_orders', [])) for r in results for v in r['reads'])}
    for r in results:
        for v in r['reads']:
            print(r['case']['turn'], 'changed', v.get('orders_changed'), json.dumps(v.get('order_diff'))[:900])
        if r.get('error'):
            print(r['case']['turn'], 'ERROR', r['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
