"""Paired decider queries on captured live Deity Korea boards.

`embassy-finds-the-capital-2` is the only bit that varies. Each case is a
live Science run (carrying `embassy-finds-the-capital`, Domination-only) at a
turn within 40 of Diplomatic Service where the eventual winner, whose
capital we had never seen, read Neutral or warmer toward us and was at peace.
The input is the run's own event log through the turn's first state frame
and nothing after it. Both arms run one frozen ci-profile `civvis_orders`
built from the branch with the run's own requested genome (`why.log` line
one's `forced`) as `--with`. The off arm's mission orders are the control;
the on arm is the gene's Embassy on the same input.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'embassy-finds-the-capital-2'
V1 = None
CONTROL = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CASES = json.loads((Path(__file__).parent / 'cases.json').read_text())


def cut(run, turn):
    kept = []
    with (CONTROL / run / 'events.jsonl').open('rb') as source:
        for line in source:
            if b'"kind": "state"' in line or b'"kind":"state"' in line:
                try:
                    event = json.loads(line)
                except ValueError:
                    event = {}
                at = event.get('turn') or 0
                if at > turn:
                    break
                if at == turn and (event.get('frame') or 0) == 0:
                    kept.append(line)
                    break
            kept.append(line)
    return b''.join(kept)


def purchases(payload):
    return [o for o in payload.get('orders', []) if o.get('kind') == 'delegation']


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        with (CONTROL / case['run'] / 'why.log').open() as why:
            forced = list(json.loads(why.readline())['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data = cut(case['run'], case['turn'])
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'],
                                 'cut': "events.jsonl through the turn's first state frame"},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', 'science',
                   '--turn', str(case['turn'])]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': decider_genome(stderr)}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
        off, on = record['arms']
        record['off_purchases'] = purchases(off.get('payload', {}))
        record['on_purchases'] = purchases(on.get('payload', {}))
        record['off_reproduces_live_purchase'] = True  # the off arm is the control
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = (record['off_reproduces_live_purchase']
                              and all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms']))
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        for v in r['reads']:
            print(r['case']['run'][-8:], r['case']['turn'], 'off', [(o.get('subject'), o.get('verb')) for o in v.get('off_purchases', [])],
                  'on', [(o.get('subject'), o.get('verb')) for o in v.get('on_purchases', [])])
        if r.get('error'):
            print(r['case']['run'], r['case']['turn'], 'ERROR', r['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
