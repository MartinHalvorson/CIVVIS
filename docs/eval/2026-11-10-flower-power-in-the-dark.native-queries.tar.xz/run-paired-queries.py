"""Paired decider queries on captured live Kristina boards: Flower Power.

usage: run-paired-queries.py REPO BINARY OUT GENE RUN:TURN [RUN:TURN...]

GENE is the only bit that varies. Each case is a turn of a live Deity Online
Kristina culture run on which the host's policy window was free
(`policy_change.made` false, `unlock_cost` 0), Flower Power was in
`available_policies` (Dark Age, Atomic era or later) and Cold War was known.
Both arms run one frozen ci-profile `civvis_orders` built from the branch, on
a clone of the run's own `events.jsonl` (hashed below), with that run's own
requested genome (`summary.json` `forced`, each as `--with`), `--victory
culture` and `--resumed`. The on arm adds `--with GENE`. The clone is cut after the
first state frame of the turn whose policy window is free: `civvis_orders
--turn N` reads the LAST state of turn N, which after a live deck change
reports the window as used (`made` true), so the uncut log can never show a
policy decision on a turn the live seat changed its deck. The cut log is
exactly what the live decider had read at that frame. Each arm's
`policy_deck` order (the full deck it would send) is compared with the deck
the live seat asked for that turn (`policy_deck_request.desired`).

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = sys.argv[4]
CASES = [(arg.split(':')[0], int(arg.split(':')[1])) for arg in sys.argv[5:]]
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

ROOT = Path.home() / 'civvis-civ6-runs/control'


def deck(payload):
    for order in payload.get('orders', []):
        if order.get('kind') == 'policy_deck':
            return sorted((order.get('verb') or '').split(','))
    return None


def live_board(run, turn):
    """The live seat's own reading of that turn: the first state frame and
    the deck it asked the host for."""
    state, asked = None, None
    with open(ROOT / run / 'events.jsonl') as handle:
        for line in handle:
            if '"turn": %d' % turn not in line and '"turn":%d' % turn not in line:
                continue
            row = json.loads(line)
            if row.get('turn') != turn:
                continue
            if row.get('kind') == 'state' and state is None:
                state = row
            if row.get('kind') == 'policy_deck_request' and asked is None:
                asked = sorted(row.get('desired') or [])
    rivals = state.get('rivals') or []
    return {
        'policies': sorted(state.get('policies') or []),
        'flower_power_available': 'POLICY_FLOWER_POWER' in (state.get('available_policies') or []),
        'cold_war': 'CIVIC_COLD_WAR' in (state.get('civics') or []),
        'dark_age': state.get('dark_age'), 'world_era': state.get('world_era'),
        'policy_change': state.get('policy_change'),
        'faith': state.get('faith'), 'faith_per_turn': state.get('faith_per_turn'),
        'rock_bands': sum(1 for unit in state.get('units', []) if 'ROCK_BAND' in json.dumps(unit)),
        'rivals_at_war': [index for index, rival in enumerate(rivals) if rival.get('at_war')],
        'live_deck_request': asked,
    }


def cut_at_free_window(data, turn):
    """Bytes through the first state frame of `turn` with a free policy
    window, and that frame's index."""
    offset = 0
    for line in data.splitlines(keepends=True):
        offset += len(line)
        if b'"state"' not in line:
            continue
        row = json.loads(line)
        if row.get('kind') != 'state' or row.get('turn') != turn:
            continue
        change = row.get('policy_change') or {}
        if change.get('made') is False and change.get('unlock_cost') == 0:
            return data[:offset], row.get('frame')
    raise ValueError(f'turn {turn}: no state frame with a free policy window')


def one(index, run, turn, forced, data_path, digest, size):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': {'run': run, 'turn': turn}, 'reads': []}
    try:
        cut, frame = cut_at_free_window(data_path.read_bytes(), turn)
        record = {'descriptor': {'run': run, 'file': 'events.jsonl', 'turn': turn, 'frame': frame},
                  'bytes': size, 'sha256': digest,
                  'cut': {'bytes': len(cut), 'sha256': hashlib.sha256(cut).hexdigest()},
                  'live': live_board(run, turn), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(cut)
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', 'culture',
                   '--turn', str(turn), '--resumed']
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
                row['policy_deck'] = deck(row['payload'])
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]')]
            row['policy_journal'] = [line for line in row['journal'] if 'Policies/' in line]
            record['arms'].append(row)
            shutil.rmtree(mirror)
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['deck_changed'] = off.get('policy_deck') != on.get('policy_deck')
        record['off_has_flower_power'] = 'POLICY_FLOWER_POWER' in (off.get('policy_deck') or [])
        record['on_has_flower_power'] = 'POLICY_FLOWER_POWER' in (on.get('policy_deck') or [])
        record['off_deck_matches_live_request'] = off.get('policy_deck') == record['live']['live_deck_request']
        record['on_flower_power_lines'] = [line for line in on['journal'] if 'flower' in line.lower()]
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    inputs = {}
    for run in sorted({run for run, _ in CASES}):
        summary = json.loads((ROOT / run / 'summary.json').read_text())
        forced = list(summary['forced'])
        if GENE in forced:
            raise SystemExit(f'{run}: the live genome already carried the gene')
        data = (ROOT / run / 'events.jsonl').read_bytes()
        inputs[run] = (forced, ROOT / run / 'events.jsonl', hashlib.sha256(data).hexdigest(), len(data))
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': [f'{run}:{turn}' for run, turn in CASES],
        'inputs': {run: {'sha256': digest, 'bytes': size} for run, (_, _, digest, size) in inputs.items()},
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = []
    for index, (run, turn) in enumerate(CASES):
        forced, path, digest, size = inputs[run]
        results.append(one(index, run, turn, forced, path, digest, size))
    reads = [read for result in results for read in result['reads']]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(read.get('orders_changed', False) for read in reads),
               'changed_deck_reads': sum(read.get('deck_changed', False) for read in reads),
               'on_flower_power_reads': sum(read.get('on_has_flower_power', False) for read in reads),
               'off_flower_power_reads': sum(read.get('off_has_flower_power', False) for read in reads)}
    for result in results:
        for read in result['reads']:
            off, on = read['arms']
            print(result['case'], 'live', read['live']['policies'], 'asked', read['live']['live_deck_request'])
            print('   off', off.get('exit'), off.get('policy_deck'))
            print('   on ', on.get('exit'), on.get('policy_deck'))
            for line in read.get('on_flower_power_lines', []):
                print('   ', line[:300])
        if result.get('error'):
            print(result['case'], 'ERROR', result['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
