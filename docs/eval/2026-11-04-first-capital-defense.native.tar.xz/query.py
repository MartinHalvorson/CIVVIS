"""Fresh captured-board proposals only; no native host commands or strength claim."""
from pathlib import Path
import argparse, datetime, hashlib, json, subprocess, sys
ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/martbot-mbp-m5-max-128/civvis-first-capital-before-the-camp-541a')
sys.path.insert(0, str(REPO / 'tools'))
from civ6_decision_trace import captured_input
from civ6_ladder import decider_genome
from civ6_captured_read_replay import control_payload, exact_fact

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--candidate', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
out = args.out.resolve()
out.mkdir(exist_ok=False)
candidate = args.candidate.resolve()
run = Path.home() / 'civvis-civ6-runs/control/civvis-20261104T060224Z'
source_genome = decider_genome(run / 'why.log')
profile = sorted(source_genome['forced'])
tag = 'first-capital-before-the-camp'
assert tag not in source_genome['treatments']
summary = json.loads((run / 'summary.json').read_text())
seat, target = summary['seat'], summary['victory_target']
context = json.loads((ROOT.parent / 'quick-anvil-context/civvis-20261104T060224Z.json').read_text())
observed = context['processes'][0]['argv']
assert observed[observed.index('--victory') + 1] == target
assert observed[observed.index('--civ') + 1] == seat['civ']
records = [json.loads(line) for line in (run / 'decisions.jsonl').open()]
report = {'intent': {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                     'tag': tag, 'candidate_sha256': sha(candidate.read_bytes()),
                     'source_run': run.name, 'selected_turns': [12, 14, 16, 67],
                     'scope': 'Development inputs, fresh-board proposals with repeated full-payload controls. Not persistent execution, continued counterfactual history, survival or strength evidence.'},
          'cases': []}
for turn in [12, 14, 16, 67]:
    record = next(r for r in records if (r['decision']['turn'], r['decision']['frame']) == (turn, 0))
    cap = record['input_capture']
    assert cap['complete']
    before = Path(record['binary'])
    assert sha(before.read_bytes()) == record['binary_on_disk_sha256'] == context['binary_sha256']
    selected = None
    for read in cap['reads']:
        raw = captured_input(cap, read['snapshot_id'])
        states = [json.loads(line) for line in raw.splitlines() if json.loads(line).get('kind') == 'state']
        if states and (states[-1]['turn'], states[-1].get('frame', 0)) == (turn, 0):
            selected = raw, read['snapshot_id']
            break
    assert selected is not None
    raw, snapshot = selected
    directory = out / f'{run.name}-{turn}'
    directory.mkdir()
    (directory / 'captured-events.jsonl').write_bytes(raw)
    (directory / 'source-record.json').write_text(json.dumps(record, indent=2) + '\n')
    case = {'run': run.name, 'turn': turn, 'snapshot': snapshot,
            'source_decision_sha256': record['sha256'],
            'source_binary_sha256': record['binary_on_disk_sha256'],
            'complete': False,
            'reads': [{'complete': True, 'sha256': sha(raw), 'bytes': len(raw), 'arms': []}],
            'controls': []}
    report['cases'].append(case)
    arms = {}
    for label in ['before-off', 'candidate-off', 'candidate-on', 'candidate-on-repeat', 'candidate-off-repeat']:
        binary = before if label == 'before-off' else candidate
        on = label in ['candidate-on', 'candidate-on-repeat']
        d = directory / label
        d.mkdir()
        (d / 'events.jsonl').write_bytes(raw)
        argv = [str(binary), '--mirror', str(d), '--turn', str(turn), '--victory', target,
                '--civ', seat['civ'], '--fresh-board', '--explain']
        for flag in sorted(profile + ([tag] if on else [])):
            argv += ['--with', flag]
        result = subprocess.run(argv, cwd=context['processes'][0]['cwd'], capture_output=True, timeout=60)
        (d / 'stdout').write_bytes(result.stdout)
        (d / 'stderr').write_bytes(result.stderr)
        genome = decider_genome(d / 'stderr')
        arm = {'label': label, 'argv': argv, 'exit': result.returncode, 'genome': genome}
        case['controls'].append(arm)
        (out / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
        assert result.returncode == 0 and genome
        assert sorted(genome['treatments']) == sorted(source_genome['treatments'] + ([tag] if on else []))
        assert sorted(genome['forced']) == sorted(profile + ([tag] if on else []))
        arm['payload'] = json.loads(result.stdout)
        arms[label] = arm
    for left, right in [('before-off', 'candidate-off'), ('candidate-off', 'candidate-off-repeat'), ('candidate-on', 'candidate-on-repeat')]:
        assert exact_fact(control_payload(arms[left]['payload']), control_payload(arms[right]['payload'])), (turn, left, right)
    for arm, label in [('off', 'candidate-off'), ('on', 'candidate-on')]:
        case['reads'][0]['arms'].append({'arm': arm, **{k: v for k, v in arms[label].items() if k != 'label'}})
    old, new = arms['candidate-off']['payload']['orders'], arms['candidate-on']['payload']['orders']
    case['changed'] = old != new
    case['removed_orders'] = [order for order in old if order not in new]
    case['added_orders'] = [order for order in new if order not in old]
    case['complete'] = True
    (directory / 'result.json').write_text(json.dumps(case, indent=2) + '\n')
    (out / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'turn': turn, 'changed': case['changed'], 'removed': len(case['removed_orders']), 'added': len(case['added_orders'])}), flush=True)
assert any(case['changed'] for case in report['cases']), 'No demonstrated proposal activation; keep candidate withheld.'
