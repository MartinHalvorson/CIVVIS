"""Paired decider queries on two captured live Deity boards where the second
city was sited close to a charted rival city.

`early-cities-keep-their-distance` is the only bit that varies. Each case is
the live run's `events.jsonl` cut right after the FIRST state row of the
named turn (frame 0, the frame in which the live Settler chose its site), byte
for byte. Both arms run one frozen ci-profile `civvis_orders` built from the
branch with that run's own requested genome (`summary.json` `forced`, each as
`--with`). The off arm must reproduce the live Settler target (journal line
"Settler marching to (q, r)"); the on arm is the gene's proposal on the same
input.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'early-cities-keep-their-distance'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CASES = [
    {'run': 'civvis-20261105T001143Z', 'turn': 13, 'live_target': '(45, 31)',
     'note': 'second city founded t16 six tiles from a Gran Colombian city charted at t10; lost t47 (early_city_lost)'},
    {'run': 'civvis-20261104T210549Z', 'turn': 16, 'live_target': '(2, 20)',
     'note': 'Yangsan founded t18 five tiles from a Sumerian city charted at t16; lost t27'},
]


def frame_zero(run, turn):
    out = bytearray()
    with open(Path.home() / 'civvis-civ6-runs/control' / run / 'events.jsonl', 'rb') as f:
        for line in f:
            out += line
            if b'"kind": "state"' in line[:40000]:
                try:
                    if json.loads(line).get('turn') == turn:
                        return bytes(out)
                except ValueError:
                    pass
    raise ValueError('turn not found')


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        summary = json.loads((Path.home() / 'civvis-civ6-runs/control' / case['run']
                              / 'summary.json').read_text())
        forced = list(summary['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data = frame_zero(case['run'], case['turn'])
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'cut': 'after the first state row of the turn'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', 'science',
                   '--turn', str(case['turn'])]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=600)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                lines = [l for l in stdout.read_text().splitlines() if l.startswith('{"turn"')]
                row['payload'] = json.loads(lines[-1]) if lines else {'orders': None}
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]')]
            row['settler_targets'] = sorted({l.split('Settler marching to ')[1].split(' |')[0]
                                             for l in row['journal'] if 'Settler marching to ' in l})
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
        off, on = record['arms']
        record['off_reproduces_live_target'] = case['live_target'] in off['settler_targets']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = (record['off_reproduces_live_target']
                              and all(a['exit'] == 0 and isinstance(a.get('payload', {}).get('orders'), list) and a['genome']
                                      for a in record['arms']))
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        for v in r['reads']:
            for a in v['arms']:
                print(r['case']['run'], a['arm'], 'exit', a['exit'], 'targets', a.get('settler_targets'))
        if r.get('error'):
            print(r['case']['run'], 'ERROR', r['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
