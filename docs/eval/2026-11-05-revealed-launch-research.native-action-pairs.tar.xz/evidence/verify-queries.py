from pathlib import Path
import json,hashlib,sys,datetime
r=Path(__file__).parent;repo=Path.home()/'civvis-revealed-launch-tech-takes-the-slot-8cd1';sys.path.insert(0,str(repo/'tools'))
import civ6_captured_read_replay as replay
from native_city_route_replay import control_payload,request_identity_errors
from civ6_ladder import decider_genome
sha=lambda b:hashlib.sha256(b).hexdigest();tag='revealed-launch-tech-takes-the-slot'
seal=json.loads((r/'sealed-captures.json').read_text());mapping={x['source']:x['sealed_directory'] for x in seal}
for x in seal:
 p=Path(x['sealed_directory']);assert sha((p/'bytes.bin').read_bytes())==x['archive_sha256'];assert sha((p/'snapshots.jsonl').read_bytes())==x['index_sha256']
expected={}
for l in (r/'native-decisions.jsonl').read_text().splitlines():
 x=json.loads(l);reads=replay.expanded_reads(dict(x['input_capture'],directory=mapping[x['input_capture']['directory']]));assert all(b==reads[0] for b in reads);expected[tuple([x['decision']['turn'],x['decision']['frame']])]=reads[0]
paths=[Path(p) for p in json.loads((r/'query-results.json').read_text())];results=[json.loads(p.read_text()) for p in paths];intent=json.loads((r/'intent.json').read_text());assert len(results)==len(intent['fixed_requests'])*len(intent['arm_order']);binding=json.loads((r/'candidate-build.json').read_text());assert sha(Path(binding['binary_path']).read_bytes())==binding['binary_sha256'];count=0;report=[]
for p,x in zip(paths,results):
 assert x['exit']==0 and x['binary_sha256']==binding['binary_sha256'] and sha(Path(x['argv'][0]).read_bytes())==binding['binary_sha256'];assert not request_identity_errors(x['payload'],*x['request']);assert decider_genome(p.parent/'stderr.log')==x['genome']
 capture=dict(x['payload']['input_capture']);capture['directory']=x['capture_directory_map'][capture['directory']];actual=replay.expanded_reads(capture);native=expected[tuple(x['request'])]
 assert len(actual)==x['actual_read_count'] and actual and all(b==native for b in actual);assert x['actual_read_bytes_sha256']==[sha(b) for b in actual];assert sha(native)==x['shared_input_sha256'] and len(native)==x['shared_input_bytes'];count+=len(actual)
for key in intent['fixed_requests']:
 a,b,c,d=sorted([x for x in results if x['request']==key],key=lambda x:x['round']);assert [x['arm'] for x in [a,b,c,d]]==['off','on','on','off'];assert control_payload(a['payload'])==control_payload(d['payload']);assert control_payload(b['payload'])==control_payload(c['payload']);assert all(x['actual_read_bytes_sha256']==a['actual_read_bytes_sha256'] for x in [b,c,d])
 genomes=[dict(x['genome']) for x in [a,b]]
 for field in ['treatments','forced']:
  off,on=[set(g.pop(field)) for g in genomes];assert tag not in off and on-off=={tag} and off<=on
 assert genomes[0]==genomes[1]
 def args(x):
  a=list(x['argv']);a[a.index('--mirror')+1]='<same-input>'
  if x['arm']=='on':i=a.index(tag);assert a[i-1]=='--with';del a[i-1:i+1]
  return a
 assert args(a)==args(b)
 changed=a['payload']['orders']!=b['payload']['orders'];assert changed==(key in [[179,0],[180,0]])
 assert [o for o in a['payload']['orders'] if o['kind']!='research']==[o for o in b['payload']['orders'] if o['kind']!='research']
 report.append({'request':key,'changed_orders':changed,'off_research':[o for o in a['payload']['orders'] if o['kind']=='research'],'on_research':[o for o in b['payload']['orders'] if o['kind']=='research'],'same_arm_complete_control_payload_reproduced':True,'actual_read_sequences_match':True,'only_named_genome_bit_differs':True,'nonresearch_orders_equal':True})
result={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'queries':len(results),'verified_actual_reads':count,'candidate_source':binding['source_commit'],'candidate_binary_sha256':binding['binary_sha256'],'pairs':report,'scope':'Recaptured bytes independently matched to sealed native source captures; request identities, frozen executable hashes, actual stderr genomes, repeated complete control payloads, and matched-bit proposals verified. Constructed resumed startup; no original-game read-count/parity, native host execution, saved-turn or strength claim.'};(r/'independent-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
