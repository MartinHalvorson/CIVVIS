from pathlib import Path
import subprocess,json,hashlib,shutil,sys,datetime
r=Path(__file__).parent;repo=Path.home()/'civvis-revealed-launch-tech-takes-the-slot-8cd1';sys.path.insert(0,str(repo/'tools'))
import civ6_captured_read_replay as replay
from civ6_ladder import decider_genome
from native_city_route_replay import request_identity_errors
sha=lambda b:hashlib.sha256(b).hexdigest()
intent=json.loads((r/'intent.json').read_text());tag=intent['tag'];binary=r/'candidate-civvis_orders';binding=json.loads((r/'candidate-build.json').read_text());assert sha(binary.read_bytes())==binding['binary_sha256']
context=json.loads((r/'observed-native-context.json').read_text());original=context['processes'][0]['argv'];assert original.count('--mirror')==1 and original.count('--capture-inputs')==1
mapping={x['source']:x['sealed_directory'] for x in json.loads((r/'sealed-captures.json').read_text())};records=[json.loads(x) for x in (r/'native-decisions.jsonl').read_text().splitlines()];common=r/'current-capture';results=[]
for round_index,arm in enumerate(intent['arm_order']):
 for rec in records:
  key=[rec['decision']['turn'],rec['decision']['frame']];capture=dict(rec['input_capture'],directory=mapping[rec['input_capture']['directory']]);expected=replay.expanded_reads(capture);assert expected and all(x==expected[0] for x in expected),'Static-byte replay requires identical observed reads'
  out=r/f'query-{round_index}-{key[0]}-{key[1]}-{arm}';out.mkdir();(out/'events.jsonl').write_bytes(expected[0]);assert not common.exists()
  args=list(original);args[0]=str(binary);args[args.index('--mirror')+1]=str(out);args[args.index('--capture-inputs')+1]=str(common)
  assert tag not in args and '--resumed' not in args
  args.append('--resumed')
  if arm=='on':args.extend(['--with',tag])
  start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with (out/'stderr.log').open('w') as err:
   p=subprocess.Popen(args,cwd=repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1)
   if sys.platform=='darwin':subprocess.run(['/usr/sbin/taskpolicy','-B','-p',str(p.pid)],check=True)
   try:
    p.stdin.write(str(key[0])+'\n');p.stdin.flush();reply=replay.request_reply(p,60);assert not request_identity_errors(reply,*key)
    (out/'payload.json').write_text(json.dumps(reply,indent=2)+'\n')
    actual=replay.expanded_reads(reply['input_capture']);assert actual and all(x==expected[0] for x in actual),'Actual read bytes differ from sealed input prefix'
    p.stdin.close();code=p.wait(timeout=10);assert code==0
   finally:
    if p.poll() is None:p.terminate();p.wait(timeout=5)
    p.stdout.close()
  genome=decider_genome(out/'stderr.log');assert genome
  capture_map={reply['input_capture']['directory']:str(out/'recaptured'/Path(reply['input_capture']['directory']).relative_to(common))};shutil.move(common,out/'recaptured')
  receipt={'arm':arm,'round':round_index,'request':key,'argv':args,'cwd':str(repo),'exit':code,'started_utc':start,'binary_sha256':binding['binary_sha256'],'genome':genome,'payload':reply,'actual_read_count':len(actual),'shared_input_sha256':sha(expected[0]),'shared_input_bytes':len(expected[0]),'actual_read_bytes_sha256':[sha(x) for x in actual],'capture_directory_map':capture_map,'scope':intent['scope']}
  (out/'result.json').write_text(json.dumps(receipt,indent=2)+'\n');results.append(str(out/'result.json'));(r/'query-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'round':round_index,'arm':arm,'request':key,'reads':len(actual),'research_orders':[x for x in reply['orders'] if x.get('kind')=='research']}),flush=True)
print('All preregistered queries complete',flush=True)
