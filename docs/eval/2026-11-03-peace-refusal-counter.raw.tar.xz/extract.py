from pathlib import Path
import json,hashlib,datetime
root=Path(__file__).parent;run=Path('/Users/martbot-mbp-m5-max-128/civvis-civ6-runs/control/civvis-20261103T002240Z');log=Path('/Users/martbot-mbp-m5-max-128/civvis-climb-logs/civvis-20261103T002240Z-play.log')
sha=lambda x:hashlib.sha256(x).hexdigest();selected=[];events=[];states=[];war=[]
for n,raw in enumerate((run/'events.jsonl').read_bytes().splitlines(keepends=True),1):
 r=json.loads(raw)
 if r.get('kind')=='state' and r.get('frame')==0:
  rival=next((x for x in r.get('rivals',[]) if x.get('player')==1),None)
  if rival:war.append({'turn':r['turn'],'at_war':rival['at_war']})
  if r['turn'] in [88,89,97,98,102,103,182]:states.append(raw);selected.append({'file':'states.jsonl','source_line':n,'sha256':sha(raw)})
 if r.get('kind')=='peace_request' or (r.get('kind')=='order_failed' and r.get('order_kind')=='peace') or (r.get('kind')=='deal_session' and 96<=(r.get('turn') or -1)<=104):
  events.append(raw);selected.append({'file':'peace-and-session-events.jsonl','source_line':n,'sha256':sha(raw)})
(root/'states.jsonl').write_bytes(b''.join(states));(root/'peace-and-session-events.jsonl').write_bytes(b''.join(events))
for n,raw in enumerate(log.read_bytes().splitlines(keepends=True),1):
 if b'deal_sessions=' in raw:
  assert b'deal_sessions=trade ' in raw;(root/'source-play-mode.log').write_bytes(raw);selected.append({'file':'source-play-mode.log','source_line':n,'sha256':sha(raw)});break
else:raise AssertionError('no observed source mode')
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run':run.name,'source_mode':'trade','source_mode_evidence':'Actual play log, not inferred from current installed settings.','peace_requests':[json.loads(x) for x in events if json.loads(x).get('kind')=='peace_request'],'peace_sessions_opened':[json.loads(x) for x in events if json.loads(x).get('kind')=='deal_session' and json.loads(x).get('target')==1 and json.loads(x).get('phase')=='opening'],'war_first_observed_turn':next(x['turn'] for x in war if x['at_war']),'war_never_observed_ended_after_89':all(x['at_war'] for x in war if x['turn']>=89),'source_files':{str(p):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in [run/'events.jsonl',run/'summary.json',log]},'slices':selected,'scope':'Direct-peace transport observation only. No proof that an interactive peace session would be accepted or remain live. Historical Oct3 peace-freeze CSV is unavailable here; the repository source documents it but that is not newly verified native evidence. Do not change the operator transport policy from this observation.'}
(root/'native-facts.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['source_mode','peace_sessions_opened','war_first_observed_turn','war_never_observed_ended_after_89']}))
