-- Offline regression for the deal SESSION lane: a sale, a passage purchase
-- and a peace offer are asked inside a `MAKE_DEAL` diplomacy session, the way
-- the shipped screens do, because a session-less working deal is never
-- evaluated — 636 EQUALIZE asks and 253 peace proposals went out over 42 live
-- runs and not one answer ever came back. This test loads the shipped agent
-- and drives the real order arms, the real statement handler and the real
-- closer against a fixture that plays the engine's part: the session opens,
-- our opening statement puts the question, the rival's statement carries the
-- verdict, the answer is accepted or walked away from, and the session is
-- closed by us. It also pins the stand-down: three unanswered sessions and
-- the lane stops opening screens for the run.
--
-- Run: lua5.1 tools/civ6_control/mod/deal_session_test.lua

local here = arg[0]:match("(.*)/[^/]*$") or "."

local function stub()
	return setmetatable({}, {
		__index = function() return stub() end,
		__call = function() return stub() end,
		__newindex = function() end,
	})
end
setmetatable(_G, { __index = function(_, key)
	if key == "CivvisApplyOrder" or key == "CivvisOnIncomingDeal" or key == "CivvisTrade"
			or key == "CivvisOnDiplomacyStatement" or key == "CivvisOnDealSessionClosed" then
		return rawget(_G, key);
	end
	return stub()
end })

CivvisControlConfig = { TradeRetryTurns = 3, TradeResponseTurns = 2, PeaceRetryTurns = 5,
	DealSessions = true, DealSessionHoldSeconds = 4, DealSessionStandDown = 3 }

local events = {}
local realPrint = print
print = function(line)
	if type(line) == "string" and (line:find('"kind":"deal_', 1, true)
			or line:find('"kind":"peace_', 1, true)
			or line:find('"kind":"orphan_', 1, true)
			or line:find('"kind":"counter_', 1, true)) then
		events[#events + 1] = line
	end
end

-- The one channel the contexts share: record what the agent tells the closer.
local holds = {}
LuaEvents = setmetatable({
	CivvisDealSession = function(subject, open, seconds)
		holds[#holds + 1] = { subject = subject, open = open, seconds = seconds }
	end,
}, { __index = function() return stub() end })

DealDirection = { OUTGOING = "outgoing", INCOMING = "incoming" }
DealItemTypes = { RESOURCES = "resources", FAVOR = "favor", GOLD = "gold", AGREEMENTS = "agreements", GREATWORK = "greatwork" }
DealAgreementTypes = { MAKE_PEACE = "make_peace", OPEN_BORDERS = "open_borders" }
DealProposalAction = {
	PENDING = "pending", PROPOSED = "proposed", ACCEPTED = "accepted", REJECTED = "rejected",
	ADJUSTED = "adjusted", EQUALIZE = "equalize", EQUALIZE_FAILED = "equalize_failed",
}
local resourceRows = { RESOURCE_DYES = { ResourceType = "RESOURCE_DYES", Index = 12 } }
GameInfo = {
	Resources = setmetatable({}, { __index = function(_, key)
		if type(key) == "number" then
			for _, row in pairs(resourceRows) do if row.Index == key then return row end end
			return nil
		end
		return resourceRows[key]
	end }),
	Resource_Consumption = {},
	GreatWorks = {},
}
local TURN = 50
Game = {
	GetLocalPlayer = function() return 7 end,
	GetCurrentGameTurn = function() return TURN end,
}

local sessions = { requested = {}, closed = {}, nextId = 900 }
DiplomacyResponseTypes = { INITIAL = 0, ACKNOWLEDGE = 1 }
DiplomacyManager = {
	GetKeyName = function(key) return key end,
	FindOpenSessionID = function() return nil end,
	HasQueuedSession = function() return true end,
	RequestSession = function(pid, subject, kind)
		sessions.requested[#sessions.requested + 1] = { pid = pid, subject = subject, kind = kind }
	end,
	CloseSession = function(id) sessions.closed[#sessions.closed + 1] = id end,
}

local chunk, err = loadfile(here .. "/CivvisControlAgent.lua")
assert(chunk, "could not load agent: " .. tostring(err))
local ran, runtimeErr = pcall(chunk)
assert(ran, "CivvisControlAgent.lua raised at chunk load: " .. tostring(runtimeErr))

local applyOrder = rawget(_G, "CivvisApplyOrder")
local onStatement = rawget(_G, "CivvisOnDiplomacyStatement")
local onClosed = rawget(_G, "CivvisOnDealSessionClosed")
local trade = rawget(_G, "CivvisTrade")
assert(type(applyOrder) == "function" and type(onStatement) == "function"
	and type(onClosed) == "function" and type(trade) == "table",
	"CivvisControlAgent.lua did not export the session lane")

local failures = 0
local function check(name, got, want)
	if got ~= want then
		failures = failures + 1
		realPrint(string.format("FAIL %s: got %s want %s", name, tostring(got), tostring(want)))
	else
		realPrint(string.format("ok   %s = %s", name, tostring(got)))
	end
end
local function lastEvent(kind)
	for i = #events, 1, -1 do
		if events[i]:find('"kind":"' .. kind .. '"', 1, true) then return events[i] end
	end
	return nil
end
local function eventField(line, key)
	if line == nil then return nil end
	local quoted = line:match('"' .. key .. '":"([^"]*)"')
	if quoted ~= nil then return quoted end
	return line:match('"' .. key .. '":([^,}]*)')
end

-- The engine's part: one rival's deal manager, with `opts.incoming` as the
-- rival's answer.
local function fixture(opts)
	opts = opts or {}
	local state = { sends = {}, items = {}, atWar = opts.atWar or false,
		dealsEqual = opts.dealsEqual ~= false }
	local nextId = 100
	local function newItem(kind)
		local item = { kind = kind, id = nextId }
		nextId = nextId + 1
		function item:SetValueType(v) self.valueType = v end
		function item:SetSubType(v) self.subType = v end
		function item:GetSubType() return self.subType end
		function item:SetDuration(v) self.duration = v end
		function item:SetAmount(v) self.amount = v end
		function item:SetLocked(v) self.locked = v end
		function item:GetMaxAmount() return 999 end
		function item:IsValid() return true end
		function item:GetID() return self.id end
		return item
	end
	local outgoing = {}
	function outgoing:AddItemOfType(kind, owner)
		local item = newItem(kind); item.owner = owner
		state.items[#state.items + 1] = item
		return item
	end
	function outgoing:Validate() state.validated = (state.validated or 0) + 1 end
	function outgoing:IsValid() return true end
	function outgoing:RemoveItemByID() end
	local incoming = {}
	function incoming:Items()
		local list = opts.incoming or {}
		local i = 0
		return function()
			i = i + 1
			local spec = list[i]
			if spec == nil then return nil end
			return {
				GetType = function() return spec.kind end,
				GetFromPlayerID = function() return spec.from end,
				GetDuration = function() return spec.duration or 0 end,
				GetAmount = function() return spec.amount or 0 end,
				GetValueType = function() return spec.valueType end,
				GetSubType = function() return spec.subType end,
			}
		end
	end
	DealManager = {
		HasPendingDeal = function() return false end,
		ClearWorkingDeal = function(direction) state.cleared = direction end,
		GetWorkingDeal = function(direction)
			if direction == DealDirection.INCOMING then return incoming end
			return outgoing
		end,
		GetPossibleDealItems = function(pid, subject, kind)
			if kind == DealItemTypes.RESOURCES then
				return { { ForType = 12, MaxAmount = 3, IsValid = true } }
			end
			return {}
		end,
		CopyIncomingToOutgoingWorkingDeal = function() state.copied = true end,
		AreWorkingDealsEqual = function() return state.dealsEqual end,
		SendWorkingDeal = function(action, pid, subject)
			state.sends[#state.sends + 1] = { action, pid, subject, holds = #holds }
			if opts.onSend ~= nil then opts.onSend(action) end
		end,
	}
	local player = {
		GetDiplomacy = function()
			return {
				HasMet = function() return true end,
				IsAtWarWith = function() return state.atWar end,
				HasOpenBordersFrom = function() return false end,
			}
		end,
		GetTreasury = function() return { GetGoldBalance = function() return 400 end } end,
	}
	Players = setmetatable({ [7] = player }, {
		__index = function() return { IsMajor = function() return true end } end,
	})
	return state, player
end

-- ── A sale: session first, question on our statement, close on theirs ──
local sale, player = fixture({ incoming = {
	{ kind = "gold", from = 3, duration = 0, amount = 90 },
	{ kind = "resources", from = 7, duration = 30, amount = 1, valueType = 12 },
} })
local ok, why = applyOrder(player, 7, { kind = "sell", subject = "3", verb = "RESOURCE_DYES=1", x = 60 }, TURN)
check("the sale is asked", ok, true)
check("the sale says asked", why, "sell_asked")
check("no working deal is sent before the session", #sale.sends, 0)
check("a MAKE_DEAL session is requested", sessions.requested[1] and sessions.requested[1].kind, "MAKE_DEAL")
check("the session names the rival", sessions.requested[1] and sessions.requested[1].subject, 3)
check("the closer is told to hold", holds[1] and holds[1].open, true)
check("the hold carries the configured seconds", holds[1] and holds[1].seconds, 4)
check("the session is registered", trade.sessions[3] ~= nil, true)
check("the opening is in the ledger", eventField(lastEvent("deal_session"), "phase"), "opening")

-- Unrelated diplomacy must not claim the pending outgoing deal's session.
onStatement(3, 7, { StatementType = "GREETING", SessionID = 899 })
check("a greeting does not send the pending offer", #sale.sends, 0)
check("a greeting does not bind its session", trade.sessions[3] and trade.sessions[3].sessionID, nil)
onStatement(7, 3, { StatementType = "MAKE_DEAL" })
check("an opening without a session id does not send", #sale.sends, 0)

-- Our own opening statement: the session is live, the question goes out.
onStatement(7, 3, { StatementType = "MAKE_DEAL", SessionID = 901 })
check("the question is EQUALIZE", sale.sends[1] and sale.sends[1][1], "equalize")
check("the question names both players", sale.sends[1] and (sale.sends[1][2] .. ":" .. sale.sends[1][3]), "7:3")
check("the session id is kept", trade.sessions[3] and trade.sessions[3].sessionID, 901)
check("the ask is in the ledger", eventField(lastEvent("deal_session"), "phase"), "asked")
-- The rival answers from the game core, behind the turn's queued commands
-- (DiplomacyActionView.lua:2582): live answers took up to 14.7 s, and a
-- session the 4-second opening hold closed first froze the game four times.
check("the ask re-arms the closer's hold", holds[#holds] and holds[#holds].open, true)
check("the answer window outlasts the opening hold", holds[#holds] and holds[#holds].seconds, 30)
check("the hold is re-armed before the question goes out", sale.sends[1] and sale.sends[1].holds, #holds)
check("the ask records its answer window", eventField(lastEvent("deal_session"), "hold"), "30")

trade.unanswered = 2
-- Firaxis distinguishes the opening acknowledgement from deal evaluation
-- (DiplomacyActionView.lua:2547-2559). Neither it nor another session's
-- response may accept the fixture's already-populated incoming deal.
onStatement(3, 7, { StatementType = "MAKE_DEAL", SessionID = 901,
	StatementSubType = "NONE", ResponseType = DiplomacyResponseTypes.ACKNOWLEDGE,
	DealAction = DealProposalAction.ADJUSTED })
onStatement(3, 7, { StatementType = "MAKE_DEAL", SessionID = 901 })
onStatement(3, 7, { StatementType = "MAKE_DEAL", SessionID = 999,
	DealAction = DealProposalAction.ADJUSTED })
onStatement(3, 7, { StatementType = "GREETING", SessionID = 901,
	DealAction = DealProposalAction.ADJUSTED })
check("nonanswers do not accept an incoming deal", #sale.sends, 1)
check("nonanswers keep the deal session open", trade.sessions[3] ~= nil, true)
check("nonanswers do not close native sessions", #sessions.closed, 0)
check("nonanswers do not reset the stand-down count", trade.unanswered, 2)

-- The rival's statement carries its verdict: a fair answer is accepted and
-- the session is closed by us.
onStatement(3, 7, { StatementType = "MAKE_DEAL", SessionID = 901, DealAction = DealProposalAction.ADJUSTED })
check("a fair answer is accepted", sale.sends[2] and sale.sends[2][1], "accepted")
check("the close is in the ledger", eventField(lastEvent("deal_closed"), "gold"), "90")
check("the session is closed by us", sessions.closed[1], 901)
check("the session is forgotten", trade.sessions[3], nil)
check("the closer is released", holds[#holds] and holds[#holds].open, false)
check("the answer resets the unanswered count", trade.unanswered, 0)

-- ── A lowball is walked away from, and the session still closes ──
TURN = 60
local low, lowPlayer = fixture({ incoming = {
	{ kind = "gold", from = 3, duration = 0, amount = 20 },
	{ kind = "resources", from = 7, duration = 30, amount = 1, valueType = 12 },
} })
applyOrder(lowPlayer, 7, { kind = "sell", subject = "3", verb = "RESOURCE_DYES=1", x = 60 }, TURN)
onStatement(7, 3, { StatementType = "MAKE_DEAL", SessionID = 902 })
onStatement(3, 7, { StatementType = "MAKE_DEAL", SessionID = 902, DealAction = DealProposalAction.ADJUSTED })
check("a lowball is not accepted", #low.sends, 1)
check("a lowball is in the ledger", eventField(lastEvent("deal_declined"), "worth"), "20")
check("a declined session is closed too", sessions.closed[2], 902)

-- ── An answer delivered from inside the send still releases the closer ──
-- The answer window is armed before the send, so the close an inline answer
-- triggers is the last thing the closer hears; armed after, it would hold a
-- closed session's screen for the whole window.
TURN = 65
local inline, inlinePlayer
inline, inlinePlayer = fixture({
	incoming = {
		{ kind = "gold", from = 3, duration = 0, amount = 20 },
		{ kind = "resources", from = 7, duration = 30, amount = 1, valueType = 12 },
	},
	onSend = function(action)
		if action == "equalize" then
			onStatement(3, 7, { StatementType = "MAKE_DEAL", SessionID = 907,
				DealAction = DealProposalAction.ADJUSTED })
		end
	end,
})
applyOrder(inlinePlayer, 7, { kind = "sell", subject = "3", verb = "RESOURCE_DYES=1", x = 60 }, TURN)
onStatement(7, 3, { StatementType = "MAKE_DEAL", SessionID = 907 })
check("an inline answer is read as the answer", eventField(lastEvent("deal_declined"), "worth"), "20")
check("an inline answer closes the session", trade.sessions[3], nil)
check("the closer ends released after an inline answer", holds[#holds] and holds[#holds].open, false)

-- ── Peace rides the same lane: PROPOSED on our statement, then waits for the
-- host frame that proves ACCEPTED actually ended the war. ──
TURN = 70
local peace, peacePlayer = fixture({ atWar = true })
ok, why = applyOrder(peacePlayer, 7, { kind = "peace", subject = "5" }, TURN)
check("peace is submitted through the lane", ok, true)
check("peace says submitted", why, "peace_submitted")
check("peace waits for its session", #peace.sends, 0)
check("peace requests a MAKE_DEAL session", sessions.requested[#sessions.requested].kind, "MAKE_DEAL")
onStatement(7, 5, { StatementType = "MAKE_DEAL", SessionID = 903 })
check("the peace offer is PROPOSED once the session is live", peace.sends[1] and peace.sends[1][1], "proposed")
onStatement(5, 7, { StatementType = "MAKE_DEAL", SessionID = 903,
	StatementSubType = "NONE", ResponseType = DiplomacyResponseTypes.INITIAL,
	DealAction = DealProposalAction.ADJUSTED })
onStatement(5, 7, { StatementType = "MAKE_DEAL", SessionID = 903 })
check("a peace greeting does not consume the offer", trade.sessions[5] ~= nil, true)
check("a peace greeting does not submit another deal", #peace.sends, 1)

onStatement(5, 7, { StatementType = "MAKE_DEAL", SessionID = 903, DealAction = DealProposalAction.ACCEPTED })
check("an accepted peace is enacted by our ACCEPTED", peace.sends[2] and peace.sends[2][1], "accepted")
check("the peace answer is in the ledger", eventField(lastEvent("peace_response"), "accepted"), "true")
check("the answer is not called enacted before a host frame",
	eventField(lastEvent("peace_response"), "enacted"), "false")
check("the accepted session waits for the host frame", trade.sessions[5] ~= nil, true)
peace.atWar = false
trade.pollPeace()
check("the host frame proves peace", eventField(lastEvent("peace_result"), "enacted"), "true")
check("the peace session is closed", sessions.closed[#sessions.closed], 903)

-- Match the shipped `OnProposeOrAcceptDeal` path when the returned working
-- deal is not equal: send ADJUSTED and keep the session alive instead of
-- claiming that an ACCEPTED call enacted an invalid package.
TURN = 75
local adjusted, adjustedPlayer = fixture({ atWar = true, dealsEqual = false })
applyOrder(adjustedPlayer, 7, { kind = "peace", subject = "12" }, TURN)
onStatement(7, 12, { StatementType = "MAKE_DEAL", SessionID = 905 })
onStatement(12, 7, { StatementType = "MAKE_DEAL", SessionID = 905, DealAction = DealProposalAction.ACCEPTED })
check("an unequal accepted deal is adjusted", adjusted.sends[2] and adjusted.sends[2][1], "adjusted")
check("an unequal accepted deal is not enacted", eventField(lastEvent("peace_response"), "enacted"), "false")
check("an adjusted peace session stays open", trade.sessions[12] ~= nil, true)
adjusted.dealsEqual = true
onStatement(12, 7, { StatementType = "MAKE_DEAL", SessionID = 905, DealAction = DealProposalAction.ACCEPTED })
check("a reconciled deal is accepted", adjusted.sends[3] and adjusted.sends[3][1], "accepted")
adjusted.atWar = false
trade.pollPeace()
check("a reconciled deal proves peace", eventField(lastEvent("peace_result"), "enacted"), "true")

-- An adjusted answer is not an accepted treaty. If the closer later ends the
-- still-open session, it must be closed without manufacturing a peace result.
TURN = 78
local adjustedClosed, adjustedClosedPlayer = fixture({ atWar = true, dealsEqual = false })
applyOrder(adjustedClosedPlayer, 7, { kind = "peace", subject = "13" }, TURN)
onStatement(7, 13, { StatementType = "MAKE_DEAL", SessionID = 906 })
onStatement(13, 7, { StatementType = "MAKE_DEAL", SessionID = 906, DealAction = DealProposalAction.ACCEPTED })
onClosed(906)
check("an adjusted session closes", trade.sessions[13], nil)
check("an adjusted close has no synthetic peace result",
	eventField(lastEvent("peace_result"), "target"), "12")

TURN = 80
local refused, refusedPlayer = fixture({ atWar = true })
applyOrder(refusedPlayer, 7, { kind = "peace", subject = "6" }, TURN)
onStatement(7, 6, { StatementType = "MAKE_DEAL", SessionID = 904 })
local closedBeforePeaceRefusal = #sessions.closed
onStatement(6, 7, { StatementType = "MAKE_DEAL", SessionID = 904, DealAction = DealProposalAction.REJECTED })
check("a refused peace sends nothing more", #refused.sends, 1)
check("the refusal is in the ledger", eventField(lastEvent("peace_response"), "accepted"), "false")

-- A refusal may be followed by the rival's counter in this same session.
-- Closing at the refusal loses ownership before that next statement arrives.
check("a refused peace keeps its session for the counter", trade.sessions[6] ~= nil, true)
check("a peace refusal does not close under its counter", #sessions.closed, closedBeforePeaceRefusal)
check("the peace counter wait is recorded", eventField(lastEvent("deal_session"), "phase"), "counter_wait")
check("the peace counter hold is bounded", holds[#holds] and holds[#holds].seconds, 4)
onStatement(6, 7, { StatementType = "MAKE_DEAL", SessionID = 9999, StatementSubType = "POSITIVE" })
onStatement(6, 7, { StatementType = "GREETING", SessionID = 904, StatementSubType = "POSITIVE" })
onStatement(7, 6, { StatementType = "MAKE_DEAL", SessionID = 904, StatementSubType = "POSITIVE" })
check("unrelated statements do not consume a peace counter", #refused.sends, 1)
onStatement(6, 7, { StatementType = "MAKE_DEAL", SessionID = 904, StatementSubType = "POSITIVE" })
check("the peace counter is refused", refused.sends[2] and refused.sends[2][1], "rejected")
check("the peace counter is recorded", eventField(lastEvent("counter_answered"), "statement"), "POSITIVE")
check("peace closes after the counter is answered", sessions.closed[#sessions.closed], 904)
check("the answered peace counter is forgotten", trade.sessions[6], nil)
check("a refused counter does not enact peace", refused.atWar, true)

TURN = 84
local noCounter, noCounterPlayer = fixture({ atWar = true })
applyOrder(noCounterPlayer, 7, { kind = "peace", subject = "18" }, TURN)
onStatement(7, 18, { StatementType = "MAKE_DEAL", SessionID = 918 })
onStatement(18, 7, { StatementType = "MAKE_DEAL", SessionID = 918, DealAction = DealProposalAction.REJECTED })
local unansweredBeforePeaceCounter = trade.unanswered
onClosed(918)
check("no peace counter closes with its own reason", eventField(lastEvent("deal_session"), "why"), "counter_not_sent")
check("a refused peace is not an unanswered ask", trade.unanswered, unansweredBeforePeaceCounter)
check("no peace counter leaves no held turn", trade.turnHold, nil)
check("no peace counter leaves no session", trade.sessions[18], nil)

CivvisControlConfig.PeaceCounterHoldSeconds = 0
TURN = 85
local immediate, immediatePlayer = fixture({ atWar = true })
applyOrder(immediatePlayer, 7, { kind = "peace", subject = "19" }, TURN)
onStatement(7, 19, { StatementType = "MAKE_DEAL", SessionID = 919 })
onStatement(19, 7, { StatementType = "MAKE_DEAL", SessionID = 919, DealAction = DealProposalAction.REJECTED })
check("zero peace counter hold restores immediate close", trade.sessions[19], nil)
check("zero hold closes the actual session", sessions.closed[#sessions.closed], 919)
CivvisControlConfig.PeaceCounterHoldSeconds = nil

CivvisControlConfig.DealSessions = "trade"
TURN = 86
local requestedBeforeTradeOnly = #sessions.requested
local directPeace, directPeacePlayer = fixture({ atWar = true })
applyOrder(directPeacePlayer, 7, { kind = "peace", subject = "20" }, TURN)
check("trade-only peace retains its direct proposal", directPeace.sends[1] and directPeace.sends[1][1], "proposed")
check("trade-only peace opens no session", #sessions.requested, requestedBeforeTradeOnly)
check("trade-only peace registers no counter wait", trade.sessions[20], nil)

-- ── Peace-only mode keeps trade asks direct but still opens a peace session ──
CivvisControlConfig.DealSessions = "peace"
TURN = 90
local requestedBeforePeaceOnly = #sessions.requested
local peaceOnlySale, peaceOnlySeller = fixture()
applyOrder(peaceOnlySeller, 7,
	{ kind = "sell", subject = "3", verb = "RESOURCE_DYES=1", x = 60 }, TURN)
check("peace-only sends sales directly", peaceOnlySale.sends[1] and peaceOnlySale.sends[1][1], "equalize")
check("peace-only sale opens no session", #sessions.requested, requestedBeforePeaceOnly)
check("peace-only sale does not spend the unanswered budget", trade.unanswered, 0)
local peaceOnly, peaceOnlyPlayer = fixture({ atWar = true })
applyOrder(peaceOnlyPlayer, 7, { kind = "peace", subject = "14" }, TURN)
check("peace-only peace waits for a session", #peaceOnly.sends, 0)
check("peace-only peace opens a session", #sessions.requested, requestedBeforePeaceOnly + 1)
onStatement(7, 14, { StatementType = "MAKE_DEAL", SessionID = 907 })
check("peace-only peace sends in the session", peaceOnly.sends[1] and peaceOnly.sends[1][1], "proposed")
onStatement(14, 7, { StatementType = "MAKE_DEAL", SessionID = 907,
	DealAction = DealProposalAction.REJECTED })
CivvisControlConfig.DealSessions = true

-- ── Unanswered sessions are counted, and the third stands the lane down ──
for i = 1, 3 do
	TURN = 100 + i * 10
	local quiet, quietPlayer = fixture()
	local asked = applyOrder(quietPlayer, 7, { kind = "sell", subject = "3", verb = "RESOURCE_DYES=1", x = 60 }, TURN)
	check("unanswered ask " .. i .. " goes out", asked, true)
	onStatement(7, 3, { StatementType = "MAKE_DEAL", SessionID = 910 + i })
	-- The closer's ladder shuts the screen; the core reports the session closed.
	onClosed(910 + i)
	check("unanswered session " .. i .. " is counted", trade.unanswered, i)
	check("unanswered session " .. i .. " drops the ask", trade.pending[3], nil)
	check("unanswered session " .. i .. " says the question went out",
		eventField(lastEvent("deal_session"), "sent"), "true")
	check("unanswered session " .. i .. " records a queued rival session",
		eventField(lastEvent("deal_session"), "queued"), "true")
end
check("the lane stands down after three", trade.disabled, true)
check("the stand-down is in the ledger", lastEvent("deal_sessions_stood_down") ~= nil, true)
local requestedBefore = #sessions.requested
TURN = 150
local direct, directPlayer = fixture()
applyOrder(directPlayer, 7, { kind = "sell", subject = "3", verb = "RESOURCE_DYES=1", x = 60 }, TURN)
check("a stood-down lane asks directly", direct.sends[1] and direct.sends[1][1], "equalize")
check("a stood-down lane opens no session", #sessions.requested, requestedBefore)

-- ── The auto-closer honours the hold, and only for the diplomacy views ──
-- ── A sent ask closed unanswered holds the end turn (G72 t126 wedge) ──
-- The rival's verdict still arrives, as its own session to us; ending the
-- turn under it is the wedge. Hold until the rival speaks or the window ends.
local queue = rawget(_G, "CivvisQueue")
local clock, endTurns = 1000.0, 0
UI = setmetatable({ GetElapsedTime = function() return clock end,
       HasSentTurnComplete = function() return false end,
       RequestAction = function() endTurns = endTurns + 1 end },
       { __index = function() return stub() end })
ActionTypes = { ACTION_ENDTURN = "end_turn" }
CivvisControlConfig.DealAnswerHoldSeconds = 30
-- A fresh lane: the earlier sections' unanswered asks left holds and sessions.
trade.disabled, trade.unanswered, trade.turnHold = false, 0, nil
trade.sessions, trade.pending, trade.asked = {}, {}, {}
local function holdPhase() return eventField(lastEvent("deal_turn_hold"), "phase") end

TURN = 200
local held, heldPlayer = fixture()
check("a held-turn ask goes out",
	applyOrder(heldPlayer, 7, { kind = "sell", subject = "3", verb = "RESOURCE_DYES=1", x = 60 }, TURN), true)
onStatement(7, 3, { StatementType = "MAKE_DEAL", SessionID = 960 })
onClosed(960)
check("a sent ask closed unanswered holds the turn", holdPhase(), "held")
queue.requestEndTurn(TURN)
check("…the end turn is not requested", endTurns, 0)
check("…and the hold says so once", holdPhase(), "holding")
clock = clock + 10
queue.requestEndTurn(TURN, { REASON = "UserForced" })
check("…a forced end turn is held too", endTurns, 0)
onStatement(3, 7, { StatementType = "MAKE_DEAL", SessionID = 961 })
check("the rival speaking releases the hold", holdPhase(), "released")
check("…naming why", eventField(lastEvent("deal_turn_hold"), "why"), "rival_spoke")
clock = clock + 1
queue.requestEndTurn(TURN)
check("…and the turn ends", endTurns, 1)

TURN = 210
local quiet2, quiet2Player = fixture()
applyOrder(quiet2Player, 7, { kind = "sell", subject = "3", verb = "RESOURCE_DYES=1", x = 60 }, TURN)
onStatement(7, 3, { StatementType = "MAKE_DEAL", SessionID = 962 })
onClosed(962)
clock = clock + 29
queue.requestEndTurn(TURN)
check("inside the window the turn is held", endTurns, 1)
clock = clock + 2
queue.requestEndTurn(TURN)
check("after DealAnswerHoldSeconds the turn ends", endTurns, 2)
check("…the hold expired", eventField(lastEvent("deal_turn_hold"), "why"), "expired")

TURN = 220
local stale, stalePlayer = fixture()
applyOrder(stalePlayer, 7, { kind = "sell", subject = "3", verb = "RESOURCE_DYES=1", x = 60 }, TURN)
onStatement(7, 3, { StatementType = "MAKE_DEAL", SessionID = 964 })
onClosed(964)
TURN = 221
clock = clock + 1
queue.requestEndTurn(TURN)
check("a hold from an earlier turn does not hold this one", endTurns, 3)
check("…it is dropped as over", eventField(lastEvent("deal_turn_hold"), "why"), "turn_over")

-- An ask that never went out (no opening statement) leaves no hold.
TURN = 230
local unsent, unsentPlayer = fixture()
applyOrder(unsentPlayer, 7, { kind = "sell", subject = "3", verb = "RESOURCE_DYES=1", x = 60 }, TURN)
local before = #events
for subject, session in pairs(trade.sessions) do
	if subject == 3 then session.sent = false end
end
trade.abandon(3, "session_closed")
check("an unsent ask closed unanswered holds nothing", trade.turnHold, nil)
clock = clock + 1
queue.requestEndTurn(TURN)
check("…the turn ends at once", endTurns, 4)

-- ── A rival's session queued behind a dismissed screen is answered (G75 t133) ──
-- Our peace asks made 2 and 3 open their own sessions to us; 2's was refused,
-- 3's queued and opened behind a view the closer had already dismissed, so
-- nothing answered it and Civ un-readied every end turn for 3.5 minutes.
local realDiplomacy = DiplomacyManager
local open, answers = {}, {}
local stuck = false
local function closeIt(id)
	answers[#answers + 1] = "close:" .. id
	if not stuck then open[id] = nil end
end
DiplomacyManager = setmetatable({
	FindOpenSessionID = function(pid, other)
		for id, s in pairs(open) do
			if s.with == other and pid == 7 then return id end
		end
		return nil
	end,
	GetSessionInfo = function(id)
		local s = open[id]
		return s and { FromPlayer = s.from, ToPlayer = 7 } or nil
	end,
	IsSessionIDOpen = function(id) return open[id] ~= nil end,
	CloseSession = closeIt,
	AddResponse = function(id, pid, answer)
		answers[#answers + 1] = "respond:" .. id .. ":" .. answer
	end,
	HasQueuedSession = function() return false end,
}, { __index = realDiplomacy })
PlayerManager = { GetAliveMajorIDs = function() return { 7, 2, 3 } end }
local rejected = {}
local realDeals = DealManager
DealManager = setmetatable({
	SendWorkingDeal = function(action, pid, other) rejected[#rejected + 1] = action .. ":" .. other end,
}, { __index = realDeals })
CivvisControlConfig.OrphanSessionSeconds = 10
local function orphan() return lastEvent("orphan_session_answered") end

TURN = 240
trade.sessions, trade.turnHold = {}, nil
open[971] = { with = 3, from = 3 }
queue.requestEndTurn(TURN)
check("the first end turn goes out", endTurns, 5)
clock = clock + 5
queue.requestEndTurn(TURN)
check("a session open 5 s into the end turn is left to the closer", #answers, 0)
clock = clock + 5.5
queue.requestEndTurn(TURN)
check("after OrphanSessionSeconds the rival's session is refused", rejected[1], "rejected:3")
check("…then closed, as OnRefuseDeal(true) does", answers[1], "close:971")
check("…and the session is gone", open[971], nil)
check("the event names the rival", eventField(orphan(), "target"), "3")
check("…how it was answered", eventField(orphan(), "how"), "refused")
check("…that we did not own it", eventField(orphan(), "owned"), "false")
check("…and that it closed", eventField(orphan(), "still_open"), "false")
clock = clock + 1
queue.requestEndTurn(TURN)
check("with nothing open, the end turn goes out again", #answers, 1)

-- A session that will not close escalates once per second, then gives up.
TURN = 250
stuck = true
open[972] = { with = 2, from = 2 }
queue.requestEndTurn(TURN)
clock = clock + 10.5
queue.requestEndTurn(TURN)
clock = clock + 0.5
queue.requestEndTurn(TURN)
check("the net checks at most once a second", #answers, 2)
clock = clock + 0.6
queue.requestEndTurn(TURN)
check("a session still open is answered NEGATIVE", answers[3], "respond:972:NEGATIVE")
clock = clock + 1.1
queue.requestEndTurn(TURN)
check("…then closed bare", answers[4], "close:972")
clock = clock + 1.1
queue.requestEndTurn(TURN)
check("…then given up on", #answers, 4)
check("…and said so", eventField(lastEvent("orphan_session_stuck"), "session"), "972")
clock = clock + 1.1
queue.requestEndTurn(TURN)
check("…once", #answers, 4)
stuck, open = false, {}

-- At a 2x debug timescale the UI clock runs twice as fast, and both windows
-- still wait REAL seconds (CivvisClock divides the scale out): the 30 s
-- answer hold and the 10 s orphan net each take twice as many UI seconds.
local realClock = rawget(_G, "CivvisClock")
realClock.setScale(2)
trade.disabled, trade.unanswered, trade.turnHold = false, 0, nil
trade.sessions, trade.pending, trade.asked = {}, {}, {}
TURN = 260
local slow, slowPlayer = fixture()
applyOrder(slowPlayer, 7, { kind = "sell", subject = "3", verb = "RESOURCE_DYES=1", x = 60 }, TURN)
onStatement(7, 3, { StatementType = "MAKE_DEAL", SessionID = 966 })
onClosed(966)
local endsBefore = endTurns
clock = clock + 50
queue.requestEndTurn(TURN)
check("at 2x, 50 UI seconds (25 real) still hold the turn", endTurns, endsBefore)
clock = clock + 12
queue.requestEndTurn(TURN)
check("…31 real seconds release it", endTurns, endsBefore + 1)
check("…as expired", eventField(lastEvent("deal_turn_hold"), "why"), "expired")
TURN = 262
open[973] = { with = 3, from = 3 }
local answersBefore = #answers
queue.requestEndTurn(TURN)
clock = clock + 15
queue.requestEndTurn(TURN)
check("at 2x, 15 UI seconds (7.5 real) leave the session to the closer", #answers, answersBefore)
clock = clock + 6
queue.requestEndTurn(TURN)
check("…10.5 real seconds answer it", answers[#answers], "close:973")
open = {}
-- Back to the plain UI clock the sections below stamp holds with.
realClock.scale, realClock.offset = 1, 0

-- A session we opened is closed (not refused) and our ledger is closed with it.
TURN = 260
trade.sessions = { [3] = { kind = "sell", action = "EQUALIZE", turn = TURN, sent = true } }
open[973] = { with = 3, from = 7 }
local rejectedBefore = #rejected
queue.requestEndTurn(TURN)
clock = clock + 10.5
queue.requestEndTurn(TURN)
check("our own session is not refused", #rejected, rejectedBefore)
check("…it is closed", answers[#answers], "close:973")
check("…the event says we owned it", eventField(orphan(), "owned"), "true")
check("…and the ledger closes it as orphaned", eventField(lastEvent("deal_session"), "why"), "orphaned")
check("…leaving no session behind", trade.sessions[3], nil)

-- The deliberate unanswered-deal hold is not second-guessed.
TURN = 270
open[974] = { with = 3, from = 3 }
trade.turnHold = { turn = TURN, target = 3, at = clock }
local answersBefore = #answers
queue.requestEndTurn(TURN)
clock = clock + 12
CivvisTrade.answerOrphanSessions(TURN)
check("inside a deal hold the session is left alone", #answers, answersBefore)
trade.turnHold, open = nil, {}

DiplomacyManager, DealManager, PlayerManager = realDiplomacy, realDeals, nil
UI = nil  -- back to the stub for the sections below

local closerSrc = assert(io.open(here .. "/CivvisControlAutoClose.lua")):read("*a")
check("the closer listens for the session hold",
	closerSrc:find("LuaEvents.CivvisDealSession.Add(", 1, true) ~= nil, true)
check("the closer holds only the diplomacy views",
	closerSrc:find("local civvisDealView = NAME == \"DiplomacyActionView\" or NAME == \"DiplomacyDealView\";", 1, true) ~= nil, true)
check("the hold is bounded by the seconds it was given",
	closerSrc:find("dealHold = dealHold - dt;", 1, true) ~= nil, true)
check("an expired owned hold enters the force-close path",
	closerSrc:find("dealForceClose = true;", 1, true) ~= nil, true)
check("the owned hold can bypass an unfinished fade",
	closerSrc:find("if civvisDealView and not dealForceClose", 1, true) ~= nil, true)
check("a host-closed owned session keeps force-close latched",
	closerSrc:find("else\n\t\t\t\t\tdealHold = 0;\n\t\t\t\t\t-- CivvisTrade emits this event", 1, true) ~= nil, true)

-- ── A host close before the hold expires must still close the UI ──
-- The live t40 wedge happened in this ordering: the host closed the
-- Civvis-owned session before its four-second hold elapsed, the listener
-- cleared the hold, and `BlackFadeAnim:IsStopped()` stayed false forever.
-- Exercise the actual listener and update callback so a source-only check
-- cannot regress to the old `dealForceClose = false` behavior.
local oldGlobalMetatable = getmetatable(_G)
setmetatable(_G, nil)
local autoCloseConfig = CivvisControlConfig
autoCloseConfig.AnnouncementSeconds = 0.05
autoCloseConfig.DialogueSeconds = 0.05
autoCloseConfig.RunTag = "deal-session-autoclose-test"

local hidden = false
local update = nil
local sessionListener = nil
local closeCalls = 0
ContextPtr = {
	GetID = function() return "DiplomacyActionView" end,
	IsHidden = function() return hidden end,
	SetHide = function(_, value) hidden = value end,
	SetUpdate = function(_, callback) update = callback end,
}
Controls = {
	BlackFadeAnim = { IsStopped = function() return false end },
}
CloseFocusedState = function()
	closeCalls = closeCalls + 1
	hidden = true
end
LuaEvents = {
	CivvisDealSession = {
		Add = function(callback) sessionListener = callback end,
	},
}
Automation = { Log = function() end }
include = function() end

local autoCloseChunk, autoCloseErr = loadfile(here .. "/CivvisControlAutoClose.lua")
assert(autoCloseChunk, "could not load the autoclose shim: " .. tostring(autoCloseErr))
local autoCloseRan, autoCloseRuntimeErr = pcall(autoCloseChunk)
assert(autoCloseRan, "CivvisControlAutoClose.lua raised in deal-session test: " .. tostring(autoCloseRuntimeErr))
assert(type(sessionListener) == "function", "the autoclose shim did not register the deal listener")
assert(type(update) == "function", "the autoclose shim did not register an update callback")

-- The opening hold is still honored while the session is live.
sessionListener(4, true, 4)
update(0.05)
check("a live deal session does not close during its hold", closeCalls, 0)

-- The ask re-arms the hold with the answer window: a slow answer is not
-- closed out from under it when the opening hold's four seconds run out.
sessionListener(4, true, 30)
update(4.5)
check("an asked deal outlives the opening hold", closeCalls, 0)

-- The host closes it early. With the old listener this next update waits on
-- the never-stopping fade and leaves `closeCalls` at zero.
sessionListener(4, false, 0)
update(0.05)
check("an early host close enters the native close ladder", closeCalls, 1)
check("the early host close hides the action view", hidden, true)

-- At a 2x debug timescale the frame deltas run twice as fast, and the answer
-- hold still waits 30 REAL seconds: the closer divides each delta by the
-- scale the agent shares, and says which scale it read.
update(0.05)  -- a hidden frame resets the closer for the next show
ExposedMembers = { CivvisTimeScale = 2, CivvisClockAck = { scale = {}, at = {} } }
hidden = false
local closesAt2x = closeCalls
sessionListener(4, true, 30)
update(25); update(25)
check("at 2x, 50 frame seconds (25 real) keep the asked deal open", closeCalls, closesAt2x)
check("…and the closer acknowledges the scale it read",
	ExposedMembers.CivvisClockAck.scale.DiplomacyActionView, 2)
update(11)
update(0.05)
check("…31 real seconds end the hold", closeCalls, closesAt2x + 1)
-- A missing or nonsense scale reads as 1, and is acknowledged as 1, so the
-- agent sees the disagreement and reverts the timescale.
ExposedMembers = { CivvisTimeScale = "fast", CivvisClockAck = { scale = {}, at = {} } }
update(0.05)
check("a nonsense scale reads as 1", ExposedMembers.CivvisClockAck.scale.DiplomacyActionView, 1)
ExposedMembers = nil
update(0.05)
check("a missing shared table still ticks", type(update), "function")

-- A direct deal can also leave a live session on an otherwise blank action
-- view.  The ordinary close rung calls CloseSession, but Firaxis does not hide
-- the view as part of that API.  Exercise all ten native rungs: the first nine
-- are deliberately inert, while the session rung must prove it closed and
-- finish the same context without closing a replacement session.
local orphanHidden = false
local orphanUpdate = nil
local orphanCloseFocusedCalls = 0
local orphanCloseCalls = 0
local orphanSessionCloses = 0
local orphanSessionOpen = true
ContextPtr = {
	GetID = function() return "DiplomacyActionView" end,
	IsHidden = function() return orphanHidden end,
	SetHide = function(_, value) orphanHidden = value end,
	SetUpdate = function(_, callback) orphanUpdate = callback end,
}
Controls = {
	BlackFadeAnim = { IsStopped = function() return true end },
}
ms_ActiveSessionID = 77
ms_currentViewMode = -1
CloseFocusedState = function()
	orphanCloseFocusedCalls = orphanCloseFocusedCalls + 1
end
Close = function()
	orphanCloseCalls = orphanCloseCalls + 1
	orphanHidden = true
end
DiplomacyManager = {
	CloseSession = function(sessionID)
		check("the closer shuts only the captured session", sessionID, 77)
		orphanSessionCloses = orphanSessionCloses + 1
		orphanSessionOpen = false
	end,
	IsSessionIDOpen = function(sessionID)
		check("the closer verifies the captured session", sessionID, 77)
		return orphanSessionOpen
	end,
}
LuaEvents = {
	CivvisDealSession = {
		Add = function() end,
	},
}
local orphanChunk, orphanErr = loadfile(here .. "/CivvisControlAutoClose.lua")
assert(orphanChunk, "could not reload the autoclose shim: " .. tostring(orphanErr))
local orphanRan, orphanRuntimeErr = pcall(orphanChunk)
assert(orphanRan, "CivvisControlAutoClose.lua raised in orphan-session test: " .. tostring(orphanRuntimeErr))
assert(type(orphanUpdate) == "function", "the orphan-session closer has no update callback")
for rung = 1, 10 do
	orphanUpdate(rung == 1 and 0.05 or 30.01)
end
check("the first nine rungs leave the blank session visible", orphanCloseFocusedCalls, 6)
check("the verified session is closed once", orphanSessionCloses, 1)
check("a closed blank session finishes its action view", orphanCloseCalls, 1)
check("the session finalizer hides the action view", orphanHidden, true)

setmetatable(_G, oldGlobalMetatable)

if failures > 0 then
	realPrint(string.format("%d failure(s)", failures))
	os.exit(1)
end
realPrint("all deal session checks passed")
