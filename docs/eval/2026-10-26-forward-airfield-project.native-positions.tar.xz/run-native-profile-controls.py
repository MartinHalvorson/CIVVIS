"""Check fixed development/optimized profile equivalence before the complete corrected-source pass."""
import concurrent.futures,datetime,hashlib,json,os,pathlib,subprocess,sys
B=pathlib.Path('/tmp/civvis-forward-airfield-project-8c23');R=pathlib.Path('/Users/martbot-mbp-m5-max-128/civvis-forward-airfield-project-8c23');sys.path.insert(0,str(R/'tools'))
from civ6_decision_trace import captured_input
from civ6_ladder import decider_genome
out=B/'native-profile-controls-01';out.mkdir();registration=json.load((B/'native-optimized-profile-registration.json').open());registration['started_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();registration['script_sha256']=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest();(out/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
def run(index):
 old=json.load((B/f'native-queries-02-serve/{index:04}/result.json').open());case=old['case'];results=[]
 for read in old['reads']:
  d=out/f'{index:04}-read-{read["descriptor"]["snapshot_id"]}';d.mkdir();data=captured_input(case['capture'],read['descriptor']['snapshot_id']);prefix=d/'input.jsonl';prefix.write_bytes(data);arms=[]
  for arm in ['off','on']:
   template=next(a for a in read['arms'] if a['arm']==arm)
   for profile,build in [('dev','persistence-dev-build'),('ci','persistence-optimized-native-build')]:
    root=d/(profile+'-'+arm);root.mkdir();os.link(prefix,root/'events.jsonl');cmd=template['argv'].copy();cmd[0]=str(B/build/'civvis_orders');cmd[cmd.index('--mirror')+1]=str(root)
    with (root/'stdout').open('wb') as stdout,(root/'stderr').open('wb') as stderr:p=subprocess.run(cmd,input=(str(case['turn'])+'\n').encode(),stdout=stdout,stderr=stderr,timeout=300)
    payload=json.loads((root/'stdout').read_text()) if p.returncode==0 else None;genome=decider_genome(root/'stderr');arms.append({'arm':arm,'profile':profile,'argv':cmd,'exit':p.returncode,'payload':payload,'genome':genome,'full_genome_matches_frozen_source':genome==template['genome']});(root/'events.jsonl').unlink()
  equal=all(next(a for a in arms if a['arm']==arm and a['profile']=='dev')['payload']==next(a for a in arms if a['arm']==arm and a['profile']=='ci')['payload'] for arm in ['off','on']);complete=all(a['exit']==0 and a['full_genome_matches_frozen_source'] for a in arms) and equal
  result={'index':index,'run':case['run'],'turn':case['turn'],'snapshot_id':read['descriptor']['snapshot_id'],'input_sha256':hashlib.sha256(data).hexdigest(),'input_bytes':len(data),'arms':arms,'entire_responses_equal_across_profiles':equal,'complete':complete};results.append(result);(d/'result.json').write_text(json.dumps(result,indent=2)+'\n');prefix.unlink()
 return results
all_results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for results in pool.map(run,registration['case_indices']):
  all_results.extend(results);print(json.dumps({'case':results[0]['index'],'reads':len(results),'all_complete':all(r['complete'] for r in results)}),flush=True)
summary={'reads':len(all_results),'all_complete':all(r['complete'] for r in all_results),'failed_reads':[{'index':r['index'],'snapshot_id':r['snapshot_id']} for r in all_results if not r['complete']]};(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
