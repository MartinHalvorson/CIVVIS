"""Paired decider queries on live Immortal Domination frames where an unwalled
rival capital stood in reach at about twice the rival's power.

`open-capital-declares-at-twice` is the only bit that varies. Each case is a
live run's own events.jsonl cut at frame 0 of the turn (every row before the
turn's second `state` row; nothing of a later turn). Both arms run one frozen
release `civvis_orders --resumed` built from the branch, with that run's own
requested genome (why.log line 1 `forced`, each as `--with`). The off arm
must reproduce the live hold (no war opening on the target); the on arm is
the gene's proposal on the same input.

Optionally a case patches the captured rows (`patch`), and says so: `denounced`
marks the target as denounced by us six turns before (state DENOUNCED,
`our_denounce_turn`, DECLARE_FORMAL_WAR allowed), so the Formal War is
legal that turn, which shows the step after the denouncement on the same frame.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import re
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'open-capital-declares-at-twice'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CASES = [
    {'run': 'civvis-20261115T172539Z', 'turn': t, 'target': 2, 'target_civ': 'Arabia'} for t in (106, 107, 108, 109, 110, 111)
] + [
    {'run': 'civvis-20261115T181018Z', 'turn': t, 'target': 3, 'target_civ': 'Germany'} for t in (101, 102)
] + [
    {'run': 'civvis-20261115T172539Z', 'turn': 108, 'target': 2, 'target_civ': 'Arabia', 'patch': 'denounced'},
    {'run': 'civvis-20261115T181018Z', 'turn': 101, 'target': 3, 'target_civ': 'Germany', 'patch': 'denounced'},
]



def cut(run, turn, patch, target):
    rows = []
    seen = 0
    pat = re.compile(r'"turn": (\d+)')
    with open(RUNS / run / 'events.jsonl', errors='replace') as f:
        for line in f:
            if '"kind": "state"' in line:
                try:
                    e = json.loads(line)
                except ValueError:
                    e = {}
                if e.get('kind') == 'state':
                    if e.get('turn', 0) > turn:
                        break
                    if e.get('turn') == turn:
                        seen += 1
                        if seen >= 2:
                            break
                        if patch == 'denounced':
                            for r in e.get('rivals') or []:
                                if r.get('player') == target:
                                    r['our_denounce_turn'] = turn - 6
                                    r['diplomatic_state'] = 'DIPLO_STATE_DENOUNCED'
                                    for w in r.get('war_declarations') or []:
                                        if w.get('statement') == 'DECLARE_FORMAL_WAR':
                                            w['allowed'] = True
                            line = json.dumps(e) + '\n'
            else:
                m = pat.search(line[-300:]) or pat.search(line[:300])
                if m and int(m.group(1)) > turn:
                    break
            rows.append(line)
    return ''.join(rows).encode()


def war_orders(payload, target):
    # A war opening on the target: a denouncement or a declaration order naming
    # it. Standing combat policies (`DIALOGUE_NEVER_DECLARES_WAR`) are not.
    return [o for o in payload.get('orders', [])
            if o.get('kind') in ('war', 'denounce') and o.get('subject') == target]


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data = cut(case['run'], case['turn'], case.get('patch'), case['target'])
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'cut': 'frame 0',
                                 'patch': case.get('patch')},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', 'domination', '--civ', 'CIVILIZATION_SUMERIA']
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=600)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_war'] = [line for line in journal if re.search(
                r'Holding off war|Holding the|Declaring war|Denouncing|open-capital-declares-at-twice|'
                r'Holding the war on|for a capture|Campaign aimed|Grand strategy', line)]
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        off_war = war_orders(off.get('payload', {}), case['target'])
        on_war = war_orders(on.get('payload', {}), case['target'])
        record['off_war_orders'] = off_war
        record['on_war_orders'] = on_war
        # Control: the live seat held this turn; the off arm must open nothing.
        record['off_reproduces_live_hold'] = not off_war
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = (record['off_reproduces_live_hold']
                              and all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms']))
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        c = r['case']
        if r.get('error'):
            print(c['run'], c['turn'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            print(c['run'][-16:], 't%d' % c['turn'], c.get('patch') or '-', 'off', v['off_war_orders'], '| on', v['on_war_orders'])
            for a in v['arms']:
                for line in a['journal_war']:
                    if 'Grand strategy' in line or 'Campaign aimed' in line:
                        continue
                    print('   ', a['arm'], re.sub(r'\s*\[civ6 .*$', '', line)[:260])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
