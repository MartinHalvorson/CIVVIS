"""Paired decider queries on live frames of the three Deity Diplomatic-lane
games of 2026-11-18, one gene at a time.

    run-diplo-seat-queries.py REPO BINARY OUT GENE

GENE is one of `diplo-seat-statue-civic-first`,
`diplo-seat-statue-is-the-finisher`, `diplo-seat-claims-the-competition`,
`diplo-seat-allies-every-friend`, and is the only bit that varies between the
arms. Each case is a live run's own events.jsonl cut after the first state row
of turn N (the turn's opening frame, before its orders), replayed at turn N:
the board the live decider chose on. Both arms run
one frozen `civvis_orders --resumed --explain` built from the branch, with
that run's own requested genome (why.log line 1 `forced`, each as `--with`);
the on arm adds `--with GENE`.

Games (6-player Continents, Online, Deity, 250 turns, seat on the Diplomatic
lane, all carrying diplo-seat-statue-harbor and diplo-seat-wonder-claim):

- civvis-20261118T055703Z, Gaul: lost on 18 of 20 points at t191. Mercantilism
  at t127, then Diplomatic Service, The Enlightenment, Nationalism,
  Colonialism, Natural History and Scorched Earth before Civil Engineering at
  t159; the host offered the Statue of Liberty at 57 turns from t159 and the
  claim took it at t182 (230 of 620 in at the end); voted from 16 to 14 at
  the t169 session; three declared friends from t90 and no alliance; a member
  of an Aid Request (t125-145), a World Games (t130-147, nobody scored), a
  second Aid Request and a Space Station competition.
- civvis-20261118T061033Z, Hungary: won on 21 points at t183, the turn its
  Statue landed. Mercantilism at t108, Civil Engineering at t140; the Statue
  on offer at 33 turns from t140 and claimed at t152; two declared friends
  from t115; World Games t133-153 with 0 points.
- civvis-20261118T072032Z, Khmer: lost on 18 at t198. Civil Engineering at
  t135, Statue claimed t136 and landed t149 on 8 points; 15 at t155, 17 at
  t174, voted to 15 at the t175 session.

What each gene's cases are and what is read from each arm:

- statue-civic-first: the turns the live seat chose a civic, from the one
  after Mercantilism to Civil Engineering itself (a control: both arms name
  it). Read: the civic the arm orders, beside the civic the live seat took.
- statue-is-the-finisher: the frames where the host offered the Statue over
  the claim's 30-turn bar (Gaul t160-181, Hungary t140-151), the Statue's last
  turns on 8 points (Khmer t145-148: held at the last) and on 17 (Hungary
  t180-182: 17 + 4 wins, a control that must read the same). Read: the arm's
  Statue production orders and its `finisher` / `statue of liberty` lines.
- claims-the-competition: the frames of the scored competitions the seat was a
  member of. Read: the arm's Send Aid / Training Athletes / Training
  Astronauts production orders and its `for the competition` lines.
- allies-every-friend: every fourth frame from the first declared friend. Read:
  the arm's alliance orders and its `alliance` lines.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = sys.argv[4]
RUNS = Path.home() / 'civvis-score-tools/deity-18/congress'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

GAUL = ('civvis-20261118T055703Z', 'CIVILIZATION_GAUL')
HUNGARY = ('civvis-20261118T061033Z', 'CIVILIZATION_HUNGARY')
KHMER = ('civvis-20261118T072032Z', 'CIVILIZATION_KHMER')
PLANS = {
    'diplo-seat-statue-civic-first': {
        # The turns the live seat chose a civic between Mercantilism and Civil Engineering.
        'games': [(GAUL, [127, 132, 137, 144, 149, 154, 157]), (HUNGARY, [108, 114, 117, 124, 126, 132, 138]),
                  (KHMER, [110, 115, 119, 124, 126, 131, 133])],
        'journal': ('civil engineering', 'Research/Decision Adopting'),
        'orders': lambda o: o.get('kind') == 'civic',
    },
    'diplo-seat-statue-is-the-finisher': {
        'games': [(GAUL, list(range(160, 182, 3))), (HUNGARY, list(range(140, 152, 2)) + [180, 181, 182]),
                  (KHMER, [136, 145, 146, 147, 148])],
        'journal': ('finisher', 'statue of liberty', 'Statue of Liberty'),
        'orders': lambda o: o.get('kind') in ('produce', 'produce_next')
        and str(o.get('verb')) == 'BUILDING_STATUE_LIBERTY',
    },
    'diplo-seat-claims-the-competition': {
        'games': [(GAUL, list(range(126, 147, 2)) + list(range(161, 187, 3))),
                  (HUNGARY, list(range(116, 131, 3)) + list(range(134, 153, 2)) + list(range(166, 183, 3)))],
        'journal': ('for the competition', 'diplo-seat-claims-the-competition'),
        'orders': lambda o: o.get('kind') in ('produce', 'produce_next') and str(o.get('verb')) in
        ('PROJECT_SEND_AID', 'PROJECT_TRAIN_ATHLETES', 'PROJECT_TRAIN_ASTRONAUTS'),
    },
    'diplo-seat-allies-every-friend': {
        'games': [(GAUL, list(range(90, 190, 4))), (HUNGARY, list(range(112, 183, 4))),
                  (KHMER, list(range(100, 196, 8)))],
        'journal': ('alliance',),
        'orders': lambda o: o.get('kind') == 'alliance',
    },
}
PLAN = PLANS[GENE]
CASES = [{'run': run, 'civ': civ, 'turn': t} for (run, civ), turns in PLAN['games'] for t in turns]
_LINES = {}


def lines_of(run):
    if run not in _LINES:
        rows = []
        with open(RUNS / run / 'events.jsonl', 'rb') as f:
            for line in f:
                # The turn of a row is read from its own JSON, not a substring.
                try:
                    turn = json.loads(line).get('turn')
                except ValueError:
                    turn = 'bad'
                rows.append((turn, line))
        _LINES[run] = rows
    return _LINES[run]


def cut(run, turn):
    """Rows through the first state row of the turn (its opening frame, before
    the turn's orders), that row, and the turn's last state row (what the live
    seat had done by the end of it)."""
    kept, first, last = [], None, None
    for row_turn, line in lines_of(run):
        if row_turn == 'bad':
            continue
        if (row_turn or 0) > turn:
            break
        if first is None:
            kept.append(line)
        if row_turn == turn and b'"kind": "state"' in line:
            row = json.loads(line)
            if row.get('kind') != 'state':
                continue
            if first is None:
                first = row
            last = row
    return b''.join(kept), first, last


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data, last, after = cut(case['run'], case['turn'])
        board = {
            'dvp': last.get('dvp'), 'favor': last.get('favor'), 'favor_per_turn': last.get('favor_per_turn'),
            'civic': last.get('civic'), 'cities': len(last.get('cities') or []),
            'civil_engineering': 'CIVIC_CIVIL_ENGINEERING' in (last.get('civics') or []),
            'mercantilism': 'CIVIC_MERCANTILISM' in (last.get('civics') or []),
            'rivals': {str(r.get('player')): str(r.get('diplomatic_state')).replace('DIPLO_STATE_', '')
                       for r in last.get('rivals') or []},
            'competitions': [{'name': e.get('name'), 'member': (e.get('ours') or {}).get('member'),
                              'ours': (e.get('ours') or {}).get('score'),
                              'best': max([s.get('score') or 0 for s in e.get('scores') or []] or [0]),
                              'turns_left': e.get('turns_left')} for e in last.get('emergencies') or []],
        } if last else None
        live = {'civic': after.get('civic'),
                'producing': {c.get('name'): c.get('producing') for c in after.get('cities') or []}} if after else None
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'],
                                 'cut': 'through the first state row of the turn'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'board': board,
                  'live_by_the_end_of_the_turn': live, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', 'diplomatic', '--civ', case['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if any(k in line for k in PLAN['journal'])]
            row['orders_gene'] = [o for o in row.get('payload', {}).get('orders', []) if PLAN['orders'](o)]
            row['orders_produce'] = [[o.get('subject'), o.get('verb')] for o in row.get('payload', {}).get('orders', [])
                                     if o.get('kind') == 'produce']
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            mirror.rmdir()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = []
    for i, c in enumerate(CASES):
        r = one(i, c)
        results.append(r)
        if r.get('error'):
            print(c['run'][-16:], c['turn'], 'ERROR', r['error'], flush=True)
            continue
        for v in r['reads']:
            off, on = v['arms']
            print(f"{c['run'][-16:]} t{c['turn']:<3} {'CHANGED' if v['orders_changed'] else 'same   '} "
                  f"| off {json.dumps(off['orders_gene'])[:160]} | on {json.dumps(on['orders_gene'])[:160]} "
                  f"| on journal {on['journal_gene'][:2]}", flush=True)
    total = {'gene': GENE, 'cases': len(results),
             'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
             'off_gene_orders': sum(len(a['orders_gene']) for r in results for v in r['reads']
                                    for a in v['arms'] if a['arm'] == 'off'),
             'on_gene_orders': sum(len(a['orders_gene']) for r in results for v in r['reads']
                                   for a in v['arms'] if a['arm'] == 'on'),
             'on_gene_journal_lines': sum(len(a['journal_gene']) for r in results for v in r['reads']
                                          for a in v['arms'] if a['arm'] == 'on'),
             'off_gene_journal_lines': sum(len(a['journal_gene']) for r in results for v in r['reads']
                                           for a in v['arms'] if a['arm'] == 'off')}
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
