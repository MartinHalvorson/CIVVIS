"""Independently verify a completed, relocated first-pad proposal comparison."""
from pathlib import Path
import argparse,copy,hashlib,json,re,sys
p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();root=a.root.resolve()
sys.path.insert(0,str(root/'verification-tools'))
from civ6_decision_trace import validate_input_capture,captured_input,exact_fact
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text())
result=load(root/'continuation-result.json');assert result['execution_complete'] is True and result['original_protocol_qualified'] is False
assert load(root/'failure.json')['complete'] is False
build=load(root/'build-receipt.json');protocol=load(root/'initial-protocol.json');expected=protocol['candidate_commit'];assert build['source']['sha']==expected==result['source_commit']
assert build['status']=='complete' and build['architecture']=='arm64'
expected_tests={('lib','ai::advanced::native_production_contract::tests'):2,('civvis_orders','first_pad_observed_commitment_tests'):4,('civvis_orders','same_turn_wall_handoff_tests'):6}
assert {(t['target'],t['filter']):t['passed'] for t in build['tests']}==expected_tests
binary=build['binaries']['civvis_orders'];assert binary==result['binary_sha256']
if (root/'probe-binary').exists():assert sha((root/'probe-binary').read_bytes())==binary
frozen=(root/'events.jsonl').read_bytes();assert sha(frozen)==load(root/'source.json')['input_sha256s'][0]
tag='first-pad-in-the-forge';references={};rows=[];all_effects=[]
for repeat in [1,2]:
 pair=load(root/f'repeat-{repeat}/continuation-pair.json');assert pair['execution_complete'] is True and pair['original_protocol_qualified'] is False and pair['binary_commit']==expected and pair['binary_sha256']==binary
 arms=pair['arms'];assert [x['arm'] for x in arms]==['off','on']
 genomes={};effect={}
 payloads={}
 for arm in arms:
  name=arm['arm'];directory=root/f'repeat-{repeat}'/name;payload=load(directory/'stdout.json');assert exact_fact(payload,arm['payload']) and arm['exit']==0
  assert payload['turn']==151 and payload['decision']['turn']==151 and payload['decision']['frame']==0 and payload['decision']['victory_portfolio']['assigned_target']=='science'
  capture=copy.deepcopy(payload['input_capture']);oldroot=Path(arm['argv'][arm['argv'].index('--capture-inputs')+1]);suffix=Path(capture['directory']).relative_to(oldroot);capture['directory']=str(directory/'input-capture'/suffix);validate_input_capture(capture);assert capture['complete'] is True
  reads=[]
  for read in capture['reads']:reads.extend([captured_input(capture,read['snapshot_id'])]*read['count'])
  assert reads and all(b==frozen for b in reads) and len(reads)==arm['actual_read_count']
  genome=None
  for line in (directory/'stderr.log').read_text().splitlines():
   try:g=json.loads(line)
   except ValueError:continue
   if g.get('kind')=='genome':genome=g;break
  assert genome is not None
  assert all(exact_fact(genome.get(k),v) for k,v in arm['genome'].items())
  assert all((tag in genome[k])==(name=='on') for k in ['forced','treatments'])
  genomes[name]=genome
  stable={k:payload[k] for k in ['orders','decision']}
  if repeat==1:references[name]=stable
  else:assert exact_fact(stable,references[name]),'Repeated full reply differs'
  payloads[name]=payload
  slow=any(o.get('kind')=='produce' and o.get('subject')==458758 and o.get('verb')=='DISTRICT_SPACEPORT' and o.get('x') is not None and o.get('y') is not None for o in payload['orders'])
  repair=any(o.get('kind')=='produce' and o.get('subject')==196610 and o.get('verb')=='DISTRICT_AQUEDUCT' for o in payload['orders'])
  held=re.search(r'observed_first_pad_held=(\d+)',payload.get('note',''));held=int(held.group(1)) if held else 0
  if name=='on':assert not slow
  effect[name]={'slow_first_pad_emitted':slow,'guard_hold_count':held,'historical_repair_emitted':repair}
  rows.append({'repeat':repeat,'arm':name,'actual_reads':len(reads),'input_sha256':sha(frozen),'binary_sha256':binary,**effect[name]})
 for k in ['forced','treatments']:
  assert set(genomes['on'][k])-set(genomes['off'][k])=={tag} and not set(genomes['off'][k])-set(genomes['on'][k])
 assert exact_fact({k:v for k,v in genomes['on'].items() if k not in ['forced','treatments']},{k:v for k,v in genomes['off'].items() if k not in ['forced','treatments']})
 assert exact_fact(payloads['off']['decision']['native_actions'],payloads['on']['decision']['native_actions'])
 assert exact_fact([o for o in payloads['off']['orders'] if not (o.get('kind')=='produce' and o.get('subject')==458758 and o.get('verb')=='DISTRICT_SPACEPORT' and o.get('x') is not None)],payloads['on']['orders'])
 assert any(o.get('subject')==196610 and o.get('kind')=='produce' and o.get('verb')=='DISTRICT_SPACEPORT' for o in payloads['on']['orders'])
 all_effects.append(effect['off']['slow_first_pad_emitted'] and not effect['on']['slow_first_pad_emitted'] and effect['on']['guard_hold_count']>0)
report={'verified':True,'original_protocol_qualified':False,'original_failure_retained':True,'binary_sha256':binary,'native_guard_observed_in_both_repetitions':all(all_effects),'candidate_source':expected,'native_tests_passed':sum(expected_tests.values()),'rows':rows,'scope':'Original historical-repair gate failed and remains failed. Secondary guard observation after the first OFF arm: same candidate bytes and captured native public input, only existing first-pad flag differs. Native action plans match and ON emitted orders equal OFF with only the weak pad removed. Not original private-state replay, host execution, survival or victory evidence.'}
(root/'independent-continuation-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
