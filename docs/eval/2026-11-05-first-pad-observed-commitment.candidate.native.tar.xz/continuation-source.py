"""Finish only the three unexecuted predeclared arms; retain the original failure."""
from pathlib import Path
import copy,datetime,hashlib,json,shutil,subprocess,sys
base=Path(__file__).parent;repo=Path.home()/'civvis-first-pad-observed-commitment-f25d';root=base/'first-pad-native-41994358659-attempt1';sys.path.insert(0,str(repo/'tools'))
from civ6_captured_read_replay import expanded_reads
from civ6_ladder import decider_genome
from civ6_decision_trace import exact_fact
from native_build_artifact import verify
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
assert (root/'failure.json').exists() and not (root/'continuation-result.json').exists()
assert read(root/'failure.json')['error'].startswith("AssertionError('Captured repair must remain")
protocol=read(base/'first-pad-experiment-protocol.json');receipt=verify(repo,base/'first-pad-hosted-artifact-41994358659',protocol['candidate_commit'],json.dumps({'lib':['ai::advanced::native_production_contract::tests'],'civvis_orders':['first_pad_observed_commitment_tests','same_turn_wall_handoff_tests']}),'1.97.1')
assert sha((root/'probe-binary').read_bytes())==receipt['binaries']['civvis_orders']
shutil.copy2(base/'first-pad-probe.py',root/'initial-probe-source.py');shutil.copy2(base/'first-pad-experiment-protocol.json',root/'initial-protocol.json')
amendment={'bound_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_protocol_qualified':False,'original_failure':read(root/'failure.json'),'observed_first_off':'Fresh planner proposes Daegu pad, repair, then restores Daegu pad; final emitted orders contain both Daegu and Seoul pads. Original required repair is absent. Do not infer the cause of private/history/source divergence.','execution':'Preserve existing OFF1 output and actual captures; do not rerun it. Execute ONLY remaining original schedule ON1,OFF2,ON2, once each, on the same frozen prefix and candidate. No different input or binary.','analysis':'Secondary within-candidate native producer-floor observation: record whether ON holds slow Seoul, preserves the actual OFF Daegu pad, and has a positive observed_first_pad_held note. This does not retroactively satisfy the original historical-repair gate. Test coverage for emitted repair is separate.'}
(root/'continuation-protocol.json').write_text(json.dumps(amendment,indent=2)+'\n')
genome=read(base/'first-pad-observed-native-151-0/observed-context.json')['actual_genome'];tag='first-pad-in-the-forge';data=(root/'events.jsonl').read_bytes();common=root/'current-capture';references={};pairs=[]
for repeat in [1,2]:
 pairroot=root/f'repeat-{repeat}';pairroot.mkdir(exist_ok=True);arms=[]
 for name in ['off','on']:
  directory=pairroot/name
  command=[str(root/'probe-binary'),'--mirror',str(directory),'--turn','151','--victory','science','--civ','CIVILIZATION_KOREA','--explain','--serve','--fresh-board','--capture-inputs',str(common)]
  for gene in genome['forced']:
   if gene!=tag:command+=['--with',gene]
  if name=='on':command+=['--with',tag]
  if repeat==1 and name=='off':
   assert (directory/'stdout.json').exists() and common.exists();code=0;reused=True
  else:
   directory.mkdir();(directory/'events.jsonl').write_bytes(data);assert not common.exists()
   proc=subprocess.run(command,cwd=repo,input='151\n',text=True,capture_output=True,timeout=180);code=proc.returncode;(directory/'stdout.json').write_text(proc.stdout);(directory/'stderr.log').write_text(proc.stderr);assert code==0,(name,code,proc.stderr[-1000:]);reused=False
  payload=read(directory/'stdout.json');assert payload['turn']==151 and (payload['decision']['turn'],payload['decision']['frame'])==(151,0) and payload['decision']['victory_portfolio']['assigned_target']=='science'
  reads=expanded_reads(payload['input_capture']);assert reads and all(b==data for b in reads)
  actual=decider_genome(directory/'stderr.log');assert actual
  stable={k:payload[k] for k in ['orders','decision']}
  if repeat==1:references[name]=stable
  else:assert exact_fact(stable,references[name]),f'{name} repeated reply changed'
  moved=directory/'input-capture';assert not moved.exists();shutil.move(str(common),str(moved))
  arms.append({'arm':name,'exit':code,'argv':command,'argv_scope':'Reconstructed from unchanged original script for reused OFF1; direct launch command for remaining arms. No native PID argv observation is claimed.','reused_original_off1_without_requery':reused,'genome':actual,'payload':payload,'binary_sha256':receipt['binaries']['civvis_orders'],'actual_read_count':len(reads),'capture_relocated_to':str(moved)})
  print(json.dumps({'repeat':repeat,'arm':name,'reads':len(reads),'production_orders':[o for o in payload['orders'] if o['kind']=='produce'],'guard_note': 'observed_first_pad_held=' in payload.get('note','')}),flush=True)
 off,on=arms
 for field in ['forced','treatments']:
  assert set(on['genome'][field])-set(off['genome'][field])=={tag} and not set(off['genome'][field])-set(on['genome'][field])
 assert exact_fact({k:v for k,v in off['genome'].items() if k not in ['forced','treatments']},{k:v for k,v in on['genome'].items() if k not in ['forced','treatments']})
 pair={'execution_complete':True,'original_protocol_qualified':False,'binary_commit':protocol['candidate_commit'],'binary_sha256':receipt['binaries']['civvis_orders'],'arms':arms,'scope':amendment['analysis']};(pairroot/'continuation-pair.json').write_text(json.dumps(pair,indent=2)+'\n');pairs.append(str(pairroot/'continuation-pair.json'))
assert sha((root/'probe-binary').read_bytes())==receipt['binaries']['civvis_orders']
(root/'continuation-result.json').write_text(json.dumps({'execution_complete':True,'original_protocol_qualified':False,'original_failure_retained':True,'pairs':pairs,'source_commit':protocol['candidate_commit'],'binary_sha256':receipt['binaries']['civvis_orders'],'scope':'Only original unexecuted roles were run. Same fixed captured public bytes; fresh private planner. Secondary native guard observation, no original historical repair parity, host execution, survival or strength claim.'},indent=2)+'\n')
