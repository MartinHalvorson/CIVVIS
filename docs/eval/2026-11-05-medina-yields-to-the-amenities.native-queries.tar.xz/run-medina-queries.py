"""Paired decider queries on captured live Deity Korea boards.

`medina-yields-to-the-amenities` is the only bit that varies. Each case is a
live run's own event log cut at the named turn's first state record (every
line before the turn's first later frame, where the host re-exports a deck it
has already changed), from a turn on which the live seat's
policy deck slotted Medina Quarter (`Slotted medina quarter over ...`), the
card not yet held and two or more cities short of Amenities in that first
frame. Both arms run one frozen
ci-profile `civvis_orders` built from the branch with that run's own
requested genome (`summary.json` `forced`, else the first `why.log` line's for
a continuation run, each as `--with`). The off arm must, like the live seat,
put Medina Quarter in its `policy_deck` order; the on arm is the gene's
proposal on the same input.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'medina-yields-to-the-amenities'
CONTROL = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CASES = [
    {'run': 'civvis-20261104T213449Z', 'turn': 101},
    {'run': 'civvis-20261104T213449Z', 'turn': 147},
    {'run': 'civvis-20261105T002152Z', 'turn': 99},
    {'run': 'civvis-20261105T010830Z', 'turn': 100},
    {'run': 'civvis-20261105T020911Z', 'turn': 130},
    {'run': 'civvis-20261105T040135Z', 'turn': 111},
]


def cut(run, turn):
    """The run's events through `turn`: stop at the first later `state`."""
    kept = []
    with (CONTROL / run / 'events.jsonl').open('rb') as source:
        for line in source:
            if b'"kind": "state"' in line or b'"kind":"state"' in line:
                try:
                    event = json.loads(line)
                except ValueError:
                    event = {}
                state = event.get('state') or event
                # The host applies a deck change at once and re-exports the
                # turn (frame > 0): the cut keeps the turn's first frame only.
                if (state.get('turn') or 0) > turn or (
                        (state.get('turn') or 0) == turn and (state.get('frame') or 0) != 0):
                    break
            kept.append(line)
    return b''.join(kept)


def medina_decks(payload):
    return [o for o in payload.get('orders', [])
            if o.get('kind') == 'policy_deck' and 'POLICY_MEDINA_QUARTER' in str(o.get('verb', ''))]


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        summary_path = CONTROL / case['run'] / 'summary.json'
        summary = json.loads(summary_path.read_text()) if summary_path.exists() else {}
        if 'forced' in summary:
            forced = list(summary['forced'])
        else:  # a continuation run: the decider's own first journal line
            with (CONTROL / case['run'] / 'why.log').open() as why:
                forced = list(json.loads(why.readline())['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data = cut(case['run'], case['turn'])
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'],
                                 'cut': 'events.jsonl through the turn'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', 'science',
                   '--turn', str(case['turn'])]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            text = stderr.read_text()
            row['journal'] = [line for line in text.splitlines() if line.startswith('[why]')]
            row['medina_journal'] = [line for line in row['journal'] if 'medina' in line.lower()]
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
        off, on = record['arms']
        record['off_medina_decks'] = medina_decks(off.get('payload', {}))
        record['on_medina_decks'] = medina_decks(on.get('payload', {}))
        # Control: like the live seat, the off arm slots Medina Quarter.
        record['off_reproduces_live_medina'] = record['off_medina_decks'] != []
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = (record['off_reproduces_live_medina']
                              and all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms']))
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        for v in r['reads']:
            for a in v['arms']:
                print(r['case']['run'], r['case']['turn'], a['arm'], 'exit', a['exit'],
                      [o['verb'][:120] for o in a.get('payload', {}).get('orders', []) if o.get('kind') == 'policy_deck'],
                      a.get('medina_journal', [])[:2])
        if r.get('error'):
            print(r['case']['run'], 'ERROR', r['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
