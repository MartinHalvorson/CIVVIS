"""Repeated first-divergence queries; no orders are published to a native game."""
from pathlib import Path
import sys,json,copy,hashlib,datetime,os
root=Path(__file__).parent;parent=root.parent;sys.path.insert(0,str(parent/'replay-tools'));import civ6_captured_read_replay as replay
from native_city_route_replay import control_payload,request_identity_errors
from civ6_decision_trace import exact_fact
def run_control(context,records,mapping,directory,timeout,delivery):
 directory.mkdir();command,cwd=replay.replay_command(context,directory);worker=None;feeder=None;results=[];key=None
 with (directory/'stderr.log').open('w') as err,(directory/'replies.jsonl').open('w') as output:
  try:
   import subprocess
   worker=subprocess.Popen(command,cwd=cwd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1)
   for record in records:
    key=(record['decision']['turn'],record['decision']['frame']);cap=dict(record['input_capture']);cap['directory']=str(mapping[cap['directory']]);expected=replay.expanded_reads(cap);path=directory/'events.jsonl'
    if path.exists():path.unlink()
    feeder=replay.deliver_reads(path,expected,timeout,delivery);mode=getattr(feeder,'mode','fifo');worker.stdin.write(str(key[0])+'\n');worker.stdin.flush();reply=replay.request_reply(worker,timeout);output.write(json.dumps(reply,sort_keys=True)+'\n');output.flush();feeder.finish();feeder=None;actual=replay.expanded_reads(reply['input_capture'])
    result={'request':list(key),'identity_errors':request_identity_errors(reply,*key),'input_delivery':mode,'native_payload_matches':exact_fact(control_payload(record),control_payload(reply)),'read_sequence_matches':expected==actual,'recorded_reads':len(expected),'replayed_reads':len(actual),'expected_read_sha256':replay.read_sha256(expected),'actual_read_sha256':replay.read_sha256(actual)};results.append(result)
    if result['identity_errors'] or not result['read_sequence_matches']:raise ValueError('actual identity/read controls differ')
    if not result['native_payload_matches']:break
   worker.stdin.close();code=worker.wait(timeout=30)
   return {'complete':code==0,'exit':code,'passed':len(results)==len(records) and all(r['native_payload_matches'] for r in results),'command':command,'cwd':cwd,'requests':results,'failed_request':next((r['request'] for r in results if not r['native_payload_matches']),None),'error':None}
  except Exception as e:
   return {'complete':False,'exit':worker.poll() if worker else None,'passed':False,'command':command,'cwd':cwd,'requests':results,'failed_request':key,'error':type(e).__name__+': '+str(e)}
  finally:
   if feeder is not None:feeder.close()
   if worker is not None:
    if worker.poll() is None:worker.terminate();worker.wait(timeout=10)
    worker.stdout.close()

build=json.loads((root/'build-receipt.json').read_text());assert build['exit']==0 and build['source_unchanged'];binary=root/'civvis_orders';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(binary)==build['binary_sha256'];base=parent/'library-delay-reconstruction/control';original=json.loads((base/'qualification.json').read_text());assert original['passed'];context=json.loads((parent/'library-delay-reconstruction/context.json').read_text());manifest=context['runtime_manifest'];runtime=Path(context['processes'][0]['cwd']);assert all(sha(runtime/f)==h for f,h in manifest.items())
context['processes'][0]['argv'][0]=str(binary);context['binary_sha256']=build['binary_sha256'];context['provenance']={'sha256':build['binary_sha256'],'revision':build['source_revision'],'kind':'frozen_candidate_build'};records=[json.loads(l) for l in (base/'native-decisions.jsonl').open()];mapping={r['source']:Path(r['sealed_directory']) for r in original['sealed_captures']};out=root/'history-proof';out.mkdir(exist_ok=False);tag='parallel-library-backlog';os.environ['CIVVIS_COMMIT']=build['source_revision']
intent={'source':build['source_revision'],'binary_sha256':build['binary_sha256'],'script_sha256':sha(__file__),'arm_order':['off','on','on','off'],'target':tag,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Later candidate program against actual chronological native captured reads. OFF must functionally reproduce every original full payload/read through80 in both controls. ON stops at first full-reply difference; prior prefix and every actual input read must match. Original launch setup was reconstructed, not kernel-observed. Every process exits successfully after EOF, including ON after its first divergence. No native execution, counterfactual future-world or strength claim.','runtime_manifest':manifest};(out/'intent.json').write_text(json.dumps(intent,indent=2)+'\n');results=[]
for n,arm in enumerate(intent['arm_order']):
 ctx=copy.deepcopy(context)
 if arm=='on':ctx['processes'][0]['argv']+=['--with',tag]
 working=out/'query';result=run_control(ctx,records,mapping,working,180,'hybrid-tail');archive=out/f'{n}-{arm}';working.rename(archive)
 genome=None
 for line in (archive/'stderr.log').open():
  try:d=json.loads(line)
  except ValueError:continue
  if d.get('kind')=='genome':genome=d;break
 result.update({'round':n,'arm':arm,'genome':genome,'archive':str(archive),'capture_directory_map':{str(working):str(archive)}});(archive/'result.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result);print(json.dumps({'round':n,'arm':arm,'native_match':result['passed'],'requests':len(result['requests']),'first_difference':result.get('failed_request'),'error':result.get('error')}),flush=True)
 assert result['complete'] and result['exit']==0
 assert genome and (tag in genome['treatments'])==(arm=='on')
 if arm=='off':
  if not result['passed']:
   (out/'baseline-rejected.json').write_text(json.dumps({'scope':intent['scope'],'result':result,'reason':'Candidate OFF differs from the recorded native baseline. Do not interpret an ON action change under the claimed exact-baseline protocol.'},indent=2)+'\n');raise SystemExit(2)
  assert len(result['requests'])==len(records)
 else:
  if result['passed']:
   (out/'no-footprint.json').write_text(json.dumps({'scope':intent['scope'],'source':intent['source'],'reason':'ON matches the complete native prefix; no firing result. Investigate rather than retune or waive the gate.'},indent=2)+'\n');raise SystemExit(3)
  last=result['requests'][-1];assert result['failed_request']==last['request'] and last['read_sequence_matches'] and not last['identity_errors'] and not last['native_payload_matches']
  assert all(r['native_payload_matches'] and r['read_sequence_matches'] and not r['identity_errors'] for r in result['requests'][:-1])
off=[r for r in results if r['arm']=='off'];on=[r for r in results if r['arm']=='on'];assert on[0]['failed_request']==on[1]['failed_request']
for r in on:
 for key in ['treatments','forced']:assert set(r['genome'][key])==set(off[0]['genome'][key])|{tag} and tag not in off[0]['genome'][key]
 for key in set(r['genome'])-{'treatments','forced','ledger_withheld'}:assert exact_fact(r['genome'][key],off[0]['genome'][key])
assert sha(binary)==build['binary_sha256'] and all(sha(runtime/f)==h for f,h in manifest.items())
(out/'completed.json').write_text(json.dumps({'scope':intent['scope'],'source':intent['source'],'binary_sha256':build['binary_sha256'],'first_difference':on[0]['failed_request'],'one_effective_bit':True,'runtime_unchanged':True,'rounds':[{k:r.get(k) for k in ['arm','passed','failed_request','archive']} for r in results]},indent=2)+'\n');print('COMPLETE',flush=True)
