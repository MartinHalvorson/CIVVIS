"""Paired decider queries on the live Pangaea board that refused Washington.

`first-capital-walks-the-one-landmass` edition.

Live Deity Macedon, four majors on a Tiny Pangaea at Online speed, game
civvis-20261111T040245Z. The first-meeting capital exchange charted
Washington on turn 11, 12 tiles from our capital behind no walls, and the
armed `first-capital-before-the-walls` refused it at every note from turn 12
to turn 62: "no charted land walk reaches their capital". Each case is a turn
of that window, cut at the turn's first state frame.

`first-capital-walks-the-one-landmass` is the only bit that varies; both arms
carry the run's own requested genome (`summary.json` `forced`, which holds
`first-capital-before-the-walls`, `early-conquest-opening` and
`find-the-capital`). Both arms run one frozen ci-profile
`civvis_orders --resumed` built from the branch. Expected: the off arm
journals the refusal; the on arm names Washington ("Opening a conquest
against America", "... Washington over uncharted ground"), and the nearest
free scout charts the walk while it crosses fog.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'first-capital-walks-the-one-landmass'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

RUNS = Path.home() / 'civvis-civ6-runs/control'
RUN = 'civvis-20261111T040245Z'
CASES = [{"run": RUN, "turn": turn} for turn in (15, 25, 35, 45, 55)]
KEYS = ('First capital before the walls', 'Opening a conquest', 'charts the walk',
        'conquest force', 'Washington')


def cut(src, dst, turn):
    """The run's log up to and including the turn's first state frame."""
    with open(src, 'rb') as f, open(dst, 'wb') as g:
        for line in f:
            g.write(line)
            if b'"kind": "state"' in line:
                try:
                    if json.loads(line).get('turn') == turn:
                        return
                except Exception:
                    pass
    raise ValueError('no state frame for that turn')


def requested(run):
    summary = json.loads((run / 'summary.json').read_text())
    return summary['forced'], summary.get('victory_target') or 'domination', 'summary.json'


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        run = RUNS / case['run']
        forced, victory, source = requested(run)
        forced = [t for t in forced if t != GENE]
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'victory': victory,
                                 'genome_source': source}, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            # Only the summary rides beside the cut log: the run's own
            # why.log/decisions would otherwise be read as this query's.
            (mirror / 'summary.json').write_bytes((run / 'summary.json').read_bytes())
            cut(run / 'events.jsonl', mirror / 'events.jsonl', case['turn'])
            data = (mirror / 'events.jsonl').read_bytes()
            record['bytes'] = len(data)
            record['sha256'] = hashlib.sha256(data).hexdigest()
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', victory,
                   '--turn', str(case['turn']), '--resumed']
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': decider_genome(stderr)}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]') and any(k in line for k in KEYS)]
            record['arms'].append(row)
            for f in mirror.iterdir():
                f.unlink()
            mirror.rmdir()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['journal_changed'] = off['journal'] != on['journal']
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        print(r['case']['run'], 't', r['case']['turn'], 'ERROR ' + r['error'] if r.get('error') else '')
        for v in r['reads']:
            print('   orders_changed', v.get('orders_changed'))
            for a in v['arms']:
                orders = a.get('payload', {}).get('orders', [])
                print('  ', a['arm'], 'exit', a['exit'], 'orders', len(orders),
                      'wall %.1fs' % a['wall_seconds'])
                for line in a['journal'][:8]:
                    print('     ', line[:300])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
