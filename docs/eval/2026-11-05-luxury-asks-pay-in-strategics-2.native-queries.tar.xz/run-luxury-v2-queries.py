"""Paired decider queries on captured live Deity Korea boards.

`luxury-asks-pay-in-strategics-2` is the only bit that varies. Each case is
a live run (carrying version one, armed 2026-11-05 02:01Z) at a luxury-slot
turn where the live seat put up an ask whose kind the buy arm had answered
`barter_short` fewer than 20 turns before (30 standard turns at Online
speed): a strategic-paid ask to the same partner, or a luxury swap of the
same copy to any partner. The input is the run's own event log through the
turn's first state frame and nothing after it, so neither arm sees the
answer to the ask being replayed. Both arms run one frozen ci-profile
`civvis_orders` built from the branch with the run's own requested genome
(`summary.json` `forced`, else the first `why.log` line's) as `--with`. The
off arm must, like the live seat, put up the live ask (partner and verb).
The on arm is version two's proposal on the same input.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'luxury-asks-pay-in-strategics-2'
V1 = 'luxury-asks-pay-in-strategics'
CONTROL = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CASES = [
    # strategic-paid asks to a partner whose strategic-paid ask shorted
    {'run': 'civvis-20261105T033244Z', 'turn': 184, 'live_target': 5, 'live_verb': 'LUXURY_ANY;RESOURCE_IRON=1'},
    {'run': 'civvis-20261105T033244Z', 'turn': 190, 'live_target': 5, 'live_verb': 'LUXURY_ANY;RESOURCE_IRON=1'},
    {'run': 'civvis-20261105T113105Z', 'turn': 124, 'live_target': 4, 'live_verb': 'LUXURY_ANY;RESOURCE_HORSES=3'},
    {'run': 'civvis-20261105T113105Z', 'turn': 130, 'live_target': 4, 'live_verb': 'LUXURY_ANY;RESOURCE_HORSES=3'},
    # swaps of a copy whose swap shorted
    {'run': 'civvis-20261105T040135Z', 'turn': 106, 'live_target': 4, 'live_verb': 'LUXURY_ANY;RESOURCE_TRUFFLES=1'},
    {'run': 'civvis-20261105T040135Z', 'turn': 118, 'live_target': 3, 'live_verb': 'LUXURY_ANY;RESOURCE_TRUFFLES=1'},
    {'run': 'civvis-20261105T040135Z', 'turn': 124, 'live_target': 2, 'live_verb': 'LUXURY_ANY;RESOURCE_TRUFFLES=1'},
    {'run': 'civvis-20261105T085437Z', 'turn': 100, 'live_target': 4, 'live_verb': 'LUXURY_ANY;RESOURCE_MARBLE=1'},
    {'run': 'civvis-20261105T085437Z', 'turn': 112, 'live_target': 1, 'live_verb': 'LUXURY_ANY;RESOURCE_MARBLE=1'},
    {'run': 'civvis-20261105T085437Z', 'turn': 136, 'live_target': 4, 'live_verb': 'LUXURY_ANY;RESOURCE_MARBLE=1'},
    {'run': 'civvis-20261105T085437Z', 'turn': 160, 'live_target': 5, 'live_verb': 'LUXURY_ANY;RESOURCE_DIAMONDS=1'},
    {'run': 'civvis-20261105T102328Z', 'turn': 106, 'live_target': 3, 'live_verb': 'LUXURY_ANY;RESOURCE_SUGAR=1'},
]


def cut(run, turn):
    """The run's events through `turn`'s first state frame, nothing after."""
    kept = []
    with (CONTROL / run / 'events.jsonl').open('rb') as source:
        for line in source:
            if b'"kind": "state"' in line or b'"kind":"state"' in line:
                try:
                    event = json.loads(line)
                except ValueError:
                    event = {}
                at = event.get('turn') or 0
                if at > turn:
                    break
                if at == turn and (event.get('frame') or 0) == 0:
                    kept.append(line)
                    break
            kept.append(line)
    return b''.join(kept)


def shorts_before(run, turn):
    """`(turn, partner)` of each `barter_short` before `turn`."""
    out = []
    for line in (CONTROL / run / 'events.jsonl').open('rb'):
        if b'barter_short' not in line:
            continue
        event = json.loads(line)
        if event.get('kind') == 'deal_offer' and event.get('reason') == 'barter_short' \
                and (event.get('turn') or 0) < turn:
            out.append((event['turn'], event['target']))
    return out


def luxury_asks(payload):
    return [o for o in payload.get('orders', [])
            if o.get('kind') == 'buy' and str(o.get('verb', '')).startswith('LUXURY_ANY')]


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        summary_path = CONTROL / case['run'] / 'summary.json'
        summary = json.loads(summary_path.read_text()) if summary_path.exists() else {}
        if 'forced' in summary:
            forced = list(summary['forced'])
        else:
            with (CONTROL / case['run'] / 'why.log').open() as why:
                forced = list(json.loads(why.readline())['forced'])
        if GENE in forced or V1 not in forced:
            raise ValueError('the live genome must carry version one and not version two')
        data = cut(case['run'], case['turn'])
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'],
                                 'cut': "events.jsonl through the turn's first state frame"},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                  'shorts_before': shorts_before(case['run'], case['turn']), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', 'science',
                   '--turn', str(case['turn'])]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': decider_genome(stderr)}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            text = stderr.read_text()
            row['journal'] = [line for line in text.splitlines() if line.startswith('[why]')]
            row['luxury_notes'] = sorted({word for word in text.replace(';', ' ').split()
                                          if word.startswith(('luxury_swap', 'luxury_strategic'))})
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
        off, on = record['arms']
        record['off_luxury_asks'] = luxury_asks(off.get('payload', {}))
        record['on_luxury_asks'] = luxury_asks(on.get('payload', {}))
        record['off_reproduces_live_ask'] = [(o.get('subject'), o.get('verb')) for o in record['off_luxury_asks']] \
            == [(case['live_target'], case['live_verb'])]
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = (record['off_reproduces_live_ask']
                              and all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms']))
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        for v in r['reads']:
            for a in v['arms']:
                print(r['case']['run'][-8:], r['case']['turn'], a['arm'], 'exit', a['exit'],
                      [(o['subject'], o['verb']) for o in luxury_asks(a.get('payload', {}))],
                      a.get('luxury_notes'), 'shorts<', v['shorts_before'][-3:])
        if r.get('error'):
            print(r['case']['run'], 'ERROR', r['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
