from pathlib import Path
import hashlib,json,copy
from civ6_decision_trace import validate_input_capture,captured_input
r=Path(__file__).parent
rec=json.loads((r/'native-record.json').read_text());unsigned={k:v for k,v in rec.items() if k!='sha256'}
assert hashlib.sha256(json.dumps(unsigned,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()==rec['sha256']
c=copy.deepcopy(rec['input_capture']);c['directory']=str(r/'sealed/source-capture-0');validate_input_capture(c)
reads=[]
for x in c['reads']:reads.extend([captured_input(c,x['snapshot_id'])]*x['count'])
assert len(reads)==18 and all(b==reads[0] for b in reads) and reads[0]==(r/'input.events.jsonl').read_bytes()
events=[json.loads(l) for l in reads[0].splitlines()];s=next(e for e in reversed(events) if e.get('kind')=='state')
assert (s['turn'],s['frame'])==(138,0)
assert not any(c.get('producing')=='DISTRICT_SPACEPORT' or any(d['type']=='DISTRICT_SPACEPORT' for d in c.get('districts',[])) for c in s['cities'])
low=next(c for c in s['cities'] if c['id']==524295);assert low['production']==18
assert max(c['production'] for c in s['cities'] if any(q.get('t')=='DISTRICT_SPACEPORT' and (q.get('n',0)>0 or q.get('s')) for q in c['buildable']))==49
planned=[a for a in rec['decision']['native_actions'] if a['type']=='produce']
assert any(a['city']==50 and a['item'].get('district')=='spaceport' for a in planned)
assert any(a['city']==50 and a['item'].get('building')=='coal_power_plant' for a in planned)
assert any(o.get('subject')==65536 and o.get('verb')=='BUILDING_COAL_POWER_PLANT' for o in rec['orders'])
assert not any(o.get('subject')==65536 and o.get('verb')=='DISTRICT_SPACEPORT' for o in rec['orders'])
assert any(o.get('subject')==524295 and o.get('verb')=='DISTRICT_SPACEPORT' for o in rec['orders'])
g=json.loads((r/'observed-genome-summary.json').read_text());assert all('first-pad-in-the-forge' in g[k] for k in ['forced','treatments'])
after=json.loads((r/'next-state.json').read_text());pads=[c['id'] for c in after['cities'] if any(d['type']=='DISTRICT_SPACEPORT' for d in c.get('districts',[]))]
assert pads==[524295],pads
print('Corroborating native witness verified:18actualreads,discardedcapitalpad,firstrealpad18versus49Production')
