-- The host-grounded board: a MOVE_TO is this turn's leg, and queued paths on
-- combat units are cancelled at turn start.
--
-- ⚠ Loads the SHIPPED `CivvisControlAgent.lua` and drives its own `applyOrders`,
-- `CivvisBoard` and `CivvisQueue` against a fake host whose pathfinder answers
-- `GetMoveToPathEx` with plots and per-plot turns the way WorldInput.lua reads
-- them.
--
-- What is checked:
--   1. a path that lands this turn is not capped;
--   2. a two-turn path is sent as its first turn's leg, the row is rewritten
--      so the queue expects the capped plot, and `move_capped` is emitted;
--   3. a path whose first step is already next turn is refused by name;
--   4. a one-entry no-route path is refused instead of being sent to the host;
--   5. a melee ATTACK is never capped;
--   6. an explicit opt-out leaves the two capped paths alone;
--   7. a matching explicit guard keeps pace with the setter;
--   8. a missing guard row is synthesized before a one-step setter move;
--   9. an unreachable or differently-targeted guard remains untouched;
--  10. queued paths: combat units are cancelled, civilians are not, and the
--      count is reported;
--  11. a refused settler move cannot draw its guard into a synthetic move;
--  12. the `orders` event carries the cap and shadow counters.
--  13. a rows-less asynchronous watch releases when the host lands the unit
--      on a different plot, so the brain can re-plan from the actual board.
--  14. an unguarded settler will not step into the measured two-plot reach of
--      a visible barbarian scout; any settler leg reachable by a visible
--      barbarian combat unit is held even with a synchronized single escort,
--      while invisible, distant, and proven-scout-escort cases retain ordinary
--      movement.
--  15. A co-located combat escort queued in an earlier frame stays with an
--      exposed Settler until the later Settler safety row is actuated.
--  16. An exposed Settler can retreat two host-reachable hexes when every
--      adjacent escape is covered.
--  17. A Builder cannot enter visible barbarian capture reach without a
--      proven escort; an exposed travelling Builder gets the same bounded
--      escape treatment, and a safe escort preserves the move.
--  18. A civilian cannot enter an active forest/jungle fire tile, while a
--      burnt tile remains legal and combat units keep ordinary movement.
--  19. An exact one-step MOVE_TO + FOUND_CITY shelter hand-off bypasses the
--      raider hold only with host-proven movement left after arrival.
--
-- Run: lua5.1 tools/civ6_control/mod/host_board_test.lua

local here = arg[0]:match("(.*)/[^/]*$") or "."

local function stub()
	return setmetatable({}, {
		__index = function() return stub() end,
		__call = function() return stub() end,
		__newindex = function() end,
	})
end

local EXPORTS = { CivvisApplyOrders = true, CivvisQueue = true, CivvisResolveActions = true,
                  CivvisBoard = true, CivvisApplyOrder = true }
local LOG = {}
Automation = { Log = function(line) LOG[#LOG + 1] = line end }
UnitOperationTypes = { PARAM_X = "x", PARAM_Y = "y" }
UnitCommandTypes = {}
DirectionTypes = {
	DIRECTION_WEST = "west", DIRECTION_EAST = "east",
	DIRECTION_NORTHWEST = "northwest", DIRECTION_NORTHEAST = "northeast",
	DIRECTION_SOUTHWEST = "southwest", DIRECTION_SOUTHEAST = "southeast",
}
-- Plot index = y * 100 + x on this fake map.
local function plotIndex(x, y) return y * 100 + x end
local featurePlots = {}
local terrainPlots = {}
local movementCosts = {}
Map = {
	GetPlotDistance = function(x1, y1, x2, y2) return math.max(math.abs(x1 - x2), math.abs(y1 - y2)) end,
	GetPlot = function(x, y)
		local terrain = terrainPlots[plotIndex(x, y)]
		if terrain ~= nil then return terrain end
		local feature = featurePlots[plotIndex(x, y)]
		if feature == nil then return nil end
		return { GetFeatureType = function() return feature end }
	end,
	GetAdjacentPlot = function(x, y, direction)
		local dx, dy = 0, 0
		if direction == DirectionTypes.DIRECTION_WEST then dx = -1
		elseif direction == DirectionTypes.DIRECTION_EAST then dx = 1
		elseif direction == DirectionTypes.DIRECTION_NORTHWEST then dy = -1
		elseif direction == DirectionTypes.DIRECTION_NORTHEAST then dx, dy = 1, -1
		elseif direction == DirectionTypes.DIRECTION_SOUTHWEST then dx, dy = -1, 1
		elseif direction == DirectionTypes.DIRECTION_SOUTHEAST then dy = 1 end
		return { GetX = function() return x + dx end, GetY = function() return y + dy end }
	end,
	GetPlotIndex = function(x, y) return plotIndex(x, y) end,
	GetPlotByIndex = function(index)
		return {
			GetX = function() return index % 100 end,
			GetY = function() return math.floor(index / 100) end,
			GetMovementCost = function() return movementCosts[index] or 1 end,
		}
	end,
}
GameInfo = setmetatable({}, { __index = function(_, k)
	if k == "UnitOperations" or k == "UnitCommands" then
		return setmetatable({}, { __index = function(_, name) return { Hash = name } end })
	end
	if k == "Units" then
		return setmetatable({}, { __index = function(_, name)
			if name == "UNIT_GALLEY" then
				return { UnitType = name, Combat = 30, RangedCombat = 0, BaseMoves = 3, Domain = "DOMAIN_SEA" }
			end
			if name == "UNIT_CARAVEL" then
				return { UnitType = name, Combat = 55, RangedCombat = 0, BaseMoves = 4, Domain = "DOMAIN_SEA" }
			end
			if name == "UNIT_SETTLER" or name == "UNIT_BUILDER" or name == "UNIT_TRADER" then
				return { UnitType = name, Combat = 0, RangedCombat = 0 }
			end
			return { UnitType = name, Combat = 20, RangedCombat = 0 }
		end })
	end
	if k == "Features" then
		return setmetatable({}, { __index = function(_, index)
			if index == 1 then return { FeatureType = "FEATURE_BURNING_FOREST" } end
			if index == 2 then return { FeatureType = "FEATURE_BURNING_JUNGLE" } end
			if index == 3 then return { FeatureType = "FEATURE_BURNT_FOREST" } end
			return nil
		end })
	end
	if k == "UnitAbilities" then
		return { ABILITY_COASTAL_RAID = { UnitAbilityType = "ABILITY_COASTAL_RAID" },
			ABILITY_MELEE_COASTAL_RAID = { UnitAbilityType = "ABILITY_MELEE_COASTAL_RAID" },
			ABILITY_TEST_PASSIVE = { UnitAbilityType = "ABILITY_TEST_PASSIVE" } }
	end
	if k == "UnitAbilityModifiers" then
		return function()
			local links = {
				{ UnitAbilityType = "ABILITY_COASTAL_RAID", ModifierId = "UNIT_COASTAL_RAID" },
				{ UnitAbilityType = "ABILITY_MELEE_COASTAL_RAID", ModifierId = "UNIT_COASTAL_RAID" },
				{ UnitAbilityType = "ABILITY_TEST_PASSIVE", ModifierId = "UNIT_TEST_PASSIVE" },
			}
			local index = 0
			return function() index = index + 1; return links[index] end
		end
	end
	if k == "Modifiers" then
		return { UNIT_COASTAL_RAID = { ModifierType = "MODIFIER_UNIT_ADJUST_RAIDING" },
			UNIT_TEST_PASSIVE = { ModifierType = "MODIFIER_UNIT_ADJUST_MOVEMENT" } }
	end
	return stub()
end })
rawset(_G, "CivvisControlConfig", {})
setmetatable(_G, { __index = function(_, k)
	if EXPORTS[k] then return rawget(_G, k) end
	return stub()
end })

local host = { units = {}, cities = {}, barbarians = {}, hidden = {}, ops = {}, cmds = {},
               paths = {}, queued = {}, blocked = {} }
local PID = 0
local function unitObject(u)
	return {
		GetID = function() return u.id end,
		GetX = function() return u.x end,
		GetY = function() return u.y end,
		GetMovesRemaining = function() return u.moves end,
		GetUnitType = function() return u.kind end,
		GetType = function() return u.kind end,
		GetAbility = function() return { GetAbilities = function()
			if u.ability_unknown then return nil end
			return u.abilities or {}
		end } end,
		GetDamage = function() return 0 end,
		GetGreatPerson = function() return nil end,
		GetFortifyTurns = function() return 0 end,
		GetFormationUnitCount = function() return 1 end,
	}
end
local function cityObject(c)
	return {
		GetX = function() return c.x end,
		GetY = function() return c.y end,
	}
end
UnitManager = {
	GetUnit = function(pid, id)
		local u = host.units[id]
		if u == nil or u.gone then return nil end
		return unitObject(u)
	end,
	CanStartOperation = function(unit, hash)
		local u = host.units[unit.GetID()]
		return not host.blocked[unit.GetID()]
			and (hash ~= "UNITOPERATION_FOUND_CITY" or u.moves > 0)
	end,
	RequestOperation = function(unit, hash, params)
		local u = host.units[unit.GetID()]
		host.ops[#host.ops + 1] = { id = u.id, op = hash, x = params and params.x, y = params and params.y }
		if hash == "UNITOPERATION_MOVE_TO" then u.pendingX, u.pendingY = params.x, params.y end
	end,
	CanStartCommand = function() return true end,
	RequestCommand = function(unit, hash) host.cmds[#host.cmds + 1] = { id = unit.GetID(), cmd = hash } end,
	-- The fake pathfinder: `host.paths[unitId .. ":" .. destIndex]` = { plots = {...}, turns = {...} }.
	GetMoveToPathEx = function(unit, index)
		return host.paths[unit.GetID() .. ":" .. index]
	end,
	GetQueuedDestination = function(unit) return host.queued[unit.GetID()] end,
}
function host.arrive(id)
	local u = host.units[id]
	if u.pendingX ~= nil then
		u.x, u.y = u.pendingX, u.pendingY
		u.moves = math.max(0, u.moves - (movementCosts[plotIndex(u.x, u.y)] or 1))
		u.pendingX, u.pendingY = nil, nil
	end
end
local function members(list)
	return function()
		local i = 0
		return function()
			i = i + 1
			if list[i] == nil then return nil end
			return i, list[i]
		end
	end
end
local player = setmetatable({
	GetUnits = function()
		local objs = {}
		for _, u in pairs(host.units) do if not u.gone then objs[#objs + 1] = unitObject(u) end end
		table.sort(objs, function(a, b) return a.GetID() < b.GetID() end)
		return { Members = members(objs) }
	end,
	GetCities = function()
		local objs = {}
		for _, c in pairs(host.cities) do objs[#objs + 1] = cityObject(c) end
		return { Members = members(objs) }
	end,
	GetDiplomacy = function() return { IsAtWarWith = function() return false end } end,
	GetScore = function() return 0 end,
	GetTreasury = function() return { GetGoldBalance = function() return 0 end } end,
	IsTurnActive = function() return true end,
}, { __index = function() return stub() end })
Players = setmetatable({}, { __index = function(_, pid)
	if pid == PID then return player end
	return setmetatable({ IsBarbarian = function() return true end,
		GetUnits = function()
			local objs = {}
			for _, u in pairs(host.barbarians) do
				if not u.gone then objs[#objs + 1] = unitObject(u) end
			end
			table.sort(objs, function(a, b) return a.GetID() < b.GetID() end)
			return { Members = members(objs) }
		end,
		GetCities = function() return { Members = members({}) } end },
		{ __index = function() return stub() end })
end })
PlayerManager = { GetAliveIDs = function() return { PID, 63 } end, GetAliveMajorIDs = function() return { PID } end }
PlayersVisibility = setmetatable({}, { __index = function()
	return { IsVisible = function(_, x, y) return not host.hidden[x .. ":" .. y] end,
		IsRevealed = function() return true end }
end })
Game = { GetLocalPlayer = function() return PID end, GetCurrentGameTurn = function() return 7 end }

local chunk, err = loadfile(here .. "/CivvisControlAgent.lua")
assert(chunk, "could not load agent: " .. tostring(err))
local ran, runtime_err = pcall(chunk)
assert(ran, "CivvisControlAgent.lua raised at chunk load: " .. tostring(runtime_err))

local applyOrders = rawget(_G, "CivvisApplyOrders")
local board = rawget(_G, "CivvisBoard")
local queue = rawget(_G, "CivvisQueue")
local config = rawget(_G, "CivvisControlConfig")
rawget(_G, "CivvisResolveActions")()
assert(type(board) == "table", "CivvisBoard is not exported")

local failures = 0
local function check(name, got, want)
	if got ~= want then
		failures = failures + 1
		print(string.format("FAIL %s: got %s want %s", name, tostring(got), tostring(want)))
	else
		print(string.format("ok   %s = %s", name, tostring(got)))
	end
end
local function ops(id)
	local out = {}
	for _, o in ipairs(host.ops) do
		if o.id == id then out[#out + 1] = o.op .. "@" .. tostring(o.x) .. "," .. tostring(o.y) end
	end
	return table.concat(out, ";")
end
local function lastEvent(kind)
	for i = #LOG, 1, -1 do
		if LOG[i]:find('"kind":"' .. kind .. '"', 1, true) then return LOG[i] end
	end
	return nil
end
local function has(line, needle) return line ~= nil and line:find(needle, 1, true) ~= nil end
local function row(subject, verb, x, y) return { kind = "unit", subject = subject, verb = verb, x = x, y = y } end
local function reset()
	host.units, host.cities, host.barbarians, host.hidden, host.ops, host.cmds, host.paths,
		host.queued, host.blocked, LOG = {}, {}, {}, {}, {}, {}, {}, {}, {}, {}
	featurePlots = {}
	terrainPlots = {}
	movementCosts = {}
	config.SettlerEscortCapSync = nil
	config.SettlerFoundingShelterHandoff = nil
	queue.reset(7); board.reset()
end

-- 1. A same-turn path is not capped.
reset()
host.units[10] = { id = 10, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.paths["10:" .. plotIndex(3, 1)] = { plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1) }, turns = { 0, 1, 1 } }
applyOrders(player, PID, 7, { row(10, "MOVE_TO", 3, 1) })
check("same-turn walk sent whole", ops(10), "UNITOPERATION_MOVE_TO@3,1")
check("nothing capped", board.stats.capped, 0)

-- 2. A two-turn path is sent as this turn's leg; the queue expects the capped plot.
reset()
host.units[11] = { id = 11, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.paths["11:" .. plotIndex(5, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1), plotIndex(4, 1), plotIndex(5, 1) },
	turns = { 0, 1, 1, 2, 2 } }
applyOrders(player, PID, 7, { row(11, "MOVE_TO", 5, 1), row(11, "FORTIFY") })
check("two-turn walk capped to its first leg", ops(11), "UNITOPERATION_MOVE_TO@3,1")
check("move_capped emitted with both plots", has(lastEvent("move_capped"), '"sent":[3,1]') and has(lastEvent("move_capped"), '"want":[5,1]'), true)
check("orders event counts the cap", has(lastEvent("orders"), '"move_capped":1'), true)
host.units[11].x, host.units[11].y = 3, 1   -- the host walked it to the capped plot
queue.drain(player, PID, 7)
check("queued fortify waits one settlement pass", ops(11), "UNITOPERATION_MOVE_TO@3,1")
queue.drain(player, PID, 7)
check("queued fortify fires after the CAPPED plot settles", ops(11), "UNITOPERATION_MOVE_TO@3,1;UNITOPERATION_FORTIFY@nil,nil")

-- 3. A path whose first step is next turn is refused by name.
reset()
host.units[12] = { id = 12, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 0 }
host.paths["12:" .. plotIndex(2, 1)] = { plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 2 } }
applyOrders(player, PID, 7, { row(12, "MOVE_TO", 2, 1) })
check("no-reach move issues nothing", ops(12), "")
check("refused as move_no_moves_this_turn", has(lastEvent("orders"), "move_no_moves_this_turn"), true)
check("orders event counts no_reach", has(lastEvent("orders"), '"move_no_reach":1'), true)

-- 4. A present one-entry path is the host's explicit no-route result. It must
-- be refused rather than sent, otherwise Civ VI accepts the request and spins
-- on its no-path sentinel forever.
reset()
host.units[26] = { id = 26, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.paths["26:" .. plotIndex(8, 8)] = {
	plots = { plotIndex(1, 1) }, turns = { 0 } }
applyOrders(player, PID, 7, { row(26, "MOVE_TO", 8, 8) })
check("one-entry no-route issues nothing", ops(26), "")
check("one-entry no-route is named", has(lastEvent("orders"), "move_no_path"), true)
check("one-entry no-route increments no_reach", has(lastEvent("orders"), '"move_no_reach":1'), true)

-- 5. A melee ATTACK is never capped, whatever the path says.
reset()
host.units[13] = { id = 13, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.paths["13:" .. plotIndex(4, 1)] = { plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1), plotIndex(4, 1) }, turns = { 0, 1, 2, 2 } }
applyOrders(player, PID, 7, { row(13, "ATTACK", 4, 1) })
check("attack sent uncapped", ops(13), "UNITOPERATION_MOVE_TO@4,1")

-- 5. The explicit opt-out keeps the ordinary per-row cap unchanged.
reset()
config.SettlerEscortCapSync = false
host.units[17] = { id = 17, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.units[18] = { id = 18, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.paths["17:" .. plotIndex(5, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1), plotIndex(4, 1), plotIndex(5, 1) },
	turns = { 0, 1, 1, 2, 2 } }
host.paths["17:" .. plotIndex(3, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1) }, turns = { 0, 1, 1 } }
host.paths["18:" .. plotIndex(5, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1), plotIndex(4, 1), plotIndex(5, 1) },
	turns = { 0, 1, 1, 1, 2 } }
host.paths["18:" .. plotIndex(3, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1) }, turns = { 0, 1, 1 } }
applyOrders(player, PID, 7, { row(17, "MOVE_TO", 5, 1), row(18, "MOVE_TO", 5, 1) })
check("opt-out: setter uses its cap", ops(17), "UNITOPERATION_MOVE_TO@3,1")
check("opt-out: guard keeps its own cap", ops(18), "UNITOPERATION_MOVE_TO@4,1")
check("opt-out: no escort sync event", lastEvent("escort_cap_synced"), nil)

-- 6. A matching explicit row is rewritten to the setter's actual leg.
reset()
config.SettlerEscortCapSync = true
host.units[17] = { id = 17, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.units[18] = { id = 18, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.paths["17:" .. plotIndex(5, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1), plotIndex(4, 1), plotIndex(5, 1) },
	turns = { 0, 1, 1, 2, 2 } }
host.paths["17:" .. plotIndex(3, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1) }, turns = { 0, 1, 1 } }
host.paths["18:" .. plotIndex(5, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1), plotIndex(4, 1), plotIndex(5, 1) },
	turns = { 0, 1, 1, 1, 2 } }
host.paths["18:" .. plotIndex(3, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1) }, turns = { 0, 1, 1 } }
local setterRow, guardRow = row(17, "MOVE_TO", 5, 1), row(18, "MOVE_TO", 5, 1)
applyOrders(player, PID, 7, { setterRow, guardRow })
check("matching: setter uses its cap", ops(17), "UNITOPERATION_MOVE_TO@3,1")
check("matching: guard follows setter cap", ops(18), "UNITOPERATION_MOVE_TO@3,1")
check("matching: guard row was rewritten", guardRow.x, 3)
check("matching: sync named both units", has(lastEvent("escort_cap_synced"), '"settler":17')
	and has(lastEvent("escort_cap_synced"), '"guard":18'), true)
check("matching: orders count the sync", has(lastEvent("orders"), '"escort_cap_synced":1'), true)

-- 7. The safe default supplies the row the planner omitted and applies it first.
reset()
host.units[19] = { id = 19, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.units[20] = { id = 20, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.paths["19:" .. plotIndex(2, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 1 } }
host.paths["20:" .. plotIndex(2, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 1 } }
local missingGuard = { row(19, "MOVE_TO", 2, 1) }
applyOrders(player, PID, 7, missingGuard)
check("shadow: guard moved before settler", ops(20), "UNITOPERATION_MOVE_TO@2,1")
check("shadow: setter still moved", ops(19), "UNITOPERATION_MOVE_TO@2,1")
check("shadow: row was inserted", #missingGuard, 2)
check("shadow: named both units", has(lastEvent("escort_shadow_injected"), '"settler":19')
	and has(lastEvent("escort_shadow_injected"), '"guard":20'), true)
check("shadow: not counted as CIVVIS order", has(lastEvent("orders"), '"seen":1')
	and has(lastEvent("orders"), '"applied":1'), true)
check("shadow: orders carry host outcome", has(lastEvent("orders"), '"escort_shadow_injected":1')
	and has(lastEvent("orders"), '"escort_shadow_applied":1')
	and has(lastEvent("orders"), '"escort_shadow_refused":0'), true)

-- 8. A guard that cannot reach the setter's leg retains its previous order.
reset()
config.SettlerEscortCapSync = true
host.units[17] = { id = 17, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.units[18] = { id = 18, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 0 }
host.paths["17:" .. plotIndex(5, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1), plotIndex(4, 1), plotIndex(5, 1) },
	turns = { 0, 1, 1, 2, 2 } }
host.paths["17:" .. plotIndex(3, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1) }, turns = { 0, 1, 1 } }
host.paths["18:" .. plotIndex(5, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1), plotIndex(4, 1), plotIndex(5, 1) },
	turns = { 0, 1, 1, 1, 2 } }
host.paths["18:" .. plotIndex(3, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1) }, turns = { 0, 2, 2 } }
applyOrders(player, PID, 7, { row(17, "MOVE_TO", 5, 1), row(18, "MOVE_TO", 5, 1) })
check("unreachable guard keeps its cap", ops(18), "UNITOPERATION_MOVE_TO@4,1")
check("unreachable guard is named", has(lastEvent("escort_cap_unresolved"), '"reason":"guard_still_capped"'), true)
check("orders count the unresolved guard", has(lastEvent("orders"), '"escort_cap_unresolved":1'), true)

-- 9. A missing but too-slow guard is not synthesized.
reset()
host.units[21] = { id = 21, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.units[22] = { id = 22, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 0 }
host.paths["21:" .. plotIndex(2, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 1 } }
host.paths["22:" .. plotIndex(2, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 2 } }
applyOrders(player, PID, 7, { row(21, "MOVE_TO", 2, 1) })
check("too-slow missing guard does not move", ops(22), "")
check("too-slow missing guard is named", has(lastEvent("escort_cap_unresolved"), '"reason":"guard_still_capped"'), true)
check("too-slow missing guard is held, not injected", has(lastEvent("orders"), '"escort_shadow_injected":0')
	and has(lastEvent("orders"), '"escort_shadow_held":1'), true)

-- 10. Different original goals are not an escort contract.
reset()
config.SettlerEscortCapSync = true
host.units[17] = { id = 17, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.units[18] = { id = 18, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.paths["17:" .. plotIndex(5, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1), plotIndex(4, 1), plotIndex(5, 1) },
	turns = { 0, 1, 1, 2, 2 } }
host.paths["17:" .. plotIndex(3, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1) }, turns = { 0, 1, 1 } }
host.paths["18:" .. plotIndex(6, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1), plotIndex(4, 1), plotIndex(5, 1), plotIndex(6, 1) },
	turns = { 0, 1, 1, 1, 2, 2 } }
applyOrders(player, PID, 7, { row(17, "MOVE_TO", 5, 1), row(18, "MOVE_TO", 6, 1) })
check("different goal keeps guard route", ops(18), "UNITOPERATION_MOVE_TO@4,1")
check("different goal emits no sync", lastEvent("escort_cap_synced"), nil)

-- 11. A host-refused settler cannot pull its guard into a synthetic move.
reset()
host.units[23] = { id = 23, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.units[24] = { id = 24, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.paths["23:" .. plotIndex(2, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 1 } }
host.paths["24:" .. plotIndex(2, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 1 } }
host.blocked[23] = true
applyOrders(player, PID, 7, { row(23, "MOVE_TO", 2, 1) })
check("blocked setter has no shadow injection", lastEvent("escort_shadow_injected"), nil)
check("blocked setter does not synthesize a guard move", has(ops(24), "UNITOPERATION_MOVE_TO"), false)

-- 12. A rows-less opening watch must release after an asynchronous host walk
-- lands somewhere other than the requested coordinate.  The next brain frame
-- needs the actual landing, not an expectation that can never become true.
reset()
host.units[25] = { id = 25, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
queue.watch(25, { x = 5, y = 5 }, { x = 1, y = 1 })
host.units[25].x, host.units[25].y = 3, 2
queue.drain(player, PID, 7)
check("mismatched async landing releases its watch", queue.pendingCount(), 0)

-- 13. Queued paths: combat units cancelled, civilians kept, count reported.
reset()
host.units[14] = { id = 14, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.units[15] = { id = 15, kind = "UNIT_SETTLER", x = 2, y = 2, moves = 2 }
host.units[16] = { id = 16, kind = "UNIT_ARCHER", x = 3, y = 3, moves = 2 }
host.queued[14] = plotIndex(9, 9)
host.queued[15] = plotIndex(8, 8)
board.cancelQueuedPaths(player, PID, 7)
check("one combat unit cancelled", #host.cmds, 1)
check("it was the warrior, not the settler", host.cmds[1] and host.cmds[1].id, 14)
check("cancel used UNITCOMMAND_CANCEL", host.cmds[1] and host.cmds[1].cmd, "UNITCOMMAND_CANCEL")
check("queued_paths reported", has(lastEvent("queued_paths"), '"found":2') and has(lastEvent("queued_paths"), '"cancelled":1'), true)

-- 14. The direct live-loss geometry is held: a new settler leaving a city for
-- a tile within a barbarian scout's measured two-plot reach cannot spend its
-- opening turn there without a guard.
reset()
host.cities[1] = { x = 1, y = 1 }
host.units[30] = { id = 30, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.barbarians[90] = { id = 90, kind = "UNIT_SCOUT", x = 2, y = 3, moves = 0 }
host.paths["30:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(30, "MOVE_TO", 1, 2) })
check("visible scout: setter stays in city", ops(30), "")
check("visible scout: hold names setter and scout", has(lastEvent("settler_scout_capture_hold"), '"settler":30')
	and has(lastEvent("settler_scout_capture_hold"), '"scout":90'), true)
check("visible scout: order is an explicit held refusal", has(lastEvent("orders"), "settler_scout_capture_hold"), true)
check("visible scout: orders count the held capture leg", has(lastEvent("orders"), '"settler_scout_capture_held":1'), true)

-- A refusal is not enough when the Settler already stands inside the scout's
-- measured envelope.  The host can prove a one-step retreat, so rewrite the
-- actuation leg to that safe tile instead of leaving the civilian exposed.
reset()
host.units[32] = { id = 32, kind = "UNIT_SETTLER", x = 1, y = 2, moves = 2 }
host.barbarians[92] = { id = 92, kind = "UNIT_SCOUT", x = 1, y = 4, moves = 0 }
host.paths["32:" .. plotIndex(1, 3)] = {
	plots = { plotIndex(1, 2), plotIndex(1, 3) }, turns = { 0, 1 } }
host.paths["32:" .. plotIndex(1, 1)] = {
	plots = { plotIndex(1, 2), plotIndex(1, 1) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(32, "MOVE_TO", 1, 3) })
check("exposed scout leg retreats to a safe neighbour", ops(32), "UNITOPERATION_MOVE_TO@1,1")
check("exposed scout retreat records the original target", has(lastEvent("settler_capture_escape"), '"want":[1,3]')
	and has(lastEvent("settler_capture_escape"), '"sent":[1,1]'), true)
check("exposed scout retreat is not counted as a hold", has(lastEvent("orders"), '"settler_scout_capture_held":0'), true)

-- The safety decision is made against the first host leg, not the far-away
-- planner target.  This catches a queued route whose current cap ends beside
-- the scout even though its intended city site is two turns away.
reset()
host.cities[1] = { x = 1, y = 1 }
host.units[36] = { id = 36, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.barbarians[96] = { id = 96, kind = "UNIT_SCOUT", x = 2, y = 3, moves = 0 }
host.paths["36:" .. plotIndex(1, 4)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2), plotIndex(1, 3), plotIndex(1, 4) },
	turns = { 0, 1, 1, 2 } }
host.paths["36:" .. plotIndex(1, 3)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2), plotIndex(1, 3) }, turns = { 0, 1, 1 } }
applyOrders(player, PID, 7, { row(36, "MOVE_TO", 1, 4) })
check("capped scout leg: setter stays in city", ops(36), "")
check("capped scout leg: event distinguishes want from sent", has(lastEvent("settler_scout_capture_hold"), '"want":[1,4]')
	and has(lastEvent("settler_scout_capture_hold"), '"sent":[1,3]'), true)

-- The scout floor protects the travelling leg as well as a first city
-- departure.  A lone settler must not enter the measured two-plot capture
-- geometry merely because it began this turn outside a city.
reset()
host.units[31] = { id = 31, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.barbarians[91] = { id = 91, kind = "UNIT_SCOUT", x = 3, y = 4, moves = 0 }
host.paths["31:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(31, "MOVE_TO", 1, 2) })
check("travelling setter stays out of two-step scout capture leg", ops(31), "")
check("travelling setter hold names the scout", has(lastEvent("settler_scout_capture_hold"), '"settler":31')
	and has(lastEvent("settler_scout_capture_hold"), '"scout":91'), true)

-- A scout hold protects the current tile too.  The live loss at turn 47 of
-- civvis-20260827T183146Z held the Settler's unsafe leg but let a warrior
-- sharing its current tile take an unrelated route; the scout then captured
-- the now-lone Settler.  Keep that guard put while the scout covers both
-- the rejected leg and the tile the Settler must remain on.
reset()
host.units[42] = { id = 42, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.units[43] = { id = 43, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.barbarians[100] = { id = 100, kind = "UNIT_SCOUT", x = 3, y = 3, moves = 0 }
host.paths["42:" .. plotIndex(2, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 1 } }
host.paths["43:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(42, "MOVE_TO", 2, 1), row(43, "MOVE_TO", 1, 2) })
check("scout-held setter stays put", ops(42), "")
check("scout-held co-located guard does not leave", ops(43), "")
check("scout-held guard is held off fallback", board.escortHolds[43], true)
check("scout-held guard event identifies both units", has(lastEvent("settler_scout_guard_hold"), '"settler":42')
	and has(lastEvent("settler_scout_guard_hold"), '"guard":43'), true)

-- A scout that covers only the rejected destination leaves a co-located guard
-- mobile: the Settler is safe on its current tile, so retaining the guard
-- would turn an actuation floor into needless army paralysis.
reset()
host.units[44] = { id = 44, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.units[45] = { id = 45, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.barbarians[101] = { id = 101, kind = "UNIT_SCOUT", x = 1, y = 4, moves = 0 }
host.paths["44:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
host.paths["45:" .. plotIndex(2, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(44, "MOVE_TO", 1, 2), row(45, "MOVE_TO", 2, 1) })
check("destination-only scout still holds setter", ops(44), "")
check("destination-only scout leaves guard mobile", ops(45), "UNITOPERATION_MOVE_TO@2,1")
check("destination-only scout emits no guard hold", lastEvent("settler_scout_guard_hold"), nil)

-- The narrowed radius preserves a normal travel leg once the known scout is
-- outside the measured two-step capture reach.
reset()
host.units[41] = { id = 41, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.barbarians[99] = { id = 99, kind = "UNIT_SCOUT", x = 4, y = 5, moves = 0 }
host.paths["41:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(41, "MOVE_TO", 1, 2) })
check("distant scout leaves travelling setter mobile", ops(41), "UNITOPERATION_MOVE_TO@1,2")

reset()
host.cities[1] = { x = 1, y = 1 }
host.units[32] = { id = 32, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.barbarians[92] = { id = 92, kind = "UNIT_SCOUT", x = 2, y = 3, moves = 0 }
host.hidden["2:3"] = true
host.paths["32:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(32, "MOVE_TO", 1, 2) })
check("invisible scout: setter still moves", ops(32), "UNITOPERATION_MOVE_TO@1,2")

-- The turn-18 shelter plan in civvis-20260928T032649Z was internally sound:
-- the three-move Settler had a one-point step onto an adjacent chosen city
-- site and an exact FOUND_CITY follow-up.  The generic raider hold vetoed the
-- step, so founding never ran and the Settler remained beside the raiders
-- until its guard died.  Let that narrow host-proven hand-off complete: the
-- failed off-site found is queued behind the walk and fires after arrival.
reset()
host.units[58] = { id = 58, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 3 }
host.barbarians[106] = { id = 106, kind = "UNIT_SCOUT", x = 1, y = 3, moves = 0 }
host.barbarians[107] = { id = 107, kind = "UNIT_HORSEMAN", x = 2, y = 3, moves = 0 }
host.paths["58:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 }, obstacles = {} }
movementCosts[plotIndex(1, 2)] = 1
applyOrders(player, PID, 7, { row(58, "MOVE_TO", 1, 2), row(58, "FOUND_CITY", 1, 2) })
check("founding shelter: exposed one-step walk is sent", ops(58), "UNITOPERATION_MOVE_TO@1,2")
check("founding shelter: scout hold is bypassed", lastEvent("settler_scout_capture_hold"), nil)
check("founding shelter: combat hold is bypassed",
	lastEvent("settler_barbarian_combat_capture_hold"), nil)
check("founding shelter: exact reserve is recorded",
	has(lastEvent("settler_founding_shelter_allowed"), '"moves":3')
	and has(lastEvent("settler_founding_shelter_allowed"), '"movement_cost":1'), true)
check("founding shelter: orders count the hand-off",
	has(lastEvent("orders"), '"settler_founding_shelter_allowed":1'), true)
host.arrive(58)
check("founding shelter: arrival retains founding movement", host.units[58].moves, 2)
queue.drain(player, PID, 7)
queue.drain(player, PID, 7)
check("founding shelter: queued found fires on arrival", ops(58),
	"UNITOPERATION_MOVE_TO@1,2;UNITOPERATION_FOUND_CITY@nil,nil")

-- A matching intent is not enough without movement left after the step.  The
-- ordinary capture floor remains in force when arrival would exhaust the unit.
reset()
host.units[58] = { id = 58, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 1 }
host.barbarians[106] = { id = 106, kind = "UNIT_SCOUT", x = 1, y = 3, moves = 0 }
host.paths["58:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 }, obstacles = {} }
movementCosts[plotIndex(1, 2)] = 1
applyOrders(player, PID, 7, { row(58, "MOVE_TO", 1, 2), row(58, "FOUND_CITY", 1, 2) })
check("founding shelter: exhausted arrival stays held", ops(58), "")
check("founding shelter: exhausted arrival emits no allowance",
	lastEvent("settler_founding_shelter_allowed"), nil)

-- Crossing a river can consume the remaining allowance independently of the
-- destination's terrain cost.  WorldInput exposes that crossing in the native
-- path's obstacles list, so the bridge must keep the conservative hold.
reset()
host.units[58] = { id = 58, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 3 }
host.barbarians[106] = { id = 106, kind = "UNIT_SCOUT", x = 1, y = 3, moves = 0 }
host.paths["58:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 },
	obstacles = { plotIndex(1, 1) } }
movementCosts[plotIndex(1, 2)] = 1
applyOrders(player, PID, 7, { row(58, "MOVE_TO", 1, 2), row(58, "FOUND_CITY", 1, 2) })
check("founding shelter: river arrival stays held", ops(58), "")
check("founding shelter: river arrival emits no allowance",
	lastEvent("settler_founding_shelter_allowed"), nil)

-- The founding row must name the exact same site.  A nearby or stale found
-- target cannot turn an otherwise exposed travel leg into a shelter hand-off.
reset()
host.units[58] = { id = 58, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 3 }
host.barbarians[106] = { id = 106, kind = "UNIT_SCOUT", x = 1, y = 3, moves = 0 }
host.paths["58:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 }, obstacles = {} }
movementCosts[plotIndex(1, 2)] = 1
applyOrders(player, PID, 7, { row(58, "MOVE_TO", 1, 2), row(58, "FOUND_CITY", 2, 2) })
check("founding shelter: mismatched site stays held", ops(58), "")
check("founding shelter: mismatched site emits no allowance",
	lastEvent("settler_founding_shelter_allowed"), nil)

-- The live loss geometry: a visible non-scout combat unit beside the actual
-- leg holds both a travelling settler and the explicit escort that the host
-- synchronized to it.  This is intentionally not limited to a city origin.
reset()
host.units[33] = { id = 33, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.units[34] = { id = 34, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.barbarians[93] = { id = 93, kind = "UNIT_MAN_AT_ARMS", x = 2, y = 3, moves = 2 }
host.paths["33:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
host.paths["34:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(33, "MOVE_TO", 1, 2), row(34, "MOVE_TO", 1, 2) })
check("visible combat: setter stays out of capture leg", ops(33), "")
check("visible combat: synced guard stays with setter", ops(34), "")
check("visible combat: hold names hostile and exact setter", has(lastEvent("settler_barbarian_combat_capture_hold"), '"settler":33')
	and has(lastEvent("settler_barbarian_combat_capture_hold"), '"hostile":93'), true)
check("visible combat: order reports combat hold", has(lastEvent("orders"), '"settler_barbarian_combat_capture_held":1'), true)
check("visible combat: guard is held off automation", board.escortHolds[34], true)

-- The same safety applies when the host had to synthesize the matching guard
-- row.  Refusing the settler must not send that host-only escort ahead alone.
reset()
host.units[37] = { id = 37, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.units[38] = { id = 38, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.barbarians[97] = { id = 97, kind = "UNIT_MUSKETMAN", x = 2, y = 3, moves = 2 }
host.paths["37:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
host.paths["38:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(37, "MOVE_TO", 1, 2) })
check("visible combat shadow: setter stays out of capture leg", ops(37), "")
check("visible combat shadow: synthetic guard stays with setter", ops(38), "")
check("visible combat shadow: host row was held, not applied", has(lastEvent("orders"), '"escort_shadow_injected":1')
	and has(lastEvent("orders"), '"escort_shadow_refused":1'), true)

-- A nearby guard with no existing order is rescued onto the settler's current
-- tile when the settler's move is held.  This is the live t73 geometry: the
-- warrior is adjacent rather than co-located, so refusing the settler alone
-- would leave it capturable before the next export.
reset()
host.units[47] = { id = 47, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.units[48] = { id = 48, kind = "UNIT_WARRIOR", x = 2, y = 1, moves = 2 }
host.barbarians[95] = { id = 95, kind = "UNIT_MAN_AT_ARMS", x = 2, y = 2, moves = 2 }
host.paths["47:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
host.paths["48:" .. plotIndex(1, 1)] = {
	plots = { plotIndex(2, 1), plotIndex(1, 1) }, turns = { 0, 1 } }
local rescueRows = { row(47, "MOVE_TO", 1, 2) }
applyOrders(player, PID, 7, rescueRows)
check("visible combat rescue: setter stays out of capture leg", ops(47), "")
check("visible combat rescue: nearby guard joins current tile", ops(48), "UNITOPERATION_MOVE_TO@1,1")
check("visible combat rescue: row is inserted before held setter", rescueRows[1].subject, 48)
check("visible combat rescue: event names both units", has(lastEvent("settler_barbarian_combat_guard_rescue"), '"settler":47')
	and has(lastEvent("settler_barbarian_combat_guard_rescue"), '"guard":48'), true)
check("visible combat rescue: shadow is applied, not counted as CIVVIS work",
	has(lastEvent("orders"), '"settler_barbarian_combat_guard_rescued":1')
	and has(lastEvent("orders"), '"escort_shadow_applied":1'), true)

-- When no guard is available, an exposed Settler still gets a proven retreat
-- rather than waiting on the combat threat's current tile.  This mirrors the
-- live turn-20 loss where the held destination was safe by the mirror but the
-- stationary Settler was already inside the host's BaseMoves envelope.
reset()
host.units[53] = { id = 53, kind = "UNIT_SETTLER", x = 1, y = 2, moves = 2 }
host.barbarians[104] = { id = 104, kind = "UNIT_WARRIOR", x = 1, y = 4, moves = 0 }
host.paths["53:" .. plotIndex(1, 3)] = {
	plots = { plotIndex(1, 2), plotIndex(1, 3) }, turns = { 0, 1 } }
host.paths["53:" .. plotIndex(1, 1)] = {
	plots = { plotIndex(1, 2), plotIndex(1, 1) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(53, "MOVE_TO", 1, 3) })
check("exposed combat leg retreats without a guard", ops(53), "UNITOPERATION_MOVE_TO@1,1")
check("exposed combat retreat identifies the threat", has(lastEvent("settler_capture_escape"), '"settler":53')
	and has(lastEvent("settler_capture_escape"), '"sent":[1,1]'), true)
check("exposed combat retreat is not counted as a hold", has(lastEvent("orders"), '"settler_barbarian_combat_capture_held":0'), true)

-- If every adjacent escape is covered, refusing the planned leg still leaves
-- the Settler on a capturable tile.  A normal Settler has two movement points;
-- ask the host for a safe two-hex route before giving up and holding it.
reset()
host.units[56] = { id = 56, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.barbarians[104] = { id = 104, kind = "UNIT_HORSEMAN", x = 1, y = 4, moves = 0 }
host.paths["56:" .. plotIndex(2, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 1 } }
host.paths["56:" .. plotIndex(3, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1) }, turns = { 0, 1, 1 } }
-- Make the threat's current and adjacent answers explicit.  The deeper
-- destination has no path answer and is outside the conservative two-hex
-- BaseMoves fallback, which isolates the two-ring escape search.
for _, p in ipairs({ { 1, 1 }, { 0, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 0, 2 }, { 1, 2 } }) do
	host.paths["104:" .. plotIndex(p[1], p[2])] = {
		plots = { plotIndex(1, 4), plotIndex(p[1], p[2]) }, turns = { 0, 1 } }
end
applyOrders(player, PID, 7, { row(56, "MOVE_TO", 2, 1) })
check("two-ring combat retreat reaches a safe destination", ops(56), "UNITOPERATION_MOVE_TO@3,1")
check("two-ring combat retreat identifies the escape", has(lastEvent("settler_capture_escape"), '"settler":56')
	and has(lastEvent("settler_capture_escape"), '"sent":[3,1]'), true)
check("two-ring combat retreat is not counted as a hold", has(lastEvent("orders"), '"settler_barbarian_combat_capture_held":0'), true)

-- Gran Colombia and roads can expose escapes beyond the fallback's two rings.
-- Host movement candidates still need a same-turn path and threat clearance.
reset()
host.units[57] = { id = 57, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 3 }
host.paths["57:" .. plotIndex(4, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1), plotIndex(3, 1), plotIndex(4, 1) },
	turns = { 0, 1, 1, 1 } }
UnitManager.GetReachableMovement = function() return { plotIndex(4, 1), plotIndex(4, 1) } end
local escape = CivvisBoard.findSettlerCaptureEscape(unitObject(host.units[57]), 1, 1, 4, 1,
	{ {} }, function(_, x) return x < 4 end)
check("host movement admits a safe third-ring escape", escape and escape.x, 4)
host.barbarians[104] = { id = 104, kind = "UNIT_HORSEMAN", x = 1, y = 4, moves = 0 }
host.paths["57:" .. plotIndex(2, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 1 } }
for _, p in ipairs({ { 1, 1 }, { 2, 1 } }) do
	host.paths["104:" .. plotIndex(p[1], p[2])] = {
		plots = { plotIndex(1, 4), plotIndex(p[1], p[2]) }, turns = { 0, 1 } }
end
applyOrders(player, PID, 7, { row(57, "MOVE_TO", 2, 1) })
check("third-ring escape reaches native order emission", ops(57), "UNITOPERATION_MOVE_TO@4,1")
check("third-ring escape records its destination",
	has(lastEvent("settler_capture_escape"), '"sent":[4,1]'), true)
host.paths["57:" .. plotIndex(4, 1)].turns = { 0, 1, 1, 2 }
escape = CivvisBoard.findSettlerCaptureEscape(unitObject(host.units[57]), 1, 1, 4, 1,
	{ {} }, function(_, x) return x < 4 end)
check("host movement cannot override a next-turn path", escape, nil)
host.paths["57:" .. plotIndex(4, 1)].turns = { 0, 1, 1, 1 }
escape = CivvisBoard.findSettlerCaptureEscape(unitObject(host.units[57]), 1, 1, 4, 1,
	{ {} }, function() return true end)
check("host movement cannot override a threat", escape, nil)
host.paths["57:" .. plotIndex(7, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(4, 1), plotIndex(7, 1) }, turns = { 0, 1, 1 } }
UnitManager.GetReachableMovement = function() return { plotIndex(7, 1) } end
escape = CivvisBoard.findSettlerCaptureEscape(unitObject(host.units[57]), 1, 1, 7, 1,
	{ {} }, function(_, x) return x < 7 end)
check("host road reach is not guessed from movement points", escape and escape.x, 7)
UnitManager.GetReachableMovement = function() error("unavailable") end
escape = CivvisBoard.findSettlerCaptureEscape(unitObject(host.units[57]), 1, 1, 2, 1,
	{}, function() return false end)
check("unavailable movement API preserves the local fallback", escape and escape.x, 2)
UnitManager.GetReachableMovement = nil

-- A co-located guard can be queued in an earlier combat frame than the
-- Settler's later safety row.  Keep that guard on the exposed current tile;
-- otherwise it leaves first and the Settler is captured before its held row
-- is even visible to the host bridge.
reset()
host.units[54] = { id = 54, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.units[55] = { id = 55, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.barbarians[105] = { id = 105, kind = "UNIT_WARRIOR", x = 1, y = 3, moves = 0 }
host.paths["55:" .. plotIndex(2, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(55, "MOVE_TO", 2, 1) })
check("earlier-frame guard stays with exposed settler", ops(55), "")
check("earlier-frame guard hold names both units",
	has(lastEvent("settler_barbarian_combat_guard_hold"), '"settler":54')
	and has(lastEvent("settler_barbarian_combat_guard_hold"), '"guard":55'), true)
check("earlier-frame guard hold is counted", has(lastEvent("orders"),
	'"settler_barbarian_combat_guard_held":1'), true)

-- A nearby guard that already has an unrelated order is deliberately not
-- overwritten.  The conservative result is observable: no rescue event or
-- shadow row, and the guard keeps the route the planner supplied.
reset()
host.units[49] = { id = 49, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.units[50] = { id = 50, kind = "UNIT_WARRIOR", x = 2, y = 1, moves = 2 }
host.barbarians[96] = { id = 96, kind = "UNIT_MAN_AT_ARMS", x = 2, y = 2, moves = 2 }
host.paths["49:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
host.paths["50:" .. plotIndex(3, 1)] = {
	plots = { plotIndex(2, 1), plotIndex(3, 1) }, turns = { 0, 1 } }
local noOverwriteRows = { row(49, "MOVE_TO", 1, 2), row(50, "MOVE_TO", 3, 1) }
applyOrders(player, PID, 7, noOverwriteRows)
check("visible combat no-overwrite: setter stays out of capture leg", ops(49), "")
check("visible combat no-overwrite: guard keeps its supplied route", ops(50), "UNITOPERATION_MOVE_TO@3,1")
check("visible combat no-overwrite: no rescue is synthesized", lastEvent("settler_barbarian_combat_guard_rescue"), nil)
check("visible combat no-overwrite: rescue counter stays zero", has(lastEvent("orders"), '"settler_barbarian_combat_guard_rescued":0'), true)

-- A combat unit can capture from more than one plot away on its next turn.
-- The live horse-archer loss at t43 used this geometry: the staggered-hex
-- distance was two, so an adjacency-only check let the Settler step onto the
-- exact tile the horse archer could enter.  Prefer the host path proof even
-- when the hostile has already spent its current-turn movement.
reset()
host.units[51] = { id = 51, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.barbarians[102] = { id = 102, kind = "UNIT_HORSEMAN", x = 4, y = 1, moves = 0 }
host.paths["51:" .. plotIndex(2, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 1 } }
host.paths["102:" .. plotIndex(2, 1)] = {
	plots = { plotIndex(4, 1), plotIndex(3, 1), plotIndex(2, 1) }, turns = { 0, 1, 1 } }
applyOrders(player, PID, 7, { row(51, "MOVE_TO", 2, 1) })
check("two-step combat reach: setter stays out of capture leg", ops(51), "")
check("two-step combat reach: host path names the threat", has(lastEvent("settler_barbarian_combat_capture_hold"), '"hostile":102')
	and has(lastEvent("settler_barbarian_combat_capture_hold"), '"hostile_reach":"path"'), true)

-- If the host cannot answer an enemy path to a civilian-occupied plot, the
-- conservative BaseMoves/distance fallback still holds a normal two-move
-- barbarian rather than accepting a false-safe leg.
reset()
host.units[52] = { id = 52, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.barbarians[103] = { id = 103, kind = "UNIT_HORSEMAN", x = 4, y = 1, moves = 0 }
host.paths["52:" .. plotIndex(2, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(52, "MOVE_TO", 2, 1) })
check("two-step fallback reach: setter stays out of capture leg", ops(52), "")
check("two-step fallback reach: distance names the threat", has(lastEvent("settler_barbarian_combat_capture_hold"), '"hostile":103')
	and has(lastEvent("settler_barbarian_combat_capture_hold"), '"hostile_reach":"base_moves"'), true)

-- A galley's distance-only envelope cannot capture a civilian on ordinary
-- land. This false threat redirected the t29 settler in 20260909T064545Z.
-- Keep native path proof and water/city/district or unknown-terrain behavior.
for _, case in ipairs({
 { name = "plain land", water = false, city = false, district = -1, held = false },
 { name = "water", water = true, city = false, district = -1, held = true },
 { name = "city", water = false, city = true, district = -1, held = true },
 { name = "district", water = false, city = false, district = 5, held = true },
 { name = "unknown", held = true },
 { name = "native path", water = false, city = false, district = -1, path = true, held = true },
}) do
 reset()
 host.units[53] = { id = 53, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
 host.barbarians[104] = { id = 104, kind = "UNIT_GALLEY", x = 4, y = 1, moves = 0 }
 if case.water ~= nil then
  terrainPlots[plotIndex(2, 1)] = {
   IsWater = function() return case.water end,
   IsCity = function() return case.city end,
   GetDistrictType = function() return case.district end,
  }
 end
 host.paths["53:" .. plotIndex(2, 1)] = {
  plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 1 } }
 if case.path then
  host.paths["104:" .. plotIndex(2, 1)] = {
   plots = { plotIndex(4, 1), plotIndex(3, 1), plotIndex(2, 1) }, turns = { 0, 1, 1 } }
 end
 applyOrders(player, PID, 7, { row(53, "MOVE_TO", 2, 1) })
 check("naval capture " .. case.name, ops(53), case.held and "" or "UNITOPERATION_MOVE_TO@2,1")
end

-- A visible combat unit outside the adjacent-capture geometry does not freeze
-- normal expansion movement.
reset()
host.units[39] = { id = 39, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.barbarians[98] = { id = 98, kind = "UNIT_WARRIOR", x = 4, y = 4, moves = 2 }
host.paths["39:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(39, "MOVE_TO", 1, 2) })
check("distant combat: setter still moves", ops(39), "UNITOPERATION_MOVE_TO@1,2")

-- A proven co-located escort may make the exact same leg, including the
-- synthesized row from the existing host escort reconciliation.
reset()
host.cities[1] = { x = 1, y = 1 }
host.units[34] = { id = 34, kind = "UNIT_SETTLER", x = 1, y = 1, moves = 2 }
host.units[35] = { id = 35, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.barbarians[94] = { id = 94, kind = "UNIT_SCOUT", x = 2, y = 3, moves = 0 }
host.paths["34:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
host.paths["35:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(34, "MOVE_TO", 1, 2) })
check("proven escort: guard shares exposed leg", ops(35), "UNITOPERATION_MOVE_TO@1,2")
check("proven escort: setter still moves", ops(34), "UNITOPERATION_MOVE_TO@1,2")
check("proven escort: no scout capture hold", lastEvent("settler_scout_capture_hold"), nil)

-- Builders are civilians too.  A Builder leaving a city for a tile inside a
-- visible barbarian combat unit's next-turn reach must not be accepted merely
-- because the host can execute the MOVE_TO.
-- The same naval terrain exception already used for Settlers applies to
-- Builders. Native 20261102T202907Z t96 held a land Iron approach for a Caravel.
for _, navalKind in ipairs({ "UNIT_GALLEY", "UNIT_CARAVEL" }) do
	for _, case in ipairs({
		{ name = "plain land", water = false, city = false, district = -1, held = false },
		{ name = "water", water = true, city = false, district = -1, held = true },
		{ name = "city", water = false, city = true, district = -1, held = true },
		{ name = "district", water = false, city = false, district = 5, held = true },
		{ name = "unknown", held = true },
		{ name = "native path", water = false, city = false, district = -1, path = true, held = true },
		{ name = "raid ability", water = false, city = false, district = -1,
			abilities = { "ABILITY_COASTAL_RAID" }, held = true },
		{ name = "melee raid ability", water = false, city = false, district = -1,
			abilities = { "ABILITY_MELEE_COASTAL_RAID" }, held = true },
		{ name = "unknown ability read", water = false, city = false, district = -1,
			ability_unknown = true, held = true },
		{ name = "unknown ability metadata", water = false, city = false, district = -1,
			abilities = { "ABILITY_TEST_UNKNOWN" }, held = true },
		{ name = "non-raiding ability", water = false, city = false, district = -1,
			abilities = { "ABILITY_TEST_PASSIVE" }, held = false },
	}) do
		reset()
		host.cities[1] = { x = 1, y = 1 }
		host.units[61] = { id = 61, kind = "UNIT_BUILDER", x = 1, y = 1, moves = 2 }
		host.barbarians[107] = { id = 107, kind = navalKind, x = 4, y = 1, moves = 0,
			abilities = case.abilities, ability_unknown = case.ability_unknown }
		if case.water ~= nil then
			terrainPlots[plotIndex(2, 1)] = {
				IsWater = function() return case.water end,
				IsCity = function() return case.city end,
				GetDistrictType = function() return case.district end,
			}
		end
		host.paths["61:" .. plotIndex(2, 1)] = {
			plots = { plotIndex(1, 1), plotIndex(2, 1) }, turns = { 0, 1 } }
		if case.path then
			host.paths["107:" .. plotIndex(2, 1)] = {
				plots = { plotIndex(4, 1), plotIndex(3, 1), plotIndex(2, 1) }, turns = { 0, 1, 1 } }
		end
		applyOrders(player, PID, 7, { row(61, "MOVE_TO", 2, 1) })
		check("builder naval capture " .. navalKind .. " " .. case.name,
			ops(61), case.held and "" or "UNITOPERATION_MOVE_TO@2,1")
	end
end

-- Exact coordinates and unit types from the native t96 hold. The destination
-- export is owned desert hills with Iron, no city center or placed district.
reset()
host.units[2490377] = { id = 2490377, kind = "UNIT_BUILDER", x = 26, y = 31, moves = 2 }
host.barbarians[8519700] = { id = 8519700, kind = "UNIT_CARAVEL", x = 29, y = 31, moves = 0 }
terrainPlots[plotIndex(27, 31)] = {
	IsWater = function() return false end,
	IsCity = function() return false end,
	GetDistrictType = function() return -1 end,
}
host.paths["2490377:" .. plotIndex(27, 31)] = {
	plots = { plotIndex(26, 31), plotIndex(27, 31) }, turns = { 0, 1 } }
applyOrders(player, PID, 96, { row(2490377, "MOVE_TO", 27, 31) })
check("native Caravel distance hold permits land Builder approach",
	ops(2490377), "UNITOPERATION_MOVE_TO@27,31")

reset()
host.cities[1] = { x = 1, y = 1 }
host.units[60] = { id = 60, kind = "UNIT_BUILDER", x = 1, y = 1, moves = 2 }
host.barbarians[106] = { id = 106, kind = "UNIT_WARRIOR", x = 2, y = 3, moves = 2 }
host.paths["60:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(60, "MOVE_TO", 1, 2) })
check("visible combat: builder stays out of capture leg", ops(60), "")
check("visible combat: builder hold names the hostile", has(lastEvent("builder_barbarian_capture_hold"),
	'"builder":60') and has(lastEvent("builder_barbarian_capture_hold"), '"hostile":106'), true)
check("visible combat: builder hold is an explicit refusal", has(lastEvent("orders"),
	'builder_barbarian_capture_hold'), true)
check("visible combat: builder hold is counted", has(lastEvent("orders"),
	'"builder_barbarian_capture_held":1'), true)

-- A civilian-occupied destination can make the host path query return no
-- answer even though Civ VI accepts the same MOVE_TO.  The geometric fallback
-- must still protect a Builder inside a visible barbarian combat envelope.
reset()
host.cities[1] = { x = 16, y = 17 }
host.units[65] = { id = 65, kind = "UNIT_BUILDER", x = 16, y = 18, moves = 2 }
host.units[66] = { id = 66, kind = "UNIT_WARRIOR", x = 15, y = 18, moves = 2 }
host.units[67] = { id = 67, kind = "UNIT_SETTLER", x = 15, y = 18, moves = 2 }
host.barbarians[110] = { id = 110, kind = "UNIT_SLINGER", x = 15, y = 17, moves = 0 }
-- No Builder path is registered: the fake host still accepts the operation,
-- which models the live occupied-tile path-probe failure.
applyOrders(player, PID, 32, { row(65, "MOVE_TO", 15, 18) })
check("occupied destination fallback: builder stays out of capture leg", ops(65), "")
check("occupied destination fallback: event names fallback", has(lastEvent("builder_barbarian_capture_hold"),
	'"builder_reach":"distance_fallback"'), true)

-- A later replan frame must not bypass a hold established by the first row
-- for the same Builder.
reset()
host.cities[1] = { x = 1, y = 1 }
host.units[64] = { id = 64, kind = "UNIT_BUILDER", x = 1, y = 1, moves = 2 }
host.barbarians[109] = { id = 109, kind = "UNIT_WARRIOR", x = 2, y = 3, moves = 2 }
host.paths["64:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(64, "MOVE_TO", 1, 2), row(64, "MOVE_TO", 1, 2) })
check("duplicate builder frame: every exposed row stays held", ops(64), "")
check("duplicate builder frame: both rows are refused", has(lastEvent("orders"),
	'"refused":2') and has(lastEvent("orders"), '"builder_barbarian_capture_hold":1')
	and has(lastEvent("orders"), '"queue_prior_refused":1'), true)

-- A travelling Builder already inside a visible combat envelope can retreat
-- when the host proves a safe two-move answer, rather than waiting in place.
reset()
host.units[61] = { id = 61, kind = "UNIT_BUILDER", x = 1, y = 2, moves = 2 }
host.barbarians[107] = { id = 107, kind = "UNIT_WARRIOR", x = 1, y = 4, moves = 0 }
host.paths["61:" .. plotIndex(1, 3)] = {
	plots = { plotIndex(1, 2), plotIndex(1, 3) }, turns = { 0, 1 } }
host.paths["61:" .. plotIndex(1, 1)] = {
	plots = { plotIndex(1, 2), plotIndex(1, 1) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(61, "MOVE_TO", 1, 3) })
check("exposed builder retreats to a safe neighbour", ops(61), "UNITOPERATION_MOVE_TO@1,1")
check("exposed builder escape keeps the original target", has(lastEvent("builder_capture_escape"),
	'"want":[1,3]') and has(lastEvent("builder_capture_escape"), '"sent":[1,1]'), true)
check("exposed builder escape is not counted as a hold", has(lastEvent("orders"),
	'"builder_barbarian_capture_held":0'), true)

-- A host-proven co-located combat escort keeps an otherwise exposed Builder
-- mobile; the bridge must not turn a safe explicit escort into a freeze.
reset()
host.units[62] = { id = 62, kind = "UNIT_BUILDER", x = 1, y = 1, moves = 2 }
host.units[63] = { id = 63, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.barbarians[108] = { id = 108, kind = "UNIT_WARRIOR", x = 2, y = 3, moves = 2 }
host.paths["62:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
host.paths["63:" .. plotIndex(1, 2)] = {
	plots = { plotIndex(1, 1), plotIndex(1, 2) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(62, "MOVE_TO", 1, 2), row(63, "MOVE_TO", 1, 2) })
check("proven builder escort: builder still moves", ops(62), "UNITOPERATION_MOVE_TO@1,2")
check("proven builder escort: guard still moves", ops(63), "UNITOPERATION_MOVE_TO@1,2")
check("proven builder escort: no hold", lastEvent("builder_barbarian_capture_hold"), nil)

-- Live run civvis-20260909T143651Z, t15: the Builder at (49,37)
-- was refused a retreat to (49,36), while its stacked Scout left for (48,36).
-- A Slinger at (49,38) captured the now-uncovered Builder. No safe path is
-- supplied here, so the actuation floor must retain the existing protection.
reset()
host.units[72] = { id = 72, kind = "UNIT_BUILDER", x = 49, y = 37, moves = 2 }
host.units[73] = { id = 73, kind = "UNIT_SCOUT", x = 49, y = 37, moves = 3 }
host.barbarians[111] = { id = 111, kind = "UNIT_SLINGER", x = 49, y = 38, moves = 0 }
host.paths["72:" .. plotIndex(49, 36)] = {
	plots = { plotIndex(49, 37), plotIndex(49, 36) }, turns = { 0, 1 } }
applyOrders(player, PID, 15, { row(73, "MOVE_TO", 48, 36), row(72, "MOVE_TO", 49, 36) })
check("stranded builder: retreat remains held", ops(72), "")
check("stranded builder: scout cannot abandon it", ops(73), "")
check("stranded builder: guard refusal is named", has(lastEvent("orders"),
	'builder_barbarian_guard_hold'), true)
check("stranded builder: guard event identifies both units", has(lastEvent("builder_barbarian_guard_hold"),
	'"builder":72') and has(lastEvent("builder_barbarian_guard_hold"), '"guard":73'), true)
-- A subsequent same-turn replan may omit the Builder entirely. Re-evaluate
-- the live stack; protecting only the original batch would re-open the hole.
applyOrders(player, PID, 15, { row(73, "MOVE_TO", 49, 36) })
check("stranded builder: later guard-only frame stays held", ops(73), "")
applyOrders(player, PID, 15, { row(73, "CAPTURE", 49, 38) })
check("stranded builder: capture cannot abandon it", ops(73), "")
applyOrders(player, PID, 15, { row(73, "ATTACK", 49, 38) })
check("stranded builder: melee departure stays held", ops(73), "")
applyOrders(player, PID, 15, { row(72, "MOVE_TO", 49, 37), row(73, "MOVE_TO", 49, 36) })
check("stranded builder: no-op civilian move does not release guard", ops(73), "")
host.paths["72:" .. plotIndex(50, 36)] = { plots = { plotIndex(49, 37) }, turns = { 0 } }
applyOrders(player, PID, 15, { row(72, "MOVE_TO", 50, 36), row(73, "MOVE_TO", 49, 36) })
check("stranded builder: no-path civilian move does not release guard", ops(73), "")
-- In-place ranged fire is allowed to clear the threat.
applyOrders(player, PID, 15, { row(73, "RANGE_ATTACK", 49, 38) })
check("stranded builder: in-place fire remains available", ops(73), "UNITOPERATION_RANGE_ATTACK@49,38")
host.ops = {}
host.barbarians = {}
applyOrders(player, PID, 16, { row(73, "MOVE_TO", 49, 36) })
check("stranded builder: guard released when danger clears", ops(73), "UNITOPERATION_MOVE_TO@49,36")

-- A safe civilian escape must leave the guard's independent order intact.
reset()
host.units[74] = { id = 74, kind = "UNIT_BUILDER", x = 1, y = 2, moves = 2 }
host.units[75] = { id = 75, kind = "UNIT_WARRIOR", x = 1, y = 2, moves = 2 }
host.barbarians[112] = { id = 112, kind = "UNIT_SLINGER", x = 1, y = 4, moves = 0 }
host.paths["74:" .. plotIndex(1, 1)] = {
	plots = { plotIndex(1, 2), plotIndex(1, 1) }, turns = { 0, 1 } }
applyOrders(player, PID, 7, { row(74, "MOVE_TO", 1, 3), row(75, "MOVE_TO", 2, 1) })
check("builder safely escapes: escape still executes", ops(74), "UNITOPERATION_MOVE_TO@1,1")
check("builder safely escapes: guard released", ops(75), "UNITOPERATION_MOVE_TO@2,1")

-- A safe city origin does not justify reserving its garrison just because a
-- Builder's outbound job was refused.
reset()
host.cities[1] = { x = 1, y = 1 }
host.units[76] = { id = 76, kind = "UNIT_BUILDER", x = 1, y = 1, moves = 2 }
host.units[77] = { id = 77, kind = "UNIT_WARRIOR", x = 1, y = 1, moves = 2 }
host.barbarians[113] = { id = 113, kind = "UNIT_SLINGER", x = 1, y = 3, moves = 0 }
applyOrders(player, PID, 7, { row(76, "MOVE_TO", 1, 2), row(77, "MOVE_TO", 2, 1) })
check("city builder: refused job does not freeze garrison", ops(77), "UNITOPERATION_MOVE_TO@2,1")

-- Gathering Storm's forest-fire table kills civilians during the active
-- FEATURE_BURNING_* phase, even when a combat escort is present.  A burnt
-- feature is the safe post-fire state, and combat units are not covered by
-- this civilian floor.
reset()
host.units[68] = { id = 68, kind = "UNIT_BUILDER", x = 1, y = 1, moves = 2 }
host.units[69] = { id = 69, kind = "UNIT_SETTLER", x = 3, y = 1, moves = 2 }
host.units[70] = { id = 70, kind = "UNIT_WARRIOR", x = 5, y = 1, moves = 2 }
host.units[71] = { id = 71, kind = "UNIT_BUILDER", x = 7, y = 1, moves = 2 }
for _, item in ipairs({
	{ id = 68, fromX = 1, x = 1, y = 2, feature = 1 },
	{ id = 69, fromX = 3, x = 3, y = 2, feature = 2 },
	{ id = 70, fromX = 5, x = 5, y = 2, feature = 1 },
	{ id = 71, fromX = 7, x = 7, y = 2, feature = 3 },
}) do
	host.paths[item.id .. ":" .. plotIndex(item.x, item.y)] = {
		plots = { plotIndex(item.fromX, 1),
			plotIndex(item.x, item.y) }, turns = { 0, 1 } }
	featurePlots[plotIndex(item.x, item.y)] = item.feature
end
applyOrders(player, PID, 7, {
	row(68, "MOVE_TO", 1, 2), row(69, "MOVE_TO", 3, 2),
	row(70, "MOVE_TO", 5, 2), row(71, "MOVE_TO", 7, 2),
})
check("active fire: builder stays off burning forest", ops(68), "")
check("active fire: settler stays off burning jungle", ops(69), "")
check("active fire: combat unit still moves", ops(70), "UNITOPERATION_MOVE_TO@5,2")
check("active fire: burnt forest remains legal", ops(71), "UNITOPERATION_MOVE_TO@7,2")
check("active fire: both civilians are counted", board.stats.active_fire_civilian_held, 2)
check("active fire: refusal is named", has(lastEvent("orders"), '"active_fire_civilian_hold":2'), true)
check("active fire: event names feature", has(lastEvent("active_fire_civilian_hold"), '"feature":"FEATURE_'), true)

-- Stalled movement reports the host path endpoint and activity before fallback.
reset()
host.units[80] = { id = 80, kind = "UNIT_GALLEY", x = 1, y = 1, moves = 3 }
local stalled = unitObject(host.units[80])
local oldActivity = UnitManager.GetActivityType
UnitManager.GetActivityType = function() return 12345 end
host.paths["80:" .. plotIndex(4, 1)] = {
	plots = { plotIndex(1, 1), plotIndex(3, 1) }, turns = { 0, 1 } }
board.moveAttempts[80] = { turn = 7, moves = 3, fallback = true }
local entry = { expect = { x = 4, y = 1 }, wait = 30 }
check("noop evidence preserves exhausted fallback", board.moveNoop(player, PID, 80,
	stalled, entry, 7, 1, 1, 3), false)
local diagnostic = lastEvent("move_noop")
check("noop evidence includes native activity", has(diagnostic, '"activity":12345'), true)
check("noop evidence names an unlisted activity by its value", has(diagnostic, '"activity_name":"12345"'), true)
local oldActivityTypes = rawget(_G, "ActivityTypes")
ActivityTypes = { ACTIVITY_OPERATION = 12345, ACTIVITY_AWAKE = 777 }
check("noop evidence names a stock activity", board.noopEvidence(stalled, 4, 1).activity_name, "operation")
check("the namer reads the stock enum", board.activityName(777), "awake")
check("no activity is no name", board.activityName(nil), nil)
ActivityTypes = oldActivityTypes
check("noop evidence includes partial endpoint", has(diagnostic, '"path_last":103'), true)
check("noop evidence identifies incomplete path", has(diagnostic, '"path_reaches_destination":false'), true)
check("noop evidence includes turn and length", has(diagnostic, '"path_last_turn":1')
	and has(diagnostic, '"path_count":2'), true)
check("noop evidence issues no orders", #host.ops, 0)
host.paths["80:" .. plotIndex(4, 1)].plots[2] = plotIndex(4, 1)
check("noop evidence confirms complete path", board.noopEvidence(stalled, 4, 1).path_reaches_destination, true)
local oldPath = UnitManager.GetMoveToPathEx
UnitManager.GetActivityType = function() error("unavailable") end
UnitManager.GetMoveToPathEx = function() error("unavailable") end
local unavailable = board.noopEvidence(stalled, 4, 1)
check("noop evidence unavailable activity stays unknown", unavailable.activity, nil)
check("noop evidence unavailable path stays unknown", unavailable.path_count, nil)
UnitManager.GetMoveToPathEx = function() return { plots = {} } end
check("noop evidence empty path is observed", board.noopEvidence(stalled, 4, 1).path_count, 0)
check("noop evidence empty path has unknown endpoint", board.noopEvidence(stalled, 4, 1).path_reaches_destination, nil)
UnitManager.GetMoveToPathEx, UnitManager.GetActivityType = oldPath, oldActivity

if failures > 0 then
	print(string.format("\n%d check(s) failed", failures))
	os.exit(1)
end
print("\nall host-board checks passed")
