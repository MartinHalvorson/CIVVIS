"""KPI for `disrupt-waits-for-the-sources` in live games: our Disrupt Rocketry
launches by the host quote the Spy saw the frame before it launched, whether a
sure Gain Sources was still on its menu, and the outcome.

usage: python3 kpi.py 'civvis-20261119T*'   (run-dir glob under ~/civvis-civ6-runs/control)

Read: the share of launches quoted below 0.7 with Gain Sources still offered
(the gene drives it toward 0 before an Exoplanet launch), and the pillage and
Spy-loss rates of all launches (11-18 baseline: 301 launches, 184 such, 43%
pillaged, 46% of launches lost the Spy). Also count the journal line
"gains sources before it disrupts" in each run's why.log.
"""
import collections
import glob
import json
import os
import sys

root = os.path.expanduser('~/civvis-civ6-runs/control/')
pattern = sys.argv[1] if len(sys.argv) > 1 else 'civvis-*'
rows = []
journal = 0
for d in sorted(glob.glob(root + pattern)):
    try:
        f = open(d + '/events.jsonl', errors='replace')
    except OSError:
        continue
    prev, launches, results = {}, [], []
    for line in f:
        if '"kind": "state"' in line:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            for u in e.get('units') or []:
                if u.get('kind') != 'UNIT_SPY':
                    continue
                c = u.get('spy_city') or {}
                row = (e.get('turn'), u.get('spy_operation'), (c.get('x'), c.get('y')),
                       {r['op'][18:]: r.get('success') for r in u.get('spy_mission_targets') or []})
                p = prev.get(u.get('id'))
                if row[1] and 'DISRUPT' in row[1] and (not p or p[1] != row[1]):
                    menu = p[3] if p and p[2] == row[2] else {}
                    launches.append({'t': row[0], 'city': row[2], 'quote': menu.get('DISRUPT_ROCKETRY'),
                                     'sources': (menu.get('GAIN_SOURCES') or 0) >= 0.999})
                prev[u.get('id')] = row
        elif '"kind": "spy_mission_result"' in line and '"ours": true' in line and 'DISRUPT' in line:
            try:
                results.append(json.loads(line))
            except ValueError:
                pass
    used = set()
    for x in launches:
        for i, e in enumerate(results):
            if i not in used and (e.get('city_x'), e.get('city_y')) == x['city'] and e['turn'] >= x['t']:
                used.add(i)
                x.update(ok=bool(e.get('succeeded')), lost=bool(e.get('spy_lost')))
                rows.append(x)
                break
    try:
        journal += sum('gains sources before it disrupts' in line for line in open(d + '/why.log', errors='replace'))
    except OSError:
        pass
quoted = [x for x in rows if x['quote'] is not None]
low = [x for x in quoted if x['quote'] < 0.7 and x['sources']]
rate = lambda xs, k: f"{100 * sum(x[k] for x in xs) / len(xs):.0f}%" if xs else '-'
print(f"launches {len(rows)} (quoted {len(quoted)}): pillaged {rate(rows, 'ok')}, Spy lost {rate(rows, 'lost')}")
print(f"quoted < 0.7 with a sure Gain Sources still offered: {len(low)} "
      f"({100 * len(low) / max(1, len(quoted)):.0f}%), pillaged {rate(low, 'ok')}, lost {rate(low, 'lost')}")
bands = collections.defaultdict(list)
for x in quoted:
    bands['<0.3' if x['quote'] < 0.3 else '0.3-0.55' if x['quote'] < 0.55 else '0.55-0.7' if x['quote'] < 0.7 else '>=0.7'].append(x)
for k in ('<0.3', '0.3-0.55', '0.55-0.7', '>=0.7'):
    print(f"  quote {k:9} n {len(bands[k]):4} pillaged {rate(bands[k], 'ok'):>4} lost {rate(bands[k], 'lost'):>4}")
print('journal lines "gains sources before it disrupts":', journal)
