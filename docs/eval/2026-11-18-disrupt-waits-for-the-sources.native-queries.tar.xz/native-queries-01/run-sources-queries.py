"""Paired decider queries on live frames where a Spy of ours launched Disrupt
Rocketry at a host quote below 0.7 with a sure Gain Sources on the host's
menu (live Deity, 2026-11-18).

`disrupt-waits-for-the-sources` is the only bit that varies. Each case is a
live run's own events.jsonl cut after the FIRST state row of turn N (the
board the seat saw at the start of its turn), at which the Spy stood idle in
a rival's city with the host offering it both Disrupt Rocketry (quoted below
0.7) and Gain Sources (quoted 1.0), and from which the live seat launched
Disrupt Rocketry that turn or the next. Both arms run one frozen
`civvis_orders --resumed` built from the branch (profile ci), with that run's
own requested genome (why.log line 1 `forced`, each as `--with`), its lane
(`summary.json` `victory_target`) and civ; the on arm adds
`--with disrupt-waits-for-the-sources`.

Read per arm: the order the payload gives the case's Spy (its verb and
operation), and the gene's journal lines.

At most two cases per run, the first two such launches of each run. This
records proposal activation on captured live input only. It does not
execute in Civ VI and makes no claim about what the Spy then achieves.
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
CASES = json.loads(Path(sys.argv[4]).read_text())
GENE = 'disrupt-waits-for-the-sources'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402


def cut(run, turn):
    """Rows through the first state row of `turn`, and that row."""
    rows = []
    with open(RUNS / run / 'events.jsonl', errors='replace') as f:
        for line in f:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > turn:
                break
            rows.append(line)
            if e.get('kind') == 'state' and e.get('turn') == turn:
                return ''.join(rows).encode(), e
    raise ValueError(f'{run} has no state row for turn {turn}')


def spy_orders(payload, spy):
    return [o for o in payload.get('orders', []) if o.get('subject') == spy]


def kind(orders):
    text = json.dumps(orders)
    for name in ('GAIN_SOURCES', 'DISRUPT_ROCKETRY', 'LISTENING_POST', 'STEAL_TECH_BOOST', 'SIPHON_FUNDS',
                 'TRAVEL', 'PROMOTE'):
        if name in text:
            return name
    return 'none' if not orders else 'other'


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data, state = cut(case['run'], case['turn'])
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'spy': case['spy'],
                                 'cut': 'through the first state row of the turn'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', case['victory'], '--civ', case['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if GENE in line or 'gains sources before' in line]
            orders = spy_orders(row.get('payload', {}), case['spy'])
            row['read'] = {'spy_orders': orders, 'spy_order': kind(orders)}
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = []
    for i, c in enumerate(CASES):
        r = one(i, c)
        results.append(r)
        if r.get('error'):
            print(c['run'], c['turn'], 'ERROR', r['error'], flush=True)
            continue
        v = r['reads'][0]
        off, on = (a['read']['spy_order'] for a in v['arms'])
        print(f"{c['run'][-8:]} t{c['turn']:<3} {c['victory']:10} L{c['level']} quote {c['quote']:.3f} "
              f"{'CHANGED' if v['orders_changed'] else 'same   '} spy off {off:16} on {on:16} "
              f"journal {len(v['arms'][1]['journal_gene'])}", flush=True)
    pairs = [(a['read']['spy_order'] for a in r['reads'][0]['arms']) for r in results if r.get('complete')]
    transitions = {}
    for off, on in pairs:
        transitions[f'{off} -> {on}'] = transitions.get(f'{off} -> {on}', 0) + 1
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
             'spy_order_off_to_on': dict(sorted(transitions.items(), key=lambda kv: -kv[1])),
             'on_journal_lines': sum(len(a['journal_gene']) for r in results for v in r['reads']
                                     for a in v['arms'] if a['arm'] == 'on'),
             'off_journal_lines': sum(len(a['journal_gene']) for r in results for v in r['reads']
                                      for a in v['arms'] if a['arm'] == 'off')}
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
