"""Paired decider queries on live frames of the five Science-lane Deity games of 2026-11-18.

`science-seat-campus-before-the-claims` is the only bit that varies. Each case is a live run's own
events.jsonl cut right after turn N's first state row (frame 0: the board the live decider saw as the
turn opened, with the queues that had just gone idle still idle), replayed at turn N. CUT=after-next
instead cuts after turn N+1, which replays the turn's last frame, the live orders already applied. Both arms run one frozen `civvis_orders --resumed` built from the branch, with that run's own
requested genome (why.log line 1 `forced`, each as `--with`); the on arm adds
`--with science-seat-campus-before-the-claims`.

Cases: every turn from the turn Writing was known to the turn the live seat placed its third Campus
(cities founded by t70): civvis-20261118T045850Z Kongo t34-75, -T081221Z America t33-71, -T084012Z
Portugal t27-93, -T091009Z Germany t37-79, -T111559Z Scotland t31-79. On these boards the live seat
held a buildable Campus it had not queued; a board where every city already has its Campus, a
threatened or attacked city, a soldier, Walls and the faith defence are the controls it must leave
alone.

Read per arm: the production orders (`produce` and `produce_next`, by city), the Campus, Library and
Government Plaza orders among them, and the gene's own journal lines. Per case: whether any order changed, and which
cities' production changed.

This records proposal activation on captured live input only. It does not execute in Civ VI and makes
no strength claim.
"""
import bisect
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
STEP = int(os.environ.get('STEP', '1'))
CUT = os.environ.get('CUT', 'first-state')
assert CUT in ('first-state', 'after-next')
GENE = 'science-seat-campus-before-the-claims'
RUNS = Path.home() / 'civvis-score-tools/deity-18/science'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

GAMES = [
    ('civvis-20261118T045850Z', 'science', 'CIVILIZATION_KONGO', range(34, 76, STEP)),
    ('civvis-20261118T081221Z', 'science', 'CIVILIZATION_AMERICA', range(33, 72, STEP)),
    ('civvis-20261118T084012Z', 'science', 'CIVILIZATION_PORTUGAL', range(27, 94, STEP)),
    ('civvis-20261118T091009Z', 'science', 'CIVILIZATION_GERMANY', range(37, 80, STEP)),
    ('civvis-20261118T111559Z', 'science', 'CIVILIZATION_SCOTLAND', range(31, 80, STEP)),
]
if os.environ.get('ONLY'):
    GAMES = [g for g in GAMES if os.environ['ONLY'] in g[0]]
CASES = [{'run': r, 'victory': v, 'civ': c, 'turn': t} for r, v, c, turns in GAMES for t in turns]
CAMPUS = ('DISTRICT_CAMPUS', 'DISTRICT_SEOWON', 'DISTRICT_OBSERVATORY')
LIBRARY = ('BUILDING_LIBRARY',)
PLAZA = ('DISTRICT_GOVERNMENT',)


def cuts(run, turns):
    """One pass over the log: the rows up to the first row past the last wanted turn + 1, each row's
    running maximum turn, and per wanted turn the index just past its first state row, that row, and
    its last state row. CUT=first-state ends the cut at the first state row of turn N; CUT=after-next
    ends it before the first row whose turn is over N + 1."""
    want = set(turns)
    last_turn = max(want)
    rows, runmax, first, last = [], [], {}, {}
    high = 0
    with open(RUNS / run / 'events.jsonl', 'rb') as f:
        for raw in f:
            try:
                e = json.loads(raw)
            except ValueError:
                continue
            t = e.get('turn') or 0
            if t > last_turn + 1:
                break
            high = max(high, t)
            rows.append(raw)
            runmax.append(high)
            if e.get('kind') == 'state' and t in want:
                first.setdefault(t, (len(rows), e))
                last[t] = e
    return rows, runmax, (first, last)


def production(row, names):
    out = {}
    for o in row.get('payload', {}).get('orders', []):
        if o.get('kind') in ('produce', 'produce_next'):
            out.setdefault(names.get(o.get('subject'), str(o.get('subject'))), []).append(
                f"{o['kind']}:{o.get('verb')}")
    return out


def named(prod, kinds):
    return sorted(city for city, orders in prod.items() if any(o.split(':', 1)[1] in kinds for o in orders))


def one(index, case, rows, marks, state):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        turn = case['turn']
        first, final = state
        if CUT == 'first-state':
            end, last = first[turn]
        else:
            # `marks` is each row's running maximum turn: the cut ends before the first row past turn+1
            end, last = bisect.bisect_right(marks, turn + 1), final[turn]
        data = b''.join(rows[:end])
        names = {c['id']: c['name'] for c in last['cities']}
        board = {
            'cities': len(last['cities']),
            'techs': len(last.get('techs') or []),
            'science': last.get('science'),
            'campus_placed': sorted(c['name'] for c in last['cities']
                                    if any(d['type'] in CAMPUS for d in c.get('districts', []))),
            'campus_offered': sorted(c['name'] for c in last['cities']
                                     if any(b['t'] in CAMPUS for b in c.get('buildable', []))),
            'plaza_placed': sorted(c['name'] for c in last['cities']
                                   if any(d['type'] in PLAZA for d in c.get('districts', []))),
            'pop': {c['name']: c.get('pop') for c in last['cities']},
            'district_capacity': {c['name']: c.get('district_capacity') for c in last['cities']},
            'producing': {c['name']: c.get('producing') for c in last['cities']},
        }
        record = {'descriptor': {'run': case['run'], 'turn': turn,
                                 'cut': 'after the first state row of the turn' if CUT == 'first-state' else 'after turn+1'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'board': board, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(turn), '--resumed',
                   '--explain', '--victory', case['victory'], '--civ', case['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if GENE + ':' in line]
            row['journal_campus'] = [line for line in journal
                                     if 'postpones its first Campus' in line
                                     or 'claims its free district slot for a Campus' in line
                                     or "claims its Campus's" in line
                                     or 'Government Plaza' in line or 'government plaza' in line]
            row['production'] = production(row, names)
            row['campus_orders'] = named(row['production'], CAMPUS)
            row['library_orders'] = named(row['production'], LIBRARY)
            row['plaza_orders'] = named(row['production'], PLAZA)
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['production_changed'] = {
            city: {'off': off['production'].get(city), 'on': on['production'].get(city)}
            for city in sorted(set(off['production']) | set(on['production']))
            if off['production'].get(city) != on['production'].get(city)}
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES, 'step': STEP, 'cut': CUT,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = []
    index = 0
    for run, victory, civ, turns in GAMES:
        rows, marks, state = cuts(run, list(turns))
        for t in turns:
            case = {'run': run, 'victory': victory, 'civ': civ, 'turn': t}
            r = one(index, case, rows, marks, state)
            results.append(r)
            index += 1
            if r.get('error'):
                print(run, t, 'ERROR', r['error'], flush=True)
                continue
            for v in r['reads']:
                off, on = v['arms']
                print(f"{run[-7:]} t{t:<3} {'CHANGED' if v['orders_changed'] else 'same   '} "
                      f"campus off {off['campus_orders']} on {on['campus_orders']} "
                      f"library off {off['library_orders']} on {on['library_orders']} "
                      f"plaza off {off['plaza_orders']} on {on['plaza_orders']} "
                      f"gene lines {len(on['journal_gene'])} secs {off['wall_seconds']:.1f}/{on['wall_seconds']:.1f}",
                      flush=True)
                for line in on['journal_gene']:
                    print('      ', line[:230], flush=True)
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
             'on_gene_lines': sum(len(v['arms'][1]['journal_gene']) for r in results for v in r['reads'] if len(v['arms']) == 2),
             'off_gene_lines': sum(len(v['arms'][0]['journal_gene']) for r in results for v in r['reads'] if len(v['arms']) == 2),
             'on_campus_orders': sum(len(v['arms'][1]['campus_orders']) for r in results for v in r['reads'] if len(v['arms']) == 2),
             'off_campus_orders': sum(len(v['arms'][0]['campus_orders']) for r in results for v in r['reads'] if len(v['arms']) == 2),
             'on_library_orders': sum(len(v['arms'][1]['library_orders']) for r in results for v in r['reads'] if len(v['arms']) == 2),
             'off_library_orders': sum(len(v['arms'][0]['library_orders']) for r in results for v in r['reads'] if len(v['arms']) == 2)}
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
