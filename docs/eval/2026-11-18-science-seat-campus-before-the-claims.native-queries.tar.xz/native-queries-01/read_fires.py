#!/usr/bin/env python3
"""read_fires.py QUERIES_DIR [--json OUT]: what the paired replays say.

Per run: the live turn each city placed its first Campus (events.jsonl, the diag extract), the first
replayed turn the off arm and the on arm issue a `produce` order for that city's Campus, and the first
three Campuses of the game in each (the three earliest cities). The on arm's turn is the first board
on which the gene would have queued the Campus; boards are independent replays of the live game, so a
gain is 'live placed turn minus the first on-arm order turn', an upper bound on what a played game
moves."""
import collections, glob, json, os, re, sys
from pathlib import Path
Q = Path(sys.argv[1])
DIAG = Path.home() / 'civvis-score-tools/deity-18/science-campus/diag'
sys.path.insert(0, str(DIAG))
import diag  # noqa: E402
GENE = 'science-seat-campus-before-the-claims'
CAMPUS = ('DISTRICT_CAMPUS',)
games = {g['tag']: g for g in diag.load()}
results = [json.loads(p.read_text()) for p in sorted(Q.glob('[0-9][0-9][0-9][0-9]/result.json'))]
by_run = collections.defaultdict(list)
for r in results:
    by_run[r['case']['run']].append(r)
out = {'boards': len(results), 'complete': sum(bool(r.get('complete')) for r in results), 'runs': {}}
passed = collections.Counter()
changed_total = 0
tot_gain = []
tot_off_gain = []
for run, rs in by_run.items():
    g = games[run]
    rows, writing = diag.city_rows(g)
    live = {r['name']: r for r in rows if not r['captured']}
    first = {'off': {}, 'on': {}}
    first_any = {'off': {}, 'on': {}}
    changed = 0
    lines = 0
    turns = []
    plaza = {'off': [], 'on': []}
    for r in rs:
        if not r.get('complete'):
            continue
        t = r['case']['turn']
        turns.append(t)
        v = r['reads'][0]
        if v.get('orders_changed'):
            changed += 1
        arms = {a['arm']: a for a in v['arms']}
        lines += len(arms['on']['journal_gene'])
        for line in arms['on']['journal_gene']:
            m = re.search(r"first Campus goes ahead of (the [A-Z][A-Za-z ]+?)(?: \(|;| \()", line)
            if 'starts the first Campus before its Settler' in line:
                passed['the empire\'s first Campus before the floor\'s Settler'] += 1
            elif 'first Campus goes ahead of' in line:
                what = re.search(r"first Campus goes ahead of (.+?)(?: \(\d| \(it keeps)", line)
                passed['first Campus ahead of ' + (what.group(1) if what else '?')] += 1
            elif 'goes ahead of' in line:
                what = re.search(r"'s (\w+) goes ahead of (.+?)(?: \(\d| \(it keeps|;)", line)
                passed[(what.group(1) if what else '?') + ' ahead of ' + (what.group(2) if what else '?')] += 1
            else:
                passed['other'] += 1
        for arm in ('off', 'on'):
            for city, orders in arms[arm]['production'].items():
                for o in orders:
                    kind, verb = o.split(':', 1)
                    if verb == 'DISTRICT_GOVERNMENT' and kind == 'produce':
                        board = v['board']
                        plaza[arm].append({'turn': t, 'city': city, 'pop': (board.get('pop') or {}).get(city),
                                           'capacity': (board.get('district_capacity') or {}).get(city),
                                           'has_campus': city in board.get('campus_placed', [])})
                    if verb in CAMPUS:
                        first_any[arm].setdefault(city, t)
                        if kind == 'produce':
                            first[arm].setdefault(city, t)
    changed_total += changed
    cities = []
    for name, r in live.items():
        if r['founded'] > 70:
            continue
        cities.append({'city': name, 'founded': r['founded'], 'offered': r['camp_offered'], 'live_placed': r['camp_placed'],
                       'off_first_order': first['off'].get(name), 'on_first_order': first['on'].get(name)})
    END = min(g['last_turn'], 150) + 1
    live3 = sorted((c['live_placed'] if c['live_placed'] is not None else END) for c in cities)[:3]
    # the on arm: a city's Campus is queued at its first on-arm order, or at its live turn if the window never ordered it
    on3 = sorted(min(x for x in (c['on_first_order'], c['live_placed'] if c['live_placed'] is not None else END) if x is not None)
                 for c in cities)[:3]
    off3 = sorted(min(x for x in (c['off_first_order'], c['live_placed'] if c['live_placed'] is not None else END) if x is not None)
                  for c in cities)[:3]
    gains = [a - b for a, b in zip(live3, on3)]
    tot_gain.append(gains)
    off_gains = [a - b for a, b in zip(off3, on3)]
    tot_off_gain.append(off_gains)
    one_slot = lambda xs: [x for x in xs if x['capacity'] is not None and x['capacity'] <= 1 and not x['has_campus']]
    out.setdefault('plaza', {})[run] = {'off': plaza['off'], 'on': plaza['on'],
                                        'off_one_slot': len(one_slot(plaza['off'])), 'on_one_slot': len(one_slot(plaza['on']))}
    out['runs'][run] = {'civ': g['seat']['civ'], 'writing': writing, 'turns': [min(turns), max(turns)] if turns else None,
                        'boards': len(rs), 'changed': changed, 'gene_lines': lines, 'live_first_three_placed': live3,
                        'off_first_three_ordered': off3, 'on_first_three_ordered': on3, 'gain_turns': gains, 'gain_vs_off_turns': off_gains, 'cities': cities}
    print(f"== {run[-7:]} {g['seat']['civ'][13:]:9s} writing t{writing} boards {len(rs)} (t{min(turns)}-{max(turns)}) changed {changed} gene lines {lines}")
    print(f"   first three Campuses: live placed {live3} | off arm {off3} | on arm first ordered {on3} | gain {gains}")
    print(f"   Plaza orders: off {len(plaza['off'])} boards (first {plaza['off'][:1]}), of them in a one-slot city with no Campus {len(one_slot(plaza['off']))};"
          f" on {len(plaza['on'])} (first {plaza['on'][:1]}), one-slot {len(one_slot(plaza['on']))}")
    for c in sorted(cities, key=lambda c: c['founded']):
        print(f"     {c['city'][:16]:16s} founded {c['founded']:3d} offered {c['offered']} live placed {c['live_placed']} off first order {c['off_first_order']} on first order {c['on_first_order']}")
out['changed'] = changed_total
out['passed'] = dict(passed.most_common())
k = len(tot_gain)
if k:
    import statistics as st
    out['gain_mean'] = [sum(gs[i] for gs in tot_gain if len(gs) > i) / max(1, sum(1 for gs in tot_gain if len(gs) > i)) for i in range(3)]
    out['gain_median'] = [st.median([gs[i] for gs in tot_gain if len(gs) > i]) for i in range(3)]
    print(f"\nboards {out['boards']} complete {out['complete']} changed {changed_total}")
    print("gain in turns, first / second / third Campus: mean", [round(x, 1) for x in out['gain_mean']], "median", out['gain_median'], "per run", tot_gain)
    out['gain_vs_off_mean'] = [sum(gs[i] for gs in tot_off_gain if len(gs) > i) / max(1, sum(1 for gs in tot_off_gain if len(gs) > i)) for i in range(3)]
    out['gain_vs_off_median'] = [st.median([gs[i] for gs in tot_off_gain if len(gs) > i]) for i in range(3)]
    print("the same against the off arm's own first order: mean", [round(x, 1) for x in out['gain_vs_off_mean']], "median", out['gain_vs_off_median'], "per run", tot_off_gain)
    print("what the on arm's gene lines passed:", dict(passed.most_common()))
if '--json' in sys.argv:
    Path(sys.argv[sys.argv.index('--json') + 1]).write_text(json.dumps(out, indent=1))
