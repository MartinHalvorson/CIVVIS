# Settler captures — civvis-20261026T024315Z

2 capture(s). Mechanism is the first match in the operator's order; every match is listed.

## t51 settler 1048582 at (54,19) — `site-in-barbarian-nest`

- detected by: `unit_captured`, captor player 63 (barbarian)
- mechanisms matched: site-in-barbarian-nest, fled-into-reach
- nearest hostile: UNIT_HORSEMAN str 36 hp 47 mv 0 at (55,18) d=1 id 5767197
- guard: UNIT_ARCHER str 15 hp 100 mv 0 at (54,20) d=1 id 720901 [proximity]
- site: (55,19) — hostile seen within 3 in the last 5 turns: True; camp within 3: False

### Settler t-2..t

| turn | pos | moves | activity | hostiles within 3 | ours within 2 |
|---|---|---|---|---|---|
| t49 | (54,19) | 0 | awake | UNIT_HORSEMAN str 36 hp 100 mv 0 at (54,17) d=2 id 5767197 | UNIT_ARCHER str 15 hp 100 mv 0 at (53,20) d=2 id 720901 |
| t50 | (54,19) | 3 | awake | UNIT_HORSEMAN str 36 hp 80 mv 0 at (54,17) d=2 id 5767197 | UNIT_ARCHER str 15 hp 100 mv 1 at (53,21) d=2 id 720901 |
| t51 | (54,19) | 3 | awake | UNIT_HORSEMAN str 36 hp 47 mv 0 at (55,18) d=1 id 5767197 | UNIT_ARCHER str 15 hp 100 mv 0 at (54,20) d=1 id 720901 |

### Orders (settler and guard)

- `{"guard": 720901, "kind": "escort_cap_synced", "sent": [53, 20], "settler": 786436, "t": 1792982730, "turn": 49, "utc": "2026-10-26T02:45:30.018Z", "want": [53, 20]}`
- `{"checked_on": 50, "kind": "order_failed", "order_kind": "unit", "reason": "not_fortified", "subject": 720901, "t": 1792982732, "turn": 49, "utc": "2026-10-26T02:45:32.187Z", "verb": "FORTIFY"}`
- `{"checked_on": 50, "kind": "order_verified", "order_kind": "unit", "subject": 720901, "t": 1792982732, "turn": 49, "utc": "2026-10-26T02:45:32.187Z", "verb": "MOVE_TO"}`
- `{"checked_on": 50, "kind": "order_verified", "order_kind": "unit", "subject": 1048582, "t": 1792982732, "turn": 49, "utc": "2026-10-26T02:45:32.187Z", "verb": "MOVE_TO"}`
- `{"checked_on": 50, "kind": "order_verified", "order_kind": "unit", "subject": 720901, "t": 1792982732, "turn": 49, "utc": "2026-10-26T02:45:32.188Z", "verb": "RANGE_ATTACK"}`
- `{"candidates": 1, "guard": 720901, "kind": "escort_cap_unresolved", "reason": "guard_has_order", "sent": [51, 21], "settler": 786436, "t": 1792982732, "turn": 50, "utc": "2026-10-26T02:45:32.187Z", "want": [51, 21]}`
- `{"checked_on": 51, "kind": "order_failed", "order_kind": "unit", "reason": "did_not_move", "subject": 1048582, "t": 1792982733, "turn": 50, "utc": "2026-10-26T02:45:33.586Z", "verb": "MOVE_TO"}`
- `{"checked_on": 51, "kind": "order_failed", "order_kind": "unit", "reason": "not_fortified", "subject": 720901, "t": 1792982733, "turn": 50, "utc": "2026-10-26T02:45:33.586Z", "verb": "FORTIFY"}`
- `{"checked_on": 51, "kind": "order_verified", "order_kind": "unit", "subject": 720901, "t": 1792982733, "turn": 50, "utc": "2026-10-26T02:45:33.586Z", "verb": "MOVE_TO"}`
- `{"from": [54, 19], "hostile": 5767197, "hostile_pos": [54, 17], "hostile_reach": "base_moves", "hostile_type": "UNIT_HORSEMAN", "kind": "settler_barbarian_combat_capture_hold", "sent": [55, 21], "settler": 1048582, "t": 1792982732, "turn": 50, "utc": "2026-10-26T02:45:32.187Z", "want": [55, 21]}`
- `{"checked_on": 52, "kind": "order_failed", "order_kind": "unit", "reason": "unit_gone", "subject": 1048582, "t": 1792982735, "turn": 51, "utc": "2026-10-26T02:45:35.505Z", "verb": "MOVE_TO"}`
- `{"checked_on": 52, "kind": "order_failed", "order_kind": "unit", "reason": "unit_gone", "subject": 1048582, "t": 1792982735, "turn": 51, "utc": "2026-10-26T02:45:35.506Z", "verb": "MOVE_TO"}`
- `{"checked_on": 52, "kind": "order_verified", "order_kind": "unit", "subject": 720901, "t": 1792982735, "turn": 51, "utc": "2026-10-26T02:45:35.505Z", "verb": "MOVE_TO"}`
- `{"checked_on": 52, "kind": "order_verified", "order_kind": "unit", "subject": 720901, "t": 1792982735, "turn": 51, "utc": "2026-10-26T02:45:35.506Z", "verb": "RANGE_ATTACK"}`
- `{"from": [54, 19], "hostile": 5767197, "hostile_pos": [55, 18], "hostile_reach": "base_moves", "hostile_type": "UNIT_HORSEMAN", "kind": "settler_barbarian_combat_capture_hold", "sent": [55, 21], "settler": 1048582, "t": 1792982733, "turn": 51, "utc": "2026-10-26T02:45:33.586Z", "want": [55, 21]}`
- `{"from": [54, 19], "hostile": 5767197, "hostile_pos": [55, 18], "hostile_reach": "base_moves", "hostile_type": "UNIT_HORSEMAN", "kind": "settler_barbarian_combat_capture_hold", "sent": [53, 20], "settler": 1048582, "t": 1792982734, "turn": 51, "utc": "2026-10-26T02:45:34.180Z", "want": [53, 20]}`

### why.log t-2..t

- t49 Military/Strategy Board: Defend Quito (value 179, need 22, force #29 of 1, deadline 2) · Relieve Quito (value 179, need 15, no force, deadline 2) · Escort settler (value 280, need 0, no force) · Escort settler (value 280, need 0, no force) · Defend Cartagena de Indias (value 60, need 24, no force, deadline 3) | rows 13 [2 Defend, 2 Relieve, 1 ClearCamp, 2 Escort, 6 Recon], 1 force(s), 0 reassigned, short: 3 Defend, 3 Relieve, 1 Escort, 1 Escort, 4 Defend, 3 Relieve, 6 ClearCamp, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t49 Expansion/Detail Settler marching to (46, 20) | 4 tiles away, the site is worth 65.8  [civ6 (56,20) = axial (46,20)]
- t49 Expansion/Detail Settler marching to (46, 20) | 3 tiles away, the site is worth 65.8  [civ6 (56,20) = axial (46,20)]
- t49 Expansion/Detail Settler ends its move short of (46, 20) | 3 tiles away with 1 movement left; the next tile costs 2, so it walks on next turn  [civ6 (56,20) = axial (46,20)]
- t49 Expansion/Detail Settler refuses (44, 16) before walking there | it lies beyond the empire's Loyalty reach on ground the seat has not explored, where the rivals that press it have never been seen; the site is retired and the next best is asked  [civ6 (52,16) = axial (44,16)]
- t49 Expansion/Detail Settler refuses (46, 21) before walking there | it lies beyond the empire's Loyalty reach on ground the seat has not explored, where the rivals that press it have never been seen; the site is retired and the next best is asked  [civ6 (56,21) = axial (46,21)]
- t49 Expansion/Detail Settler refuses (33, 17) before walking there | the native nearby-city pressure would leave the city losing 23.0 Loyalty a turn and revolting in about 5 turns; the site is retired and the next best is asked  [civ6 (41,17) = axial (33,17)]
- t49 Expansion/Detail Settler refuses (45, 19) before walking there | it lies beyond the empire's Loyalty reach on ground the seat has not explored, where the rivals that press it have never been seen; the site is retired and the next best is asked  [civ6 (54,19) = axial (45,19)]
- t49 Expansion/Detail Stranded Settler sets aside 5 unpriceable site(s) | each lies within five tiles of a rival border whose city may be hidden; the forecast cannot price that Loyalty pressure, and the exhaustion search will not guess at a city it would hand to that rival
- t49 Expansion/Detail Settler skips a doomed site at (44, 15) | stranded, it would still take a site the forecast set aside — but this one loses 23.0 Loyalty a turn and revolts in about 4  [civ6 (51,15) = axial (44,15)]
- t49 Expansion/Detail Settler takes a site the preferred search refused | nothing passed every filter, so (46, 19) (worth 28.4) is taken rather than standing still  [civ6 (55,19) = axial (46,19)]
- t49 Expansion/Detail The settler's guard stands down | no visible hostile within 8 tiles and this is not a long expedition; the army gets its body back
- t49 Expansion/Detail Settler marching to (46, 19) | 3 tiles away, the site is worth 37.3  [civ6 (55,19) = axial (46,19)]
- t49 Expansion/Detail Settler marching to (46, 19) | 2 tiles away, the site is worth 37.3  [civ6 (55,19) = axial (46,19)]
- t49 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (53,20) = axial (43,20)]
- t49 Expansion/Detail settler holds inside a barbarian's reach | 2 raider(s) could take (43, 20) and no reachable tile is better  [civ6 (53,20) = axial (43,20)]
- t49 Expansion/Detail Settler keeps (46, 20) through a blocked approach | no safe site lies within 4 tiles, and a far detour is how the last settlers spent twenty turns crossing the empire; the guard holds here until the approach clears  [civ6 (56,20) = axial (46,20)]
- t49 Expansion/Detail Settler marching to (46, 20) | 3 tiles away, the site is worth 48.4  [civ6 (56,20) = axial (46,20)]
- t49 Expansion/Detail Settler ends its move short of (46, 20) | 3 tiles away with 1 movement left; the next tile costs 2, so it walks on next turn  [civ6 (56,20) = axial (46,20)]
- t49 Expansion/Detail settler holds inside a barbarian's reach | 1 raider(s) could take (43, 20) and no reachable tile is better  [civ6 (53,20) = axial (43,20)]
- t49 Expansion/Detail Settler keeps (46, 20) through a blocked approach | no safe site lies within 4 tiles, and a far detour is how the last settlers spent twenty turns crossing the empire; the guard holds here until the approach clears  [civ6 (56,20) = axial (46,20)]
- t49 Expansion/Detail Settler marching to (46, 20) | 3 tiles away, the site is worth 48.4  [civ6 (56,20) = axial (46,20)]
- t49 Expansion/Detail Settler ends its move short of (46, 20) | 3 tiles away with 1 movement left; the next tile costs 2, so it walks on next turn  [civ6 (56,20) = axial (46,20)]
- t50 Military/Strategy Board: Escort settler (value 280, need 0, force #30 of 1, deadline 1) · Escort settler (value 280, need 0, force #31 of 1, deadline 2) · Defend Quito (value 179, need 22, force #29 of 1, deadline 3) · Relieve Quito (value 179, need 5, no force, deadline 3) · Defend Cartagena de Indias (value 60, need 25, no force, deadline 3) | rows 13 [2 Defend, 2 Relieve, 1 ClearCamp, 2 Escort, 6 Recon], 3 force(s), 0 reassigned, short: 1 Escort, 1 Escort, 1 Defend, 1 Relieve, 2 Defend, 1 Relieve, 3 ClearCamp, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t50 Military/Decision Task force #30: a land force of 1 will hold for Escort settler | objective (45, 19), anchor (45, 19), 100% ready, 0.50 local strength  [civ6 (54,19) = axial (45,19)]
- t50 Military/Decision Task force #31: a land force of 1 will hold for Escort settler | objective (43, 20), anchor (43, 20), 0% ready, 0.50 local strength  [civ6 (53,20) = axial (43,20)]
- t50 Expansion/Detail Settler retreats from a hostile's reach | 1 raider(s) could take (43, 20) next turn; (41, 21) is out of reach  [civ6 (51,21) = axial (41,21)]
- t50 Expansion/Detail Settler retreats from a hostile's reach | 1 raider(s) could take (45, 19) next turn; (45, 21) is the least exposed tile it can reach  [civ6 (55,21) = axial (45,21)]
- t50 Military/Decision Task force #30: a land force of 1 will hold for Escort settler | objective (45, 19), anchor (45, 19), 100% ready, 0.50 local strength  [civ6 (54,19) = axial (45,19)]
- t50 Military/Decision Task force #31: a land force of 1 will hold for Escort settler | objective (43, 20), anchor (43, 20), 100% ready, 0.50 local strength  [civ6 (53,20) = axial (43,20)]
- t50 Expansion/Detail Settler retreats from a hostile's reach | 1 raider(s) could take (45, 19) next turn; (45, 21) is the least exposed tile it can reach  [civ6 (55,21) = axial (45,21)]
- t51 Military/Strategy Board: Escort settler (value 280, need 0, force #30 of 1, deadline 1) · Escort settler (value 280, need 0, force #31 of 1, deadline 3) · Defend Quito (value 179, need 42, force #29 of 1, deadline 3) · Relieve Quito (value 179, need 17, no force, deadline 3) · Defend Cartagena de Indias (value 60, need 45, no force, deadline 3) | rows 13 [2 Defend, 2 Relieve, 1 ClearCamp, 2 Escort, 6 Recon], 3 force(s), 0 reassigned, short: 1 Escort, 1 Escort, 1 Defend, 1 Relieve, 3 Defend, 4 ClearCamp, 2 Relieve, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t51 Military/Decision Task force #30: a land force of 1 will hold for Escort settler | objective (45, 19), anchor (45, 19), 100% ready, 0.53 local strength  [civ6 (54,19) = axial (45,19)]
- t51 Military/Decision Task force #31: a land force of 1 will hold for Escort settler | objective (41, 21), anchor (41, 21), 100% ready, 0.53 local strength  [civ6 (51,21) = axial (41,21)]
- t51 Expansion/Detail Settler refuses (44, 16) before walking there | it lies beyond the empire's Loyalty reach on ground the seat has not explored, where the rivals that press it have never been seen; the site is retired and the next best is asked  [civ6 (52,16) = axial (44,16)]
- t51 Expansion/Detail Settler refuses (46, 21) before walking there | it lies beyond the empire's Loyalty reach on ground the seat has not explored, where the rivals that press it have never been seen; the site is retired and the next best is asked  [civ6 (56,21) = axial (46,21)]
- t51 Expansion/Detail Settler refuses (43, 16) before walking there | the native nearby-city pressure would leave the city losing 23.0 Loyalty a turn and revolting in about 5 turns; the site is retired and the next best is asked  [civ6 (51,16) = axial (43,16)]
- t51 Expansion/Detail Settler refuses (44, 15) before walking there | the native nearby-city pressure would leave the city losing 23.0 Loyalty a turn and revolting in about 5 turns; the site is retired and the next best is asked  [civ6 (51,15) = axial (44,15)]
- t51 Expansion/Detail Stranded Settler sets aside 4 unpriceable site(s) | each lies within five tiles of a rival border whose city may be hidden; the forecast cannot price that Loyalty pressure, and the exhaustion search will not guess at a city it would hand to that rival
- t51 Expansion/Detail Settler takes a site the preferred search refused | nothing passed every filter, so (45, 22) (worth -2.0) is taken rather than standing still  [civ6 (56,22) = axial (45,22)]
- t51 Expansion/Detail Settler begins an escorted expedition | the route from (41, 21) to (45, 22) is 5 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t51 Expansion/Detail Settler marching to (45, 22) | 5 tiles away, the site is worth 45.2  [civ6 (56,22) = axial (45,22)]
- t51 Expansion/Detail Settler detours around a visible threat | the approach to (45, 22) is unsafe, so every Settler leaves it alone for 6 standard turns while the army can clear the blocker; (45, 23) is the best safe alternate  [civ6 (56,23) = axial (45,23)]
- t51 Expansion/Detail Settler begins an escorted expedition | the route from (41, 22) to (45, 23) is 5 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t51 Expansion/Detail Settler marching to (45, 23) | 5 tiles away, the site is worth 29.6  [civ6 (56,23) = axial (45,23)]
- t51 Expansion/Detail Settler retreats from a hostile's reach | 1 raider(s) could take (45, 19) next turn; (45, 21) is the least exposed tile it can reach  [civ6 (55,21) = axial (45,21)]
- t51 Expansion/Detail Settler gives up on (46, 19) | retreated 3 times while walking there; the approach is not clearing, so the site is retired for 30 standard turns  [civ6 (55,19) = axial (46,19)]
- t51 Military/Decision Task force #30: a land force of 1 will hold for Escort settler | objective (45, 19), anchor (45, 19), 100% ready, 0.57 local strength  [civ6 (54,19) = axial (45,19)]
- t51 Military/Decision Task force #31: a land force of 1 will hold for Escort settler | objective (41, 21), anchor (41, 21), 100% ready, 0.57 local strength  [civ6 (51,21) = axial (41,21)]
- t51 Military/Decision Task force #30: a land force of 1 will hold for Escort settler | objective (45, 19), anchor (45, 19), 100% ready, 0.55 local strength  [civ6 (54,19) = axial (45,19)]
- t51 Military/Decision Task force #31: a land force of 1 will hold for Escort settler | objective (41, 21), anchor (41, 21), 100% ready, 0.65 local strength  [civ6 (51,21) = axial (41,21)]
- t51 Expansion/Detail Settler retreats from a hostile's reach | 1 raider(s) could take (45, 19) next turn; (43, 20) is the least exposed tile it can reach  [civ6 (53,20) = axial (43,20)]
- t51 Military/Decision Task force #30: a land force of 1 will hold for Escort settler | objective (45, 19), anchor (45, 19), 100% ready, 0.55 local strength  [civ6 (54,19) = axial (45,19)]
- t51 Military/Decision Task force #31: a land force of 1 will hold for Escort settler | objective (41, 21), anchor (41, 21), 100% ready, 0.65 local strength  [civ6 (51,21) = axial (41,21)]
- t51 Expansion/Detail Settler retreats from a hostile's reach | 1 raider(s) could take (45, 19) next turn; (43, 20) is the least exposed tile it can reach  [civ6 (53,20) = axial (43,20)]

## t171 settler 4194312 at (19,32) — `alone-in-fog`

- detected by: `unit_captured`, captor player 1
- mechanisms matched: alone-in-fog, fled-into-reach
- nearest hostile: none
- guard: ? id 5832735 [escort_cap_unresolved]

### Settler t-2..t

| turn | pos | moves | activity | hostiles within 3 | ours within 2 |
|---|---|---|---|---|---|
| t169 | (20,33) | 0 | awake | none | UNIT_IRONCLAD str 70 hp 100 mv 1 at (20,33) d=0 id 7602210<br>UNIT_PIKE_AND_SHOT str 55 hp 100 mv 0 at (20,33) d=0 id 5832735<br>UNIT_HORSEMAN str 36 hp 80 mv 6 at (22,34) d=2 id 2031620 |
| t170 | (17,33) | 0 | awake | none | none |
| t171 | (19,32) | 1 | awake | none | none |

### Orders (settler and guard)

- `{"candidates": 2, "kind": "escort_cap_unresolved", "reason": "ambiguous_guards", "sent": [20, 33], "settler": 4194312, "t": 1792983132, "turn": 169, "utc": "2026-10-26T02:52:12.299Z", "want": [20, 33]}`
- `{"checked_on": 170, "kind": "order_verified", "order_kind": "unit", "subject": 4194312, "t": 1792983139, "turn": 169, "utc": "2026-10-26T02:52:19.277Z", "verb": "MOVE_TO"}`
- `{"checked_on": 170, "kind": "order_verified", "order_kind": "unit", "subject": 5832735, "t": 1792983139, "turn": 169, "utc": "2026-10-26T02:52:19.277Z", "verb": "MOVE_TO"}`
- `{"checked_on": 171, "kind": "order_verified", "order_kind": "unit", "subject": 4194312, "t": 1792983145, "turn": 170, "utc": "2026-10-26T02:52:25.312Z", "verb": "MOVE_TO"}`
- `{"checked_on": 172, "kind": "order_verified", "order_kind": "unit", "subject": 4194312, "t": 1792983152, "turn": 171, "utc": "2026-10-26T02:52:32.450Z", "verb": "MOVE_TO"}`
- `{"checked_on": 172, "kind": "order_verified", "order_kind": "unit", "subject": 4194312, "t": 1792983152, "turn": 171, "utc": "2026-10-26T02:52:32.450Z", "verb": "MOVE_TO"}`

### why.log t-2..t

- t169 Strategy/Strategy Campaign remains aimed at Athens | the major-war army stays committed until it captures the city or its war target changes  [civ6 (10,28) = axial (-4,28)]
- t169 Economy/Decision Bogotá starts ranger to reopen the land frontier | the empire has no land eyes and unexplored ground is what the settler veto reads; this is the fastest viable launch (5.4 turns)
- t169 Military/Strategy Board: Destroy 3 of field cannon (value 1210, need 297, force #161 of 3, deadline 1) · Escort settler (value 280, need 0, force #160 of 1, deadline 1) · Destroy 1 of line infantry (value 360, need 116, no force, deadline 2) · Destroy 1 of frigate (value 179, need 64, force #162 of 1, deadline 1) · Escort settler (value 280, need 0, no force, deadline 3) | rows 9 [1 Siege, 4 Destroy, 3 Escort, 1 Recon], 7 force(s), 3 reassigned, short: 2 Destroy, 1 Escort, 2 Destroy, 2 Escort, 3 Siege
- t169 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (10, 32), anchor (10, 32), 0% ready, 0.36 local strength  [civ6 (26,32) = axial (10,32)]
- t169 Military/Decision Task force #165: a sea force of 1 will hold for Escort builder | objective (40, 26), anchor (40, 26), 0% ready, 3.00 local strength  [civ6 (53,26) = axial (40,26)]
- t169 Expansion/Detail Settler keeps (0, 16) through a blocked approach | no safe site lies within 8 tiles, and a far detour is how the last settlers spent twenty turns crossing the empire; the guard holds here until the approach clears  [civ6 (8,16) = axial (0,16)]
- t169 Expansion/Detail Settler marching to (0, 16) | 26 tiles away, the site is worth 30.3  [civ6 (8,16) = axial (0,16)]
- t169 Expansion/Detail Settler keeps (0, 16) through a blocked approach | no safe site lies within 8 tiles, and a far detour is how the last settlers spent twenty turns crossing the empire; the guard holds here until the approach clears  [civ6 (8,16) = axial (0,16)]
- t169 Expansion/Detail Settler marching to (0, 16) | 26 tiles away, the site is worth 30.3  [civ6 (8,16) = axial (0,16)]
- t169 Expansion/Detail Settler marching to (0, 16) | 25 tiles away, the site is worth 30.3  [civ6 (8,16) = axial (0,16)]
- t169 Expansion/Detail Settler marching to (0, 16) | 24 tiles away, the site is worth 30.3  [civ6 (8,16) = axial (0,16)]
- t169 Expansion/Detail Settler marching to (0, 16) | 23 tiles away, the site is worth 30.3  [civ6 (8,16) = axial (0,16)]
- t169 Expansion/Detail Settler marching to (0, 16) | 22 tiles away, the site is worth 30.3  [civ6 (8,16) = axial (0,16)]
- t169 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (10, 32), anchor (10, 32), 0% ready, 0.36 local strength  [civ6 (26,32) = axial (10,32)]
- t169 Military/Decision Task force #165: a sea force of 1 will hold for Escort builder | objective (40, 26), anchor (40, 26), 0% ready, 3.00 local strength  [civ6 (53,26) = axial (40,26)]
- t169 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (10, 32), anchor (10, 32), 0% ready, 0.36 local strength  [civ6 (26,32) = axial (10,32)]
- t169 Military/Decision Task force #165: a sea force of 1 will hold for Escort builder | objective (40, 26), anchor (40, 26), 0% ready, 3.00 local strength  [civ6 (53,26) = axial (40,26)]
- t169 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (10, 32), anchor (10, 32), 0% ready, 0.36 local strength  [civ6 (26,32) = axial (10,32)]
- t169 Military/Decision Task force #165: a sea force of 1 will hold for Escort builder | objective (40, 26), anchor (40, 26), 0% ready, 3.00 local strength  [civ6 (53,26) = axial (40,26)]
- t169 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (10, 32), anchor (10, 32), 0% ready, 0.36 local strength  [civ6 (26,32) = axial (10,32)]
- t169 Military/Decision Task force #165: a sea force of 1 will hold for Escort builder | objective (40, 26), anchor (40, 26), 0% ready, 3.00 local strength  [civ6 (53,26) = axial (40,26)]
- t169 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (7,19) = axial (-2,19)]
- t169 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (20,33) = axial (4,33)]
- t169 Military/Detail Holding the capture of Athens for a wall-breaker on its way | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (10,28) = axial (-4,28)]
- t169 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (10, 32), anchor (10, 32), 0% ready, 3.00 local strength  [civ6 (26,32) = axial (10,32)]
- t169 Military/Decision Task force #165: a sea force of 1 will hold for Escort builder | objective (40, 26), anchor (40, 26), 0% ready, 3.00 local strength  [civ6 (53,26) = axial (40,26)]
- t169 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (7,19) = axial (-2,19)]
- t169 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (20,33) = axial (4,33)]
- t169 Military/Detail Holding the capture of Athens for a wall-breaker on its way | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (10,28) = axial (-4,28)]
- t170 Military/Strategy Board: Escort settler (value 280, need 0, force #166 of 1, deadline 3) · Escort settler (value 280, need 0, force #160 of 1, deadline 3) · Destroy 1 of line infantry (value 101, need 90, force #167 of 2, deadline 2) · Recon Greece's capital (value 300, need 0, force #163 of 1) · Siege Athens (value 285, need 435, force #136 of 6, staging) | rows 5 [1 Siege, 1 Destroy, 2 Escort, 1 Recon], 6 force(s), 2 reassigned, short: 1 Escort, 2 Siege
- t170 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (4, 33), anchor (4, 33), 0% ready, 3.00 local strength  [civ6 (20,33) = axial (4,33)]
- t170 Military/Decision Task force #166: a sea force of 1 will hold for Escort settler | objective (-2, 19), anchor (-2, 19), 0% ready, 0.62 local strength  [civ6 (7,19) = axial (-2,19)]
- t170 Expansion/Detail A naval guard joins the settler | the sea layer shares the water leg while the land guard remains responsible for the landing; the hull can route to the embarked Settler and will close the gap on its military turn
- t170 Expansion/Detail Settler marching to (-1, 16) | 3 tiles away, the site is worth 56.6  [civ6 (7,16) = axial (-1,16)]
- t170 Expansion/Detail Settler past its walk deadline takes (-1, 16) | 32 turns out of a city against a deadline of 16; the best legal site within 2 tiles is worth 53.6 net of the step, and a city there beats the site it has not reached  [civ6 (7,16) = axial (-1,16)]
- t170 Expansion/Detail A naval guard joins the settler | the sea layer shares the water leg while the land guard remains responsible for the landing; the hull can route to the embarked Settler and will close the gap on its military turn
- t170 Expansion/Detail A guard joins the settler | it will share the settler's tile; a stacked civilian cannot be captured
- t170 Expansion/Detail Settler falls back toward its guard | its tile is threatened (risk 14) and the guard is 29 tiles away — waiting here is how the last settler was captured  [civ6 (51,33) = axial (35,33)]
- t170 Expansion/Detail Settler falls back toward its guard | its tile is threatened (risk 7) and the guard is 28 tiles away — waiting here is how the last settler was captured  [civ6 (51,33) = axial (35,33)]
- t170 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 4 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (22,34) = axial (5,34)]
- t170 Expansion/Detail Settler marching to (0, 16) | 19 tiles away, the site is worth 30.3  [civ6 (8,16) = axial (0,16)]
- t170 Expansion/Detail Settler sidesteps a barbarian's reach | (2, 32) could be taken next turn; (1, 33) keeps out of it  [civ6 (17,33) = axial (1,33)]
- t170 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (4, 33), anchor (4, 33), 0% ready, 3.00 local strength  [civ6 (20,33) = axial (4,33)]
- t170 Military/Decision Task force #166: a sea force of 1 will hold for Escort settler | objective (-2, 19), anchor (-2, 19), 0% ready, 0.62 local strength  [civ6 (7,19) = axial (-2,19)]
- t170 Military/Detail Holding the capture of Athens for a wall-breaker on its way | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (10,28) = axial (-4,28)]
- t170 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (4, 33), anchor (4, 33), 0% ready, 3.00 local strength  [civ6 (20,33) = axial (4,33)]
- t170 Military/Decision Task force #166: a sea force of 1 will hold for Escort settler | objective (-2, 19), anchor (-2, 19), 0% ready, 0.62 local strength  [civ6 (7,19) = axial (-2,19)]
- t170 Expansion/Detail A naval guard joins the settler | the sea layer shares the water leg while the land guard remains responsible for the landing; the hull can route to the embarked Settler and will close the gap on its military turn
- t170 Expansion/Detail Settler marching to (-1, 16) | 1 tiles away, the site is worth 56.6  [civ6 (7,16) = axial (-1,16)]
- t170 Military/Detail Holding the capture of Athens for a wall-breaker on its way | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (10,28) = axial (-4,28)]
- t170 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (4, 33), anchor (4, 33), 0% ready, 3.00 local strength  [civ6 (20,33) = axial (4,33)]
- t170 Military/Decision Task force #166: a sea force of 1 will hold for Escort settler | objective (-2, 19), anchor (-2, 19), 0% ready, 0.62 local strength  [civ6 (7,19) = axial (-2,19)]
- t170 Military/Detail Holding the capture of Athens for a wall-breaker on its way | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (10,28) = axial (-4,28)]
- t171 Military/Strategy Board: Escort settler (value 280, need 0, force #160 of 1, deadline 1) · Destroy 1 of tank (value 480, need 156, no force, deadline 2) · Escort settler (value 280, need 0, force #166 of 1, deadline 4) · Recon Greece's capital (value 300, need 0, force #170 of 1) · Siege Athens (value 285, need 259, force #136 of 4, staging) | rows 5 [1 Siege, 1 Destroy, 2 Escort, 1 Recon], 6 force(s), 3 reassigned, short: 3 Destroy, 1 Siege
- t171 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 0.69 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #166: a sea force of 1 will hold for Escort settler | objective (-1, 16), anchor (-1, 16), 0% ready, 3.00 local strength  [civ6 (7,16) = axial (-1,16)]
- t171 Military/Decision Task force #169: a land force of 2 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 1.11 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Expansion/Detail Settler past its walk deadline takes (-1, 17) | 33 turns out of a city against a deadline of 16; the best legal site within 2 tiles is worth 80.6 net of the step, and a city there beats the site it has not reached  [civ6 (7,17) = axial (-1,17)]
- t171 Expansion/Decision Founding a city at (-1, 17) at the walk deadline | 33 turns out of a city against a deadline of 16; the site is worth 83.6, and every turn a Settler walks is a city it is not  [civ6 (7,17) = axial (-1,17)]
- t171 Expansion/Detail Settler retreats from a hostile's reach | 3 raider(s) could take (1, 33) next turn; (3, 31) is the least exposed tile it can reach  [civ6 (18,31) = axial (3,31)]
- t171 Expansion/Detail settler holds inside a barbarian's reach | 4 raider(s) could take (3, 31) and no reachable tile is better  [civ6 (18,31) = axial (3,31)]
- t171 Expansion/Detail Settler sets (0, 16) aside | the cached site stopped passing its checks (a city within three tiles); it stays out of the next picks for 6 standard turns so a threat flickering at the edge of sight cannot flip the march every frame  [civ6 (8,16) = axial (0,16)]
- t171 Expansion/Detail Settler takes the safest reachable legal site | no ranked site is reachable; (3, 15) is 16 tiles away and beats a Settler standing still  [civ6 (10,15) = axial (3,15)]
- t171 Expansion/Detail Settler keeps (3, 15) through a blocked approach | no safe site lies within 8 tiles, and a far detour is how the last settlers spent twenty turns crossing the empire; the guard holds here until the approach clears  [civ6 (10,15) = axial (3,15)]
- t171 Expansion/Detail Settler begins an escorted expedition | the route from (3, 31) to (3, 15) is 17 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t171 Expansion/Detail Settler marching to (3, 15) | 16 tiles away, the site is worth 82.1  [civ6 (10,15) = axial (3,15)]
- t171 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 0.69 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #166: a sea force of 1 will hold for Escort settler | objective (-1, 16), anchor (-1, 16), 0% ready, 3.00 local strength  [civ6 (7,16) = axial (-1,16)]
- t171 Military/Decision Task force #169: a land force of 2 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 1.11 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 0.69 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #166: a sea force of 1 will hold for Escort settler | objective (-1, 16), anchor (-1, 16), 0% ready, 3.00 local strength  [civ6 (7,16) = axial (-1,16)]
- t171 Military/Decision Task force #169: a land force of 2 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 1.11 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 0.69 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #166: a sea force of 1 will hold for Escort settler | objective (-1, 16), anchor (-1, 16), 0% ready, 3.00 local strength  [civ6 (7,16) = axial (-1,16)]
- t171 Military/Decision Task force #169: a land force of 2 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 1.11 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 0.69 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #166: a sea force of 1 will hold for Escort settler | objective (-1, 16), anchor (-1, 16), 0% ready, 3.00 local strength  [civ6 (7,16) = axial (-1,16)]
- t171 Military/Decision Task force #169: a land force of 2 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 1.11 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 0.69 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #166: a sea force of 1 will hold for Escort settler | objective (-1, 16), anchor (-1, 16), 0% ready, 3.00 local strength  [civ6 (7,16) = axial (-1,16)]
- t171 Military/Decision Task force #169: a land force of 2 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 1.11 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 0.69 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #166: a sea force of 1 will hold for Escort settler | objective (-1, 16), anchor (-1, 16), 0% ready, 3.00 local strength  [civ6 (7,16) = axial (-1,16)]
- t171 Military/Decision Task force #169: a land force of 2 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 1.11 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 0.69 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #166: a sea force of 1 will hold for Escort settler | objective (-1, 16), anchor (-1, 16), 0% ready, 3.00 local strength  [civ6 (7,16) = axial (-1,16)]
- t171 Military/Decision Task force #169: a land force of 2 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 1.11 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 0.69 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #166: a sea force of 1 will hold for Escort settler | objective (-1, 16), anchor (-1, 16), 0% ready, 3.00 local strength  [civ6 (7,16) = axial (-1,16)]
- t171 Military/Decision Task force #169: a land force of 2 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 1.11 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Detail Holding the capture of Athens for a wall-breaker on its way | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (10,28) = axial (-4,28)]
- t171 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 3.00 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #166: a sea force of 1 will hold for Escort settler | objective (-1, 16), anchor (-1, 16), 0% ready, 1.12 local strength  [civ6 (7,16) = axial (-1,16)]
- t171 Military/Decision Task force #169: a land force of 2 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 3.00 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Expansion/Decision Settler founds a city for shelter at (-1, 17) | the site is worth 138.1; estimated nearby attack damage is 23.2 against 200 city HP, so founding beats exposing the settler for another turn  [civ6 (7,17) = axial (-1,17)]
- t171 Expansion/Detail Settler retreats from a hostile's reach | 4 raider(s) could take (2, 32) next turn; (3, 32) is the least exposed tile it can reach  [civ6 (19,32) = axial (3,32)]
- t171 Expansion/Detail settler holds inside a barbarian's reach | 4 raider(s) could take (3, 32) and no reachable tile is better  [civ6 (19,32) = axial (3,32)]
- t171 Expansion/Detail A guard joins the settler | it will share the settler's tile; a stacked civilian cannot be captured
- t171 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 3 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (21,33) = axial (5,33)]
- t171 Expansion/Detail Settler marching to (3, 15) | 17 tiles away, the site is worth 82.1  [civ6 (10,15) = axial (3,15)]
- t171 Expansion/Detail Settler waits outside a barbarian's reach | (3, 31) could be taken next turn and no safe step makes progress  [civ6 (19,32) = axial (3,32)]
- t171 Expansion/Detail Settler HELD short of (3, 15) | 17 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (10,15) = axial (3,15)]
- t171 Military/Detail Holding the capture of Athens for a wall-breaker on its way | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (10,28) = axial (-4,28)]
- t171 Cities/Decision Valencia de Carabobo starts monument | 30 production, about 17 turns at 1.8 a turn; the empire holds 16 military for 9 cities against a target of 1.0 each, and 1 settler, 6 builders, 0 traders  [civ6 (7,17) = axial (-1,17)]
- t171 Military/Decision Task force #160: a sea force of 1 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 3.00 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Military/Decision Task force #169: a land force of 2 will hold for Escort settler | objective (1, 33), anchor (1, 33), 0% ready, 3.00 local strength  [civ6 (17,33) = axial (1,33)]
- t171 Expansion/Detail settler holds inside a barbarian's reach | 4 raider(s) could take (3, 32) and no reachable tile is better  [civ6 (19,32) = axial (3,32)]
- t171 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 3 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (21,33) = axial (5,33)]
- t171 Expansion/Detail Settler marching to (3, 15) | 17 tiles away, the site is worth 82.1  [civ6 (10,15) = axial (3,15)]
- t171 Expansion/Detail Settler waits outside a barbarian's reach | (3, 31) could be taken next turn and no safe step makes progress  [civ6 (19,32) = axial (3,32)]
- t171 Expansion/Detail Settler HELD short of (3, 15) | 17 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (10,15) = axial (3,15)]
- t171 Military/Detail Holding the capture of Athens for a wall-breaker on its way | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (10,28) = axial (-4,28)]

