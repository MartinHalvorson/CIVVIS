from pathlib import Path
import sys,json,subprocess,hashlib,datetime
repo=Path('/Users/martbot-mbp-m5-max-128/civvis-main-managed');sys.path.insert(0,str(repo/'tools'))
from civ6_decision_trace import captured_input
from civ6_ladder import decider_genome
root=Path(__file__).parent;run=Path('/Users/martbot-mbp-m5-max-128/civvis-civ6-runs/control/civvis-20261103T002240Z')
binary=Path('/Users/martbot-mbp-m5-max-128/civvis-runs/2026-11-02-native-process-context/civvis-20261102T232731Z/frozen-observed-orders')
genome=decider_genome(run/'why.log');profile=sorted(genome['forced']);tag='culture-digs-one-museum';assert tag not in profile
summary=json.loads((run/'summary.json').read_text());civ=summary['seat']['civ'];results=[]
for turn in (153,160):
 rows=[json.loads(x) for x in (run/'decisions.jsonl').read_text().splitlines()];row=next(r for r in rows if (r['decision']['turn'],r['decision']['frame'])==(turn,0));cap=row['input_capture'];assert cap['complete'];raw=None
 for read in cap['reads']:
  r=captured_input(cap,read['snapshot_id']);states=[json.loads(x) for x in r.splitlines() if json.loads(x).get('kind')=='state']
  if states and (states[-1]['turn'],states[-1].get('frame',0))==(turn,0):raw=r;state=states[-1];break
 assert raw;case=root/f't{turn}';case.mkdir(exist_ok=False);(case/'captured-events.jsonl').write_bytes(raw)
 for label,on in [('off-0',False),('on-0',True),('off-1',False)]:
  d=case/label;d.mkdir();(d/'events.jsonl').write_bytes(raw);flags=sorted(profile+([tag] if on else []));argv=[str(binary),'--mirror',str(d),'--turn',str(turn),'--victory','culture','--civ',civ,'--fresh-board','--explain']
  for f in flags:argv+=['--with',f]
  p=subprocess.run(argv,cwd=repo,capture_output=True,timeout=60);(d/'stdout').write_bytes(p.stdout);(d/'stderr').write_bytes(p.stderr);assert p.returncode==0,(label,p.stderr[-1000:]);payload=json.loads(p.stdout);observed=decider_genome(d/'stderr');assert observed and (tag in observed['forced'])==on
  result={'turn':turn,'label':label,'argv':argv,'profile':observed,'input_sha256':hashlib.sha256(raw).hexdigest(),'orders':payload['orders'],'production':[o for o in payload['orders'] if o['kind']=='city'],'native_production':[a for a in payload['decision']['native_actions'] if a['type'] in ['produce','produce_next','purchase']]};results.append(result);(d/'events.jsonl').unlink();print(json.dumps({k:result[k] for k in ['turn','label','production','native_production']}),flush=True)
 assert results[-1]['orders']==results[-3]['orders']
(root/'query-results.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'One-shot captured-board mechanism diagnostic; not persistent native replay, host execution or strength evidence. All failed attempts retained.','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'results':results},indent=2)+'\n')
