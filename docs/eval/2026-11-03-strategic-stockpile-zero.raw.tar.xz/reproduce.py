from pathlib import Path
from lupa.lua51 import LuaRuntime
root=Path(__file__).parent
for label,passed,failed in [('before',12,4),('candidate',16,0)]:
 lines=[];p=root/label/'strategic_stockpile_readback_test.lua';lua=LuaRuntime();lua.globals().print=lambda *args:lines.append(' '.join(str(a) for a in args));lua.execute('arg = {[0] = ...}',str(p));error=None
 try:lua.execute(p.read_text())
 except Exception as e:error=str(e)
 assert any(f'{passed} stockpile readback checks passed; {failed} failed' in line for line in lines),(label,lines,error)
 assert (error is not None)==bool(failed),(label,error)
 print(label,passed,'passed',failed,'failed as expected')
