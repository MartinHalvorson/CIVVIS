# Settler captures — civvis-20261026T005810Z

1 capture(s). Mechanism is the first match in the operator's order; every match is listed.

## t18 settler 327683 at (13,14) — `site-in-barbarian-nest`

- detected by: `unit_captured`, captor player 63 (barbarian)
- mechanisms matched: site-in-barbarian-nest
- nearest hostile: UNIT_SCOUT str 10 hp 48 mv 0 at (12,12) d=3 id 1966080
- guard: UNIT_SCOUT str 10 hp 81 mv 0 at (13,14) d=0 id 196608 [escort_cap_unresolved]
- site: (13,15) — hostile seen within 3 in the last 5 turns: True; camp within 3: False

### Settler t-2..t

| turn | pos | moves | activity | hostiles within 3 | ours within 2 |
|---|---|---|---|---|---|
| t16 | (13,14) | 1 | awake | none | UNIT_WARRIOR str 20 hp 100 mv 1 at (12,15) d=1 id 131073<br>UNIT_SCOUT str 10 hp 100 mv 0 at (13,13) d=1 id 196608 |
| t17 | (12,15) | 1 | awake | UNIT_SCOUT str 10 hp 48 mv 0 at (12,12) d=3 id 1966080 | UNIT_WARRIOR str 20 hp 100 mv 2 at (13,14) d=1 id 131073<br>UNIT_SCOUT str 10 hp 100 mv 2 at (12,13) d=2 id 196608 |
| t18 | (13,14) | 2 | awake | none | UNIT_SCOUT str 10 hp 81 mv 0 at (13,14) d=0 id 196608<br>UNIT_WARRIOR str 20 hp 89 mv 0 at (11,13) d=2 id 131073 |

### Orders (settler and guard)

- `{"checked_on": 17, "kind": "order_verified", "order_kind": "unit", "subject": 327683, "t": 1792976381, "turn": 16, "utc": "2026-10-26T00:59:41.569Z", "verb": "MOVE_TO"}`
- `{"checked_on": 17, "kind": "order_verified", "order_kind": "unit", "subject": 196608, "t": 1792976381, "turn": 16, "utc": "2026-10-26T00:59:41.569Z", "verb": "MOVE_TO"}`
- `{"checked_on": 18, "kind": "order_failed", "order_kind": "unit", "reason": "did_not_move", "subject": 196608, "t": 1792976383, "turn": 17, "utc": "2026-10-26T00:59:43.019Z", "verb": "MOVE_TO"}`
- `{"checked_on": 18, "kind": "order_verified", "order_kind": "unit", "subject": 196608, "t": 1792976383, "turn": 17, "utc": "2026-10-26T00:59:43.019Z", "verb": "MOVE_TO"}`
- `{"checked_on": 18, "kind": "order_verified", "order_kind": "unit", "subject": 327683, "t": 1792976383, "turn": 17, "utc": "2026-10-26T00:59:43.019Z", "verb": "MOVE_TO"}`
- `{"checked_on": 18, "kind": "order_verified", "order_kind": "unit", "subject": 196608, "t": 1792976383, "turn": 17, "utc": "2026-10-26T00:59:43.019Z", "verb": "ATTACK"}`
- `{"guard": 196608, "kind": "escort_cap_synced", "sent": [13, 14], "settler": 327683, "t": 1792976383, "turn": 18, "utc": "2026-10-26T00:59:43.624Z", "want": [13, 14]}`
- `{"candidates": 1, "guard": 196608, "kind": "escort_cap_unresolved", "reason": "guard_still_capped", "sent": [14, 12], "settler": 327683, "t": 1792976383, "turn": 18, "utc": "2026-10-26T00:59:43.794Z", "want": [14, 12]}`
- `{"checked_on": 19, "kind": "order_failed", "order_kind": "unit", "reason": "unit_gone", "subject": 327683, "t": 1792976385, "turn": 18, "utc": "2026-10-26T00:59:45.098Z", "verb": "MOVE_TO"}`
- `{"checked_on": 19, "kind": "order_verified", "order_kind": "unit", "subject": 196608, "t": 1792976385, "turn": 18, "utc": "2026-10-26T00:59:45.098Z", "verb": "MOVE_TO"}`
- `{"checked_on": 19, "kind": "order_verified", "order_kind": "unit", "subject": 327683, "t": 1792976385, "turn": 18, "utc": "2026-10-26T00:59:45.098Z", "verb": "MOVE_TO"}`
- `{"checked_on": 19, "kind": "order_verified", "order_kind": "unit", "subject": 196608, "t": 1792976385, "turn": 18, "utc": "2026-10-26T00:59:45.098Z", "verb": "MOVE_TO"}`

### why.log t-2..t

- t16 Military/Strategy Board: Escort settler (value 280, need 0, no force) · Escort settler (value 280, need 0, no force) · ClearCamp camp at (2, 13) (value 120, need 38, no force) · Recon sector 1 (value 30, need 0, no force) · Recon sector 2 (value 30, need 0, no force) | rows 9 [1 ClearCamp, 2 Escort, 6 Recon], 0 force(s), 0 reassigned, short: 1 Escort, 1 Escort, 3 ClearCamp, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t16 Expansion/Detail Settler marching to (5, 16) | 1 tiles away, the site is worth 131.1  [civ6 (13,16) = axial (5,16)]
- t16 Expansion/Detail Settler marching to (6, 15) | 3 tiles away, the site is worth 159.7  [civ6 (13,15) = axial (6,15)]
- t16 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 2 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (13,11) = axial (8,11)]
- t16 Expansion/Detail Settler marching to (6, 15) | 2 tiles away, the site is worth 159.7  [civ6 (13,15) = axial (6,15)]
- t16 Expansion/Detail Settler marching to (6, 15) | 1 tiles away, the site is worth 185.5  [civ6 (13,15) = axial (6,15)]
- t16 Expansion/Detail Settler ends its move short of (6, 15) | 1 tiles away with 1 movement left; the next tile costs 2, so it walks on next turn  [civ6 (13,15) = axial (6,15)]
- t17 Military/Strategy Board: Escort settler (value 280, need 0, no force, deadline 1) · Escort settler (value 280, need 0, no force, deadline 2) · Destroy 1 of scout (value 14, need 8, no force, deadline 1) · ClearCamp camp at (2, 13) (value 120, need 38, no force) · Recon sector 1 (value 30, need 0, no force) | rows 10 [1 Destroy, 1 ClearCamp, 2 Escort, 6 Recon], 0 force(s), 0 reassigned, short: 2 Escort, 2 Escort, 1 Destroy, 3 ClearCamp, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t17 Expansion/Detail A guard is called to the settler | sharing the tile blocks capture outright  [civ6 (13,14) = axial (6,14)]
- t17 Expansion/Detail Settler sets (6, 15) aside | the cached site stopped passing its checks (a city within three tiles); it stays out of the next picks for 6 standard turns so a threat flickering at the edge of sight cannot flip the march every frame  [civ6 (13,15) = axial (6,15)]
- t17 Expansion/Detail Settler begins an escorted expedition | the route from (6, 14) to (11, 6) is 8 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t17 Expansion/Detail A guard joins the settler | it will share the settler's tile; a stacked civilian cannot be captured
- t17 Expansion/Detail Settler marching to (11, 6) | 8 tiles away, the site is worth 77.4  [civ6 (14,6) = axial (11,6)]
- t17 Expansion/Detail Guard cuts down the scout pinning its settler | its zone of control is what holds the pair on (6, 13); the blow kills it  [civ6 (12,12) = axial (6,12)]
- t17 Economy/Decision Quito starts scout to reopen the land frontier | the empire has no land eyes and unexplored ground is what the settler veto reads; this is the fastest viable launch (3.3 turns)
- t17 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 2 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (12,13) = axial (6,13)]
- t17 Expansion/Detail Settler marching to (11, 6) | 9 tiles away, the site is worth 77.4  [civ6 (14,6) = axial (11,6)]
- t17 Expansion/Detail Settler ends its move short of (11, 6) | 9 tiles away with 1 movement left; the next tile costs 2, so it walks on next turn  [civ6 (14,6) = axial (11,6)]
- t18 Expansion/Decision Bogotá starts a Settler for the early city floor | early-settler-floor: 2 cities and 1 walking against a floor of 6 before turn 60, 9.0 turns
- t18 Expansion/Detail A guard is called to the settler | sharing the tile blocks capture outright  [civ6 (12,15) = axial (5,15)]
- t18 Expansion/Detail Settler keeps (11, 6) through a blocked approach | no safe site lies within 8 tiles, and a far detour is how the last settlers spent twenty turns crossing the empire; the guard holds here until the approach clears  [civ6 (14,6) = axial (11,6)]
- t18 Expansion/Detail Settler marching to (11, 6) | 9 tiles away, the site is worth 77.4  [civ6 (14,6) = axial (11,6)]
- t18 Expansion/Detail Settler waits with the guard it just called | the guard spent its move reaching this tile; the pair marches next turn  [civ6 (12,15) = axial (5,15)]
- t18 Expansion/Detail Settler HELD short of (11, 6) | 9 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (14,6) = axial (11,6)]
- t18 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (12,15) = axial (5,15)]
- t18 Expansion/Detail Settler marching to (11, 6) | 9 tiles away, the site is worth 77.4  [civ6 (14,6) = axial (11,6)]
- t18 Expansion/Detail Settler begins an escorted expedition | the route from (5, 14) to (13, 7) is 8 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t18 Expansion/Detail A guard joins the settler | it will share the settler's tile; a stacked civilian cannot be captured
- t18 Expansion/Detail Settler marching to (13, 7) | 8 tiles away, the site is worth 63.0  [civ6 (16,7) = axial (13,7)]
- t18 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 2 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (11,13) = axial (5,13)]
- t18 Expansion/Detail Settler marching to (13, 7) | 7 tiles away, the site is worth 63.0  [civ6 (16,7) = axial (13,7)]
- t18 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 2 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (11,13) = axial (5,13)]
- t18 Expansion/Detail Settler marching to (13, 7) | 6 tiles away, the site is worth 63.0  [civ6 (16,7) = axial (13,7)]

