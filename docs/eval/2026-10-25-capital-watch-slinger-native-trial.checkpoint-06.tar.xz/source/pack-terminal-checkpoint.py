"""Preserve terminal raw cohorts and dated non-atomic observer checkpoints."""
import argparse,datetime,hashlib,io,json,pathlib,shutil,tarfile
P=argparse.ArgumentParser(description=__doc__)
P.add_argument('--cohort',action='append',required=True,help='NUMBER:TAG')
P.add_argument('--collection',type=int,required=True)
P.add_argument('--checkpoint',type=int,required=True)
P.add_argument('--reference-binaries',action='store_true')
P.add_argument('--extra',action='append',default=[])
args=P.parse_args()
repo=pathlib.Path.cwd(); base=pathlib.Path('/tmp/civvis-capital-watch-slinger-native-trial-2315')
control=pathlib.Path.home()/'civvis-civ6-runs/control'
experiment=pathlib.Path.home()/'civvis-civ6-runs/experiments/2026-10-25-capital-watch-slinger-native-trial-codex-1025i-root'
prefix='2026-10-25-capital-watch-slinger-native-trial'

def digest(data):return hashlib.sha256(data).hexdigest()
def archive(out,files,with_manifest=False):
 if out.exists():raise ValueError('retain previous archive: '+str(out))
 manifest={}
 with tarfile.open(out,'w:xz') as tar:
  for name,p in sorted(files.items()):
   at=datetime.datetime.now(datetime.timezone.utc).isoformat(); data=p.read_bytes()
   manifest[name]={'bytes':len(data),'sha256':digest(data),'read_utc':at}
   member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;tar.addfile(member,io.BytesIO(data))
  if with_manifest:
   data=(json.dumps(manifest,indent=2)+'\n').encode();member=tarfile.TarInfo('manifest.json');member.size=len(data);member.mode=0o644;tar.addfile(member,io.BytesIO(data))
 with tarfile.open(out) as tar:
  for name,expected in manifest.items():
   data=tar.extractfile(name).read()
   if len(data)!=expected['bytes'] or digest(data)!=expected['sha256']:raise ValueError('archive byte mismatch')
 return {'members':len(files)+int(with_manifest),'bytes':out.stat().st_size,'sha256':digest(out.read_bytes())},manifest

files={}; results={}; binary_sha=set(); references={}; known_binaries={}
if args.reference_binaries:
 for previous in sorted((repo/'docs/eval').glob(prefix+'.checkpoint-*.tar.xz')):
  with tarfile.open(previous) as tar:
   try: manifest=json.loads(tar.extractfile('manifest.json').read())
   except KeyError: continue
   for name,identity in manifest.items():
    if name.endswith('/civvis_orders'): known_binaries.setdefault(identity['sha256'],(previous,name))
for spec in args.cohort:
 number,tag=spec.split(':',1);number=int(number); run=control/tag
 summary=json.loads((run/'summary.json').read_text())
 if not summary.get('game_stopped'):raise ValueError('not terminal: '+tag)
 raw={str(p.relative_to(control)):p for p in run.rglob('*') if p.is_file() and p.suffix.lower() not in ['.png','.jpg','.jpeg']}
 info,manifest=archive(repo/'docs/eval'/f'{prefix}.cohort-{number:02}.tar.xz',raw)
 identity=base/f'cohort-{number:02}-archive.json';identity.write_text(json.dumps({'archive':info,'files':manifest,'scope':'all non-image terminal files; individually read and non-atomic'},indent=2)+'\n');results[tag]=info
 files[identity.name]=identity
 for suffix in ['json.gz','log']:
  p=base/f'game-{number:02}-upgrades.{suffix}'; files[p.name]=p
 shutil.copy2(base/f'game-{number:02}-upgrades.json.gz',repo/'docs/eval'/f'{prefix}.game-{number:02}-upgrades.json.gz')
 decision=json.loads(next((run/'decisions.jsonl').open()))
 binary=pathlib.Path(decision['binary']); actual=digest(binary.read_bytes())
 if actual!=decision['binary_on_disk_sha256']:raise ValueError('actual binary changed')
 if actual not in binary_sha:
  binary_sha.add(actual)
  reference=known_binaries.get(actual)
  if reference:
   previous,member=reference
   with tarfile.open(previous) as tar:
    if digest(tar.extractfile(member).read())!=actual:raise ValueError('archived adapter mismatch')
   references[actual]={'archive':str(previous.relative_to(repo)),'archive_sha256':digest(previous.read_bytes()),'member':member,'binary_sha256':actual,'actual_path':str(binary)}
  for p in binary.parent.iterdir():
   if p.is_file() and (not reference or p.name!=binary.name):files['adapters/'+actual+'/'+p.name]=p
for name in [f'collection-{args.collection:02}.json.gz',f'collection-{args.collection:02}.log']:
 files[name]=base/name
for name in ['state.json','observer.log']:files['observer/'+name]=experiment/name
if references:
 reference_file=base/f'checkpoint-{args.checkpoint:02}-binary-references.json'
 reference_file.write_text(json.dumps(references,indent=2)+'\n');files[reference_file.name]=reference_file
for value in args.extra:
 p=pathlib.Path(value);files['extra/'+p.name]=p
files['source/'+pathlib.Path(__file__).name]=pathlib.Path(__file__)
info,_=archive(repo/'docs/eval'/f'{prefix}.checkpoint-{args.checkpoint:02}.tar.xz',files,True)
(base/f'checkpoint-{args.checkpoint:02}-archive.json').write_text(json.dumps(info)+'\n')
shutil.copy2(base/f'collection-{args.collection:02}.json.gz',repo/'docs/eval'/f'{prefix}.collection-{args.collection:02}.json.gz')
print(json.dumps({'cohorts':results,'checkpoint':info},indent=2))
