"""Bounded pilot monitor; restore only the owned screen after eight families."""
from pathlib import Path
import datetime,fcntl,hashlib,json,os,re,sys,time
REPO=Path('/Users/martbot-mbp-m5-max-128/civvis-native-science-fuel-pilot-b489')
ROOT=Path('/Users/martbot-mbp-m5-max-128/civvis-civ6-runs/control')
OUT=Path('/Users/martbot-mbp-m5-max-128/civvis-runs/2026-11-02-native-science-fuel-pilot')
sys.path.insert(0,str(REPO/'tools'))
import civ6_science_fuel_pilot as pilot
ARM=json.loads((REPO/'docs/eval/2026-11-02-native-science-fuel-pilot.arm.json').read_text())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def metadata_primary():
 families={}
 for directory in ROOT.glob('civvis-*'):
  runtime=directory/'runtime_updates.jsonl'
  if not runtime.exists():continue
  try:
   with runtime.open() as stream:
    start=next((r['utc'] for r in (json.loads(line) for line in stream) if r.get('status')=='start' and r.get('utc')),None)
  except (OSError,json.JSONDecodeError):continue
  if start is None:continue
  family=re.sub(r'-cont\d+$','',directory.name);item=families.setdefault(family,{'start':start,'science':False})
  if pilot.stamp(start)<pilot.stamp(item['start']):item['start']=start
  try:summary=json.loads((directory/'summary.json').read_text())
  except (OSError,json.JSONDecodeError):continue
  item['science']|=summary.get('configured') is True and summary.get('victory_target')=='science'
 return [name for name,item in sorted(families.items(),key=lambda pair:pilot.stamp(pair[1]['start'])) if pilot.stamp(item['start'])>pilot.stamp(ARM['armed_utc']) and item['science']]
def restore_owned(path,expected_sha,prior):
 descriptor=os.open(path,os.O_RDWR|os.O_NOFOLLOW)
 try:
  fcntl.flock(descriptor,fcntl.LOCK_EX|fcntl.LOCK_NB)
  os.lseek(descriptor,0,os.SEEK_SET);current=os.read(descriptor,65536)
  fdstat=os.fstat(descriptor);pathstat=os.stat(path,follow_symlinks=False)
  if sha(current)!=expected_sha or (fdstat.st_dev,fdstat.st_ino)!=(pathstat.st_dev,pathstat.st_ino):return False
  os.ftruncate(descriptor,0);os.lseek(descriptor,0,os.SEEK_SET)
  if prior:os.write(descriptor,prior)
  os.fsync(descriptor);os.lseek(descriptor,0,os.SEEK_SET)
  return os.read(descriptor,65536)==prior
 finally:os.close(descriptor)
def main():
 lock=(OUT/'monitor.lock').open('a')
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:raise SystemExit('Pilot monitor already running')
 screen=Path(ARM['screen_path']);collector_sha=sha((REPO/'tools/civ6_science_fuel_pilot.py').read_bytes());deadline=time.monotonic()+7200;last=None
 while time.monotonic()<deadline:
  if sha(screen.read_bytes())!=ARM['after_sha256']:
   receipt={'utc':now(),'status':'screen_changed_no_write','current_sha256':sha(screen.read_bytes())};(OUT/'monitor-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True);return
  families=metadata_primary()
  if len(families)!=last:print(json.dumps({'utc':now(),'primary_metadata_count':len(families),'families':families[:8]}),flush=True);last=len(families)
  if len(families)>=8:
   assert sha((REPO/'tools/civ6_science_fuel_pilot.py').read_bytes())==collector_sha
   census=pilot.census(ROOT,ARM['armed_utc'],8)
   assert census['primary_observed']>=8 and [f['family'] for f in census['primary']]==families[:8]
   raw=(json.dumps(census,indent=2)+'\n').encode();(OUT/'auto-stop-census.json').write_bytes(raw)
   restored=restore_owned(screen,ARM['after_sha256'],bytes.fromhex(ARM['before_hex']))
   receipt={'utc':now(),'status':'restored_after_eight' if restored else 'ownership_changed_no_restore','screen_path':str(screen),'before_sha256':ARM['after_sha256'],'after_sha256':sha(screen.read_bytes()),'cohort':families[:8],'observed_primary_count':census['primary_observed'],'census_sha256':sha(raw),'collector_sha256':collector_sha,'authorization':'Preregistered first-eight-family stop rule; no other policy files are written.'}
   (OUT/'stop-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True);return
  time.sleep(15)
 print(json.dumps({'utc':now(),'status':'window_expired_no_restore','primary_metadata_count':last}),flush=True)
if __name__=='__main__':main()
