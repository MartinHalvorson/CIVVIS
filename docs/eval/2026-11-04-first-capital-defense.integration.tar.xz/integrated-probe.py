"""Wait for the already-running native build, then compare captured proposals."""
from pathlib import Path
import copy, hashlib, json, os, shutil, subprocess, sys, time
ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/martbot-mbp-m5-max-128/civvis-first-capital-before-the-camp-541a')
sys.path.insert(0, str(REPO / 'tools'))
import civ6_captured_read_replay as replay
from civ6_ladder import decider_genome

binary = REPO / 'target/ci/civvis_orders'
source_commit = os.environ['CIVVIS_PROBE_SOURCE']
assert binary.is_file()
frozen = ROOT / 'integrated-ci-orders'
assert not frozen.exists()
shutil.copy2(binary, frozen)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert sha(frozen.read_bytes()) == sha(binary.read_bytes())
production = ['src/ai/advanced.rs', 'src/ai/advanced/genes.rs',
              'src/ai/advanced/objective_board.rs', 'src/ai/advanced/treatment_flags.rs',
              'src/ai/advanced/first_capital_defense.rs']
manifest = {}
for name in production:
    committed = subprocess.check_output(['git', 'show', source_commit + ':' + name], cwd=REPO)
    assert committed == (REPO / name).read_bytes(), name
    manifest[name] = sha(committed)
intent = {'scope': 'Candidate commands, not observed native processes. Original input qualification is separate. Stop ON at the first changed order; no continued counterfactual history or strength estimate.',
          'source_commit': source_commit, 'production_files_sha256': manifest,
          'candidate_sha256': sha(frozen.read_bytes()),
          'test_fixture_note': 'A visibility correction to the Rust test fixture may be dirty; production source above must match the build-start commit.'}
(ROOT / 'intent.json').write_text(json.dumps(intent, indent=2) + '\n')
q = ROOT.parent / 'quick-anvil-context/control-through-70'
proof = json.loads((q / 'qualification.json').read_text())
assert proof['passed'] and proof['through_turn'] == 70
assert all(c['passed'] and len(c['requests']) == 163 for c in proof['controls'])
records = [json.loads(line) for line in (q / 'native-decisions.jsonl').open()]
mapping = {r['source']: Path(r['sealed_directory']) for r in proof['sealed_captures']}
context = json.loads((q / 'observed-context.json').read_text())
genome = decider_genome(q / 'control-0/stderr.log')
base_argv = context['processes'][0]['argv']
tag = 'first-capital-before-the-camp'
assert tag not in genome['treatments']
out = ROOT / 'integrated-prefix-through70'
out.mkdir(exist_ok=False)
report = {'intent': intent, 'original_qualification_sha256': sha((q / 'qualification.json').read_bytes()), 'results': []}
original_payload = replay.control_payload
for label, enabled in [('off-0', False), ('off-1', False), ('on-0', True), ('on-1', True)]:
    argv = [str(frozen)] + base_argv[1:] + (['--with', tag] if enabled else [])
    candidate_context = {'binary_sha256': intent['candidate_sha256'],
                         'provenance': {'sha256': intent['candidate_sha256'], 'scope': intent['scope']},
                         'processes': [{'argv': argv, 'cwd': context['processes'][0]['cwd']}]}
    replay.control_payload = (lambda record: {'orders': record['orders']}) if enabled else original_payload
    result = replay.run_control(candidate_context, records, mapping, out / label, 60, 'hybrid')
    realized = decider_genome(out / label / 'stderr.log')
    expected = sorted(genome['treatments'] + ([tag] if enabled else []))
    profile_ok = bool(realized) and sorted(realized['treatments']) == expected and sorted(realized['forced']) == sorted(genome['forced'] + ([tag] if enabled else []))
    reads_ok = bool(result['requests']) and all(not r['identity_errors'] and r['read_sequence_matches'] for r in result['requests'])
    changed = bool(enabled and result.get('failed_request') and reads_ok and not result['requests'][-1]['native_payload_matches'] and all(r['native_payload_matches'] for r in result['requests'][:-1]) and (result.get('error') or '').startswith('ValueError: original-binary control differs'))
    entry = {'label': label, 'basis': 'orders_only' if enabled else 'full_orders_and_decision',
             'valid_prefix': profile_ok and reads_ok and (result['passed'] or changed),
             'profile_matches': profile_ok, 'first_order_change': changed, 'result': result}
    report['results'].append(entry)
    (out / 'comparisons.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'variant': label, 'valid': entry['valid_prefix'], 'requests': len(result['requests']), 'first_difference': result.get('failed_request'), 'changed': changed}), flush=True)
    assert entry['valid_prefix'] and (enabled or result['passed'])
replay.control_payload = original_payload
# Fresh-board activation queries are separately controlled and labelled.
subprocess.run([sys.executable, str(ROOT / 'query.py'), '--candidate', str(frozen), '--out', str(ROOT / 'integrated-queries')], check=True)
