"""Verify preserved proposals and native read traces; never execute a binary."""
from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]).resolve()
repo=Path(sys.argv[2]).resolve()
sys.path.insert(0,str(repo/'tools'))
import civ6_captured_read_replay as replay
from native_city_route_replay import control_payload
sha=lambda b:hashlib.sha256(b).hexdigest()
proof=json.loads((root/'source/qualification.json').read_text())
raw=(root/'source/native-decisions.jsonl').read_bytes()
assert sha(raw)==proof['native_decisions_sha256']
native=[json.loads(l) for l in raw.splitlines()]
assert proof['passed'] and len(native)==163
report=json.loads((root/'integrated-prefix-through70/comparisons.json').read_text())
repeated={}
for entry in report['results']:
 label=entry['label'];result=entry['result']
 replies=[json.loads(l) for l in (root/'integrated-prefix-through70'/label/'replies.jsonl').open()]
 assert entry['valid_prefix'] and entry['profile_matches']
 assert len(replies)==len(result['requests'])
 for original,reply,metric in zip(native,replies,result['requests']):
  assert not metric['identity_errors'] and metric['read_sequence_matches']
  expected=dict(original['input_capture'],directory=str(root/'source/source-capture-0'))
  actual_path=Path(reply['input_capture']['directory']);parts=actual_path.parts;i=parts.index('integrated-prefix-through70')
  actual=dict(reply['input_capture'],directory=str(root.joinpath(*parts[i:])))
  before,after=replay.expanded_reads(expected),replay.expanded_reads(actual)
  assert before==after
  assert [sha(x) for x in before]==metric['expected_read_sha256']==metric['actual_read_sha256']
  if label.startswith('off'):assert control_payload(original)==control_payload(reply)
  assert replay.frame_key(original)==replay.frame_key(reply)
 if label.startswith('off'):assert result['passed'] and len(replies)==163
 else:
  assert entry['first_order_change'] and result['failed_request']==[12,0] and len(replies)==23
  assert all(a['orders']==b['orders'] for a,b in zip(native,replies[:-1]))
  assert native[22]['orders']!=replies[-1]['orders']
 repeated[label]=[control_payload(x) for x in replies]
assert repeated['off-0']==repeated['off-1']
assert repeated['on-0']==repeated['on-1']
cases=json.loads((root/'integrated-queries/results.json').read_text())['cases']
assert len(cases)==4
for case in cases:
 d=root/'integrated-queries'/f"{case['run']}-{case['turn']}";raw=(d/'captured-events.jsonl').read_bytes()
 assert sha(raw)==case['reads'][0]['sha256'] and len(raw)==case['reads'][0]['bytes']
 record=json.loads((d/'source-record.json').read_text())
 capture=dict(record['input_capture'],directory=str(root/'source/source-capture-0'))
 assert replay.captured_input(capture,case['snapshot'])==raw
 arms={a['label']:a for a in case['controls']}
 for label,arm in arms.items():
  assert arm['exit']==0
  assert json.loads((d/label/'stdout').read_bytes())==arm['payload']
 for left,right in [('before-off','candidate-off'),('candidate-off','candidate-off-repeat'),('candidate-on','candidate-on-repeat')]:
  assert control_payload(arms[left]['payload'])==control_payload(arms[right]['payload'])
 assert case['changed']==(case['turn']==12)
print('verified: 163 OFF requests twice, 23 ON requests twice to first changed order, exact native read traces, and 20 repeated fixed-board queries')
