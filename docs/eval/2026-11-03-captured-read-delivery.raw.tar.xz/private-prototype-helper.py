"""Qualify hybrid delivery; observed read bytes/count remain authoritative."""
from pathlib import Path
import sys,json,datetime,threading,hashlib,shutil,copy
repo=Path('/Users/martbot-mbp-m5-max-128/civvis-main-managed');sys.path.insert(0,str(repo/'tools'))
import civ6_captured_read_replay as replay
root=Path(__file__).parent;q=root/'qualify-100-01';out=root/'qualify-100-hybrid-01';out.mkdir(exist_ok=False)
assert replay.sha((repo/'tools/civ6_captured_read_replay.py').read_bytes())=='f0cb7f2b84173dca2115514b35e12a55acea7cffe303c3d0ba22f41d6c628e7e'
proof=json.loads((q/'qualification.json').read_text());assert proof['through_turn']==100
raw=(q/'native-decisions.jsonl').read_bytes();assert replay.sha(raw)==proof['native_decisions_sha256'];records=[json.loads(line) for line in raw.splitlines()];context=json.loads((q/'observed-context.json').read_text());binary=Path(context['processes'][0]['argv'][0]);assert replay.sha(binary.read_bytes())==context['binary_sha256'];shutil.copy2(binary,root/'frozen-original-orders');assert replay.sha((root/'frozen-original-orders').read_bytes())==context['binary_sha256']
mapping={}
for item in proof['sealed_captures']:
 p=Path(item['sealed_directory']);assert replay.sha((p/'bytes.bin').read_bytes())==item['archive_sha256'] and replay.sha((p/'snapshots.jsonl').read_bytes())==item['index_sha256'];mapping[item['source']]=p
fifo=replay.FifoReads
class IdenticalSnapshot:
 def __init__(self,path,reads,timeout):
  assert reads and reads[0] and all(data==reads[0] for data in reads)
  self.path=Path(path);self.reads=reads;self.error=None;self.served=None;self.phase='static_identical_snapshot_read_count_not_inferred';self.read_number=None;self.bytes_sent=len(reads[0]);self.done=threading.Event();self.path.write_bytes(reads[0]);self.done.set()
 def finish(self):
  # Delivery cannot infer how many opens occurred. run_control STILL compares
  # every captured actual read and its count, identity and the full payload.
  pass
 def close(self):pass
def delivery(path,reads,timeout):
 return IdenticalSnapshot(path,reads,timeout) if reads and all(data==reads[0] for data in reads) else fifo(path,reads,timeout)
replay.FifoReads=delivery
classes=[]
for record in records:
 capture=dict(record['input_capture'],directory=str(mapping[record['input_capture']['directory']]));reads=replay.expanded_reads(capture);classes.append({'request':replay.frame_key(record),'mode':'identical_regular_file' if all(data==reads[0] for data in reads) else 'original_fifo','recorded_read_count':len(reads),'unique_snapshots':len(set(reads))})
intent={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'through_turn':100,'control_repeats':2,'request_timeout_seconds':60,'original_binary_sha256':context['binary_sha256'],'helper_sha256':replay.sha(Path(__file__).read_bytes()),'parent_failed_qualification_sha256':replay.sha((q/'qualification.json').read_bytes()),'policy':'Regular file only when every recorded read byte string is identical within this request; original FIFO for every variable-read request. No change to full-payload, frame identity or exact ordered captured-read comparison. Regular delivery does not infer a served count.','negative_control':'After both full original controls pass, remove one identical expected read from the first request; the actual captured read-count gate must reject it.','requests':classes};(out/'intent.json').write_text(json.dumps(intent,indent=2)+'\n');results=[]
for number in range(2):
 result=replay.run_control(context,records,mapping,out/f'control-{number}',60);results.append(result);report={'passed':len(results)==2 and all(r['passed'] for r in results),'scope':'Original executable, full native payload, exact frame identities and ordered read bytes/count. No treatment or native action.','controls':results};(out/'qualification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'control':number,'passed':result['passed'],'requests':len(result['requests']),'failed_request':result.get('failed_request'),'error':result.get('error')}),flush=True)
 if not result['passed']:raise SystemExit(2)
first=copy.deepcopy(records[0]);assert classes[0]['mode']=='identical_regular_file' and classes[0]['recorded_read_count']>1
for read in first['input_capture']['reads']:
 if read['count']>1:read['count']-=1;break
else:raise AssertionError('first request has no repeated captured read')
negative=replay.run_control(context,[first],mapping,out/'negative-missing-recorded-read',60);(out/'negative-control.json').write_text(json.dumps(negative,indent=2)+'\n');assert not negative['passed'] and negative['requests'] and negative['requests'][0]['read_sequence_matches'] is False and negative['requests'][0]['native_payload_matches'] is True and not negative['requests'][0]['identity_errors'];print('Negative reference read-count control rejected as required',flush=True)
