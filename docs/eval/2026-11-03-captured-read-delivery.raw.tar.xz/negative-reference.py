"""A deliberately wrong reference count must fail the actual hybrid API."""
from pathlib import Path
import sys,json,copy,hashlib,datetime
repo=Path('/Users/martbot-mbp-m5-max-128/civvis-captured-read-delivery-4227');sys.path.insert(0,str(repo/'tools'))
import civ6_captured_read_replay as replay
root=Path(__file__).parent;q=root/'culture-hybrid-01';proof=json.loads((q/'qualification.json').read_text());assert proof['passed'] and len(proof['controls'])==2
raw=(q/'native-decisions.jsonl').read_bytes();assert replay.sha(raw)==proof['native_decisions_sha256'];record=copy.deepcopy(json.loads(raw.splitlines()[0]));context=json.loads((q/'observed-context.json').read_text());mapping={r['source']:Path(r['sealed_directory']) for r in proof['sealed_captures']}
expected=replay.expanded_reads(dict(record['input_capture'],directory=str(mapping[record['input_capture']['directory']])));assert len(expected)==17 and len(set(expected))==1
record['input_capture']['reads'][0]['count']-=1
out=root/'negative-reference-01';result=replay.run_control(context,[record],mapping,out,60,delivery='hybrid');report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Deliberately remove one expected identical read. No treatment, changed byte content or host command.','driver_sha256':replay.sha((repo/'tools/civ6_captured_read_replay.py').read_bytes()),'deliberately_wrong_reference_record':record,'result':result};(root/'negative-reference-01.json').write_text(json.dumps(report,indent=2)+'\n')
assert not result['passed'] and len(result['requests'])==1;r=result['requests'][0];assert r['input_delivery']=='regular' and r['native_payload_matches'] is True and not r['identity_errors'] and r['read_sequence_matches'] is False and r['recorded_reads']==16 and r['replayed_reads']==17;print('Actual native program: full payload/identity preserved; wrong 16-versus-17 read reference rejected',flush=True)
