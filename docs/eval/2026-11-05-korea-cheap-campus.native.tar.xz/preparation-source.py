from pathlib import Path
import json,hashlib,sys,subprocess,shutil,datetime
base=Path(__file__).parent;pilot=base/'current-writing-native-pilot-20261105T114538Z';frozen=pilot/'frozen-launcher-world0';sys.path.insert(0,str(frozen/'tools'));import civ6_captured_read_replay as replay
from civ6_decision_trace import validate_input_capture,captured_input,exact_fact
from civ6_ladder import decider_genome
root=base/'korea-cheap-campus-witness-114538';root.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,d:p.write_text(json.dumps(d,indent=2)+'\n')
try:
 assert read(pilot/'independent-native-record-verification.json')['all_planned_native_arms_verified']
 context=read(pilot/'native-01-pilot/observed-context.json');run=Path(read(pilot/'native-plan.json')['commands']['01-pilot']['run_dir']);binary=Path(context['argv'][0]);digest=sha(binary.read_bytes());assert digest==context['binary_sha256'];assert context['binary_provenance']['revision']=='0ab72aa31ec43b2d127bf86ba67b7b1ee1a28c15'
 protocol={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':context['binary_provenance']['revision'],'binary_sha256':digest,'selection':'Earliest chronological frame0 of this completed qualified pilot with >=2 cities, a walking Settler, a city without a Campus training a Settler, native legal Seowon quote 0<turns<=3, native Settler quote longer than Seowon, an actual early-floor postponement journal, and all actual input reads byte-identical. Retain structural exclusions. No behavioral candidate queries before selecting.','original_controls':'Two fresh-private controls, same original binary and actual frozen genome, scheduled before judging agreement. No changed source or runtime setting.','candidate_plan':'After code tests/native build, same selected input only. All four OFF/ON/OFF/ON roles retained. OFF/ON refers to existing campus-claims-the-free-slot-2; preserve actual other genome fields. Require OFF retains Settler and ON emits selected-city Seowon placement. No replacement input, private-history parity, native execution or strength claim.'};write(root/'protocol.json',protocol)
 why=(run/'why.log').read_text().splitlines();excluded=[];chosen=None
 for line in (run/'decisions.jsonl').open():
  rec=json.loads(line);d=rec.get('decision',{})
  if d.get('frame')!=0:continue
  cap=rec['input_capture'];validate_input_capture(cap);assert cap['complete'];versions={};count=0
  for r in cap['reads']:
   assert 'snapshot_id' in r;b=captured_input(cap,r['snapshot_id']);versions[sha(b)]=b;count+=r['count']
  state=next(e for l in reversed(next(iter(versions.values())).splitlines()) if (e:=json.loads(l)).get('kind')=='state')
  if len(state['cities'])<2 or not any(u['kind']=='UNIT_SETTLER' for u in state['units']):continue
  for city in state['cities']:
   if city.get('producing')!='UNIT_SETTLER' or any(x['type'] in ['DISTRICT_CAMPUS','DISTRICT_SEOWON'] for x in city['districts']):continue
   campus=next((q for q in city['buildable'] if q['t']=='DISTRICT_SEOWON' and q.get('s') and 0<q.get('p',999)<=3),None);settler=next((q for q in city['buildable'] if q['t']=='UNIT_SETTLER'),None)
   if campus is None or settler is None or settler.get('p',0)<=campus['p']:continue
   marker=f'[why] t{d["turn"]} Cities/Detail {city["name"]} postpones its first Campus';notes=[w for w in why if w.startswith(marker) and 'held by early Settler floor' in w]
   if not notes:continue
   if len(versions)!=1:excluded.append({'request':[d['turn'],0],'city':city['name'],'reason':'multiple actual input versions','versions':len(versions)});continue
   chosen=(rec,next(iter(versions.values())),state,city,campus,settler,count,notes);break
  if chosen:break
 assert chosen,'No mechanically qualified original witness; do not select by candidate results'
 rec,data,state,city,campus,settler,count,notes=chosen;unsigned={k:v for k,v in rec.items() if k!='sha256'};assert sha(json.dumps(unsigned,sort_keys=True,separators=(',',':'),allow_nan=False).encode())==rec['sha256'];assert rec['binary_on_disk_sha256']==digest and rec['decision']['victory_portfolio']['assigned_target']=='science'
 write(root/'native-record.json',rec);(root/'events.jsonl').write_bytes(data);write(root/'observed-context.json',context);write(root/'selection-exclusions.json',excluded);sealed=root/'captured-source';sealed.mkdir();mapping,receipts=replay.seal_captures([rec],sealed);write(root/'capture-receipts.json',receipts);write(root/'capture-locations.json',{k:str(p.relative_to(root)) for k,p in mapping.items()})
 finding={'request':[state['turn'],state.get('frame')],'city':city['name'],'city_id':city['id'],'cities':len(state['cities']),'walking_settlers':sum(u['kind']=='UNIT_SETTLER' for u in state['units']),'population':city['pop'],'production':city['production'],'seowon_quote':campus,'settler_quote':settler,'native_actual_reads':count,'input_sha256':sha(data),'record_sha256':rec['sha256'],'native_journal':notes,'source':context['binary_provenance']['revision'],'binary_sha256':digest,'scope':'Actual native opportunity, not an incorrect-rule assertion. Existing floor deliberately holds the Settler. No own win or claim a pause would win.'};write(root/'finding.json',finding);print(finding,flush=True)
 refs=None;controls=[];common=root/'current-capture';genome=context['actual_genome']
 for number in [1,2]:
  directory=root/f'original-control-{number}';directory.mkdir();(directory/'events.jsonl').write_bytes(data);cmd=[str(binary),'--mirror',str(directory),'--turn',str(state['turn']),'--victory','science','--civ','CIVILIZATION_KOREA','--explain','--serve','--fresh-board','--capture-inputs',str(common)]
  for gene in genome['forced']:cmd+=['--with',gene]
  write(directory/'command.json',{'argv':cmd,'cwd':str(frozen)});proc=subprocess.run(cmd,cwd=frozen,input=str(state['turn'])+'\n',text=True,capture_output=True,timeout=180);(directory/'stdout.json').write_text(proc.stdout);(directory/'stderr.log').write_text(proc.stderr);assert proc.returncode==0;payload=json.loads(proc.stdout);actual=decider_genome(directory/'stderr.log');assert exact_fact(actual,genome);actual_reads=replay.expanded_reads(payload['input_capture']);assert actual_reads and all(b==data for b in actual_reads);stable={k:payload[k] for k in ['orders','decision']}
  if refs is None:refs=stable
  else:assert exact_fact(refs,stable)
  orders=[o for o in payload['orders'] if o['kind']=='produce' and o.get('subject')==city['id']];shutil.move(str(common),str(directory/'input-capture'));row={'repeat':number,'actual_reads':len(actual_reads),'genome':actual,'target_city_orders':orders,'retains_settler':not any(o.get('verb')=='DISTRICT_SEOWON' for o in orders)};write(directory/'result.json',row);controls.append(row);print({k:v for k,v in row.items() if k!='genome'},flush=True)
 write(root/'result.json',{'execution_complete':True,'original_cold_controls_retain_settler':all(r['retains_settler'] for r in controls),'controls':controls,'scope':'Both original-source controls retained; no changed candidate has been queried. No original private-history parity, host execution or strength claim.'})
except BaseException as error:write(root/'failure.json',{'error':repr(error),'scope':'Retained preparation/control failure; no replacement witness or silent retry.'});raise
