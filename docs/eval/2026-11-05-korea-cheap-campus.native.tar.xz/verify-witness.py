from pathlib import Path
import json,hashlib,sys,copy
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).parent
sys.path.insert(0,str(root/'verification-tools'))
from civ6_decision_trace import validate_input_capture,captured_input,exact_fact
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
rec=read(root/'native-record.json');unsigned={k:v for k,v in rec.items() if k!='sha256'};assert sha(json.dumps(unsigned,sort_keys=True,separators=(',',':'),allow_nan=False).encode())==rec['sha256'];finding=read(root/'finding.json');data=(root/'events.jsonl').read_bytes();assert sha(data)==finding['input_sha256'];cap=copy.deepcopy(rec['input_capture']);cap['directory']=str(root/read(root/'capture-locations.json')[cap['directory']])
def verify_reads(capture):
 validate_input_capture(capture);assert capture['complete'];count=0
 for r in capture['reads']:
  assert 'snapshot_id' in r;assert captured_input(capture,r['snapshot_id'])==data;count+=r['count']
 assert count;return count
assert verify_reads(cap)==finding['native_actual_reads']==18
state=next(e for l in reversed(data.splitlines()) if (e:=json.loads(l)).get('kind')=='state');seat=next(e for l in data.splitlines() if (e:=json.loads(l)).get('kind')=='seat');assert seat['difficulty']=='DIFFICULTY_DEITY' and seat['civ']=='CIVILIZATION_KOREA';assert [state['turn'],state.get('frame')]==finding['request'];assert len(state['cities'])>=2 and any(u['kind']=='UNIT_SETTLER' for u in state['units']);city=next(c for c in state['cities'] if c['id']==finding['city_id']);assert city['producing']=='UNIT_SETTLER';campus=next(q for q in city['buildable'] if q['t']=='DISTRICT_SEOWON');settler=next(q for q in city['buildable'] if q['t']=='UNIT_SETTLER');assert campus==finding['seowon_quote'] and settler==finding['settler_quote'];assert campus['s'] and 0<campus['p']<=3 and settler['p']>campus['p'];assert not any(d['type'] in ['DISTRICT_CAMPUS','DISTRICT_SEOWON'] for d in city['districts']);assert rec['decision']['victory_portfolio']['assigned_target']=='science'
context=read(root/'observed-context.json');assert rec['binary_on_disk_sha256']==context['binary_sha256']==finding['binary_sha256'];assert context['binary_provenance']['revision']==finding['source'];expected=context['actual_genome'];assert 'campus-claims-the-free-slot-2' in expected['treatments'];controls=[];reference=None
for n in [1,2]:
 folder=root/f'original-control-{n}';payload=read(folder/'stdout.json');result=read(folder/'result.json');raw=next(json.loads(l) for l in (folder/'stderr.log').read_text().splitlines() if l.startswith('{') and json.loads(l).get('kind')=='genome');actual={k:raw.get(k) for k in expected};assert exact_fact(actual,expected) and exact_fact(actual,result['genome']);capture=copy.deepcopy(payload['input_capture']);capture['directory']=str(folder/'input-capture');count=verify_reads(capture);assert count==result['actual_reads'];assert payload['decision']['victory_portfolio']['assigned_target']=='science';stable={k:payload[k] for k in ['orders','decision']}
 if reference is None:reference=stable
 else:assert exact_fact(reference,stable)
 orders=[o for o in payload['orders'] if o['kind']=='produce' and o.get('subject')==city['id']];assert orders==result['target_city_orders']==[];controls.append({'repeat':n,'actual_reads':count,'target_city_produce_orders':orders})
report={'verified':True,'request':finding['request'],'native_actual_reads':18,'original_cold_controls':controls,'scope':'Canonical native witness, all actual captured bytes, native legal quotes and original-binary cold proposal controls only. No changed candidate query, original private-state replay, native placement or strength claim.'};(root/'independent-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
