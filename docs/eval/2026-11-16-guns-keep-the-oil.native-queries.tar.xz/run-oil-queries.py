"""Paired decider queries on captured live Domination boards for `guns-keep-the-oil`.

`guns-keep-the-oil` is the only bit that varies. Each case is a live run's
events.jsonl cut after turn N+1 (the line before the first event of turn N+2),
byte for byte. Both arms run one frozen release `civvis_orders --resumed
--explain` built from the branch, with that run's own genome (every `forced`
tag of its why.log header as `--with`); the on arm adds
`--with guns-keep-the-oil`.

Boards (all Gilgamesh Domination):
- Emperor civvis-20261116T021437Z turns 149-182: two Infantry spent the 14 Oil
  the first Artillery came out to at 158; Isin and Ur queued more at 153-154.
- Emperor civvis-20261116T024741Z turns 150-160: four cities queued Infantry
  on +3 Oil at 151-155 beside three Artillery; the stock was 0 from 157.
- Emperor civvis-20261116T023139Z turns 184-190: no Oil all game (control:
  the gene has nothing to hold, so the arms must agree).
- Immortal civvis-20261115T230117Z turns 135-137: three Line Infantry
  upgraded into Infantry on +3 Oil with two Artillery fielded.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import functools
import os
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'guns-keep-the-oil'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CASES = ([{'run': 'civvis-20261116T021437Z', 'turn': t}
          for t in (149, 150, 151, 152, 153, 154, 155, 156, 157, 158,
                    160, 165, 170, 175, 180, 182)]
         + [{'run': 'civvis-20261116T024741Z', 'turn': t}
            for t in (150, 151, 152, 153, 154, 155, 156, 157, 160)]
         + [{'run': 'civvis-20261116T023139Z', 'turn': t} for t in (184, 189, 190)]
         + [{'run': 'civvis-20261115T230117Z', 'turn': t} for t in (135, 136, 137)])
JOBS = int(sys.argv[4]) if len(sys.argv) > 4 else 1
KEEP = ('guns-keep-the-oil', 'infantry', 'artillery', 'tank', ' oil')


@functools.lru_cache(maxsize=None)
def turn_offsets(run):
    """For each turn T, the byte offset of the first event of a turn after T."""
    offsets = {}
    position = 0
    with (RUNS / run / 'events.jsonl').open('rb') as src:
        for line in src:
            try:
                turn = json.loads(line).get('turn')
            except ValueError:
                turn = None
            if isinstance(turn, int):
                for earlier in range(0, turn):
                    offsets.setdefault(earlier, position)
            position += len(line)
    return offsets, position


def cut(run, turn):
    """The run's events.jsonl through turn N+1, byte for byte."""
    offsets, size = turn_offsets(run)
    end = offsets.get(turn + 1, size)
    with (RUNS / run / 'events.jsonl').open('rb') as src:
        return src.read(end)


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data = cut(case['run'], case['turn'])
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'],
                                 'cut': 'events.jsonl through turn N+1'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        master = root / 'events.cut.jsonl'
        master.write_bytes(data)
        del data
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            os.link(master, mirror / 'events.jsonl')
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', 'domination', '--civ', 'CIVILIZATION_SUMERIA']
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]') and any(k in line for k in KEEP)]
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        master.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['journal_changed'] = off['journal'] != on['journal']
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=1))
    return result


def orders(arm):
    return [(o.get('kind'), o.get('subject'), o.get('verb'))
            for o in arm.get('payload', {}).get('orders', [])]


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=JOBS) as pool:
        done = list(pool.map(lambda pair: one(*pair), enumerate(CASES)))
    results = []
    for i, (c, r) in enumerate(zip(CASES, done)):
        results.append(r)
        if r.get('error'):
            print(c['run'], c['turn'], 'ERROR', r['error'], flush=True)
            continue
        for v in r['reads']:
            off, on = v['arms']
            o, n = orders(off), orders(on)
            print(f"{c['run'][-7:]} t{c['turn']} exit {off['exit']}/{on['exit']} "
                  f"orders {len(o)}/{len(n)} changed={v['orders_changed']}", flush=True)
            for x in o:
                if x not in n:
                    print('   off only', x, flush=True)
            for x in n:
                if x not in o:
                    print('   on only ', x, flush=True)
            for line in on['journal']:
                if GENE in line or 'infantry' in line:
                    print('   on  ', line[:230], flush=True)
            for line in off['journal']:
                if 'infantry' in line:
                    print('   off ', line[:230], flush=True)
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
