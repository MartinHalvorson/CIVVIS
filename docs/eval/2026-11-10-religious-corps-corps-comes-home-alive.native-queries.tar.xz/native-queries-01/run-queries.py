"""Paired decider queries for one religious-corps gene on captured live boards.

Each case is a live Deity Russia Religious-target game at a turn where, at the
turn's first state frame (frame 0), one of our religious units met the gene's
condition: for `corps-comes-home-alive` a unit at 60 hit points or less at
least three tiles from any city of ours; for `last-charge-joins-the-army` an
Apostle or Missionary of ours holding exactly one spread charge on the last
turn it was seen, which is the turn the live game spent that charge; for
`religion-seat-takes-the-debater` an Apostle of ours whose exported promotion
menu held Debater while it had no promotion and had moves, and which went on
to take a different promotion. The board
is the run's events.jsonl cut at that frame, the run's other files linked
beside it. Both arms run one frozen `civvis_orders --resumed` built from the
branch with the run's own requested genome (`summary.json` `forced`, each as
`--with`, less tags the binary does not know); the on arm adds `--with <gene>`.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
REVISION = sys.argv[4]
GENE = sys.argv[5]
RUNS = Path.home() / 'civvis-civ6-runs/control'
CASES = json.loads(Path(sys.argv[6]).read_text())
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402


def known_tags():
    text = subprocess.run(['git', '-C', str(REPO), 'show', f'{REVISION}:src/ai/advanced/genes.rs'],
                          capture_output=True, text=True, check=True).stdout
    return set(re.findall(r'Gene \{ tag: "([^"]+)"', text))


def cut(src, dst, turn):
    with open(src, 'rb') as f, open(dst, 'wb') as g:
        for line in f:
            g.write(line)
            if line.startswith(b'{"available_policies"'):
                try:
                    if json.loads(line).get('turn') == turn:
                        break
                except Exception:
                    pass


def unit_orders(payload, unit):
    return [o for o in payload.get('orders', []) if o.get('subject') == unit]


def one(index, case, known):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        run = RUNS / case['run']
        summary = json.loads((run / 'summary.json').read_text())
        forced = list(summary['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        dropped = [t for t in forced if known and t not in known]
        forced = [t for t in forced if not known or t in known]
        record = {'descriptor': {'run': case['run'], 'turn': case['turn']},
                  'dropped_unknown_tags': dropped, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            for f in run.iterdir():
                if f.name == 'events.jsonl' or f.suffix == '.png' or not f.is_file():
                    continue
                os.symlink(f, mirror / f.name)
            cut(run / 'events.jsonl', mirror / 'events.jsonl', case['turn'])
            data = (mirror / 'events.jsonl').read_bytes()
            record['bytes'] = len(data)
            record['sha256'] = hashlib.sha256(data).hexdigest()
            cmd = [str(BINARY), '--explain', '--resumed', '--mirror', str(mirror),
                   '--victory', 'religious', '--turn', str(case['turn'])]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=2400)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            else:
                row['stderr_tail'] = stderr.read_text()[-1500:]
            record['arms'].append(row)
            for f in mirror.iterdir():
                f.unlink()
            mirror.rmdir()
        off, on = record['arms']
        record['off_unit_orders'] = unit_orders(off.get('payload', {}), case['unit'])
        record['on_unit_orders'] = unit_orders(on.get('payload', {}), case['unit'])
        record['unit_orders_changed'] = record['off_unit_orders'] != record['on_unit_orders']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    known = known_tags()
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(), 'binary_revision': REVISION,
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(lambda pair: one(pair[0], pair[1], known), enumerate(CASES)))
    reads = [v for r in results for v in r['reads']]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'unit_orders_changed': sum(v.get('unit_orders_changed', False) for v in reads),
               'changed_order_reads': sum(v.get('orders_changed', False) for v in reads)}
    for r in results:
        for v in r['reads']:
            brief = lambda orders: [(o.get('verb'), o.get('x'), o.get('y'), o.get('promotion')) for o in orders or []]
            print(r['case']['run'][-8:], r['case']['turn'], r['case']['unit'], r['case'].get('kind', r['case'].get('took', ''))[-12:], r['case'].get('hp', ''),
                  'off', brief(v.get('off_unit_orders')), 'on', brief(v.get('on_unit_orders')))
        if r.get('error'):
            print(r['case']['run'], 'ERROR', r['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
