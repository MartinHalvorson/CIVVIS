"""Paired decider queries on captured live Deity Korea boards.

`disrupt-waits-for-the-match-point` is the only bit that varies. Each case is
a live run's own event log cut at the named turn's first state record (every
line before the turn's first later frame), from a turn on which the live seat
ordered a Spy to Disrupt Rocketry (`unit` `SPY_DISRUPT_ROCKETRY`) while no
rival had yet landed three space projects. Both arms run one frozen
ci-profile `civvis_orders` built from the branch with that run's own
requested genome (`summary.json` `forced`, else the first `why.log` line's
for a continuation run, each as `--with`). The off arm must, like the live
seat, order the Disrupt; the on arm is the gene's proposal on the same input.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'disrupt-waits-for-the-match-point'
CONTROL = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CASES = [
    {'run': 'civvis-20261104T213449Z', 'turn': 149},
    {'run': 'civvis-20261104T222818Z', 'turn': 119},
    {'run': 'civvis-20261104T232613Z', 'turn': 141},
    {'run': 'civvis-20261105T020911Z', 'turn': 147},
    {'run': 'civvis-20261105T031845Z', 'turn': 150},
    {'run': 'civvis-20261105T034948Z', 'turn': 139},
]


def cut(run, turn):
    """The run's events through `turn`: stop at the first later `state`."""
    kept = []
    with (CONTROL / run / 'events.jsonl').open('rb') as source:
        for line in source:
            if b'"kind": "state"' in line or b'"kind":"state"' in line:
                try:
                    event = json.loads(line)
                except ValueError:
                    event = {}
                state = event.get('state') or event
                # A purchase is re-exported at once (frame > 0): the cut keeps
                # the turn's first frame only.
                if (state.get('turn') or 0) > turn or (
                        (state.get('turn') or 0) == turn and (state.get('frame') or 0) != 0):
                    break
            kept.append(line)
    return b''.join(kept)


def spy_ops(payload):
    return [o for o in payload.get('orders', [])
            if o.get('kind') == 'unit' and str(o.get('verb', '')).startswith('SPY_')]


def disrupts(payload):
    return [o for o in spy_ops(payload) if o.get('verb') == 'SPY_DISRUPT_ROCKETRY']


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        summary_path = CONTROL / case['run'] / 'summary.json'
        summary = json.loads(summary_path.read_text()) if summary_path.exists() else {}
        if 'forced' in summary:
            forced = list(summary['forced'])
        else:  # a continuation run: the decider's own first journal line
            with (CONTROL / case['run'] / 'why.log').open() as why:
                forced = list(json.loads(why.readline())['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data = cut(case['run'], case['turn'])
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'],
                                 'cut': 'events.jsonl through the turn'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', 'science',
                   '--turn', str(case['turn'])]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            text = stderr.read_text()
            row['journal'] = [line for line in text.splitlines() if line.startswith('[why]')]
            row['spy_journal'] = [line for line in row['journal'] if 'spy' in line.lower() or 'disrupt' in line.lower()]
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
        off, on = record['arms']
        record['off_spy_ops'] = spy_ops(off.get('payload', {}))
        record['on_spy_ops'] = spy_ops(on.get('payload', {}))
        # Control: like the live seat, the off arm orders Disrupt Rocketry.
        record['off_reproduces_live_disrupt'] = disrupts(off.get('payload', {})) != []
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = (record['off_reproduces_live_disrupt']
                              and all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms']))
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        for v in r['reads']:
            for a in v['arms']:
                print(r['case']['run'], r['case']['turn'], a['arm'], 'exit', a['exit'],
                      [(o['subject'], o['verb']) for o in spy_ops(a.get('payload', {}))])
        if r.get('error'):
            print(r['case']['run'], 'ERROR', r['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
