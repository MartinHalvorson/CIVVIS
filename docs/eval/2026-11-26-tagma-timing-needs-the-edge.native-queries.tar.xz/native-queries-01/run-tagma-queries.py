"""Paired decider queries on live frames of four T8 benchmark games of
2026-11-26 (Deity 6p, Online, Byzantium Religion seats) in which a founded
Religion lane read "Grand strategy: conquest | Tagma timing is live" at
power 34-72 against the strongest rival's 316-377 and never took a city.

`tagma-timing-needs-the-edge` is the only bit that varies. Each case is a
live run's own events.jsonl cut after turn N+1 (every row through the first
rows of the next turn), replayed at turn N. Both arms run one frozen
`civvis_orders --resumed` built from the branch, with that run's own
requested genome (why.log line 1 `forced`, each as `--with`); the on arm adds
`--with tagma-timing-needs-the-edge`.

Cases: turns at which the live game logged "Tagma timing is live".

Read per arm: the grand-strategy line, the orders and the gene's own journal
lines. This records proposal activation on captured live input only. It does
not execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'tagma-timing-needs-the-edge'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

GAMES = [
    ('civvis-t8-20261126T101919Z', 'religious', 'CIVILIZATION_BYZANTIUM', [31, 56, 99, 141]),
    ('civvis-t8-20261126T120405Z', 'religious', 'CIVILIZATION_BYZANTIUM', [43, 74, 100]),
    ('civvis-t8-20261126T140214Z', 'religious', 'CIVILIZATION_BYZANTIUM', [26, 50, 80]),
    ('civvis-t8-20261126T144622Z', 'religious', 'CIVILIZATION_BYZANTIUM', [33, 63, 112]),
]
CASES = [{'run': r, 'victory': v, 'civ': c, 'turn': t} for r, v, c, turns in GAMES for t in turns]


def cut(run, turn):
    """Rows through turn+1 (the replay recipe), and the turn's last state row."""
    rows, last = [], None
    with open(RUNS / run / 'events.jsonl', errors='replace') as f:
        for line in f:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > turn + 1:
                break
            rows.append(line)
            if e.get('kind') == 'state' and e.get('turn') == turn:
                last = e
    return ''.join(rows).encode(), last


def production(row, names):
    """Unit orders by subject."""
    out = {}
    for o in row.get('payload', {}).get('orders', []):
        if o.get('kind') in ('move', 'attack', 'fortify', 'unit'):
            out.setdefault(str(o.get('subject')), []).append(
                f"{o.get('verb')}:{o.get('x')},{o.get('y')}")
    return out


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data, last = cut(case['run'], case['turn'])
        names = {c['id']: c['name'] for c in (last or {}).get('cities', [])}
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'cut': 'after turn+1'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                  'board': {'cities': len((last or {}).get('cities', []))},
                  'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', case['victory'], '--civ', case['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=600)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if GENE + ':' in line]
            row['tagma_lines'] = [line for line in journal if 'Tagma timing is live' in line]
            row['strategy_lines'] = [line for line in journal if 'Grand strategy:' in line]
            row['production'] = production(row, names)
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['production_changed'] = {
            city: {'off': off['production'].get(city), 'on': on['production'].get(city)}
            for city in sorted(set(off['production']) | set(on['production']))
            if off['production'].get(city) != on['production'].get(city)}
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
             'on_gene_lines': 0, 'off_gene_lines': 0, 'on_tagma_lines': 0, 'off_tagma_lines': 0}
    for r in results:
        c = r['case']
        if r.get('error'):
            print(c['run'], c['turn'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            off, on = v['arms']
            for arm, name in ((off, 'off'), (on, 'on')):
                total[f'{name}_gene_lines'] += len(arm.get('journal_gene', []))
                total[f'{name}_tagma_lines'] += len(arm.get('tagma_lines', []))
            print(f"{c['run'][-16:]} t{c['turn']:<3} {'CHANGED' if v.get('orders_changed') else 'same   '} "
                  f"tagma off {len(off.get('tagma_lines', []))} on {len(on.get('tagma_lines', []))} "
                  f"gene lines {len(on.get('journal_gene', []))} units changed {len(v.get('production_changed', {}))}")
            for line in on.get('strategy_lines', [])[:1] + on.get('journal_gene', [])[:2]:
                print('      ', line[:230])
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
