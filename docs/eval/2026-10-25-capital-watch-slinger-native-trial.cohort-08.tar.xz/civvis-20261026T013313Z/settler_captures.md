# Settler captures — civvis-20261026T013313Z

3 capture(s). Mechanism is the first match in the operator's order; every match is listed.

## t31 settler 655362 at (42,11) — `site-in-barbarian-nest`

- detected by: `unit_captured`, captor player 63 (barbarian)
- mechanisms matched: site-in-barbarian-nest
- nearest hostile: UNIT_WARRIOR str 20 hp 39 mv 0 at (41,10) d=2 id 3211301
- guard: UNIT_WARRIOR str 20 hp 67 mv 1 at (42,13) d=2 id 131073 [proximity]
- site: (42,11) — hostile seen within 3 in the last 5 turns: True; camp within 3: False

### Settler t-2..t

| turn | pos | moves | activity | hostiles within 3 | ours within 2 |
|---|---|---|---|---|---|
| t29 | (41,15) | 0 | awake | UNIT_SCOUT str 10 hp 38 mv 0 at (41,12) d=3 id 1769484 | UNIT_WARRIOR str 20 hp 67 mv 0 at (41,15) d=0 id 131073<br>UNIT_ARCHER str 15 hp 100 mv 1 at (40,16) d=2 id 786440 |
| t30 | (42,13) | 1 | awake | none | UNIT_WARRIOR str 20 hp 67 mv 1 at (42,13) d=0 id 131073 |
| t31 | (42,11) | 0 | awake | UNIT_WARRIOR str 20 hp 39 mv 0 at (41,10) d=2 id 3211301<br>UNIT_SCOUT str 10 hp 38 mv 1 at (45,12) d=3 id 1769484 | none |

### Orders (settler and guard)

- `{"guard": 131073, "kind": "escort_cap_synced", "sent": [41, 15], "settler": 655362, "t": 1792978497, "turn": 29, "utc": "2026-10-26T01:34:57.722Z", "want": [41, 15]}`
- `{"checked_on": 30, "kind": "order_verified", "order_kind": "unit", "subject": 655362, "t": 1792978499, "turn": 29, "utc": "2026-10-26T01:34:59.135Z", "verb": "MOVE_TO"}`
- `{"checked_on": 30, "kind": "order_verified", "order_kind": "unit", "subject": 131073, "t": 1792978499, "turn": 29, "utc": "2026-10-26T01:34:59.135Z", "verb": "MOVE_TO"}`
- `{"guard": 131073, "kind": "escort_cap_synced", "sent": [42, 13], "settler": 655362, "t": 1792978499, "turn": 30, "utc": "2026-10-26T01:34:59.135Z", "want": [42, 13]}`
- `{"checked_on": 31, "kind": "order_failed", "order_kind": "unit", "reason": "not_fortified", "subject": 131073, "t": 1792978500, "turn": 30, "utc": "2026-10-26T01:35:00.998Z", "verb": "FORTIFY"}`
- `{"checked_on": 31, "kind": "order_verified", "order_kind": "unit", "subject": 655362, "t": 1792978500, "turn": 30, "utc": "2026-10-26T01:35:00.998Z", "verb": "MOVE_TO"}`
- `{"checked_on": 31, "kind": "order_verified", "order_kind": "unit", "subject": 131073, "t": 1792978500, "turn": 30, "utc": "2026-10-26T01:35:00.998Z", "verb": "MOVE_TO"}`
- `{"candidates": 1, "guard": 131073, "kind": "escort_cap_unresolved", "reason": "guard_has_order", "sent": [42, 11], "settler": 655362, "t": 1792978500, "turn": 31, "utc": "2026-10-26T01:35:00.998Z", "want": [42, 11]}`
- `{"checked_on": 32, "kind": "order_verified", "order_kind": "unit", "subject": 655362, "t": 1792978503, "turn": 31, "utc": "2026-10-26T01:35:03.281Z", "verb": "MOVE_TO"}`
- `{"checked_on": 32, "kind": "order_verified", "order_kind": "unit", "subject": 131073, "t": 1792978503, "turn": 31, "utc": "2026-10-26T01:35:03.281Z", "verb": "MOVE_TO"}`
- `{"checked_on": 32, "kind": "order_verified", "order_kind": "unit", "subject": 131073, "t": 1792978503, "turn": 31, "utc": "2026-10-26T01:35:03.281Z", "verb": "MOVE_TO"}`
- `{"checked_on": 32, "kind": "order_verified", "order_kind": "unit", "subject": 131073, "t": 1792978503, "turn": 31, "utc": "2026-10-26T01:35:03.281Z", "verb": "MOVE_TO"}`

### why.log t-2..t

- t29 Military/Strategy Board: Escort settler (value 280, need 0, no force, deadline 4) · Destroy 1 of slinger (value 35, need 8, force #10 of 1, deadline 1) · Recon sector 4 (value 30, need 0, no force) · Recon sector 5 (value 30, need 0, no force) · Recon sector 13 (value 30, need 0, no force) | rows 8 [1 Destroy, 1 Escort, 6 Recon], 2 force(s), 1 reassigned, short: 1 Escort, 1 Destroy, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t29 Expansion/Detail Settler marching to (37, 12) | 4 tiles away, the site is worth 4.7  [civ6 (43,12) = axial (37,12)]
- t29 Expansion/Detail Settler marching to (30, 20) | 2 tiles away, the site is worth 68.1  [civ6 (40,20) = axial (30,20)]
- t29 Expansion/Detail Settler refuses (37, 13) before walking there | it lies within five tiles of a rival border whose city may be hidden — the forecast cannot price that Loyalty pressure; the site is retired and the next best is asked  [civ6 (43,13) = axial (37,13)]
- t29 Expansion/Detail Settler refuses (38, 13) before walking there | it lies within five tiles of a rival border whose city may be hidden — the forecast cannot price that Loyalty pressure; the site is retired and the next best is asked  [civ6 (44,13) = axial (38,13)]
- t29 Expansion/Detail Settler refuses (38, 14) before walking there | it lies within five tiles of a rival border whose city may be hidden — the forecast cannot price that Loyalty pressure; the site is retired and the next best is asked  [civ6 (45,14) = axial (38,14)]
- t29 Expansion/Detail Stranded Settler sets aside 1 unpriceable site(s) | each lies within five tiles of a rival border whose city may be hidden; the forecast cannot price that Loyalty pressure, and the exhaustion search will not guess at a city it would hand to that rival
- t29 Expansion/Detail Settler takes the safest reachable legal site | no ranked site is reachable; (29, 21) is 1 tiles away and beats a Settler standing still  [civ6 (39,21) = axial (29,21)]
- t29 Expansion/Detail Settler marching to (29, 21) | 1 tiles away, the site is worth 68.1  [civ6 (39,21) = axial (29,21)]
- t30 Military/Strategy Board: Escort settler (value 280, need 0, no force, deadline 5) · Escort builder (value 50, need 0, no force, deadline 2) · Recon sector 4 (value 30, need 0, no force) · Recon sector 5 (value 30, need 0, no force) · Recon sector 13 (value 30, need 0, no force) | rows 8 [2 Escort, 6 Recon], 1 force(s), 0 reassigned, short: 1 Escort, 1 Escort, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t30 Expansion/Detail Settler marching to (37, 12) | 3 tiles away, the site is worth 51.4  [civ6 (43,12) = axial (37,12)]
- t30 Expansion/Detail Settler marching to (37, 12) | 2 tiles away, the site is worth 51.4  [civ6 (43,12) = axial (37,12)]
- t30 Expansion/Detail Settler marching to (37, 12) | 1 tiles away, the site is worth 51.4  [civ6 (43,12) = axial (37,12)]
- t30 Expansion/Detail Settler ends its move short of (37, 12) | 1 tiles away with 1 movement left; the next tile costs 2, so it walks on next turn  [civ6 (43,12) = axial (37,12)]
- t30 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (42,13) = axial (36,13)]
- t30 Cities/Decision Barinas starts granary | 32 production, about 12 turns at 2.7 a turn; the empire holds 4 military for 3 cities against a target of 1.0 each, and 1 settler, 2 builders, 0 traders  [civ6 (39,21) = axial (29,21)]
- t30 Expansion/Detail Settler marching to (37, 12) | 1 tiles away, the site is worth 51.6  [civ6 (43,12) = axial (37,12)]
- t30 Expansion/Detail Settler ends its move short of (37, 12) | 1 tiles away with 1 movement left; the next tile costs 2, so it walks on next turn  [civ6 (43,12) = axial (37,12)]
- t30 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (42,13) = axial (36,13)]
- t30 Expansion/Detail Settler marching to (37, 12) | 1 tiles away, the site is worth 51.6  [civ6 (43,12) = axial (37,12)]
- t30 Expansion/Detail Settler ends its move short of (37, 12) | 1 tiles away with 1 movement left; the next tile costs 2, so it walks on next turn  [civ6 (43,12) = axial (37,12)]
- t30 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (42,13) = axial (36,13)]
- t31 Military/Strategy Board: Escort settler (value 280, need 0, no force, deadline 1) · Recon sector 4 (value 30, need 0, no force) · Recon sector 13 (value 30, need 0, no force) · Recon sector 14 (value 30, need 0, no force) · Recon sector 22 (value 30, need 0, no force) | rows 7 [1 Escort, 6 Recon], 1 force(s), 0 reassigned, short: 1 Escort, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t31 Expansion/Detail Settler refuses (38, 13) before walking there | it lies within five tiles of a rival border whose city may be hidden — the forecast cannot price that Loyalty pressure; the site is retired and the next best is asked  [civ6 (44,13) = axial (38,13)]
- t31 Expansion/Detail Settler refuses (38, 12) before walking there | it lies within five tiles of a rival border whose city may be hidden — the forecast cannot price that Loyalty pressure; the site is retired and the next best is asked  [civ6 (44,12) = axial (38,12)]
- t31 Expansion/Detail Settler refuses (38, 14) before walking there | it lies within five tiles of a rival border whose city may be hidden — the forecast cannot price that Loyalty pressure; the site is retired and the next best is asked  [civ6 (45,14) = axial (38,14)]
- t31 Expansion/Detail Settler falls back to a nearby safe site | 3 higher-priority sites failed the live Loyalty forecast; this ranked local site still passes it  [civ6 (42,11) = axial (37,11)]
- t31 Expansion/Detail The settler's guard stands down | no visible hostile within 8 tiles and this is not a long expedition; the army gets its body back
- t31 Expansion/Detail Settler marching to (37, 11) | 2 tiles away, the site is worth 46.8  [civ6 (42,11) = axial (37,11)]
- t31 Expansion/Detail A guard is called to the settler | sharing the tile blocks capture outright  [civ6 (42,12) = axial (36,12)]
- t31 Expansion/Detail The settler's guard stands down | no visible hostile within 8 tiles and this is not a long expedition; the army gets its body back
- t31 Expansion/Detail Settler marching to (37, 11) | 1 tiles away, the site is worth 46.8  [civ6 (42,11) = axial (37,11)]

## t154 settler 3735570 at (29,12) — `alone-in-fog`

- detected by: `unit_captured`, captor player 1
- mechanisms matched: alone-in-fog
- nearest hostile: none
- guard: ? id 2097154 [escort_cap_synced]

### Settler t-2..t

| turn | pos | moves | activity | hostiles within 3 | ours within 2 |
|---|---|---|---|---|---|
| t152 | (31,10) | 1 | awake | none | none |
| t153 | (30,10) | 2.5 | awake | none | none |
| t154 | (29,12) | 0 | awake | none | none |

### Orders (settler and guard)

- `{"checked_on": 153, "kind": "order_verified", "order_kind": "unit", "subject": 3735570, "t": 1792978930, "turn": 152, "utc": "2026-10-26T01:42:10.941Z", "verb": "MOVE_TO"}`
- `{"checked_on": 154, "kind": "order_verified", "order_kind": "unit", "subject": 3735570, "t": 1792978935, "turn": 153, "utc": "2026-10-26T01:42:15.577Z", "verb": "MOVE_TO"}`
- `{"checked_on": 155, "kind": "order_verified", "order_kind": "unit", "subject": 3735570, "t": 1792978939, "turn": 154, "utc": "2026-10-26T01:42:19.950Z", "verb": "MOVE_TO"}`

### why.log t-2..t

- t152 Military/Strategy Board: Defend Bogotá (value 2083, need 339, force #162 of 5, deadline 16) · Defend Barinas (value 1334, need 177, no force, deadline 2) · Relieve Barinas (value 1334, need 64, no force, deadline 2) · Defend Quito (value 688, need 374, no force, deadline 3) · Relieve Quito (value 688, need 153, no force, deadline 3) | rows 18 [4 Defend, 4 Relieve, 1 Siege, 3 Escort, 6 Recon], 2 force(s), 0 reassigned, short: 4 Defend, 5 Defend, 2 Relieve, 10 Defend, 4 Relieve, 11 Defend, 5 Relieve, 3 Relieve, 1 Escort, 4 Siege, 1 Escort, 1 Escort, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t152 Expansion/Detail Settler marching to (39, 5) | 13 tiles away, the site is worth -47.1  [civ6 (41,5) = axial (39,5)]
- t152 Expansion/Detail Settler marching to (39, 5) | 12 tiles away, the site is worth -47.1  [civ6 (41,5) = axial (39,5)]
- t152 Expansion/Detail Settler marching to (39, 5) | 11 tiles away, the site is worth -47.1  [civ6 (41,5) = axial (39,5)]
- t152 Expansion/Detail Settler marching to (39, 5) | 10 tiles away, the site is worth -47.1  [civ6 (41,5) = axial (39,5)]
- t152 Expansion/Detail Settler is stranded at (33, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (34,3) = axial (33,3)]
- t152 Expansion/Detail Settler retreats from a hostile's reach | 1 raider(s) could take (27, 8) next turn; (26, 10) is out of reach  [civ6 (31,10) = axial (26,10)]
- t152 Expansion/Detail Settler is stranded at (26, 10) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (31,10) = axial (26,10)]
- t152 Expansion/Detail Settler is stranded at (33, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (34,3) = axial (33,3)]
- t152 Expansion/Detail Settler is stranded at (26, 10) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (31,10) = axial (26,10)]
- t153 Military/Strategy Board: Defend Bogotá (value 2083, need 436, force #162 of 5, deadline 1) · Relieve Bogotá (value 2083, need 177, no force, deadline 1) · Defend Barinas (value 1334, need 333, no force, deadline 3) · Relieve Barinas (value 1334, need 213, no force, deadline 3) · Defend Quito (value 688, need 380, no force, deadline 3) | rows 18 [4 Defend, 4 Relieve, 1 Siege, 3 Escort, 6 Recon], 3 force(s), 0 reassigned, short: 5 Defend, 4 Relieve, 8 Defend, 5 Relieve, 9 Defend, 4 Relieve, 13 Defend, 8 Relieve, 2 Escort, 2 Escort, 13 Siege, 1 Escort, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t153 Expansion/Detail Settler marching to (39, 5) | 10 tiles away, the site is worth -26.3  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler marching to (39, 5) | 9 tiles away, the site is worth -26.3  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler marching to (39, 5) | 8 tiles away, the site is worth -26.3  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler marching to (39, 5) | 7 tiles away, the site is worth -26.3  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler HELD short of (39, 5) | 7 tiles away and it did not move — our own heavy_chariot is standing on the next tile  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler is stranded at (33, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (34,3) = axial (33,3)]
- t153 Expansion/Detail Settler explores the frontier | no legal city site was reachable, so it steps toward unseen land at (32, 3) and will re-price sites after the next board reveal  [civ6 (33,3) = axial (32,3)]
- t153 Expansion/Detail Settler is stranded at (32, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (33,3) = axial (32,3)]
- t153 Expansion/Detail Settler explores the frontier | no legal city site was reachable, so it steps toward unseen land at (31, 3) and will re-price sites after the next board reveal  [civ6 (32,3) = axial (31,3)]
- t153 Expansion/Detail Settler is stranded at (31, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (32,3) = axial (31,3)]
- t153 Expansion/Detail Settler retreats from (26, 10) | its tile is threatened (risk 38); stepping to (25, 10) (risk 7) rather than waiting to be taken  [civ6 (30,10) = axial (25,10)]
- t153 Expansion/Detail Settler is stranded at (25, 10) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (30,10) = axial (25,10)]
- t153 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (45,12) = axial (39,12)]
- t153 Expansion/Detail Settler marching to (39, 5) | 7 tiles away, the site is worth -26.3  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler HELD short of (39, 5) | 7 tiles away and it did not move — our own heavy_chariot is standing on the next tile  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler is stranded at (31, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (32,3) = axial (31,3)]
- t153 Expansion/Detail Settler is stranded at (25, 10) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (30,10) = axial (25,10)]
- t153 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (45,12) = axial (39,12)]
- t153 Expansion/Detail Settler marching to (39, 5) | 7 tiles away, the site is worth -26.3  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler HELD short of (39, 5) | 7 tiles away and it did not move — our own heavy_chariot is standing on the next tile  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler is stranded at (31, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (32,3) = axial (31,3)]
- t153 Expansion/Detail Settler is stranded at (25, 10) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (30,10) = axial (25,10)]
- t153 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (45,12) = axial (39,12)]
- t154 Military/Strategy Board: Defend Bogotá (value 2083, need 559, force #162 of 5, deadline 1) · Relieve Bogotá (value 2083, need 255, no force, deadline 1) · Defend Barinas (value 1334, need 429, no force, deadline 3) · Relieve Barinas (value 1334, need 305, no force, deadline 3) · Escort settler (value 280, need 0, no force, deadline 1) | rows 17 [4 Defend, 4 Relieve, 1 Siege, 2 Escort, 6 Recon], 3 force(s), 0 reassigned, short: 8 Defend, 6 Relieve, 10 Defend, 7 Relieve, 2 Escort, 10 Defend, 5 Relieve, 10 Defend, 5 Relieve, 2 Escort, 30 Siege, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t154 Expansion/Detail Settler refuses (38, 6) before walking there | the native nearby-city pressure would leave the city losing 5.0 Loyalty a turn and revolting in about 20 turns; the site is retired and the next best is asked  [civ6 (41,6) = axial (38,6)]
- t154 Expansion/Detail Settler begins an escorted expedition | the route from (39, 12) to (39, 6) is 6 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t154 Expansion/Detail Settler marching to (39, 6) | 6 tiles away, the site is worth 40.8  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail A naval guard joins the settler | the sea layer shares the water leg while the land guard remains responsible for the landing; the hull can route to the embarked Settler and will close the gap on its military turn
- t154 Expansion/Detail A guard joins the settler | it will share the settler's tile; a stacked civilian cannot be captured
- t154 Expansion/Detail Settler falls back toward its guard | its tile is threatened (risk 4) and the guard is 15 tiles away — waiting here is how the last settler was captured  [civ6 (57,7) = axial (54,7)]
- t154 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 14 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (57,7) = axial (54,7)]
- t154 Expansion/Detail Settler marching to (39, 6) | 5 tiles away, the site is worth 40.8  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (40, 10) to (39, 10) without a bound naval guard that can follow the water leg  [civ6 (45,10) = axial (40,10)]
- t154 Expansion/Detail Settler HELD short of (39, 6) | 5 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler retreats from (31, 3) | its tile is threatened (risk 32); stepping to (32, 3) (risk 0) rather than waiting to be taken  [civ6 (33,3) = axial (32,3)]
- t154 Expansion/Detail Settler is stranded at (32, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (33,3) = axial (32,3)]
- t154 Expansion/Detail Settler retreats from a hostile's reach | 2 raider(s) could take (25, 10) next turn; (23, 12) is the least exposed tile it can reach  [civ6 (29,12) = axial (23,12)]
- t154 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (45,10) = axial (40,10)]
- t154 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 8 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (51,7) = axial (48,7)]
- t154 Expansion/Detail Settler marching to (39, 6) | 5 tiles away, the site is worth 40.8  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (40, 10) to (39, 10) without a bound naval guard that can follow the water leg  [civ6 (45,10) = axial (40,10)]
- t154 Expansion/Detail Settler HELD short of (39, 6) | 5 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler is stranded at (32, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (33,3) = axial (32,3)]
- t154 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (45,10) = axial (40,10)]
- t154 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 8 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (51,7) = axial (48,7)]
- t154 Expansion/Detail Settler marching to (39, 6) | 5 tiles away, the site is worth 40.8  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (40, 10) to (39, 10) without a bound naval guard that can follow the water leg  [civ6 (45,10) = axial (40,10)]
- t154 Expansion/Detail Settler HELD short of (39, 6) | 5 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler begins an escorted expedition | the route from (32, 3) to (39, 6) is 10 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t154 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 2 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (35,3) = axial (34,3)]
- t154 Expansion/Detail Settler marching to (39, 6) | 10 tiles away, the site is worth 40.8  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 2 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (35,3) = axial (34,3)]
- t154 Expansion/Detail Settler marching to (39, 6) | 10 tiles away, the site is worth 40.8  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler HELD short of (39, 6) | 10 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (45,10) = axial (40,10)]

## t154 settler 3866640 at (33,3) — `site-in-barbarian-nest`

- detected by: `unit_captured`, captor player 1
- mechanisms matched: site-in-barbarian-nest, alone-in-fog
- nearest hostile: none
- guard: UNIT_PIKEMAN str 45 hp 100 mv 5 at (35,3) d=2 id 4259864 [escort_cap_unresolved]
- site: (41,5) — hostile seen within 3 in the last 5 turns: True; camp within 3: False

### Settler t-2..t

| turn | pos | moves | activity | hostiles within 3 | ours within 2 |
|---|---|---|---|---|---|
| t152 | (34,3) | 3 | hold | none | UNIT_PIKEMAN str 45 hp 100 mv 5 at (35,3) d=1 id 4259864 |
| t153 | (32,3) | 1 | awake | none | none |
| t154 | (33,3) | 2 | awake | none | UNIT_PIKEMAN str 45 hp 100 mv 5 at (35,3) d=2 id 4259864 |

### Orders (settler and guard)

- `{"checked_on": 153, "kind": "order_verified", "order_kind": "unit", "subject": 4259864, "t": 1792978930, "turn": 152, "utc": "2026-10-26T01:42:10.941Z", "verb": "MOVE_TO"}`
- `{"checked_on": 153, "kind": "order_verified", "order_kind": "unit", "subject": 4259864, "t": 1792978930, "turn": 152, "utc": "2026-10-26T01:42:10.942Z", "verb": "MOVE_TO"}`
- `{"checked_on": 154, "kind": "order_verified", "order_kind": "unit", "subject": 3866640, "t": 1792978935, "turn": 153, "utc": "2026-10-26T01:42:15.577Z", "verb": "MOVE_TO"}`
- `{"checked_on": 154, "kind": "order_verified", "order_kind": "unit", "subject": 4259864, "t": 1792978935, "turn": 153, "utc": "2026-10-26T01:42:15.578Z", "verb": "MOVE_TO"}`
- `{"checked_on": 154, "kind": "order_verified", "order_kind": "unit", "subject": 4259864, "t": 1792978935, "turn": 153, "utc": "2026-10-26T01:42:15.578Z", "verb": "MOVE_TO"}`
- `{"checked_on": 155, "kind": "order_failed", "order_kind": "unit", "reason": "unit_gone", "subject": 3866640, "t": 1792978939, "turn": 154, "utc": "2026-10-26T01:42:19.950Z", "verb": "MOVE_TO"}`
- `{"checked_on": 155, "kind": "order_verified", "order_kind": "unit", "subject": 3866640, "t": 1792978939, "turn": 154, "utc": "2026-10-26T01:42:19.950Z", "verb": "MOVE_TO"}`
- `{"checked_on": 155, "kind": "order_verified", "order_kind": "unit", "subject": 4259864, "t": 1792978939, "turn": 154, "utc": "2026-10-26T01:42:19.950Z", "verb": "MOVE_TO"}`

### why.log t-2..t

- t152 Military/Strategy Board: Defend Bogotá (value 2083, need 339, force #162 of 5, deadline 16) · Defend Barinas (value 1334, need 177, no force, deadline 2) · Relieve Barinas (value 1334, need 64, no force, deadline 2) · Defend Quito (value 688, need 374, no force, deadline 3) · Relieve Quito (value 688, need 153, no force, deadline 3) | rows 18 [4 Defend, 4 Relieve, 1 Siege, 3 Escort, 6 Recon], 2 force(s), 0 reassigned, short: 4 Defend, 5 Defend, 2 Relieve, 10 Defend, 4 Relieve, 11 Defend, 5 Relieve, 3 Relieve, 1 Escort, 4 Siege, 1 Escort, 1 Escort, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t152 Expansion/Detail Settler marching to (39, 5) | 13 tiles away, the site is worth -47.1  [civ6 (41,5) = axial (39,5)]
- t152 Expansion/Detail Settler marching to (39, 5) | 12 tiles away, the site is worth -47.1  [civ6 (41,5) = axial (39,5)]
- t152 Expansion/Detail Settler marching to (39, 5) | 11 tiles away, the site is worth -47.1  [civ6 (41,5) = axial (39,5)]
- t152 Expansion/Detail Settler marching to (39, 5) | 10 tiles away, the site is worth -47.1  [civ6 (41,5) = axial (39,5)]
- t152 Expansion/Detail Settler is stranded at (33, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (34,3) = axial (33,3)]
- t152 Expansion/Detail Settler retreats from a hostile's reach | 1 raider(s) could take (27, 8) next turn; (26, 10) is out of reach  [civ6 (31,10) = axial (26,10)]
- t152 Expansion/Detail Settler is stranded at (26, 10) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (31,10) = axial (26,10)]
- t152 Expansion/Detail Settler is stranded at (33, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (34,3) = axial (33,3)]
- t152 Expansion/Detail Settler is stranded at (26, 10) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (31,10) = axial (26,10)]
- t153 Military/Strategy Board: Defend Bogotá (value 2083, need 436, force #162 of 5, deadline 1) · Relieve Bogotá (value 2083, need 177, no force, deadline 1) · Defend Barinas (value 1334, need 333, no force, deadline 3) · Relieve Barinas (value 1334, need 213, no force, deadline 3) · Defend Quito (value 688, need 380, no force, deadline 3) | rows 18 [4 Defend, 4 Relieve, 1 Siege, 3 Escort, 6 Recon], 3 force(s), 0 reassigned, short: 5 Defend, 4 Relieve, 8 Defend, 5 Relieve, 9 Defend, 4 Relieve, 13 Defend, 8 Relieve, 2 Escort, 2 Escort, 13 Siege, 1 Escort, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t153 Expansion/Detail Settler marching to (39, 5) | 10 tiles away, the site is worth -26.3  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler marching to (39, 5) | 9 tiles away, the site is worth -26.3  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler marching to (39, 5) | 8 tiles away, the site is worth -26.3  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler marching to (39, 5) | 7 tiles away, the site is worth -26.3  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler HELD short of (39, 5) | 7 tiles away and it did not move — our own heavy_chariot is standing on the next tile  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler is stranded at (33, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (34,3) = axial (33,3)]
- t153 Expansion/Detail Settler explores the frontier | no legal city site was reachable, so it steps toward unseen land at (32, 3) and will re-price sites after the next board reveal  [civ6 (33,3) = axial (32,3)]
- t153 Expansion/Detail Settler is stranded at (32, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (33,3) = axial (32,3)]
- t153 Expansion/Detail Settler explores the frontier | no legal city site was reachable, so it steps toward unseen land at (31, 3) and will re-price sites after the next board reveal  [civ6 (32,3) = axial (31,3)]
- t153 Expansion/Detail Settler is stranded at (31, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (32,3) = axial (31,3)]
- t153 Expansion/Detail Settler retreats from (26, 10) | its tile is threatened (risk 38); stepping to (25, 10) (risk 7) rather than waiting to be taken  [civ6 (30,10) = axial (25,10)]
- t153 Expansion/Detail Settler is stranded at (25, 10) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (30,10) = axial (25,10)]
- t153 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (45,12) = axial (39,12)]
- t153 Expansion/Detail Settler marching to (39, 5) | 7 tiles away, the site is worth -26.3  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler HELD short of (39, 5) | 7 tiles away and it did not move — our own heavy_chariot is standing on the next tile  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler is stranded at (31, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (32,3) = axial (31,3)]
- t153 Expansion/Detail Settler is stranded at (25, 10) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (30,10) = axial (25,10)]
- t153 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (45,12) = axial (39,12)]
- t153 Expansion/Detail Settler marching to (39, 5) | 7 tiles away, the site is worth -26.3  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler HELD short of (39, 5) | 7 tiles away and it did not move — our own heavy_chariot is standing on the next tile  [civ6 (41,5) = axial (39,5)]
- t153 Expansion/Detail Settler is stranded at (31, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (32,3) = axial (31,3)]
- t153 Expansion/Detail Settler is stranded at (25, 10) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (30,10) = axial (25,10)]
- t153 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (45,12) = axial (39,12)]
- t154 Military/Strategy Board: Defend Bogotá (value 2083, need 559, force #162 of 5, deadline 1) · Relieve Bogotá (value 2083, need 255, no force, deadline 1) · Defend Barinas (value 1334, need 429, no force, deadline 3) · Relieve Barinas (value 1334, need 305, no force, deadline 3) · Escort settler (value 280, need 0, no force, deadline 1) | rows 17 [4 Defend, 4 Relieve, 1 Siege, 2 Escort, 6 Recon], 3 force(s), 0 reassigned, short: 8 Defend, 6 Relieve, 10 Defend, 7 Relieve, 2 Escort, 10 Defend, 5 Relieve, 10 Defend, 5 Relieve, 2 Escort, 30 Siege, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t154 Expansion/Detail Settler refuses (38, 6) before walking there | the native nearby-city pressure would leave the city losing 5.0 Loyalty a turn and revolting in about 20 turns; the site is retired and the next best is asked  [civ6 (41,6) = axial (38,6)]
- t154 Expansion/Detail Settler begins an escorted expedition | the route from (39, 12) to (39, 6) is 6 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t154 Expansion/Detail Settler marching to (39, 6) | 6 tiles away, the site is worth 40.8  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail A naval guard joins the settler | the sea layer shares the water leg while the land guard remains responsible for the landing; the hull can route to the embarked Settler and will close the gap on its military turn
- t154 Expansion/Detail A guard joins the settler | it will share the settler's tile; a stacked civilian cannot be captured
- t154 Expansion/Detail Settler falls back toward its guard | its tile is threatened (risk 4) and the guard is 15 tiles away — waiting here is how the last settler was captured  [civ6 (57,7) = axial (54,7)]
- t154 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 14 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (57,7) = axial (54,7)]
- t154 Expansion/Detail Settler marching to (39, 6) | 5 tiles away, the site is worth 40.8  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (40, 10) to (39, 10) without a bound naval guard that can follow the water leg  [civ6 (45,10) = axial (40,10)]
- t154 Expansion/Detail Settler HELD short of (39, 6) | 5 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler retreats from (31, 3) | its tile is threatened (risk 32); stepping to (32, 3) (risk 0) rather than waiting to be taken  [civ6 (33,3) = axial (32,3)]
- t154 Expansion/Detail Settler is stranded at (32, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (33,3) = axial (32,3)]
- t154 Expansion/Detail Settler retreats from a hostile's reach | 2 raider(s) could take (25, 10) next turn; (23, 12) is the least exposed tile it can reach  [civ6 (29,12) = axial (23,12)]
- t154 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (45,10) = axial (40,10)]
- t154 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 8 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (51,7) = axial (48,7)]
- t154 Expansion/Detail Settler marching to (39, 6) | 5 tiles away, the site is worth 40.8  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (40, 10) to (39, 10) without a bound naval guard that can follow the water leg  [civ6 (45,10) = axial (40,10)]
- t154 Expansion/Detail Settler HELD short of (39, 6) | 5 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler is stranded at (32, 3) | no legal site is reachable and a city cannot be founded here; it holds until the board changes  [civ6 (33,3) = axial (32,3)]
- t154 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (45,10) = axial (40,10)]
- t154 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 8 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (51,7) = axial (48,7)]
- t154 Expansion/Detail Settler marching to (39, 6) | 5 tiles away, the site is worth 40.8  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (40, 10) to (39, 10) without a bound naval guard that can follow the water leg  [civ6 (45,10) = axial (40,10)]
- t154 Expansion/Detail Settler HELD short of (39, 6) | 5 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler begins an escorted expedition | the route from (32, 3) to (39, 6) is 10 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t154 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 2 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (35,3) = axial (34,3)]
- t154 Expansion/Detail Settler marching to (39, 6) | 10 tiles away, the site is worth 40.8  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 2 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (35,3) = axial (34,3)]
- t154 Expansion/Detail Settler marching to (39, 6) | 10 tiles away, the site is worth 40.8  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Settler HELD short of (39, 6) | 10 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (42,6) = axial (39,6)]
- t154 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (45,10) = axial (40,10)]

