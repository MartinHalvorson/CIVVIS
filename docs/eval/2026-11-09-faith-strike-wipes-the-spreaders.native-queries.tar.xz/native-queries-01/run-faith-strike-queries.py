"""Paired decider queries on captured live boards where a heretic strike was open.

`faith-strike-wipes-the-spreaders` is the only bit that varies. Each case is a
turn from a live run's events.jsonl, cut at its first state frame, where, at peace, a rival's visible spreaders
stood within one-turn reach of distinct land soldiers of ours and the host read
`can_declare`. Both arms run one frozen ci-profile `civvis_orders --resumed`
built from the branch with that run's own requested genome (`summary.json`
`forced`, each as `--with`).

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'faith-strike-wipes-the-spreaders'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

RUNS = Path.home() / 'civvis-civ6-runs/control'
CASES = [
    {'run': 'civvis-20261108T224818Z', 'turn': 157, 'rival': 'CIVILIZATION_GAUL'},
    {'run': 'civvis-20261108T230605Z-cont2', 'turn': 119, 'rival': 'CIVILIZATION_SWEDEN'},
    {'run': 'civvis-20261109T015051Z', 'turn': 106, 'rival': 'CIVILIZATION_GRAN_COLOMBIA'},
    {'run': 'civvis-20261109T024657Z', 'turn': 134, 'rival': 'CIVILIZATION_NORWAY'},
    {'run': 'civvis-20261109T032208Z', 'turn': 102, 'rival': 'CIVILIZATION_NUBIA'},
    {'run': 'civvis-20261109T070122Z', 'turn': 81, 'rival': 'CIVILIZATION_SPAIN'},
    {'run': 'civvis-20261109T074546Z', 'turn': 95, 'rival': 'CIVILIZATION_SPAIN'},
    # A turn the gene holds: too few of the spreaders can be reached.
    {'run': 'civvis-20261109T073552Z', 'turn': 55, 'rival': 'CIVILIZATION_FRANCE'},
]


def cut(src, dst, turn):
    """The run's log up to and including the turn's first state frame."""
    with open(src, 'rb') as f, open(dst, 'wb') as g:
        for line in f:
            g.write(line)
            if line.startswith(b'{"available_policies"'):
                try:
                    if json.loads(line).get('turn') == turn:
                        return
                except Exception:
                    pass
    raise ValueError('no state frame for that turn')


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        summary = json.loads((RUNS / case['run'] / 'summary.json').read_text())
        forced = [t for t in summary['forced'] if t != GENE]
        victory = summary.get('victory') or 'religious'
        run = RUNS / case['run']
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'victory': victory}, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            for f in run.iterdir():
                if f.name != 'events.jsonl' and f.suffix != '.png' and f.is_file():
                    (mirror / f.name).symlink_to(f)
            cut(run / 'events.jsonl', mirror / 'events.jsonl', case['turn'])
            data = (mirror / 'events.jsonl').read_bytes()
            record['bytes'] = len(data)
            record['sha256'] = hashlib.sha256(data).hexdigest()
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', victory,
                   '--turn', str(case['turn']), '--resumed']
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=420)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': decider_genome(stderr)}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]') and ('heretic' in line.lower()
                                                               or 'faith-strike' in line
                                                               or 'Striking' in line)]
            record['arms'].append(row)
            for f in mirror.iterdir():
                f.unlink()
            mirror.rmdir()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['planned_actions_changed'] = (off.get('payload', {}).get('decision', {}).get('native_actions')
                                             != on.get('payload', {}).get('decision', {}).get('native_actions'))
        record['journal_changed'] = off['journal'] != on['journal']
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def verbs(arm):
    orders = arm.get('payload', {}).get('orders', [])
    out = {}
    for o in orders:
        key = o.get('verb') or o.get('kind')
        out[key] = out.get(key, 0) + 1
    return orders, out


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        print(r['case']['run'], 't', r['case']['turn'], r['case']['rival'], 'ERROR ' + r['error'] if r.get('error') else '')
        for v in r['reads']:
            for a in v['arms']:
                orders, counts = verbs(a)
                wars = [o for o in orders if 'WAR' in str(o.get('verb') or '') or 'war' in str(o.get('kind') or '')]
                print('  ', a['arm'], 'exit', a['exit'], 'orders', len(orders),
                      'condemn', counts.get('CONDEMN_HERETIC', 0), 'war', wars[:2])
                for line in a['journal'][:4]:
                    print('     ', line[:300])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
