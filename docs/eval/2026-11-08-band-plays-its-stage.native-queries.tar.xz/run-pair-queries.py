"""Paired decider queries on captured live mid-game turns.

One gene is the only bit that varies. Each case is a live run's control
directory cut at the named turn: `events.jsonl` up to and including that
turn's state export (the frame-0 cut `replay.sh` uses), every other file of
the run linked unchanged. Both arms run one frozen ci-profile `civvis_orders`
with that run's own requested genome (`summary.json` `forced`, each as
`--with`, keeping only tags this binary knows); the on arm adds the gene. The
off arm must reproduce the live decision named in the case (`control`); the on
arm is the gene's proposal on the same input.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.

usage: run-pair-queries.py REPO BINARY OUT GENE CASES.json
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO, BINARY, OUT, GENE, CASES = (Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]),
                                   sys.argv[4], json.loads(Path(sys.argv[5]).read_text()))
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CONTROL = Path.home() / 'civvis-civ6-runs/control'


def cut(run, turn):
    """The run's events through `turn`'s first state export, as bytes."""
    out = bytearray()
    with (CONTROL / run / 'events.jsonl').open('rb') as source:
        for line in source:
            out += line
            if line.startswith(b'{"available_policies"'):
                try:
                    if json.loads(line).get('turn') == turn:
                        return bytes(out)
                except ValueError:
                    pass
    raise ValueError(f'{run} has no state export for turn {turn}')


def known_tags():
    """Tags this binary accepts: a probe run rejects unknown ones by name."""
    return None


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        summary = json.loads((CONTROL / case['run'] / 'summary.json').read_text())
        forced = [t for t in summary['forced'] if t not in case.get('drop', [])]
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data = cut(case['run'], case['turn'])
        record = {'descriptor': {'run': case['run'], 'turn': case['turn']},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            for f in (CONTROL / case['run']).iterdir():
                if f.name == 'events.jsonl' or f.suffix == '.png' or not f.is_file():
                    continue
                (mirror / f.name).symlink_to(f)
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--turn', str(case['turn']),
                   '--victory', case['victory'], '--civ', case['civ']] + list(case.get('extra', []))
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=600)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text().strip().splitlines()[-1])
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]')]
            record['arms'].append(row)
            for f in mirror.iterdir():
                f.unlink()
        off, on = record['arms']
        off_orders = off.get('payload', {}).get('orders', [])
        # Control: every live decision the case names appears in the off arm.
        record['off_reproduces_live'] = all(
            any(o.get('subject') == want['subject'] and want['verb'] in str(o.get('verb'))
                for o in off_orders)
            for want in case['control'])
        record['orders_changed'] = off_orders != on.get('payload', {}).get('orders')
        record['journal_changed'] = off['journal'] != on['journal']
        record['complete'] = (record['off_reproduces_live']
                              and all(a['exit'] == 0 and 'payload' in a and a['genome']
                                      for a in record['arms']))
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    summary = {'gene': GENE, 'cases': len(results),
               'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False)
                                          for r in results for v in r['reads'])}
    for r in results:
        for v in r['reads']:
            for a in v['arms']:
                orders = a.get('payload', {}).get('orders', [])
                print(r['case']['run'], r['case']['turn'], a['arm'], 'exit', a['exit'],
                      [(o['verb'], o.get('subject'), o.get('x'), o.get('y')) for o in orders
                       if o['kind'] in r['case'].get('show', ['produce', 'unit'])])
            for line in sorted(set(v['arms'][1]['journal']) - set(v['arms'][0]['journal']))[:8]:
                print('   on+', line[:220])
        if r.get('error'):
            print(r['case']['run'], 'ERROR', r['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
