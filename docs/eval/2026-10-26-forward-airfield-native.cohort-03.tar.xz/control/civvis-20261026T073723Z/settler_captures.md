# Settler captures — civvis-20261026T073723Z

1 capture(s). Mechanism is the first match in the operator's order; every match is listed.

## t113 settler 3801106 at (32,5) — `site-in-barbarian-nest`

- detected by: `unit_captured`, captor player 63 (barbarian)
- mechanisms matched: site-in-barbarian-nest, weak-guard
- nearest hostile: UNIT_SWORDSMAN str 35 hp 30 mv 0 at (31,4) d=2 id 4587545
- guard: UNIT_CROSSBOWMAN str 30 hp 100 mv 0.5 at (34,11) d=6 id 2752520 [escort_cap_unresolved]
- site: (32,5) — hostile seen within 3 in the last 5 turns: True; camp within 3: False

### Settler t-2..t

| turn | pos | moves | activity | hostiles within 3 | ours within 2 |
|---|---|---|---|---|---|
| t111 | (31,9) | 5 | awake | none | UNIT_CROSSBOWMAN str 30 hp 100 mv 5 at (31,9) d=0 id 2752520<br>UNIT_MAN_AT_ARMS str 45 hp 100 mv 2 at (33,8) d=2 id 2228239 |
| t112 | (31,9) | 6 | hold | none | UNIT_CROSSBOWMAN str 30 hp 100 mv 6 at (31,9) d=0 id 2752520<br>UNIT_MAN_AT_ARMS str 45 hp 100 mv 5 at (32,8) d=1 id 2228239<br>UNIT_MAN_AT_ARMS str 45 hp 100 mv 0.5 at (33,9) d=2 id 2424848 |
| t113 | (32,5) | 0 | awake | UNIT_SWORDSMAN str 35 hp 30 mv 0 at (31,4) d=2 id 4587545 | none |

### Orders (settler and guard)

- `{"guard": 2752520, "kind": "escort_cap_synced", "sent": [31, 9], "settler": 3801106, "t": 1793000518, "turn": 111, "utc": "2026-10-26T07:41:58.209Z", "want": [31, 9]}`
- `{"checked_on": 112, "kind": "order_verified", "order_kind": "unit", "subject": 3801106, "t": 1793000521, "turn": 111, "utc": "2026-10-26T07:42:01.059Z", "verb": "MOVE_TO"}`
- `{"checked_on": 112, "kind": "order_verified", "order_kind": "unit", "subject": 2752520, "t": 1793000521, "turn": 111, "utc": "2026-10-26T07:42:01.059Z", "verb": "MOVE_TO"}`
- `{"candidates": 1, "guard": 2752520, "kind": "escort_cap_unresolved", "reason": "guard_has_order", "sent": [32, 5], "settler": 3801106, "t": 1793000524, "turn": 113, "utc": "2026-10-26T07:42:04.083Z", "want": [32, 5]}`
- `{"checked_on": 114, "kind": "order_verified", "order_kind": "unit", "subject": 3801106, "t": 1793000528, "turn": 113, "utc": "2026-10-26T07:42:08.413Z", "verb": "MOVE_TO"}`
- `{"checked_on": 114, "kind": "order_verified", "order_kind": "unit", "subject": 2752520, "t": 1793000528, "turn": 113, "utc": "2026-10-26T07:42:08.413Z", "verb": "MOVE_TO"}`
- `{"checked_on": 114, "kind": "order_verified", "order_kind": "unit", "subject": 2752520, "t": 1793000528, "turn": 113, "utc": "2026-10-26T07:42:08.413Z", "verb": "MOVE_TO"}`

### why.log t-2..t

- t111 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 3 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (40,14) = axial (33,14)]
- t111 Expansion/Detail Settler marching to (31, 5) | 9 tiles away, the site is worth 117.8  [civ6 (33,5) = axial (31,5)]
- t111 Expansion/Detail Settler departs its city before its guard | the guard remains assigned, while the Settler takes the first safe step toward its target now
- t111 Expansion/Detail Settler marching to (31, 5) | 8 tiles away, the site is worth 117.8  [civ6 (33,5) = axial (31,5)]
- t111 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 4 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (40,14) = axial (33,14)]
- t111 Expansion/Detail Settler marching to (31, 5) | 7 tiles away, the site is worth 117.8  [civ6 (33,5) = axial (31,5)]
- t111 Expansion/Detail Settler ends its move short of (31, 5) | 7 tiles away with 0 movement left; the next tile costs 2, so it walks on next turn  [civ6 (33,5) = axial (31,5)]
- t111 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 31 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (56,23) = axial (45,23)]
- t111 Expansion/Detail Settler marching to (22, 10) | 6 tiles away, the site is worth 114.1  [civ6 (27,10) = axial (22,10)]
- t111 Expansion/Detail Settler crosses without its naval escort | 2 turns held on the water and no hostile ship is visible within 6 tiles; every turn afloat is the exposure the escort exists to cut  [civ6 (32,9) = axial (28,9)]
- t111 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 32 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (56,23) = axial (45,23)]
- t111 Expansion/Detail Settler marching to (22, 10) | 5 tiles away, the site is worth 114.1  [civ6 (27,10) = axial (22,10)]
- t111 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (27, 9) to (26, 9) without a bound naval guard that can follow the water leg  [civ6 (31,9) = axial (27,9)]
- t111 Expansion/Detail Settler HELD short of (22, 10) | 5 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (27,10) = axial (22,10)]
- t111 Expansion/Detail Settler detours around a visible threat | the approach to (29, 5) is unsafe, so every Settler leaves it alone for 6 standard turns while the army can clear the blocker; (28, 5) is the best safe alternate  [civ6 (30,5) = axial (28,5)]
- t111 Expansion/Detail Settler begins an escorted expedition | the route from (29, 8) to (28, 5) is 4 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t111 Expansion/Detail Settler falls back toward its guard | its tile is threatened (risk 17) and the guard is 1 tiles away — waiting here is how the last settler was captured  [civ6 (33,9) = axial (29,9)]
- t111 Expansion/Detail Settler marching to (28, 5) | 5 tiles away, the site is worth 69.4  [civ6 (30,5) = axial (28,5)]
- t111 Expansion/Detail Settler marching to (28, 5) | 4 tiles away, the site is worth 69.4  [civ6 (30,5) = axial (28,5)]
- t111 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (28, 9) to (28, 8) without a bound naval guard that can follow the water leg  [civ6 (32,9) = axial (28,9)]
- t111 Expansion/Detail Settler HELD short of (28, 5) | 4 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (30,5) = axial (28,5)]
- t111 Expansion/Detail Settler begins an escorted expedition | the route from (29, 14) to (30, 5) is 9 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t111 Expansion/Detail Settler marching to (30, 5) | 9 tiles away, the site is worth 87.1  [civ6 (32,5) = axial (30,5)]
- t111 Expansion/Detail Settler marching to (30, 5) | 8 tiles away, the site is worth 87.1  [civ6 (32,5) = axial (30,5)]
- t111 Expansion/Decision Builder chooses more useful work | job at (33, 13) adds 2.8 after travel, versus 2.5 here; guard and route safety still apply  [civ6 (39,13) = axial (33,13)]
- t111 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (31,9) = axial (27,9)]
- t111 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (32,9) = axial (28,9)]
- t111 Expansion/Detail Settler marching to (31, 5) | 7 tiles away, the site is worth 117.8  [civ6 (33,5) = axial (31,5)]
- t111 Expansion/Detail Settler ends its move short of (31, 5) | 7 tiles away with 0 movement left; the next tile costs 2, so it walks on next turn  [civ6 (33,5) = axial (31,5)]
- t111 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 32 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (56,23) = axial (45,23)]
- t111 Expansion/Detail Settler marching to (22, 10) | 5 tiles away, the site is worth 114.1  [civ6 (27,10) = axial (22,10)]
- t111 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (27, 9) to (26, 9) without a bound naval guard that can follow the water leg  [civ6 (31,9) = axial (27,9)]
- t111 Expansion/Detail Settler HELD short of (22, 10) | 5 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (27,10) = axial (22,10)]
- t111 Expansion/Detail Settler falls back toward its guard | its tile is threatened (risk 17) and the guard is 1 tiles away — waiting here is how the last settler was captured  [civ6 (33,9) = axial (29,9)]
- t111 Expansion/Detail Settler waits for its guard | 1 turn(s) so far; marching alone is how the last two settlers were captured
- t111 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (31,9) = axial (27,9)]
- t111 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (33,8) = axial (29,8)]
- t111 Expansion/Detail Settler marching to (31, 5) | 7 tiles away, the site is worth 117.8  [civ6 (33,5) = axial (31,5)]
- t111 Expansion/Detail Settler ends its move short of (31, 5) | 7 tiles away with 0 movement left; the next tile costs 2, so it walks on next turn  [civ6 (33,5) = axial (31,5)]
- t111 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 31 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (56,21) = axial (46,21)]
- t111 Expansion/Detail Settler marching to (22, 10) | 5 tiles away, the site is worth 114.1  [civ6 (27,10) = axial (22,10)]
- t111 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (27, 9) to (26, 9) without a bound naval guard that can follow the water leg  [civ6 (31,9) = axial (27,9)]
- t111 Expansion/Detail Settler HELD short of (22, 10) | 5 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (27,10) = axial (22,10)]
- t111 Expansion/Detail Settler marching to (28, 5) | 4 tiles away, the site is worth 69.4  [civ6 (30,5) = axial (28,5)]
- t111 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (29, 8) to (28, 8) without a bound naval guard that can follow the water leg  [civ6 (33,8) = axial (29,8)]
- t111 Expansion/Detail Settler HELD short of (28, 5) | 4 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (30,5) = axial (28,5)]
- t111 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (31,9) = axial (27,9)]
- t111 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (33,8) = axial (29,8)]
- t112 Military/Strategy Board: Escort settler (value 280, need 0, no force, deadline 2) · Deter Guayaquil (value 251, need 0, no force) · Escort builder (value 50, need 0, force #42 of 1) · Recon sector 6 (value 30, need 0, no force) · Recon sector 14 (value 30, need 0, no force) | rows 9 [2 Escort, 1 Deter, 6 Recon], 2 force(s), 0 reassigned, short: 1 Escort, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t112 Military/Decision Task force #42: a land force of 1 will hold for Escort builder | objective (34, 15), anchor (34, 15), 0% ready, 3.00 local strength  [civ6 (41,15) = axial (34,15)]
- t112 Expansion/Detail Settler begins an escorted expedition | the route from (31, 12) to (32, 5) is 7 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t112 Expansion/Detail Settler marching to (32, 5) | 7 tiles away, the site is worth 90.8  [civ6 (34,5) = axial (32,5)]
- t112 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 2 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (37,13) = axial (31,13)]
- t112 Expansion/Detail Settler marching to (32, 5) | 6 tiles away, the site is worth 90.8  [civ6 (34,5) = axial (32,5)]
- t112 Expansion/Detail Settler begins an escorted expedition | the route from (27, 9) to (31, 5) is 4 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t112 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 31 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (56,21) = axial (46,21)]
- t112 Expansion/Detail Settler marching to (31, 5) | 4 tiles away, the site is worth 134.8  [civ6 (33,5) = axial (31,5)]
- t112 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (27, 9) to (28, 8) without a bound naval guard that can follow the water leg  [civ6 (31,9) = axial (27,9)]
- t112 Expansion/Detail Settler HELD short of (31, 5) | 4 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (33,5) = axial (31,5)]
- t112 Expansion/Detail Settler marching to (28, 5) | 4 tiles away, the site is worth 118.2  [civ6 (30,5) = axial (28,5)]
- t112 Expansion/Detail Settler crosses without its naval escort | 2 turns held on the water and no hostile ship is visible within 6 tiles; every turn afloat is the exposure the escort exists to cut  [civ6 (33,8) = axial (29,8)]
- t112 Expansion/Detail Settler marching to (28, 5) | 3 tiles away, the site is worth 118.2  [civ6 (30,5) = axial (28,5)]
- t112 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (28, 8) to (28, 7) without a bound naval guard that can follow the water leg  [civ6 (32,8) = axial (28,8)]
- t112 Expansion/Detail Settler HELD short of (28, 5) | 3 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (30,5) = axial (28,5)]
- t112 Expansion/Detail Settler marching to (30, 5) | 7 tiles away, the site is worth 135.9  [civ6 (32,5) = axial (30,5)]
- t112 Expansion/Detail Settler marching to (30, 5) | 6 tiles away, the site is worth 135.9  [civ6 (32,5) = axial (30,5)]
- t112 Expansion/Detail Settler marching to (30, 5) | 5 tiles away, the site is worth 135.9  [civ6 (32,5) = axial (30,5)]
- t112 Expansion/Detail Settler marching to (30, 5) | 4 tiles away, the site is worth 135.9  [civ6 (32,5) = axial (30,5)]
- t112 Expansion/Detail Settler ends its move short of (30, 5) | 4 tiles away with 0 movement left; the next tile costs 1, so it walks on next turn  [civ6 (32,5) = axial (30,5)]
- t112 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (31,9) = axial (27,9)]
- t112 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (32,8) = axial (28,8)]
- t112 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (33,9) = axial (29,9)]
- t112 Military/Decision Task force #42: a land force of 1 will hold for Escort builder | objective (34, 15), anchor (34, 15), 0% ready, 3.00 local strength  [civ6 (41,15) = axial (34,15)]
- t112 Expansion/Detail Settler marching to (32, 5) | 5 tiles away, the site is worth 90.8  [civ6 (34,5) = axial (32,5)]
- t112 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 29 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (56,18) = axial (47,18)]
- t112 Expansion/Detail Settler marching to (31, 5) | 4 tiles away, the site is worth 117.8  [civ6 (33,5) = axial (31,5)]
- t112 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (27, 9) to (27, 8) without a bound naval guard that can follow the water leg  [civ6 (31,9) = axial (27,9)]
- t112 Expansion/Detail Settler HELD short of (31, 5) | 4 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (33,5) = axial (31,5)]
- t112 Expansion/Detail Settler detours around a visible threat | the approach to (28, 5) is unsafe, so every Settler leaves it alone for 6 standard turns while the army can clear the blocker; (32, 4) is the best safe alternate  [civ6 (34,4) = axial (32,4)]
- t112 Expansion/Detail Settler begins an escorted expedition | the route from (28, 8) to (32, 4) is 4 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t112 Expansion/Detail A guard joins the settler | it will share the settler's tile; a stacked civilian cannot be captured
- t112 Expansion/Detail Settler marching to (32, 4) | 4 tiles away, the site is worth 91.4  [civ6 (34,4) = axial (32,4)]
- t112 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (28, 8) to (29, 7) without a bound naval guard that can follow the water leg  [civ6 (32,8) = axial (28,8)]
- t112 Expansion/Detail Settler HELD short of (32, 4) | 4 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (34,4) = axial (32,4)]
- t112 Expansion/Detail Settler marching to (30, 5) | 4 tiles away, the site is worth 119.0  [civ6 (32,5) = axial (30,5)]
- t112 Expansion/Detail Settler ends its move short of (30, 5) | 4 tiles away with 0 movement left; the next tile costs 1, so it walks on next turn  [civ6 (32,5) = axial (30,5)]
- t112 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (31,9) = axial (27,9)]
- t112 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (32,8) = axial (28,8)]
- t112 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (33,9) = axial (29,9)]
- t112 Military/Decision Task force #42: a land force of 1 will hold for Escort builder | objective (34, 15), anchor (34, 15), 0% ready, 3.00 local strength  [civ6 (41,15) = axial (34,15)]
- t112 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 29 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (56,18) = axial (47,18)]
- t112 Expansion/Detail Settler marching to (31, 5) | 4 tiles away, the site is worth 117.8  [civ6 (33,5) = axial (31,5)]
- t112 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (27, 9) to (27, 8) without a bound naval guard that can follow the water leg  [civ6 (31,9) = axial (27,9)]
- t112 Expansion/Detail Settler HELD short of (31, 5) | 4 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (33,5) = axial (31,5)]
- t112 Expansion/Detail Settler marching to (32, 4) | 4 tiles away, the site is worth 91.4  [civ6 (34,4) = axial (32,4)]
- t112 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (28, 8) to (29, 7) without a bound naval guard that can follow the water leg  [civ6 (32,8) = axial (28,8)]
- t112 Expansion/Detail Settler HELD short of (32, 4) | 4 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (34,4) = axial (32,4)]
- t112 Expansion/Detail Settler marching to (30, 5) | 4 tiles away, the site is worth 119.0  [civ6 (32,5) = axial (30,5)]
- t112 Expansion/Detail Settler ends its move short of (30, 5) | 4 tiles away with 0 movement left; the next tile costs 1, so it walks on next turn  [civ6 (32,5) = axial (30,5)]
- t112 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (31,9) = axial (27,9)]
- t112 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (32,8) = axial (28,8)]
- t112 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (33,9) = axial (29,9)]
- t113 Military/Strategy Board: Escort settler (value 280, need 0, no force, deadline 2) · Escort settler (value 280, need 0, no force, deadline 2) · Escort settler (value 280, need 0, force #43 of 1, deadline 3) · Deter Guayaquil (value 251, need 0, no force) · Escort builder (value 50, need 0, force #42 of 1) | rows 11 [4 Escort, 1 Deter, 6 Recon], 3 force(s), 1 reassigned, short: 1 Escort, 1 Escort, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t113 Military/Decision Task force #42: a land force of 1 will hold for Escort builder | objective (33, 14), anchor (33, 14), 0% ready, 3.00 local strength  [civ6 (40,14) = axial (33,14)]
- t113 Military/Decision Task force #43: a land force of 1 will hold for Escort settler | objective (32, 9), anchor (32, 9), 0% ready, 3.00 local strength  [civ6 (36,9) = axial (32,9)]
- t113 Expansion/Detail A guard is called to the settler | sharing the tile blocks capture outright  [civ6 (36,9) = axial (32,9)]
- t113 Expansion/Detail Settler marching to (32, 5) | 4 tiles away, the site is worth 90.8  [civ6 (34,5) = axial (32,5)]
- t113 Expansion/Detail Settler marching to (32, 5) | 3 tiles away, the site is worth 90.8  [civ6 (34,5) = axial (32,5)]
- t113 Expansion/Detail Settler marching to (32, 5) | 2 tiles away, the site is worth 90.8  [civ6 (34,5) = axial (32,5)]
- t113 Expansion/Detail Settler waits with the guard it just called | the guard spent its move reaching this tile; the pair marches next turn  [civ6 (35,7) = axial (32,7)]
- t113 Expansion/Detail Settler HELD short of (32, 5) | 2 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (34,5) = axial (32,5)]
- t113 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 29 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (56,18) = axial (47,18)]
- t113 Expansion/Detail Settler marching to (31, 5) | 4 tiles away, the site is worth 134.8  [civ6 (33,5) = axial (31,5)]
- t113 Expansion/Detail Settler crosses without its naval escort | 2 turns held on the water and no hostile ship is visible within 6 tiles; every turn afloat is the exposure the escort exists to cut  [civ6 (31,9) = axial (27,9)]
- t113 Expansion/Detail Settler marching to (30, 5) | 3 tiles away, the site is worth 135.9  [civ6 (32,5) = axial (30,5)]
- t113 Expansion/Detail Settler marching to (30, 5) | 2 tiles away, the site is worth 135.9  [civ6 (32,5) = axial (30,5)]
- t113 Expansion/Detail Settler marching to (30, 5) | 1 tiles away, the site is worth 135.9  [civ6 (32,5) = axial (30,5)]
- t113 Expansion/Detail A naval guard joins the settler | the sea layer shares the water leg while the land guard remains responsible for the landing; the hull can route to the embarked Settler and will close the gap on its military turn
- t113 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 29 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (56,18) = axial (47,18)]
- t113 Expansion/Detail Settler marching to (32, 4) | 4 tiles away, the site is worth 91.4  [civ6 (34,4) = axial (32,4)]
- t113 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (28, 8) to (29, 7) without a bound naval guard that can follow the water leg  [civ6 (32,8) = axial (28,8)]
- t113 Expansion/Detail Settler HELD short of (32, 4) | 4 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (34,4) = axial (32,4)]
- t113 Expansion/Detail Settler begins an escorted expedition | the route from (29, 9) to (31, 5) is 4 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t113 Expansion/Detail Settler marching to (31, 5) | 4 tiles away, the site is worth 134.8  [civ6 (33,5) = axial (31,5)]
- t113 Expansion/Detail Settler marching to (31, 5) | 3 tiles away, the site is worth 134.8  [civ6 (33,5) = axial (31,5)]
- t113 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (29, 8) to (29, 7) without a bound naval guard that can follow the water leg  [civ6 (33,8) = axial (29,8)]
- t113 Expansion/Detail Settler HELD short of (31, 5) | 3 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (33,5) = axial (31,5)]
- t113 Expansion/Decision Builder chooses more useful work | job at (32, 15) adds 12.5 after travel, versus 5.6 here; guard and route safety still apply  [civ6 (39,15) = axial (32,15)]
- t113 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (32,8) = axial (28,8)]
- t113 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (33,8) = axial (29,8)]
- t113 Military/Decision Task force #42: a land force of 1 will hold for Escort builder | objective (33, 14), anchor (33, 14), 0% ready, 3.00 local strength  [civ6 (40,14) = axial (33,14)]
- t113 Military/Decision Task force #43: a land force of 1 will hold for Escort settler | objective (32, 9), anchor (32, 9), 0% ready, 3.00 local strength  [civ6 (36,9) = axial (32,9)]
- t113 Expansion/Detail Settler marching to (32, 5) | 2 tiles away, the site is worth 90.8  [civ6 (34,5) = axial (32,5)]
- t113 Expansion/Detail Settler waits with the guard it just called | the guard spent its move reaching this tile; the pair marches next turn  [civ6 (35,7) = axial (32,7)]
- t113 Expansion/Detail Settler HELD short of (32, 5) | 2 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (34,5) = axial (32,5)]
- t113 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 26 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (54,16) = axial (46,16)]
- t113 Expansion/Detail Settler marching to (32, 4) | 4 tiles away, the site is worth 74.5  [civ6 (34,4) = axial (32,4)]
- t113 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (28, 8) to (29, 7) without a bound naval guard that can follow the water leg  [civ6 (32,8) = axial (28,8)]
- t113 Expansion/Detail Settler HELD short of (32, 4) | 4 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (34,4) = axial (32,4)]
- t113 Expansion/Detail Settler marching to (31, 5) | 3 tiles away, the site is worth 117.8  [civ6 (33,5) = axial (31,5)]
- t113 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (29, 8) to (29, 7) without a bound naval guard that can follow the water leg  [civ6 (33,8) = axial (29,8)]
- t113 Expansion/Detail Settler HELD short of (31, 5) | 3 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (33,5) = axial (31,5)]
- t113 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (32,8) = axial (28,8)]
- t113 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (33,8) = axial (29,8)]
- t113 Military/Decision Task force #42: a land force of 1 will hold for Escort builder | objective (33, 14), anchor (33, 14), 0% ready, 3.00 local strength  [civ6 (40,14) = axial (33,14)]
- t113 Military/Decision Task force #43: a land force of 1 will hold for Escort settler | objective (32, 9), anchor (32, 9), 0% ready, 3.00 local strength  [civ6 (36,9) = axial (32,9)]
- t113 Expansion/Detail Settler marching to (32, 5) | 2 tiles away, the site is worth 90.8  [civ6 (34,5) = axial (32,5)]
- t113 Expansion/Detail Settler waits with the guard it just called | the guard spent its move reaching this tile; the pair marches next turn  [civ6 (35,7) = axial (32,7)]
- t113 Expansion/Detail Settler HELD short of (32, 5) | 2 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (34,5) = axial (32,5)]
- t113 Expansion/Detail Settler begins an escorted expedition | the route from (28, 8) to (22, 10) is 6 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t113 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 25 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (53,15) = axial (46,15)]
- t113 Expansion/Detail Settler marching to (22, 10) | 6 tiles away, the site is worth 110.1  [civ6 (27,10) = axial (22,10)]
- t113 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (28, 8) to (27, 8) without a bound naval guard that can follow the water leg  [civ6 (32,8) = axial (28,8)]
- t113 Expansion/Detail Settler HELD short of (22, 10) | 6 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (27,10) = axial (22,10)]
- t113 Expansion/Detail Settler marching to (31, 5) | 3 tiles away, the site is worth 117.8  [civ6 (33,5) = axial (31,5)]
- t113 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (29, 8) to (29, 7) without a bound naval guard that can follow the water leg  [civ6 (33,8) = axial (29,8)]
- t113 Expansion/Detail Settler HELD short of (31, 5) | 3 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (33,5) = axial (31,5)]
- t113 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (32,8) = axial (28,8)]
- t113 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (33,8) = axial (29,8)]

