"""Paired decider queries for `denial-war-needs-the-lane-edge` on captured live boards.

Each case is a live Deity Online Kristina (Sweden) Culture-target game of
2026-11-10 at the turn and frame whose decision record carries one of our
science-denial war's orders: the Formal-War denunciation of the racer (for
five of them a declared friend on the turn its friendship came up for
renewal) or the declaration itself, which why.log names "Declaring war on X
to deny the space race". The board is the run's events.jsonl cut after that
turn's state frame number `frame`, the run's other files linked beside it.
Both arms run one frozen `civvis_orders --resumed` built from the branch with
the run's own requested genome (`summary.json` `forced`, each as `--with`,
less tags the binary does not know); the on arm adds `--with <gene>`.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
REVISION = sys.argv[4]
GENE = sys.argv[5]
RUNS = Path.home() / 'civvis-civ6-runs/control'
CASES = json.loads(Path(sys.argv[6]).read_text())
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

WHY = ('to deny the space race', GENE, 'religion-denial-needs-the-edge', 'No launcher war on')


def known_tags():
    text = subprocess.run(['git', '-C', str(REPO), 'show', f'{REVISION}:src/ai/advanced/genes.rs'],
                          capture_output=True, text=True, check=True).stdout
    return set(re.findall(r'Gene \{ tag: "([^"]+)"', text))


def cut(src, dst, turn, frame):
    seen = 0
    with open(src, 'rb') as f, open(dst, 'wb') as g:
        for line in f:
            g.write(line)
            if line.startswith(b'{"available_policies"'):
                try:
                    if json.loads(line).get('turn') == turn:
                        if seen == frame:
                            break
                        seen += 1
                except Exception:
                    pass


def war_orders(payload):
    return [o for o in payload.get('orders', []) if o.get('kind') in ('war', 'denounce')
            or o.get('verb') == 'DENOUNCE']


def one(index, case, known):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        run = RUNS / case['run']
        summary = json.loads((run / 'summary.json').read_text())
        forced = list(summary['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        dropped = [t for t in forced if known and t not in known]
        forced = [t for t in forced if not known or t in known]
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'frame': case['frame']},
                  'dropped_unknown_tags': dropped, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            for f in run.iterdir():
                if f.name == 'events.jsonl' or f.suffix == '.png' or not f.is_file():
                    continue
                os.symlink(f, mirror / f.name)
            cut(run / 'events.jsonl', mirror / 'events.jsonl', case['turn'], case['frame'])
            data = (mirror / 'events.jsonl').read_bytes()
            record['bytes'] = len(data)
            record['sha256'] = hashlib.sha256(data).hexdigest()
            cmd = [str(BINARY), '--explain', '--resumed', '--mirror', str(mirror),
                   '--victory', 'culture', '--turn', str(case['turn'])]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=2400)
            played = decider_genome(stderr)
            why = [line for line in stderr.read_text(errors='replace').splitlines()
                   if line.startswith('[why]') and any(key in line for key in WHY)]
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played,
                   'gene_in_genome': GENE in (played or {}).get('forced', []), 'why': why}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            else:
                row['stderr_tail'] = stderr.read_text()[-1500:]
            record['arms'].append(row)
            for f in mirror.iterdir():
                f.unlink()
            mirror.rmdir()
        off, on = record['arms']
        record['off_war_orders'] = war_orders(off.get('payload', {}))
        record['on_war_orders'] = war_orders(on.get('payload', {}))
        record['war_orders_changed'] = record['off_war_orders'] != record['on_war_orders']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['on_gene_lines'] = [line for line in on['why'] if GENE in line]
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    known = known_tags()
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(), 'binary_revision': REVISION,
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda pair: one(pair[0], pair[1], known), enumerate(CASES)))
    reads = [v for r in results for v in r['reads']]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'off_war_or_denounce': sum(bool(v.get('off_war_orders')) for v in reads),
               'war_orders_changed': sum(v.get('war_orders_changed', False) for v in reads),
               'on_gene_lines': sum(bool(v.get('on_gene_lines')) for v in reads),
               'changed_order_reads': sum(v.get('orders_changed', False) for v in reads)}
    for r in results:
        for v in r['reads']:
            brief = lambda orders: [(o.get('kind'), o.get('subject'), o.get('verb')) for o in orders or []]
            c = r['case']
            print(c['run'][-14:], c['turn'], c['frame'],
                  'off', brief(v.get('off_war_orders')), 'on', brief(v.get('on_war_orders')))
            for line in v.get('on_gene_lines', [])[:1]:
                print('    ', line)
        if r.get('error'):
            print(r['case']['run'], 'ERROR', r['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
