"""Paired decider queries on recorded hotseat boards: one gene varies.

Usage: run_pairs.py REPO BINARY OUT CASES GENE MODE

CASES: one case per line, `seat_dir victory civ turn expect [last_turn]`.
`seat_dir` is a recorded seat folder (`.../<run>-pN`) whose `events.jsonl`
the live decider read. Both arms run the same frozen `civvis_orders` on the
same bytes; the on arm adds `--with GENE`. Nothing else differs.

MODE `oneshot`: the seat's events cut after turn+1, replayed at `turn` with
`--resumed` (the recipe of
`docs/eval/2026-11-27-stacked-shooter-steps-out.native-queries.tar.xz`).

MODE `serve`: the live decider's own mode (`--serve --fresh-board`). The
events are fed as the game wrote them, a frame at a time, from `turn`'s
first state to the last state of `last_turn` (default `turn`): before each
ask, the log is cut just before the next frame's `state` record of that turn
(or after that turn+1 for its last frame). The recorded reply is the last
frame's; the earlier frames' orders are kept beside it. A memory across
frames or turns (a gene that remembers what an earlier frame sent, or the
order channel's verdicts on the previous turn's orders) is exercised only
this way.

Records proposal activation on captured input only: nothing runs in Civ VI
and nothing here is a strength claim.
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
CASES_FILE = Path(sys.argv[4])
GENE = sys.argv[5]
MODE = sys.argv[6]
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CASES = []
for line in CASES_FILE.read_text().splitlines():
    if line.strip() and not line.startswith('#'):
        fields = line.split()
        seat, victory, civ, turn, expect = fields[:5]
        last = int(fields[5]) if len(fields) > 5 else int(turn)
        CASES.append({'seat': seat, 'victory': victory, 'civ': civ,
                      'turn': int(turn), 'expect': expect, 'last_turn': last})


def lines_of(seat):
    return (Path(seat) / 'events.jsonl').read_bytes().splitlines(keepends=True)


def turn_of(line):
    try:
        event = json.loads(line)
    except ValueError:
        return None, None
    return event.get('turn'), event.get('kind')


def cut_after(lines, turn):
    """Rows through turn+1 (the replay recipe)."""
    rows = []
    for line in lines:
        t, _ = turn_of(line)
        if (t or 0) > turn + 1:
            break
        rows.append(line)
    return rows


def frame_cuts(lines, turn):
    """One cut per frame of `turn`: just before the next `state` of that turn,
    and the last through turn+1."""
    rows = cut_after(lines, turn)
    starts = [i for i, line in enumerate(rows)
              if turn_of(line) == (turn, 'state')]
    if not starts:
        return [rows]
    cuts = [rows[:start] for start in starts[1:]]
    cuts.append(rows)
    return cuts


def unit_orders(payload):
    return [o for o in payload.get('orders', []) if o.get('kind') == 'unit']


def run_arm(case, arm, root, cuts):
    mirror = root / arm
    mirror.mkdir()
    events = mirror / 'events.jsonl'
    stderr = root / (arm + '.stderr')
    if MODE == 'oneshot':
        cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
               '--explain', '--victory', case['victory'], '--civ', case['civ']]
    else:
        cmd = [str(BINARY), '--mirror', str(mirror), '--serve', '--fresh-board', '--explain',
               '--victory', case['victory'], '--civ', case['civ']]
    if arm == 'on':
        cmd += ['--with', GENE]
    started = time.monotonic()
    replies = []
    with stderr.open('wb') as err:
        if MODE == 'oneshot':
            events.write_bytes(b''.join(cuts[-1][1]))
            out = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=err, timeout=900)
            code = out.returncode
            if code == 0:
                replies.append(json.loads(out.stdout))
        else:
            process = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                       stderr=err, text=True, bufsize=1)
            for ask, cut in cuts:
                events.write_bytes(b''.join(cut))
                process.stdin.write(f"{ask}\n")
                process.stdin.flush()
                replies.append(json.loads(process.stdout.readline()))
            process.stdin.close()
            code = process.wait(timeout=900)
    row = {'arm': arm, 'argv': cmd, 'exit': code, 'wall_seconds': time.monotonic() - started,
           'genome': decider_genome(stderr), 'frames_asked': len(cuts)}
    if code == 0 and replies:
        row['payload'] = replies[-1]
        if len(replies) > 1:
            row['earlier_frames_orders'] = [r.get('orders', []) for r in replies[:-1]]
    else:
        row['stderr_tail'] = stderr.read_text(errors='replace')[-2000:]
    journal = [line for line in stderr.read_text(errors='replace').splitlines()
               if line.startswith('[why]')]
    row['journal_gene'] = [line for line in journal if GENE + ':' in line]
    row['unit_orders'] = len(unit_orders(row.get('payload', {})))
    events.unlink()
    stderr.unlink()
    return row


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        lines = lines_of(case['seat'])
        if MODE == 'serve':
            cuts = [(t, cut) for t in range(case['turn'], case['last_turn'] + 1)
                    for cut in frame_cuts(lines, t)]
        else:
            cuts = [(case['turn'], cut_after(lines, case['turn']))]
        data = b''.join(cuts[-1][1])
        record = {'descriptor': {'seat': Path(case['seat']).name, 'turn': case['turn'],
                                 'last_turn': case['last_turn'], 'cut': 'after last_turn+1',
                                 'mode': MODE, 'frames': len(cuts)},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            record['arms'].append(run_arm(case, arm, root, cuts))
        off, on = record['arms']
        record['orders_changed'] = (off.get('payload', {}).get('orders')
                                    != on.get('payload', {}).get('orders'))
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome']
                                 for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'mode': MODE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    (OUT / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    results = [one(i, c) for i, c in enumerate(CASES)]
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        c = r['case']
        if r.get('error'):
            print(Path(c['seat']).name, c['turn'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            off, on = v['arms']
            print(f"{Path(c['seat']).name} t{c['turn']:<3} {c['expect']:<8} "
                  f"{'CHANGED' if v.get('orders_changed') else 'same   '} "
                  f"unit orders off {off.get('unit_orders')} on {on.get('unit_orders')} "
                  f"gene lines on {len(on.get('journal_gene', []))} off {len(off.get('journal_gene', []))} "
                  f"exit {off.get('exit')}/{on.get('exit')}")
            for line in on.get('journal_gene', [])[:3]:
                print('      ', line[:300])
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
