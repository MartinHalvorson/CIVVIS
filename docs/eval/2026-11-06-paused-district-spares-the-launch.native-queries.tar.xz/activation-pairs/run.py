"""Readonly standalone captured-input activation; never sends native orders."""
from pathlib import Path
import json,hashlib,sys,subprocess,datetime
r=Path(__file__).resolve().parent;root=r.parent;p=root.parent.parent
load=lambda f:json.loads(f.read_text());save=lambda f,d:f.write_text(json.dumps(d,indent=2)+'\n');sha=lambda b:hashlib.sha256(b).hexdigest()
sys.path.insert(0,str(p/'replay-tail-analysis-tools-d152cd119e/tools'))
import civ6_captured_read_replay as h
assert load(root.parent/'original-qualification.json')['passed']
assert not (r/'start.json').exists();save(r/'start.json',{'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runner_sha256':sha(Path(__file__).read_bytes()),'native_games':0})
ctx=load(root/'candidate-context.json');binary=Path(ctx['processes'][0]['argv'][0]);assert sha(binary.read_bytes())==ctx['binary_sha256']
records=[json.loads(l) for l in (root.parent/'native-prefix.jsonl').read_text().splitlines()];native=next(d for d in records if [d['decision']['turn'],d['decision']['frame']]==[178,1]);mapping=load(root.parent/'capture-mapping.json');reads=h.expanded_reads(dict(native['input_capture'],directory=mapping[native['input_capture']['directory']]))
unique=[]
for data in reads:
 if data not in unique:unique.append(data)
assert len(unique)==2
base=list(ctx['processes'][0]['argv']);base.remove('--serve');i=base.index('--capture-inputs');del base[i:i+2]
base+=['--turn','178','--resumed'];assert '--serve' not in base
results=[]
try:
 for i,data in enumerate(unique):
  directory=r/f'input-{i}';directory.mkdir();f=directory/'events.jsonl';f.write_bytes(data)
  s=next(json.loads(l) for l in reversed(data.splitlines()) if b'"kind":"state"' in l or b'"kind": "state"' in l)
  assert s['turn']==178
  expected_key=[s['turn'],s['frame']];arms={}
  for arm in ['off-0','off-1','on-0','on-1']:
   folder=r/f'read-{i}'/arm;folder.mkdir(parents=True)
   words=list(base);words[words.index('--mirror')+1]=str(directory)
   if arm.startswith('on'):words+=['--with','paused-district-spares-the-launch']
   assert sha(f.read_bytes())==sha(data)
   q=subprocess.run(words,cwd=root/'runtime',capture_output=True,text=True,timeout=180)
   (folder/'stdout.json').write_text(q.stdout);(folder/'stderr.log').write_text(q.stderr)
   save(folder/'invocation.json',{'argv':words,'cwd':str(root/'runtime'),'exit':q.returncode})
   assert q.returncode==0 and sha(f.read_bytes())==sha(data)
   reply=json.loads(q.stdout);assert [reply['decision']['turn'],reply['decision']['frame']]==expected_key
   genome=next(json.loads(l) for l in q.stderr.splitlines() if l.startswith('{') and json.loads(l).get('kind')=='genome')
   arms[arm]={'arm':arm.split('-')[0],'exit':q.returncode,'argv':words,'cwd':str(root/'runtime'),'genome':genome,'payload':h.control_payload(reply)}
   print('input',i,'request',expected_key,arm,'exit0',flush=True)
  for a,b in [('off-0','off-1'),('on-0','on-1')]:assert arms[a]['genome']==arms[b]['genome'] and h.exact_fact(arms[a]['payload'],arms[b]['payload'])
  results.append({'complete':True,'sha256':sha(data),'bytes':len(data),'request':expected_key,'arms':[arms['off-0'],arms['on-0']]})
 record={'complete':True,'reads':results,'scope':load(r/'protocol.json')['scope']};save(r/'raw-action-pairs.json',record)
 assert any(not h.exact_fact(x['arms'][0]['payload']['orders'],x['arms'][1]['payload']['orders']) for x in results)
 save(r/'complete.json',{'complete':True,'queries':8,'distinct_captured_prefixes':2,'native_games':0,'scope':record['scope']})
 print('Eight standalone activation queries passed; repeated payloads exact.',flush=True)
except BaseException as error:
 save(r/'failure-retained.json',{'error':repr(error),'native_games':0,'no_query_retry_or_replacement':True});raise
