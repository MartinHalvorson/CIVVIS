"""Paired decider queries for `every-shooter-at-the-walls` on captured live boards.

Each case is a live Deity Online Culture game (Kristina of Sweden, then
Pericles of Greece) of 2026-11-10/11 at a turn before t130 whose first state
frame shows a hostile land shooter of a rival at war with us (any unit with a
ranged or bombard attack: Archer to Field Cannon, and the siege guns) within
two tiles of a city of ours. The board is the run's events.jsonl cut at that turn's first
state frame (frame 0), the run's other files linked beside it. Both arms run
one frozen `civvis_orders --resumed` built from the branch with the run's own
requested genome (`summary.json` `forced`, each as `--with`, less tags the
binary does not know, plus `siege-at-the-walls-dies-first` and
`city-strike-takes-the-gun` where the run did not carry them); the on arm adds
`--with <gene>`.

Per arm it records the combat orders (unit RANGE_ATTACK / ATTACK and
city_strike), how many of them and of the city strikes land on a hostile
shooter's tile within two of a city of ours, and how many on a Field
Cannon's.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
REVISION = sys.argv[4]
GENE = sys.argv[5]
RUNS = Path.home() / 'civvis-civ6-runs/control'
CASES = json.loads(Path(sys.argv[6]).read_text())
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

SIEGE = ('CATAPULT', 'BOMBARD', 'TREBUCHET', 'DOMREY', 'ARTILLERY')


def cube(x, y):
    return x - (y - (y & 1)) // 2, y


def dist(a, b):
    aq, ar = cube(*a)
    bq, br = cube(*b)
    return (abs(aq - bq) + abs(ar - br) + abs(aq + ar - bq - br)) // 2


def known_tags():
    text = subprocess.run(['git', '-C', str(REPO), 'show', f'{REVISION}:src/ai/advanced/genes.rs'],
                          capture_output=True, text=True, check=True).stdout
    return set(re.findall(r'Gene \{ tag: "([^"]+)"', text))


def cut(src, dst, turn):
    frame = None
    with open(src, 'rb') as f, open(dst, 'wb') as g:
        for line in f:
            g.write(line)
            if line.startswith(b'{"available_policies"'):
                try:
                    state = json.loads(line)
                except Exception:
                    continue
                if state.get('turn') == turn:
                    frame = state
                    break
    return frame


def wall_threat_tiles(state):
    cities = [((c['x'], c['y']), c.get('damage') or 0, (c.get('max_wall_damage') or 0) - (c.get('wall_damage') or 0))
              for c in state.get('cities') or []]
    tiles = set()
    for rival in state.get('rivals') or []:
        if not rival.get('at_war'):
            continue
        for unit in rival.get('units') or []:
            kind = unit.get('kind') or ''
            pos = (unit.get('x'), unit.get('y'))
            if None in pos or not (unit.get('combat') or 0) > 0:
                continue
            if any(k in kind for k in SIEGE):
                if any(dist(pos, c[0]) <= 3 for c in cities):
                    tiles.add(pos)
            elif not (unit.get('ranged') or 0) > 0:
                if any(dist(pos, c[0]) == 1 and c[2] <= 0 and 200 - c[1] <= 100 for c in cities):
                    tiles.add(pos)
    return tiles


def gun_tiles(state, cannons_only=False):
    out = set()
    cities = [(c['x'], c['y']) for c in state.get('cities') or []]
    for rival in state.get('rivals') or []:
        if not rival.get('at_war'):
            continue
        for unit in rival.get('units') or []:
            pos = (unit.get('x'), unit.get('y'))
            shooter = (unit.get('ranged') or 0) > 0 or any(k in (unit.get('kind') or '') for k in SIEGE)
            if cannons_only:
                shooter = 'FIELD_CANNON' in (unit.get('kind') or '')
            if shooter and None not in pos and any(dist(pos, c) <= 2 for c in cities):
                out.add(pos)
    return out


def combat_orders(payload):
    return [o for o in payload.get('orders', [])
            if o.get('kind') == 'city_strike'
            or (o.get('kind') == 'unit' and o.get('verb') in ('RANGE_ATTACK', 'ATTACK'))]


def siege_members(stderr_text):
    found = re.findall(r'a land force of (\d+) will (?:advance|muster|engage|hold) for Siege', stderr_text)
    return max((int(n) for n in found), default=0)


def one(index, case, known):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        run = RUNS / case['run']
        try:
            forced = list(json.loads((run / 'summary.json').read_text())['forced'])
        except (OSError, KeyError, ValueError):
            forced = list(json.loads((run / 'why.log').open().readline())['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        # Both arms play the two genes this one builds on, armed live since
        # 2026-11-10 20:35Z and 23:37Z; only the named gene differs.
        for base in ('siege-at-the-walls-dies-first', 'city-strike-takes-the-gun'):
            if base not in forced:
                forced.append(base)
        dropped = [t for t in forced if known and t not in known]
        forced = [t for t in forced if not known or t in known]
        record = {'descriptor': {'run': case['run'], 'turn': case['turn']},
                  'dropped_unknown_tags': dropped, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            for f in run.iterdir():
                if f.name == 'events.jsonl' or f.suffix == '.png' or not f.is_file():
                    continue
                os.symlink(f, mirror / f.name)
            frame = cut(run / 'events.jsonl', mirror / 'events.jsonl', case['turn'])
            threats = wall_threat_tiles(frame or {})
            record['wall_threat_tiles'] = sorted(threats)
            guns = gun_tiles(frame or {})
            cannons = gun_tiles(frame or {}, cannons_only=True)
            record['gun_tiles'] = sorted(guns)
            record['cannon_tiles'] = sorted(cannons)
            data = (mirror / 'events.jsonl').read_bytes()
            record['bytes'] = len(data)
            record['sha256'] = hashlib.sha256(data).hexdigest()
            cmd = [str(BINARY), '--explain', '--resumed', '--mirror', str(mirror),
                   '--victory', 'culture', '--turn', str(case['turn'])]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=2400)
            played = decider_genome(stderr)
            text = stderr.read_text(errors='replace')
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played,
                   'siege_force': siege_members(text),
                   'journal': [l for l in text.splitlines()
                               if 'Wall threats:' in l or 'Siege rows stand down' in l][:4]}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
                blows = combat_orders(row['payload'])
                row['combat_orders'] = blows
                row['blows_on_wall_threats'] = sum(1 for o in blows if (o.get('x'), o.get('y')) in threats)
                strikes = [o for o in blows if o.get('kind') == 'city_strike']
                row['city_strikes'] = len(strikes)
                row['city_strikes_on_guns'] = sum(1 for o in strikes if (o.get('x'), o.get('y')) in guns)
                row['blows_on_shooters'] = sum(1 for o in blows if (o.get('x'), o.get('y')) in guns)
                row['blows_on_cannons'] = sum(1 for o in blows if (o.get('x'), o.get('y')) in cannons)
            else:
                row['stderr_tail'] = text[-1500:]
            record['arms'].append(row)
            stdout.unlink()
            stderr.unlink()
            for f in mirror.iterdir():
                f.unlink()
            mirror.rmdir()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['combat_changed'] = off.get('combat_orders') != on.get('combat_orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    known = known_tags()
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(), 'binary_revision': REVISION,
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(lambda pair: one(pair[0], pair[1], known), enumerate(CASES)))
    reads = [v for r in results for v in r['reads']]
    def arm(v, i, key):
        return (v.get('arms') or [{}, {}])[i].get(key, 0) if len(v.get('arms') or []) == 2 else 0
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for v in reads),
               'changed_combat_reads': sum(v.get('combat_changed', False) for v in reads),
               'blows_on_wall_threats_off': sum(arm(v, 0, 'blows_on_wall_threats') for v in reads),
               'blows_on_wall_threats_on': sum(arm(v, 1, 'blows_on_wall_threats') for v in reads),
               'combat_orders_off': sum(len(arm(v, 0, 'combat_orders') or []) for v in reads),
               'combat_orders_on': sum(len(arm(v, 1, 'combat_orders') or []) for v in reads),
               'blows_on_shooters_off': sum(arm(v, 0, 'blows_on_shooters') for v in reads),
               'blows_on_shooters_on': sum(arm(v, 1, 'blows_on_shooters') for v in reads),
               'blows_on_cannons_off': sum(arm(v, 0, 'blows_on_cannons') for v in reads),
               'blows_on_cannons_on': sum(arm(v, 1, 'blows_on_cannons') for v in reads),
               'city_strikes_off': sum(arm(v, 0, 'city_strikes') for v in reads),
               'city_strikes_on': sum(arm(v, 1, 'city_strikes') for v in reads),
               'city_strikes_on_guns_off': sum(arm(v, 0, 'city_strikes_on_guns') for v in reads),
               'city_strikes_on_guns_on': sum(arm(v, 1, 'city_strikes_on_guns') for v in reads),
               'cases_more_gun_strikes': sum(arm(v, 1, 'city_strikes_on_guns') > arm(v, 0, 'city_strikes_on_guns') for v in reads),
               'cases_fewer_gun_strikes': sum(arm(v, 1, 'city_strikes_on_guns') < arm(v, 0, 'city_strikes_on_guns') for v in reads),
               'siege_force_units_off': sum(arm(v, 0, 'siege_force') for v in reads),
               'siege_force_units_on': sum(arm(v, 1, 'siege_force') for v in reads),
               'cases_more_blows_on_threats': sum(arm(v, 1, 'blows_on_wall_threats') > arm(v, 0, 'blows_on_wall_threats') for v in reads),
               'cases_fewer_blows_on_threats': sum(arm(v, 1, 'blows_on_wall_threats') < arm(v, 0, 'blows_on_wall_threats') for v in reads)}
    for r in results:
        for v in r['reads']:
            print(r['case']['run'][-7:], r['case']['turn'], 'blows on shooters off/on',
                  arm(v, 0, 'blows_on_shooters'), arm(v, 1, 'blows_on_shooters'),
                  'strikes off/on', arm(v, 0, 'city_strikes'), arm(v, 1, 'city_strikes'),
                  'changed' if v.get('orders_changed') else '')
        if r.get('error'):
            print(r['case']['run'], 'ERROR', r['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
