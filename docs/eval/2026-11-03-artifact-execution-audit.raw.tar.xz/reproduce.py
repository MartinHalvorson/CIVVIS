from pathlib import Path
import json,subprocess,sys,tempfile
root=Path(__file__).parent
with tempfile.TemporaryDirectory() as temp:
 for expected in sorted((root/'reports').glob('*.json')):
  saved=json.loads(expected.read_text());output=Path(temp)/expected.name
  subprocess.run([sys.executable,str(root/'source/tools/civ6_artifact_activation_audit.py'),'--run-dir',str(root/'cases'/saved['run']),'--out',str(output)],check=True,capture_output=True)
  assert json.loads(output.read_text())==saved,expected.name
print('Three complete native audits reproduced exactly, including source hashes.')
