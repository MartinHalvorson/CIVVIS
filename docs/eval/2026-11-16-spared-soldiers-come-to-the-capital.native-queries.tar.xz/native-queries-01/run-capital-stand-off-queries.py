"""Paired decider queries on live frames of the wars that took our original
capital, from the declaration to the turn before the loss.

`spared-soldiers-come-to-the-capital` is the only bit that varies. Each case
is a live run's own events.jsonl cut after turn N+1 (every row through the
first rows of the next turn), replayed at turn N. Both arms run one frozen
release `civvis_orders --resumed` built from the branch, with that run's own
requested genome (why.log line 1 `forced`, each as `--with`); the on arm adds
`--with spared-soldiers-come-to-the-capital`.

Read per arm: the Anvil's one-blow rewrites at the original capital (`takes`
a tile two or less out, or four or more out) and the gene's `comes in to`
lines, and for every land soldier of ours standing more than two tiles from
the capital in the turn's last state row, what the arm ordered it: a move
ending within two of the capital, a move elsewhere, or a hold.

Cases: the wars that took Rome in civvis-20261115T222126Z (Nubia, t110-t117)
and civvis-20261116T033254Z (Phoenicia, t133-t144), Athens in
civvis-20261115T095713Z (Portugal), civvis-20261115T125708Z (Kongo) and
civvis-20261116T032213Z (Kongo), Uruk in civvis-20261116T032722Z (Kongo) and
civvis-20261115T204822Z (Babylon), and St. Petersburg in
civvis-20261115T142213Z (Byzantium). Turns whose Anvil stands at another city
(Puteoli in 222126Z) are the controls the gene must leave alone.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import re
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'spared-soldiers-come-to-the-capital'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

GAMES = [
    ('civvis-20261115T222126Z', 'score', 'CIVILIZATION_ROME', range(110, 117)),
    ('civvis-20261116T033254Z', 'score', 'CIVILIZATION_ROME', range(133, 144)),
    ('civvis-20261115T095713Z', 'culture', 'CIVILIZATION_GREECE', range(113, 124)),
    ('civvis-20261115T125708Z', 'culture', 'CIVILIZATION_GREECE', range(89, 96)),
    ('civvis-20261116T032213Z', 'culture', 'CIVILIZATION_GREECE', range(87, 91)),
    ('civvis-20261116T032722Z', 'domination', 'CIVILIZATION_SUMERIA', range(87, 91)),
    ('civvis-20261115T204822Z', 'domination', 'CIVILIZATION_SUMERIA', range(60, 73)),
    ('civvis-20261115T142213Z', 'culture', 'CIVILIZATION_RUSSIA', range(197, 205)),
]
CASES = [{'run': r, 'victory': v, 'civ': c, 'turn': t} for r, v, c, turns in GAMES for t in turns]
TAKES = re.compile(r'Anvil at (.+?): the (\S+) posted at \((-?\d+), (-?\d+)\) takes \((-?\d+), (-?\d+)\)')
COMES = re.compile(r'Anvil at (.+?): the (\S+) (\d+) tiles out comes in to \((-?\d+), (-?\d+)\)')
NONMIL = ('SETTLER', 'BUILDER', 'TRADER', 'MISSIONARY', 'APOSTLE', 'PROPHET', 'INQUISITOR', 'GURU',
          'GREAT_', 'SPY', 'ARCHAEOLOGIST', 'NATURALIST', 'ROCK_BAND', 'MEDIC', 'MILITARY_ENGINEER')


def ax(x, y):
    return x - (y - (y & 1)) // 2, y


def axd(a, b):
    dq, dr = a[0] - b[0], a[1] - b[1]
    return (abs(dq) + abs(dr) + abs(dq + dr)) // 2


def cut(run, turn):
    """Rows through turn+1 (the replay recipe), and the turn's last state row."""
    rows, last = [], None
    with open(RUNS / run / 'events.jsonl', errors='replace') as f:
        for line in f:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > turn + 1:
                break
            rows.append(line)
            if e.get('kind') == 'state' and e.get('turn') == turn:
                last = e
    return ''.join(rows).encode(), last


def read_arm(row, last, capital):
    cpos = ax(capital['x'], capital['y'])
    out = {'takes_near': 0, 'takes_far': 0, 'comes_in': 0}
    for line in row['journal_anvil']:
        m = TAKES.search(line)
        if m and m.group(1) == capital['name']:
            d = axd((int(m.group(5)), int(m.group(6))), cpos)
            if d <= 2:
                out['takes_near'] += 1
            elif d >= 4:
                out['takes_far'] += 1
        c = COMES.search(line)
        if c and c.group(1) == capital['name']:
            out['comes_in'] += 1
    far = {}
    for u in last['units']:
        k, cls = u.get('kind') or '', u.get('class') or ''
        if not cls or 'NAVAL' in cls or 'AIR' in cls or any(n in k for n in NONMIL):
            continue
        d = axd(ax(u['x'], u['y']), cpos)
        if d > 2:
            far[u['id']] = d
    moves, holds = {}, set()
    for o in row.get('payload', {}).get('orders', []):
        if o.get('kind') != 'unit' or o.get('subject') not in far:
            continue
        if o.get('verb') == 'MOVE_TO' and o.get('x') is not None:
            moves[o['subject']] = (o['x'], o['y'])
        elif o.get('verb') in ('FORTIFY', 'SKIP', 'SLEEP', 'ALERT', 'HEAL'):
            holds.add(o['subject'])
    home = sorted(u for u, p in moves.items() if axd(ax(*p), cpos) <= 2)
    out.update(far_soldiers=len(far), moved_home=len(home),
               moved_elsewhere=len(moves) - len(home),
               held=len([u for u in holds if u not in moves]))
    return out


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data, last = cut(case['run'], case['turn'])
        capital = next(c for c in last['cities']
                       if c.get('original_capital') and c.get('original_owner') in (0, None))
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'cut': 'after turn+1'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                  'capital': {k: capital.get(k) for k in ('name', 'x', 'y', 'damage', 'wall_damage')},
                  'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', case['victory'], '--civ', case['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=600)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_anvil'] = [line for line in journal if 'Anvil at' in line
                                    or 'is under threat' in line]
            row['read'] = read_arm(row, last, capital)
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for arm in ('off', 'on'):
        for key in ('takes_near', 'takes_far', 'comes_in', 'far_soldiers', 'moved_home', 'moved_elsewhere', 'held'):
            total[f'{arm}_{key}'] = sum(a['read'][key] for r in results for v in r['reads']
                                        for a in v['arms'] if a['arm'] == arm)
    for r in results:
        c = r['case']
        if r.get('error'):
            print(c['run'], c['turn'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            off, on = (a['read'] for a in v['arms'])
            print(f"{c['run'][-16:]} t{c['turn']:<3} {v['capital']['name'][:12]:12} "
                  f"{'CHANGED' if v['orders_changed'] else 'same   '} | off takes>=4 {off['takes_far']} home {off['moved_home']} "
                  f"held {off['held']} | on comes-in {on['comes_in']} takes>=4 {on['takes_far']} home {on['moved_home']} "
                  f"held {on['held']} | far soldiers {off['far_soldiers']}")
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
