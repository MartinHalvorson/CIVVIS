#!/usr/bin/env python3
"""queries_toward.py QUERIES_DIR: per case and arm, our land soldiers standing more than two tiles from the
original capital (the turn's last state row) by what the arm ordered: a move ending nearer the capital, a
move ending no nearer, or a hold (fortify/skip with no move). Totals per arm, and per game."""
import glob, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from importlib import import_module
q = import_module('run-capital-stand-off-queries'.replace('-', '_')) if False else None
NONMIL = ('SETTLER', 'BUILDER', 'TRADER', 'MISSIONARY', 'APOSTLE', 'PROPHET', 'INQUISITOR', 'GURU',
          'GREAT_', 'SPY', 'ARCHAEOLOGIST', 'NATURALIST', 'ROCK_BAND', 'MEDIC', 'MILITARY_ENGINEER')
RUNS = os.path.expanduser('~/civvis-civ6-runs/control')
def ax(x, y): return x - (y - (y & 1)) // 2, y
def axd(a, b):
    dq, dr = a[0] - b[0], a[1] - b[1]
    return (abs(dq) + abs(dr) + abs(dq + dr)) // 2
cache = {}
def last_state(run, turn):
    if run not in cache:
        frames = {}
        for line in open(os.path.join(RUNS, run, 'events.jsonl'), errors='replace'):
            if '"kind": "state"' not in line: continue
            e = json.loads(line)
            if e.get('kind') == 'state': frames[e['turn']] = e
        cache[run] = frames
    return cache[run][turn]
tot = {'off': [0, 0, 0], 'on': [0, 0, 0]}
per = {}
for p in sorted(glob.glob(os.path.join(sys.argv[1], '*', 'result.json'))):
    r = json.load(open(p)); c = r['case']; v = r['reads'][0]
    st = last_state(c['run'], c['turn'])
    cap = v['capital']; cpos = ax(cap['x'], cap['y'])
    far = {}
    for u in st['units']:
        k, cls = u.get('kind') or '', u.get('class') or ''
        if not cls or 'NAVAL' in cls or 'AIR' in cls or any(n in k for n in NONMIL): continue
        d = axd(ax(u['x'], u['y']), cpos)
        if d > 2: far[u['id']] = d
    row = {}
    for a in v['arms']:
        moves, holds = {}, set()
        for o in a['payload']['orders']:
            if o.get('kind') != 'unit' or o.get('subject') not in far: continue
            if o.get('verb') == 'MOVE_TO' and o.get('x') is not None: moves[o['subject']] = (o['x'], o['y'])
            elif o.get('verb') in ('FORTIFY', 'SKIP', 'SLEEP', 'ALERT', 'HEAL'): holds.add(o['subject'])
        toward = sum(1 for u, pos in moves.items() if axd(ax(*pos), cpos) < far[u])
        other = len(moves) - toward
        held = len([u for u in holds if u not in moves])
        row[a['arm']] = (toward, other, held)
        for i, x in enumerate((toward, other, held)): tot[a['arm']][i] += x
        g = per.setdefault(c['run'], {'off': [0, 0, 0], 'on': [0, 0, 0], 'cases': 0})
        for i, x in enumerate((toward, other, held)): g[a['arm']][i] += x
    per[c['run']]['cases'] += 1
    if row['off'] != row['on']:
        print(f"{c['run'][-16:]} t{c['turn']:<3} {cap['name'][:12]:12} far {len(far):2} | off toward/other/held {row['off']} | on {row['on']}")
print('per game (toward, other, held):')
for run, g in per.items(): print(f"  {run} cases {g['cases']:2} off {g['off']} on {g['on']}")
print('total far-soldier orders (toward, other, held): off', tot['off'], 'on', tot['on'])
