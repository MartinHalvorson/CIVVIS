"""Bounded, task-local build/evidence controller. No native host or policy commands."""
from pathlib import Path
import datetime,json,subprocess,time
root=Path(__file__).parent;deadline=time.monotonic()+3600

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def await_json(name):
 while time.monotonic()<deadline:
  p=root/name
  if p.exists():
   try:return json.loads(p.read_text())
   except json.JSONDecodeError:pass
  time.sleep(2)
 raise TimeoutError(name)
def stage(name,args):
 print(json.dumps({'stage':name,'started':now()}),flush=True)
 with (root/(name+'.log')).open('wb') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
 receipt={'stage':name,'exit':r.returncode,'completed':now(),'command':args};(root/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
assert await_json('candidate-build.json')['exit']==0
await_json('candidate-binary.json');assert (root/'frozen-candidate-ci-orders').is_file()
stage('queries-01',['python3',str(root/'query.py'),'--candidate',str(root/'frozen-candidate-ci-orders'),'--out',str(root/'queries-01')])
stage('prefix-comparisons-01',['python3',str(root/'compare-prefix.py')])
stage('independent-verify',['python3',str(root/'verify.py')])
assert await_json('full-rust.json')['exit']==0
stage('package',['python3',str(root/'package.py')])
print(json.dumps({'evidence_completed':now(),'next':'Render the scoped report, add activation artifact, extract/verify archive, regenerate gates, then commit/push and coordinate. No automatic publication.'}),flush=True)
