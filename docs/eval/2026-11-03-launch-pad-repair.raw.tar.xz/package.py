"""Seal completed development evidence once; this never runs a native game."""
from pathlib import Path
import datetime,hashlib,json,re,shutil,subprocess,tarfile
root=Path(__file__).parent;repo=Path('/Users/martbot-mbp-m5-max-128/civvis-launch-pad-spares-the-repair-4cb9');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();binary=json.loads((root/'candidate-binary.json').read_text())
assert head==binary['source_head']=='93f036e6ba14c2fa29ee8c6cc3a614d16588a5f7'
assert binary['source_sha256']=={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in binary['source_sha256']}
assert json.loads((root/'candidate-build.json').read_text())['exit']==0
assert json.loads((root/'full-rust.json').read_text())['exit']==0
assert '7 passed; 0 failed' in (root/'focused-rust-03.log').read_text()
verification=json.loads((root/'independent-verification.json').read_text());assert len(verification['prefixes'])==4 and len(verification['fresh_boards'])==4
queries=json.loads((root/'queries-01/results.json').read_text());assert len(queries['cases'])==4 and all(c['complete'] for c in queries['cases'])
archive=repo/'docs/eval/2026-11-03-launch-pad-repair.raw.tar.xz';archive.parent.mkdir(exist_ok=True);assert not archive.exists(),'Sealed archive is immutable; use a separate supplement for later evidence.'
package=root/'evidence-package';package.mkdir(exist_ok=False)
directories=['helpers','native-primary','census-inputs','native-qualified-01','prefix-comparisons-01','prefix-comparisons-02','queries-01']
files=['compiler-version.txt','cargo-version.txt','finish-evidence.py','helper-hashes.json','hold-repair-census.json','native-freeze.json','candidate-binary.json','candidate-build.json','full-rust.json','independent-verification.json','query.py','compare-prefix.py','compare-prefix-02.py','prefix-intent-02.json','prefix-comparisons-01.log','prefix-comparisons-02.log','verify.py','validate.py','package.py','prefix-intent.json','validation-controller.log','native-qualification.log','focused-rust.log','focused-rust-02.log','focused-rust-03.log','candidate-build.log','full-rust.log','append-tests.log','manifest-tests.log','format-check.log','genes-check.log']
for directory in directories:
 for source in sorted((root/directory).rglob('*')):
  if not source.is_file() or source.is_symlink() or '__pycache__' in source.parts:continue
  if source.name=='events.jsonl' and source.parent.name.startswith(('control-','on-','off-')):continue
  destination=package/source.relative_to(root);destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,destination)
for name in files:shutil.copy2(root/name,package/name)
for name in binary['source_sha256']:
 destination=package/'candidate-source'/name;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,destination)
 before=subprocess.run(['git','show','2bd9ae08e752ae088867b3c4147f8456b290e384:'+name],cwd=repo,capture_output=True)
 if before.returncode==0:
  destination=package/'before-source'/name;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(before.stdout)
members={str(p.relative_to(package)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(package.rglob('*')) if p.is_file()}
(package/'member-hashes.json').write_text(json.dumps(members,indent=2)+'\n')
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for source in sorted(package.rglob('*')):
  if source.is_file():tar.add(source,arcname=str(source.relative_to(package)),recursive=False)
results=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (root/'full-rust.log').read_text())];assert results and sum(x[1] for x in results)==0
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tag':'launch-pad-spares-the-repair','source_head':head,'base':'2bd9ae08e752ae088867b3c4147f8456b290e384','binary':binary,'scope':'Development captured proposals and exact original/OFF/read controls only. Inputs reused; no held-out confirmation, native repair execution/completion, win-rate, promotion or native treatment claim.','full_rust':{'passed':sum(x[0] for x in results),'failed':0,'ignored':sum(x[2] for x in results),'threads':4},'focused_rust':{'passed':7,'failed':0},'qualification':verification['qualifications'],'prefixes':verification['prefixes'],'fresh_boards':verification['fresh_boards'],'census':verification['census'],'archive':{'path':str(archive.relative_to(repo)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'members':len(members)+1},'members':members}
(repo/'docs/eval/2026-11-03-launch-pad-repair.json').write_text(json.dumps(report,indent=2)+'\n');(root/'sealed-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'archive':report['archive'],'full_rust':report['full_rust'],'changed_boards':sum(x['changed'] for x in verification['fresh_boards'])}))
