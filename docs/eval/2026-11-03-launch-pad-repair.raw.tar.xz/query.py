"""Captured native boards only; no host commands or native policy writes."""
from pathlib import Path
import argparse,datetime,hashlib,json,subprocess,sys,shutil
repo=Path('/Users/martbot-mbp-m5-max-128/civvis-launch-pad-spares-the-repair-4cb9');sys.path.insert(0,str(repo/'tools'))
from civ6_decision_trace import captured_input
from civ6_ladder import decider_genome
from civ6_captured_read_replay import exact_fact,control_payload,seal_captures
sha=lambda raw:hashlib.sha256(raw).hexdigest()
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--candidate',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);args=ap.parse_args();out=args.out.resolve();out.mkdir(exist_ok=False)
root=Path(__file__).parent;candidate=args.candidate.resolve();tag='launch-pad-spares-the-repair';runs=Path.home()/'civvis-civ6-runs/control'
selected=[('civvis-20261103T070446Z',159),('civvis-20261103T070446Z',160),('civvis-20261103T053148Z',199),('civvis-20261103T024543Z',177)]
report={'intent':{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_sha256':sha(candidate.read_bytes()),'selected':selected,'scope':'Fresh captured-board proposals, not persistent history or native execution/strength. Before/OFF and repeated OFF/ON full-payload controls; all source snapshot bytes retained.'},'cases':[]}
for name,turn in selected:
 run=runs/name;genome=decider_genome(run/'why.log');profile=sorted(genome['forced']);assert tag not in genome['treatments'];assert 'launch-pad-holds-its-queue' in genome['treatments']
 summary=json.loads((run/'summary.json').read_text());seat=summary['seat'];target=summary['victory_target'];context_source=Path.home()/'civvis-runs/2026-11-02-native-process-context'/name/'observed-context.json';context=json.loads(context_source.read_text());actual=context['processes'][0]['argv'];assert actual[actual.index('--victory')+1]==target and actual[actual.index('--civ')+1]==seat['civ']
 record=next(json.loads(line) for line in (run/'decisions.jsonl').open() if (json.loads(line)['decision']['turn'],json.loads(line)['decision']['frame'])==(turn,0));cap=record['input_capture'];assert cap['complete'];before=Path(record['binary']);digest=sha(before.read_bytes());assert digest==record['binary_on_disk_sha256']==context['binary_sha256']
 frozen=root/'original-binaries'/digest;frozen.parent.mkdir(exist_ok=True)
 if not frozen.exists():shutil.copy2(before,frozen)
 assert sha(frozen.read_bytes())==digest;before=frozen
 selected_read=None
 for read in cap['reads']:
  raw=captured_input(cap,read['snapshot_id']);states=[json.loads(line) for line in raw.splitlines() if json.loads(line).get('kind')=='state']
  if states and (states[-1]['turn'],states[-1].get('frame',0))==(turn,0):selected_read=(raw,read['snapshot_id']);break
 assert selected_read
 raw,snapshot=selected_read;directory=out/f'{name}-{turn}';directory.mkdir();(directory/'captured-events.jsonl').write_bytes(raw);(directory/'source-record.json').write_text(json.dumps(record,indent=2)+'\n');shutil.copy2(context_source,directory/'observed-context.json');shutil.copy2(run/'summary.json',directory/'summary.json');shutil.copy2(run/'why.log',directory/'source-why.log')
 mapping,sealed=seal_captures([record],directory);adjusted={**cap,'directory':str(mapping[cap['directory']])};assert captured_input(adjusted,snapshot)==raw
 case={'run':name,'turn':turn,'source_decision_sha256':record['sha256'],'source_binary_sha256':digest,'snapshot':snapshot,'captured_events_sha256':sha(raw),'sealed_captures':sealed,'complete':False,'reads':[{'complete':True,'sha256':sha(raw),'bytes':len(raw),'arms':[]}],'controls':[]};report['cases'].append(case);arms={}
 for label in ['before-off','candidate-off','candidate-on','candidate-on-repeat','candidate-off-repeat']:
  binary=before if label=='before-off' else candidate;on=label in ['candidate-on','candidate-on-repeat'];d=directory/label;d.mkdir();(d/'events.jsonl').write_bytes(raw)
  argv=[str(binary),'--mirror',str(d),'--turn',str(turn),'--victory',target,'--civ',seat['civ'],'--fresh-board','--explain']
  for flag in sorted(profile+([tag] if on else [])):argv+=['--with',flag]
  p=subprocess.run(argv,cwd=repo,capture_output=True,timeout=60);(d/'stdout').write_bytes(p.stdout);(d/'stderr').write_bytes(p.stderr);realized=decider_genome(d/'stderr');a={'label':label,'argv':argv,'exit':p.returncode,'genome':realized};case['controls'].append(a);(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
  assert p.returncode==0 and realized and sorted(realized['treatments'])==sorted(genome['treatments']+([tag] if on else [])) and sorted(realized['forced'])==sorted(profile+([tag] if on else []))
  a['payload']=json.loads(p.stdout);arms[label]=a;(d/'events.jsonl').unlink()
 for left,right in [('before-off','candidate-off'),('candidate-off','candidate-off-repeat'),('candidate-on','candidate-on-repeat')]:assert exact_fact(control_payload(arms[left]['payload']),control_payload(arms[right]['payload'])),(name,turn,left,right,'full payload differs')
 for arm,label in [('off','candidate-off'),('on','candidate-on')]:case['reads'][0]['arms'].append({'arm':arm,**{k:v for k,v in arms[label].items() if k!='label'}})
 old=arms['candidate-off']['payload']['orders'];new=arms['candidate-on']['payload']['orders'];case['changed']=old!=new;case['removed_orders']=[o for o in old if o not in new];case['added_orders']=[o for o in new if o not in old];case['complete']=True
 (directory/'result.json').write_text(json.dumps(case,indent=2)+'\n');(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'run':name,'turn':turn,'changed':case['changed'],'removed':len(case['removed_orders']),'added':len(case['added_orders'])}),flush=True)
assert any(c['changed'] for c in report['cases']),'No demonstrated proposal activation; withhold the candidate.'
