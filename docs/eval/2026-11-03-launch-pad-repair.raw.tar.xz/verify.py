"""Recheck retained inputs, replies, profiles and read traces without execution."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "helpers"))
import civ6_captured_read_replay as replay


def rows(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def genome(path):
    for line in path.read_text().splitlines():
        try:
            value = json.loads(line)
        except ValueError:
            continue
        if isinstance(value, dict) and "treatments" in value:
            return {key: value.get(key) for key in ("strategy", "source", "lane", "civ", "strength_bound", "treatments", "ledger_withheld", "forced")}
    raise AssertionError(f"No realized genome in {path}")


def source(q):
    proof = json.loads((q / "qualification.json").read_text())
    raw = (q / "native-decisions.jsonl").read_bytes()
    assert replay.sha(raw) == proof["native_decisions_sha256"]
    mapping = {}
    for capture in proof["sealed_captures"]:
        directory = q / Path(capture["sealed_directory"]).name
        assert replay.sha((directory / "bytes.bin").read_bytes()) == capture["archive_sha256"]
        assert replay.sha((directory / "snapshots.jsonl").read_bytes()) == capture["index_sha256"]
        mapping[capture["source"]] = directory
    return proof, rows(q / "native-decisions.jsonl"), mapping


def control(records, mapping, directory, metrics, orders_only=False):
    by_key = {replay.frame_key(row): row for row in records}
    replies = rows(directory / "replies.jsonl")
    assert len(replies) == len(metrics)
    matched = []
    for metric, reply in zip(metrics, replies):
        key = tuple(metric["request"])
        record = by_key[key]
        capture = record["input_capture"]
        expected = replay.expanded_reads(dict(capture, directory=str(mapping[capture["directory"]])))
        actual = replay.expanded_reads(dict(reply["input_capture"], directory=str(directory / "recaptured")))
        assert expected == actual
        assert [replay.sha(x) for x in expected] == metric["expected_read_sha256"]
        assert [replay.sha(x) for x in actual] == metric["actual_read_sha256"]
        assert not replay.request_identity_errors(reply, *key)
        before = record["orders"] if orders_only else replay.control_payload(record)
        after = reply["orders"] if orders_only else replay.control_payload(reply)
        matched.append(replay.exact_fact(before, after))
    return matched, replies


report = {"scope": "Independent retained-evidence reconstruction only; no native execution or strength claim.", "qualifications": [], "prefixes": [], "fresh_boards": []}
q=root/'native-qualified-01';proof,records,mapping=source(q)
assert proof['passed'] and proof['through_turn']==160 and len(proof['controls'])==2
for number,result in enumerate(proof['controls']):
 matches,_=control(records,mapping,q/f'control-{number}',result['requests'])
 assert result['passed'] and len(matches)==386 and all(matches)
 report['qualifications'].append({'control':number,'requests':len(matches)})
baseline=genome(q/'control-0/stderr.log');tag='launch-pad-spares-the-repair'
p=root/'prefix-comparisons-02';proof=json.loads((p/'results.json').read_text());assert len(proof['results'])==4
on_replies=[]
for result in proof['results']:
 s=result['summary'];label=s['variant'];on=label.startswith('on-');actual=genome(p/label/'stderr.log')
 for field in ['treatments','forced']:assert sorted(actual[field])==sorted(baseline[field]+([tag] if on else []))
 for field in ['strategy','source','lane','civ','strength_bound','ledger_withheld']:assert actual[field]==baseline[field]
 matches,replies=control(records,mapping,p/label,result['driver_result']['requests'],orders_only=on)
 assert s['valid_prefix_comparison']
 if on:
  assert len(matches)==385 and all(matches[:-1]) and matches[-1] is False
  assert s['stopped_request']==[160,0]==result['driver_result']['failed_request']
  on_replies.append(replies)
 else:assert len(matches)==386 and all(matches)
 report['prefixes'].append({'arm':label,'requests':len(matches),'matching':sum(matches),'first_change':[160,0] if on else None})
assert len(on_replies[0])==len(on_replies[1])
assert all(replay.exact_fact(replay.control_payload(a),replay.control_payload(b)) for a,b in zip(*on_replies))
p=root/'queries-01';proof=json.loads((p/'results.json').read_text());assert len(proof['cases'])==4
for case in proof['cases']:
 d=p/f"{case['run']}-{case['turn']}";raw=(d/'captured-events.jsonl').read_bytes();record=json.loads((d/'source-record.json').read_text());capture=record['input_capture']
 assert replay.sha(raw)==case['captured_events_sha256']==case['reads'][0]['sha256']
 assert len(raw)==case['reads'][0]['bytes'] and record['sha256']==case['source_decision_sha256']
 unsigned={k:v for k,v in record.items() if k!='sha256'}
 assert replay.sha(json.dumps(unsigned,sort_keys=True,separators=(',',':'),allow_nan=False).encode())==record['sha256']
 context=json.loads((d/'observed-context.json').read_text());assert context['binary_sha256']==record['binary_on_disk_sha256']==case['source_binary_sha256']
 sealed=case['sealed_captures'];assert len(sealed)==1
 store=d/Path(sealed[0]['sealed_directory']).name
 assert replay.sha((store/'bytes.bin').read_bytes())==sealed[0]['archive_sha256']
 assert replay.sha((store/'snapshots.jsonl').read_bytes())==sealed[0]['index_sha256']
 assert replay.captured_input(dict(capture,directory=str(store)),case['snapshot'])==raw
 if case['run']==context['run']==json.loads((q/'observed-context.json').read_text())['run']:
  native=next(x for x in records if replay.frame_key(x)==(case['turn'],0));assert replay.exact_fact(native,record)
 controls={x['label']:x for x in case['controls']};assert len(controls)==5 and case['complete']
 for label,arm in controls.items():
  assert arm['exit']==0
  assert replay.exact_fact(arm['payload'],json.loads((d/label/'stdout').read_text()))
  assert replay.exact_fact(arm['genome'],genome(d/label/'stderr'))
 for a,b in [('before-off','candidate-off'),('candidate-off','candidate-off-repeat'),('candidate-on','candidate-on-repeat')]:assert replay.exact_fact(replay.control_payload(controls[a]['payload']),replay.control_payload(controls[b]['payload']))
 for label in ['candidate-off','candidate-on']:
  on=label=='candidate-on'
  for field in ['treatments','forced']:assert sorted(controls[label]['genome'][field])==sorted(controls['before-off']['genome'][field]+([tag] if on else []))
 changed=controls['candidate-off']['payload']['orders']!=controls['candidate-on']['payload']['orders'];assert changed==case['changed']
 report['fresh_boards'].append({'run':case['run'],'turn':case['turn'],'changed':changed})
import re
census=json.loads((root/'hold-repair-census.json').read_text());found=[]
for source_input in census['frozen_inputs']:
 why=root/'census-inputs'/source_input['run']/'why.log';assert replay.sha(why.read_bytes())==source_input['why_sha256']
 for number,line in enumerate(why.read_text().splitlines(),1):
  if 'launch-pad-holds-its-queue:' in line and 'repair' in line.lower():
   m=re.match(r'\[why\] t(\d+) .*? (.*?) keeps its Spaceport at the head',line);assert m
   found.append({'run':source_input['run'],'line':number,'turn':int(m[1]),'city':m[2],'journal':line})
assert found==census['rows'] and len(found)==198
assert len(set((x['run'],x['turn'],x['city']) for x in found))==72
assert len(set(x['run'] for x in found))==17
report['census']={'journal_lines':198,'distinct_run_turn_city':72,'runs':17}
(root/'independent-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'qualified_requests':sum(x['requests'] for x in report['qualifications']),'prefix_controls':len(report['prefixes']),'fresh_boards':len(report['fresh_boards']),'native_snapshot_bindings_verified':True,'census_verified':True}))
