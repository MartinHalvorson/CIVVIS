from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
root=Path(__file__).parent;repo=Path('/Users/martbot-mbp-m5-max-128/civvis-launch-pad-spares-the-repair-4cb9');env=os.environ.copy();env['CARGO_BUILD_JOBS']='6'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
paths=['src/ai/advanced.rs','src/ai/advanced/launch_pad_holds_its_queue.rs','src/ai/advanced/launch_pad_repair.rs','src/ai/advanced/launch_pad_repair/tests.rs','src/ai/advanced/genes.rs','src/ai/advanced/treatment_flags.rs'];hashes={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
for stage,args in [('candidate-build',['cargo','build','--profile','ci','--locked','--bin','civvis_orders']),('full-rust',['cargo','test','--profile','ci','--locked','--','--test-threads=4'])]:
 print(json.dumps({'stage':stage,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':head}),flush=True)
 stage_env=env.copy()
 if stage=='candidate-build':stage_env['CARGO_TARGET_DIR']=str(root/'candidate-target')
 with (root/(stage+'.log')).open('wb') as log:p=subprocess.run(args,cwd=repo,env=stage_env,stdout=log,stderr=subprocess.STDOUT)
 receipt={'stage':stage,'exit':p.returncode,'completed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':head,'command':args};(root/(stage+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
 assert hashes=={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
 if stage=='candidate-build':
  src=root/'candidate-target/ci/civvis_orders';dest=root/'frozen-candidate-ci-orders';assert not dest.exists();shutil.copy2(src,dest);receipt={'source_head':head,'binary_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'source_sha256':hashes,'scope':'CI-profile local shadow candidate only; no native deployment.'};(root/'candidate-binary.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'frozen_candidate':receipt['binary_sha256']}),flush=True)
