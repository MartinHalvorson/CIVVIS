"""Private first-order audit; never sends orders to the native host."""
from pathlib import Path
import json,sys,datetime
repo=Path('/Users/martbot-mbp-m5-max-128/civvis-launch-pad-spares-the-repair-4cb9')
sys.path.insert(0,str(repo/'tools'))
import civ6_captured_read_replay as replay
from civ6_ladder import decider_genome
root=Path(__file__).parent
q=root/'native-qualified-01'
proof=json.loads((q/'qualification.json').read_text())
assert proof['passed'] and proof['through_turn']==160 and len(proof['controls'])==2
assert all(c['passed'] and len(c['requests'])==386 for c in proof['controls'])
assert replay.sha((repo/'tools/civ6_captured_read_replay.py').read_bytes())=='56a8e54bf1d6c96b4e90a870342ad89012a23e5b1e77ac6fde808fcdff2391f2'
raw=(q/'native-decisions.jsonl').read_bytes()
assert replay.sha(raw)==proof['native_decisions_sha256']
records=[json.loads(x) for x in raw.splitlines()]
mapping={r['source']:Path(r['sealed_directory']) for r in proof['sealed_captures']}
context=json.loads((q/'observed-context.json').read_text())
base=context['processes'][0]['argv']
genome=decider_genome(q/'control-0/stderr.log')
assert genome and not any(t=='launch-pad-spares-the-repair' for t in genome['treatments'])
variants=[(f'off-{n}',None) for n in range(2)]+[(f'on-{n}','launch-pad-spares-the-repair') for n in range(2)]
intent={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_run':context['run'],'qualified_prefix_sha256':replay.sha((q/'qualification.json').read_bytes()),'through_turn':160,'variants':variants,'delivery':'hybrid','comparison':'Full host orders only; decision metadata may differ. Retain exact frame identity and actual read count/order/bytes. Stop at first order divergence, never continue captured world after changed action.','scope':'Candidate ON against qualified source history; no live host command, policy/default or strength change. Stop at first proposal divergence.'}
(root/'prefix-intent-02.json').write_text(json.dumps(intent,indent=2)+'\n')
out=root/'prefix-comparisons-02';out.mkdir(exist_ok=False)
original_payload=replay.control_payload
report={'intent':intent,'results':[]}
for label,tag in variants:
 command=[str(root/'frozen-candidate-ci-orders')]+base[1:]+(['--with',tag] if tag else [])
 candidate_sha=replay.sha((root/'frozen-candidate-ci-orders').read_bytes())
 variant={'binary_sha256':candidate_sha,'provenance':{'sha256':candidate_sha,'scope':'Altered shadow command, not an observed native process.'},'processes':[{'argv':command,'cwd':context['processes'][0]['cwd']}]}
 replay.control_payload=(lambda r:{'orders':r['orders']}) if tag else original_payload
 result=replay.run_control(variant,records,mapping,out/label,60,delivery='hybrid')
 for metric in result['requests']:metric['orders_match']=metric.pop('native_payload_matches')
 actual=decider_genome(out/label/'stderr.log')
 profile=bool(actual) and sorted(actual['treatments'])==sorted(genome['treatments']+([tag] if tag else [])) and sorted(actual['forced'])==sorted(genome['forced']+([tag] if tag else []))
 valid_reads=bool(result['requests']) and all(not m['identity_errors'] and m['read_sequence_matches'] for m in result['requests'])
 first_change=bool(result.get('failed_request') and result['requests'] and not result['requests'][-1]['orders_match'] and all(m['orders_match'] for m in result['requests'][:-1]) and valid_reads and (result.get('error') or '').startswith('ValueError: original-binary control differs'))
 summary={'variant':label,'profile_matches':profile,'valid_prefix_comparison':profile and valid_reads and (result['passed'] or first_change),'all_orders_match_through_endpoint':result['passed'],'comparison':'orders_only' if tag else 'full_orders_and_decision','requests':len(result['requests']),'stopped_at_first_order_change':first_change,'stopped_request':result.get('failed_request'),'error':result.get('error')}
 if first_change:
  native=next(r for r in records if replay.frame_key(r)==tuple(result['failed_request']))
  reply=json.loads((out/label/'replies.jsonl').read_bytes().splitlines()[-1])
  summary['native_orders']=native['orders'];summary['variant_orders']=reply['orders']
 report['results'].append({'summary':summary,'driver_result':result,'actual_genome':actual})
 (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in summary.items() if k not in ['native_orders','variant_orders']}),flush=True)
 if not summary['valid_prefix_comparison'] or (tag is None and not result['passed']):raise SystemExit(2)
