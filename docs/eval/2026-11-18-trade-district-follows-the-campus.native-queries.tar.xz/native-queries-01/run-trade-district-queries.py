"""Paired decider queries on live frames of four Deity games of 2026-11-18 in
which trade capacity stood at one until turn 119 or later.

`trade-district-follows-the-campus` is the only bit that varies. Each case is
a live run's own events.jsonl cut after turn N+1 (every row through the first
rows of the next turn), replayed at turn N. Both arms run one frozen
`civvis_orders --resumed` built from the branch, with that run's own requested
genome (why.log line 1 `forced`, each as `--with`); the on arm adds
`--with trade-district-follows-the-campus`.

Read per arm: the production orders (`produce` and `produce_next`, by city)
and the gene's own journal lines. Per case: whether any order changed, and
which cities' production changed.

Cases, every fifth turn from turn 60 to turn 150:
civvis-20261118T045850Z (Kongo, Science; Harbors finished at t90 and t95 with
no Lighthouse until t147), civvis-20261118T051842Z (Canada, Diplomatic;
Commercial Hubs finished at t103 and t106, first Market t145),
civvis-20261118T053007Z (Sumeria, Diplomatic; no Commercial Hub in 194 turns,
a Harbor from t122 with no Lighthouse) and civvis-20261118T061033Z (Hungary,
Diplomatic, the day's win; a Commercial Hub from t76, its Market at t119).
Turns before a Campus and its Library stand, threatened cities and queues the
gene keeps are the controls it must leave alone.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'trade-district-follows-the-campus'
RUNS = Path.home() / 'civvis-score-tools/deity-18/trade'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

GAMES = [
    ('civvis-20261118T045850Z', 'science', 'CIVILIZATION_KONGO', range(60, 151, 5)),
    ('civvis-20261118T051842Z', 'diplomatic', 'CIVILIZATION_CANADA', range(60, 151, 5)),
    ('civvis-20261118T053007Z', 'diplomatic', 'CIVILIZATION_SUMERIA', range(60, 151, 5)),
    ('civvis-20261118T061033Z', 'diplomatic', 'CIVILIZATION_HUNGARY', range(60, 151, 5)),
]
CASES = [{'run': r, 'victory': v, 'civ': c, 'turn': t} for r, v, c, turns in GAMES for t in turns]
TRADE = ('DISTRICT_COMMERCIAL_HUB', 'DISTRICT_HARBOR', 'DISTRICT_SUGUBA', 'DISTRICT_COTHON',
         'DISTRICT_ROYAL_NAVY_DOCKYARD', 'BUILDING_MARKET', 'BUILDING_LIGHTHOUSE', 'BUILDING_SUKIENNICE')


def cut(run, turn):
    """Rows through turn+1 (the replay recipe), and the turn's last state row."""
    rows, last = [], None
    with open(RUNS / run / 'events.jsonl', errors='replace') as f:
        for line in f:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > turn + 1:
                break
            rows.append(line)
            if e.get('kind') == 'state' and e.get('turn') == turn:
                last = e
    return ''.join(rows).encode(), last


def production(row, names):
    out = {}
    for o in row.get('payload', {}).get('orders', []):
        if o.get('kind') in ('produce', 'produce_next'):
            out.setdefault(names.get(o.get('subject'), str(o.get('subject'))), []).append(
                f"{o['kind']}:{o.get('verb')}")
    return out


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data, last = cut(case['run'], case['turn'])
        names = {c['id']: c['name'] for c in last['cities']}
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'cut': 'after turn+1'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                  'board': {'trade_capacity': last.get('trade_capacity'),
                            'trade_routes': len(last.get('trade_routes') or []),
                            'cities': len(last['cities']), 'gold': last.get('gold'),
                            'gold_per_turn': last.get('gold_per_turn')},
                  'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', case['victory'], '--civ', case['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=600)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if GENE + ':' in line]
            row['production'] = production(row, names)
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['production_changed'] = {
            city: {'off': off['production'].get(city), 'on': on['production'].get(city)}
            for city in sorted(set(off['production']) | set(on['production']))
            if off['production'].get(city) != on['production'].get(city)}
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
             'on_gene_lines': 0, 'off_gene_lines': 0, 'on_trade_orders': 0, 'off_trade_orders': 0}
    for r in results:
        c = r['case']
        if r.get('error'):
            print(c['run'], c['turn'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            off, on = v['arms']
            total['on_gene_lines'] += len(on['journal_gene'])
            total['off_gene_lines'] += len(off['journal_gene'])
            for arm, key in ((off, 'off_trade_orders'), (on, 'on_trade_orders')):
                total[key] += sum(1 for orders in arm['production'].values() for o in orders
                                  if o.split(':', 1)[1] in TRADE)
            print(f"{c['run'][-16:]} t{c['turn']:<3} cap {v['board']['trade_capacity']} "
                  f"{'CHANGED' if v['orders_changed'] else 'same   '} gene lines {len(on['journal_gene'])} "
                  f"{json.dumps(v['production_changed'])}")
            for line in on['journal_gene']:
                print('      ', line[:230])
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
