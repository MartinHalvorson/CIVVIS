"""Fixed all-16 captured-read selection; no treated query or Native execution."""
import collections
import hashlib
import json
import math
from pathlib import Path

ROOT = Path.home() / 'civvis-civ6-runs'
BASE = Path('/tmp/civvis-capital-watch-slinger-upgrade-f006')
STUDY = ROOT / 'experiments/2026-10-25-culture-air-interception-native-trial-codex-1025d-root/state.json'
OUT = BASE / 'native-selection'


def records(path):
    with path.open() as source:
        for line in source:
            yield json.loads(line)


def main():
    OUT.mkdir()
    assignments = json.loads(STUDY.read_text())['assigned']
    cases, cohort = [], []
    for stem in assignments:
        directories = sorted((ROOT / 'control').glob(stem + '*'))
        if not directories:
            raise ValueError('missing assigned attempt')
        for directory in directories:
            summary = json.loads((directory / 'summary.json').read_text())
            if summary.get('game_stopped') is not True:
                raise ValueError('nonterminal member')
            decisions = list(records(directory / 'decisions.jsonl'))
            states = collections.defaultdict(list)
            for event in records(directory / 'events.jsonl'):
                if event.get('kind') == 'state':
                    states[event['turn'], event['frame']].append(event)
            with (directory / 'why.log').open() as source:
                genome = json.loads(source.readline())
            genome['_summary_withheld'] = summary.get('withheld', [])
            genome_path = OUT / (directory.name + '.genome.json')
            genome_path.write_text(json.dumps(genome, indent=2) + '\n')
            selected, first_turn = {}, set()
            for index, decision in enumerate(decisions):
                meta = decision['decision']
                key = meta['turn'], meta['frame']
                readings = states[key]
                reasons = []
                if index == 0:
                    reasons.append('first_actual_decision')
                if index == len(decisions) - 1:
                    reasons.append('final_actual_decision')
                initial = meta['turn'] not in first_turn
                first_turn.add(meta['turn'])
                if initial and meta['turn'] <= 60:
                    if len(readings) != 1:
                        reasons.append('first_turn_state_unavailable')
                    else:
                        state = readings[0]
                        eligible = []
                        for unit in state.get('units', []):
                            price = unit.get('upgrade_cost')
                            if (unit.get('kind') == 'UNIT_SLINGER' and unit.get('hp', 0) >= 75
                                    and isinstance(price, (float, int)) and math.isfinite(price)
                                    and price >= 0 and state.get('gold', -1) >= price):
                                eligible.append(unit['id'])
                        if eligible:
                            reasons.append('first_decision_healthy_affordable_slinger')
                upgrades = [order for order in decision.get('orders', [])
                            if order.get('kind') == 'unit' and order.get('verb') == 'UPGRADE']
                units = {unit['id']: unit for unit in readings[0].get('units', [])} if len(readings) == 1 else {}
                if any(units.get(order.get('subject'), {}).get('kind') == 'UNIT_SLINGER' for order in upgrades):
                    reasons.append('actual_slinger_upgrade_order')
                if any(order.get('subject') not in units for order in upgrades):
                    reasons.append('unclassified_upgrade_source_control')
                if not reasons:
                    continue
                if key not in selected:
                    selected[key] = dict(run=directory.name, directory=str(directory),
                        turn=key[0], frame=key[1], decision_index=index,
                        reasons=[], state_count=len(readings), genome=str(genome_path),
                        capture=decision.get('input_capture'))
                selected[key]['reasons'] = sorted(set(selected[key]['reasons']) | set(reasons))
            cases.extend(selected.values())
            cohort.append(dict(run=directory.name, cases=len(selected),
                files={name: dict(bytes=(directory / name).stat().st_size,
                       sha256=hashlib.sha256((directory / name).read_bytes()).hexdigest())
                       for name in ['summary.json', 'events.jsonl', 'decisions.jsonl', 'why.log']}))
    report = dict(scope=__doc__,
        interpretation='First actual decision in each turn, filtered on its unique observed state; no later decision substitutes. First/final controls and all typed Slinger upgrade frames retained. Unclassified upgrade-source frames are retained as controls.',
        gene='capital-watch-arms-the-slinger', assignment_state_sha256=hashlib.sha256(STUDY.read_bytes()).hexdigest(),
        selection_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        cohort=cohort, cases=sorted(cases, key=lambda case: (case['run'], case['decision_index'])))
    (OUT / 'manifest.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(cohort=len(cohort), cases=len(cases),
        per_game=[(item['run'], item['cases']) for item in cohort],
        ambiguous_states=sum(case['state_count'] != 1 for case in cases))))


if __name__ == '__main__':
    main()
