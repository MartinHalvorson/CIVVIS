from pathlib import Path
import copy,hashlib,json
from civ6_decision_trace import captured_input,validate_input_capture
root=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((root/'native-record.json').read_text());unsigned={k:v for k,v in r.items() if k!='sha256'}
assert sha(json.dumps(unsigned,sort_keys=True,separators=(',',':'),allow_nan=False).encode())==r['sha256']
capture=copy.deepcopy(r['input_capture']);capture['directory']=str(root/'source-capture');validate_input_capture(capture)
reads=[captured_input(capture,x['snapshot_id']) for x in capture['reads'] for _ in range(x['count'])]
assert len(reads)==18 and all(b==reads[0] for b in reads)
assert reads[0]==(root/'input-1.events.jsonl').read_bytes()
s=json.loads((root/'source.json').read_text());assert sha(reads[0])==s['input_sha256s'][0]
assert s['no_observed_pad_committed_before_request'] and s['rule_active']
ctx=json.loads((root/'observed-context.json').read_text())
assert ctx['binary_sha256']==r['binary_on_disk_sha256']==s['binary_sha256']
assert all('first-pad-in-the-forge' in ctx['actual_genome'][k] for k in ['forced','treatments'])
before=json.loads((root/'observed-state.json').read_text());after=json.loads((root/'next-observed-state.json').read_text())
assert not any(d['type']=='DISTRICT_SPACEPORT' for c in before['cities'] for d in c['districts'])
assert not any(c.get('producing')=='DISTRICT_SPACEPORT' for c in before['cities'])
assert [c['name'] for c in after['cities'] if any(d['type']=='DISTRICT_SPACEPORT' for d in c['districts'])]==['Seoul']
assert any(a.get('city')==52 and a.get('item',{}).get('district')=='spaceport' for a in r['decision']['native_actions'])
assert any(a.get('city')==52 and a.get('item',{}).get('repair')=='district' for a in r['decision']['native_actions'])
assert any(x['subject']==458758 and x['verb']=='DISTRICT_SPACEPORT' for x in r['orders'])
assert not any(x['subject']==196610 and x['verb']=='DISTRICT_SPACEPORT' for x in r['orders'])
assert any(x['subject']==196610 and x['verb']=='DISTRICT_AQUEDUCT' for x in r['orders'])
assert s['cities']['Daegu']['production']==42 and s['cities']['Seoul']['production']==16
print('Native witness verified:18identicalactualreads,plannerpad/repairemissionmismatch,slowfirstrealpad')
