from pathlib import Path
import json,hashlib,datetime
root=Path(__file__).parent;screen=root.parent/'free-slot-campus-clock/live-screen';cohort=json.loads((screen/'interim-review-20261104T1948Z.json').read_text())['rows'];rows=[]
for world in cohort:
 run=Path.home()/'civvis-civ6-runs/control'/world['run'];requests={}
 for l in (run/'decisions.jsonl').open():
  r=json.loads(l);actions=[a for a in r['decision'].get('native_actions',[]) if a['type']=='reassign_governor']
  if actions:requests[(r['decision']['turn'],r['decision']['frame'])]=(r,actions)
 for l in (run/'events.jsonl').open('rb'):
  e=json.loads(l)
  if e.get('kind')!='state':continue
  key=(e['turn'],e['frame'])
  if key not in requests:continue
  record,actions=requests.pop(key)
  for a in actions:
   native_target=next((int(k) for k,v in record['decision']['city_ids'].items() if v==a['city']),None);target=next((c for c in e['cities'] if c['id']==native_target),None);name={'magnus':'GOVERNOR_THE_RESOURCE_MANAGER','victor':'GOVERNOR_THE_DEFENDER','pingala':'GOVERNOR_THE_EDUCATOR','liang':'GOVERNOR_THE_BUILDER','reyna':'GOVERNOR_THE_FINANCIER','moksha':'GOVERNOR_THE_CARDINAL','amani':'GOVERNOR_THE_AMBASSADOR'}.get(a['governor']);gov=next((g for g in e.get('governors',[]) if g['type']==name),None);source=next((c for c in e['cities'] if gov and c['id']==gov['city']),None)
   if not source or source['id']==native_target:continue
   brief=lambda c:{k:c.get(k) for k in ['id','name','pop','loyalty','loyalty_per_turn','original_capital','original_owner']}
   rows.append({'run':world['run'],'observed_arm':world['observed_arm'],'revision':world['revision'],'request':key,'governor':a['governor'],'source':brief(source),'target':brief(target) if target else None,'state_line_sha256':hashlib.sha256(l).hexdigest(),'signed_decision_sha256':record['sha256']})
report={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixed_cohort':[r['run'] for r in cohort],'transfers':rows,'scope':'Observed own-city governor transfer proposals in fixed first10 Campus screen launch contexts. Exact native state/request matched, source/target keyed by decision city IDs. No counterfactual outcome or causal treatment estimate.'};(root/'cohort-transfer-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'transfers':len(rows),'negative_donor_rate':sum(r['source']['loyalty_per_turn']<0 for r in rows),'negative_original_capital_donor_rate':sum(r['source']['loyalty_per_turn']<0 and r['source']['original_capital'] for r in rows)}))
