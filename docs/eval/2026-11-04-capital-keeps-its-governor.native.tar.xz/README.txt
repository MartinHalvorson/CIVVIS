capital-keeps-its-governor: captured native proposal proof, default OFF.

Run: python3 verify.py --root . --repo /path/to/CIVVIS
Requires repository tools available in the pinned/current CIVVIS checkout.
The verifier reconstructs raw read bytes/count/order one request at a time,
checks native canonical receipt hashes, per-arm full orders/decision payloads,
argv/genome parity, actual EOF receipts, source exports and the native loss.
The safe-capital-native-193444 folder holds an unchanged negative control.

Observed native binaries are not bundled. Their exact argv/cwd, on-disk
SHA256 and observed provenance are preserved. The constructed candidate's
source exports, compiler/profile, immutable executable SHA256 and checkpoint
are in candidate-build.json. The verifier checks executable bytes when they
are available locally; an extracted archive alone does not execute a binary.
The two original native controls retain their original full payload oracle.
Two separately constructed policy-window reference queries account for #4430;
the second repeats the first, then two new candidate-OFF controls match it.
Both ON probes first differ69/0; four successful prefix runs exit0 and remove
only Magnus's governor_assign to Caracas. They do not continue an ON world.

The raw original native loss reaches Free Cities ownership at90/0. It is not
proof withholding a transfer would save the capital. A source-index/path map
retains original absolute observations while verify.py resolves packaged
captures under its supplied root. Equal files may be stored as tar hardlinks
after SHA256 AND exact streaming byte equality; no raw data is rewritten.
