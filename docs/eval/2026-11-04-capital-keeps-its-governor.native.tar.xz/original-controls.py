from pathlib import Path
import json,sys
sys.path.insert(0,str(Path.home()/'civvis-main-managed/tools'))
import civ6_captured_read_replay as replay
root=Path(__file__).parent;contexts=root.parent/'free-slot-campus-clock/live-screen';p=next(contexts.glob('civvis-20261104T192352Z.pid-*.json'));c=json.loads(p.read_text());assert c['valid_arm_and_binary'] and c['argv_capture_method'];records=replay.select_records(Path.home()/'civvis-civ6-runs/control'/c['run']/'decisions.jsonl',90,c);(root/'observed-context.json').write_bytes(p.read_bytes());(root/'native-decisions.jsonl').write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in records));mapping,seals=replay.seal_captures(records,root);(root/'sealed-captures.json').write_text(json.dumps(seals,indent=2)+'\n');report={'scope':'Original full native reply/read controls before governor-donor research; no treatment.','controls':[]}
for n in range(2):
 r=replay.run_control(c,records,mapping,root/f'original-control-{n}',60,'hybrid');report['controls'].append(r);(root/'original-controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'repeat':n,'passed':r['passed'],'requests':len(r['requests']),'error':r.get('error')}),flush=True);assert r['passed']
