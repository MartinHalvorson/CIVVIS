from pathlib import Path
import json,copy,hashlib,gzip,sys,argparse
ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).parent);ap.add_argument('--repo',type=Path,default=Path.home()/'civvis-main-managed');args=ap.parse_args();root=args.root.resolve();sys.path.insert(0,str(args.repo/'tools'))
from civ6_decision_trace import captured_input,exact_fact
from civ6_ladder import decider_genome
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();payload=lambda r:{k:r[k] for k in ['orders','decision'] if k in r};manifest=read(root/'archive-manifest.json');old=Path(manifest['original_root'])
def local(p):
 p=Path(p)
 if p.is_absolute():
  try:return root/p.relative_to(old)
  except ValueError:return p
 return root/p
def filehash(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def expanded(capture,mapping):
 c=copy.deepcopy(capture);assert c['complete'];c['directory']=str(local(mapping.get(c['directory'],c['directory'])));cache={};result=[]
 for v in c['reads']:
  if v['snapshot_id'] not in cache:cache[v['snapshot_id']]=captured_input(c,v['snapshot_id'])
  result.extend([cache[v['snapshot_id']]]*v['count'])
 return result
def seals(base):
 rows=read(base/'sealed-captures.json')
 for s in rows:
  d=local(s['sealed_directory']);assert filehash(d/'bytes.bin')==s['archive_sha256'] and filehash(d/'snapshots.jsonl')==s['index_sha256']
 return {s['source']:s['sealed_directory'] for s in rows}
def verify_native(base,length):
 c=read(base/'observed-context.json');assert c['valid_arm_and_binary'] and c['argv_capture_method'];mapping=seals(base);count=0
 if Path(c['processes'][0]['argv'][0]).exists():assert filehash(Path(c['processes'][0]['argv'][0]))==c['binary_sha256']
 for line in (base/'native-decisions.jsonl').open():
  r=json.loads(line);unsigned={k:v for k,v in r.items() if k!='sha256'};assert sha(json.dumps(unsigned,sort_keys=True,separators=(',',':'),allow_nan=False).encode())==r['sha256'];assert r['binary']==c['processes'][0]['argv'][0] and r['binary_on_disk_sha256']==c['binary_sha256'];count+=1
 assert count==length
 original=read(base/'original-controls.json');assert len(original['controls'])==2 and all(r['passed'] and len(r['requests'])==length for r in original['controls'])
 for n in range(2):verify_stream(base/f'original-control-{n}',base/'native-decisions.jsonl',base/'native-decisions.jsonl',mapping,length,None);assert decider_genome(base/f'original-control-{n}/stderr.log')==c['actual_genome']
 return c,mapping
def verify_stream(d,oracle,native,mapping,length,receipt):
 count=0
 with (d/'replies.jsonl').open() as f,oracle.open() as o,native.open() as s:
  for i in range(length):
   a,b,c=map(json.loads,[next(f),next(o),next(s)]);assert exact_fact(payload(a),payload(b));key=[c['decision']['turn'],c['decision']['frame']];assert [a['turn'],a['decision']['frame']]==key;actual=expanded(a['input_capture'],receipt['capture_directory_map'] if receipt else {});expected=expanded(c['input_capture'],mapping);assert actual==expected
   if receipt:assert receipt['delivered'][i]=={'request':key,'reads':[{'sha256':sha(x),'bytes':len(x)} for x in actual]}
   count+=1
  assert not f.readline()
 assert count==length
 if receipt:assert receipt['exit']==0 and receipt['requests']==length and (receipt['complete_expected_payload_checked'] or oracle==d/'replies.jsonl');assert receipt['genome']==decider_genome(d/'stderr.log')
source,mapping=verify_native(root,225);result=read(root/'candidate-results.json');assert result['passed'] and result['first_difference']==[69,0] and result['successful_pair_repetitions']==2;build=read(root/'candidate-build.json')
if (root/'candidate-ci-orders').exists():assert filehash(root/'candidate-ci-orders')==build['sha256']
for f,h in build['source_files_sha256'].items():assert filehash(root/'source-exports'/f)==h
for n in range(2):
 for label,oracle in [(f'policy-window-reference-{n}',root/'policy-window-reference-0/replies.jsonl'),(f'candidate-off-control-{n}',root/'policy-window-reference-0/replies.jsonl')]:
  d=root/label;r=read(d/'receipt.json');assert r['exit']==0 and r['genome']==source['actual_genome'];verify_stream(d,oracle,root/'native-decisions.jsonl',mapping,225,r)
 for arm in ['off','on']:
  d=root/f'successful-{arm}-{n}';r=read(d/'receipt.json');oracle=root/('candidate-off-control-0/replies.jsonl' if arm=='off' else 'candidate-on-probe-0/replies.jsonl');verify_stream(d,oracle,root/'native-decisions.jsonl',mapping,result['prefix_requests'],r);assert r['binary_sha256']==build['sha256']
 a=read(root/f'successful-off-{n}/receipt.json');b=read(root/f'successful-on-{n}/receipt.json');assert a['delivered']==b['delivered'];x,y=list(a['argv']),list(b['argv']);x[x.index('--mirror')+1]=y[y.index('--mirror')+1]='<input>';assert y[-2:]==['--with','capital-keeps-its-governor'];del y[-2:];assert x==y and a['cwd']==b['cwd'];x,y=copy.deepcopy(a['genome']),copy.deepcopy(b['genome'])
 for field in ['treatments','forced']:
  before,after=x.pop(field),y.pop(field);assert 'capital-keeps-its-governor' not in before and set(after)==set(before)|{'capital-keeps-its-governor'}
 assert x==y
before=[json.loads(l) for l in (root/'candidate-off-control-0/replies.jsonl').open()][:result['prefix_requests']];after=[json.loads(l) for l in (root/'candidate-on-probe-0/replies.jsonl').open()];assert len(after)==len(before)
for a,b in zip(before[:-1],after[:-1]):assert exact_fact(payload(a),payload(b))
removed=[o for o in before[-1]['orders'] if o not in after[-1]['orders']];added=[o for o in after[-1]['orders'] if o not in before[-1]['orders']];assert removed==result['removed_orders'] and added==result['added_orders'];assert {'kind':'governor_assign','subject':196609,'verb':'GOVERNOR_THE_RESOURCE_MANAGER','x':0,'y':-1} in removed
proof=read(root/'native-loss-proof.json');blob=(root/'native-192352-through90.jsonl.gz').read_bytes();raw=gzip.decompress(blob);assert sha(blob)==proof['raw_prefix']['sha256_gzip'] and sha(raw)==proof['raw_prefix']['sha256_uncompressed'];events=[json.loads(l) for l in raw.splitlines()];states={(e['turn'],e['frame']):e for e in events if e.get('kind')=='state'};record=next(json.loads(l) for l in (root/'native-decisions.jsonl').open() if [json.loads(l)['decision'][k] for k in ['turn','frame']]==[69,0]);last=expanded(record['input_capture'],mapping)[-1];pre=next(json.loads(l) for l in reversed(last.splitlines()) if json.loads(l).get('kind')=='state');assert exact_fact(pre,states[(69,0)]);capital=next(c for c in pre['cities'] if c['id']==65536);assert capital['loyalty']==96.3125 and capital['loyalty_per_turn']==-0.515625 and capital['original_capital'] and capital['original_owner']==0;assert any(g['city']==65536 and g['type']=='GOVERNOR_THE_RESOURCE_MANAGER' for g in pre['governors']);assert record['decision']['city_ids']['196609']==51;assert all(e in events for e in proof['host_governor_reports']);assert any(r.get('civ')=='CIVILIZATION_FREE_CITIES' and proof['free_city_identity'] in r['cities'] for r in states[(90,0)]['minors']);assert proof['free_city_identity']['original_owner']==0 and proof['free_city_identity']['original_capital']
negative=root/'safe-capital-native-193444'
if (negative/'candidate-results.json').exists():
 nc,nm=verify_native(negative,344);nr=read(negative/'candidate-results.json');assert nr['passed']
 for n in range(2):
  for arm in ['off','on']:
   d=negative/f'successful-{arm}-{n}';receipt=read(d/'receipt.json');verify_stream(d,negative/'policy-window-reference-0/replies.jsonl',negative/'native-decisions.jsonl',nm,344,receipt);assert receipt['binary_sha256']==build['sha256']
  a=read(negative/f'successful-off-{n}/receipt.json');b=read(negative/f'successful-on-{n}/receipt.json');assert a['genome']==nc['actual_genome'] and a['delivered']==b['delivered'];x,y=list(a['argv']),list(b['argv']);x[x.index('--mirror')+1]=y[y.index('--mirror')+1]='<input>';assert y[-2:]==['--with','capital-keeps-its-governor'];del y[-2:];assert x==y and a['cwd']==b['cwd'];x,y=copy.deepcopy(a['genome']),copy.deepcopy(b['genome'])
  for field in ['treatments','forced']:
   before,after=x.pop(field),y.pop(field);assert 'capital-keeps-its-governor' not in before and set(after)==set(before)|{'capital-keeps-its-governor'}
  assert x==y
report={'independently_verified':True,'source_run':source['run'],'original_controls':{'repetitions':2,'requests_each':225},'corrected_reference_queries':{'repetitions':2,'second_matches_first_full_payload':True,'requests_each':225},'candidate_off_full_controls':{'repetitions':2,'requests_each':225},'first_difference':[69,0],'prefix_requests':result['prefix_requests'],'successful_prefix_pairs':2,'actual_eof_exits':0,'removed_orders':removed,'added_orders':added,'isolated_governor_only_change':result['isolated_governor_only_change'],'native_pre_state_bound_to_actual_captured_last_read':True,'native_governor_moves_and_later_free_city_identity_verified':True,'safe_native_control':read(negative/'candidate-results.json') if (negative/'candidate-results.json').exists() else None,'scope':'Actual original native loss plus captured-input proposal intervention; no continued ON world, saved-capital or strength claim.'};(root/'independent-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['independently_verified','first_difference','prefix_requests','isolated_governor_only_change','scope']}))
