from pathlib import Path
import json,hashlib,tarfile,lzma,sys,copy,subprocess,os,shutil
root=Path(__file__).parent.resolve();repo=Path.home()/'civvis-capital-keeps-its-governor-e6de';sys.path.insert(0,str(Path.home()/'civvis-main-managed/tools'));import civ6_captured_read_replay as replay
subprocess.run(['taskpolicy','-B','-p',str(os.getpid())],check=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def filehash(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def same(a,b):
 with a.open('rb') as x,b.open('rb') as y:
  while True:
   u,v=x.read(1024*1024),y.read(1024*1024)
   if u!=v:return False
   if not u:return True
out=root/'successful-prefix-pairs';out.mkdir(exist_ok=True);result=json.loads((root/'candidate-results.json').read_text())
for n in range(2):
 arms=[];last_reads=None
 for arm in ['off','on']:
  d=root/f'successful-{arm}-{n}';r=json.loads((d/'receipt.json').read_text());last=json.loads(list((d/'replies.jsonl').open())[-1]);capture=copy.deepcopy(last['input_capture']);capture['directory']=r['capture_directory_map'][capture['directory']];reads=replay.expanded_reads(capture)
  if last_reads is not None:assert reads==last_reads
  last_reads=reads;arms.append({'arm':arm,'argv':r['argv'],'exit':r['exit'],'genome':r['genome'],'payload':last})
 unique=[];seen=[]
 for blob in last_reads:
  if any(blob==b for b in seen):continue
  seen.append(blob);unique.append({'complete':True,'sha256':sha(blob),'bytes':len(blob),'arms':arms})
 pair={'complete':True,'prefix_requests':result['prefix_requests'],'through_request':[69,0],'scope':'Successful persistent paired prefixes with actual EOF0. Reads list distinct byte versions in final request; raw receipts bind their order/count and every preceding request. No continued ON world or strength claim.','reads':unique};(out/f'pair-{n}.json').write_text(json.dumps(pair,indent=2)+'\n')
(root/'policy-window-reference-build.json').write_bytes((root.parent/'native-policy-window/candidate-build.json').read_bytes())
(root/'README.txt').write_text('''capital-keeps-its-governor: captured native proposal proof, default OFF.

Run: python3 verify.py --root . --repo /path/to/CIVVIS
Requires repository tools available in the pinned/current CIVVIS checkout.
The verifier reconstructs raw read bytes/count/order one request at a time,
checks native canonical receipt hashes, per-arm full orders/decision payloads,
argv/genome parity, actual EOF receipts, source exports and the native loss.
The safe-capital-native-193444 folder holds an unchanged negative control.

Observed native binaries are not bundled. Their exact argv/cwd, on-disk
SHA256 and observed provenance are preserved. The constructed candidate's
source exports, compiler/profile, immutable executable SHA256 and checkpoint
are in candidate-build.json. The verifier checks executable bytes when they
are available locally; an extracted archive alone does not execute a binary.
The two original native controls retain their original full payload oracle.
Two separately constructed policy-window reference queries account for #4430;
the second repeats the first, then two new candidate-OFF controls match it.
Both ON probes first differ69/0; four successful prefix runs exit0 and remove
only Magnus's governor_assign to Caracas. They do not continue an ON world.

The raw original native loss reaches Free Cities ownership at90/0. It is not
proof withholding a transfer would save the capital. A source-index/path map
retains original absolute observations while verify.py resolves packaged
captures under its supplied root. Equal files may be stored as tar hardlinks
after SHA256 AND exact streaming byte equality; no raw data is rewritten.
''')
roots=['source-exports','successful-prefix-pairs','source-capture-0','original-control-0','original-control-1','policy-window-reference-0','policy-window-reference-1','candidate-off-control-0','candidate-off-control-1','candidate-on-probe-0','candidate-on-probe-1','successful-off-0','successful-off-1','successful-on-0','successful-on-1','safe-capital-native-193444']
names=['README.txt','original-controls.py','query-prefix.py','qualify-candidate.py','verify.py','build-evidence.py','audit-cohort.py','frozen-intent.json','candidate-build.json','candidate-results.json','independent-verification.json','observed-context.json','native-decisions.jsonl','sealed-captures.json','native-loss-proof.json','raw-receipt.json','cohort-transfer-audit.json','shipped-governor-rule.txt','native-192352-through90.jsonl.gz','original-controls.json','policy-window-reference-context.json','policy-window-reference-build.json','candidate-off-context.json','candidate-on-context.json','focused-rust-tests.log','full-rust-suite.log','rust-quality.log','native-build.log','candidate-qualification.log','independent-verification.log']
paths={root/n for n in names}
for n in roots:
 p=root/n;assert p.is_dir(),p;paths.update(v for v in p.rglob('*') if v.is_file())
for s in json.loads((root/'sealed-captures.json').read_text()):paths.update(v for v in Path(s['sealed_directory']).rglob('*') if v.is_file())
assert all(p.is_file() and not p.is_symlink() and p.is_relative_to(root) for p in paths)
manifest={'original_root':str(root),'scope':'Raw captured-input proposal proof and safe negative control; no continued candidate world, saved capital, or strength inference.','files':{str(p.relative_to(root)):{'sha256':filehash(p),'bytes':p.stat().st_size} for p in sorted(paths)}};(root/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');paths.add(root/'archive-manifest.json');archive=repo/'docs/eval/2026-11-04-capital-keeps-its-governor.native.tar.xz';assert not archive.exists();duplicates={};links=0
with lzma.LZMAFile(archive,'w',format=lzma.FORMAT_XZ,filters=[{'id':lzma.FILTER_LZMA2,'preset':6,'dict_size':64*1024*1024}]) as compressed:
 with tarfile.open(fileobj=compressed,mode='w|') as tar:
  for p in sorted(paths):
   name=str(p.relative_to(root));info=tar.gettarinfo(str(p),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;digest=filehash(p);old=duplicates.get(digest)
   if old and same(p,old):info.type=tarfile.LNKTYPE;info.linkname=str(old.relative_to(root));info.size=0;tar.addfile(info);links+=1
   else:
    with p.open('rb') as f:tar.addfile(info,f)
    duplicates[digest]=p
receipt={'archive':str(archive),'sha256':filehash(archive),'bytes':archive.stat().st_size,'members':len(paths),'exact_duplicate_hardlinks':links};(root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
