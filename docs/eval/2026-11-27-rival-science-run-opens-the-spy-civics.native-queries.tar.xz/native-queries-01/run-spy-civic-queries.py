"""Paired decider queries on live frames of four T8 benchmark games of
2026-11-26/27 (Lv 8 Deity 6p, Online, Diplo off, Religion seats) lost to a
rival's Science Victory with launches 0/4 against 4/4. Each seat held Guilds
and Reformed Church by t81-95 but took Diplomatic Service (its first Spy slot)
only at t115-138, the civic slot spending the turns between on the government
ladder or the ordinary argmax.

`rival-science-run-opens-the-spy-civics` is the only bit that varies. Each case
is a live run's own events.jsonl cut after turn N+1, replayed at turn N, a turn
on which the live seat adopted a civic other than Diplomatic Service. Both arms
run one frozen `civvis_orders --resumed` built from the branch, with that run's
own requested genome (why.log line 1 `forced`, each as `--with`); the on arm
adds `--with rival-science-run-opens-the-spy-civics`.

Read per arm: the civic order. This records proposal activation on captured
live input only. It does not execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'rival-science-run-opens-the-spy-civics'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

GAMES = [
    ('civvis-t8-20261126T123528Z', 'religious', 'CIVILIZATION_ETHIOPIA', [99]),
    ('civvis-t8-20261126T162529Z', 'religious', 'CIVILIZATION_ETHIOPIA', [92, 99]),
    ('civvis-t8-20261127T034217Z', 'religious', 'CIVILIZATION_RUSSIA', [91, 92, 93, 95, 97]),
    ('civvis-t8-20261127T041052Z', 'religious', 'CIVILIZATION_RUSSIA', [91, 92, 93, 94, 96]),
]
CASES = [{'run': r, 'victory': v, 'civ': c, 'turn': t} for r, v, c, turns in GAMES for t in turns]


def cut(run, turn):
    """Rows through turn N's first state row: the frame on which the live
    civic slot was empty (the turn's later rows already carry the pick)."""
    rows, last = [], None
    with open(RUNS / run / 'events.jsonl', errors='replace') as f:
        for line in f:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > turn:
                break
            rows.append(line)
            if e.get('kind') == 'state' and e.get('turn') == turn:
                last = e
                break
    if last is None or last.get('civic') is not None:
        raise ValueError('turn N does not open on an empty civic slot')
    return ''.join(rows).encode(), last


def civics(row):
    """Civic orders, in order."""
    return [o.get('verb') for o in row.get('payload', {}).get('orders', [])
            if o.get('kind') == 'civic']


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data, last = cut(case['run'], case['turn'])
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'cut': 'through turn N first state row'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                  'board': {'cities': len((last or {}).get('cities', []))},
                  'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', case['victory'], '--civ', case['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=600)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if GENE + ':' in line]
            row['civics'] = civics(row)
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['civic_changed'] = off['civics'] != on['civics']
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
             'civic_changed_reads': sum(bool(v.get('civic_changed')) for r in results
                                        for v in r['reads']),
             'on_diplomatic_service': sum('CIVIC_DIPLOMATIC_SERVICE' in v['arms'][1].get('civics', [])
                                          for r in results for v in r['reads']),
             'off_diplomatic_service': sum('CIVIC_DIPLOMATIC_SERVICE' in v['arms'][0].get('civics', [])
                                           for r in results for v in r['reads'])}
    for r in results:
        c = r['case']
        if r.get('error'):
            print(c['run'], c['turn'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            off, on = v['arms']
            print(f"{c['run'][-16:]} t{c['turn']:<3} {'CHANGED' if v.get('orders_changed') else 'same   '} "
                  f"civic off {off.get('civics')} on {on.get('civics')}")
            for line in on.get('journal_gene', [])[:2]:
                print('      ', line[:230])
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
