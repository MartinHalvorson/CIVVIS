from pathlib import Path
import copy,json,subprocess,sys
r=Path(__file__).parent;sys.path.insert(0,str(r/'native-witness'))
from civ6_decision_trace import captured_input,validate_input_capture,exact_fact
subprocess.run([sys.executable,str(r/'native-witness/verify-witness.py')],check=True)
load=lambda p:json.loads(p.read_text());control=r/'legacy-cold-controls';result=load(control/'result.json');assert result['complete'] and result['all_control_research_matches_historical'];data=(r/'native-witness/input.events.jsonl').read_bytes();reference=None
for row in result['rows']:
 d=control/f"repeat-{row['repeat']}";p=load(d/'stdout.json');c=copy.deepcopy(p['input_capture']);oldroot=Path(row['argv'][row['argv'].index('--capture-inputs')+1]);c['directory']=str(d/'capture'/Path(c['directory']).relative_to(oldroot));validate_input_capture(c);reads=[]
 for x in c['reads']:reads.extend([captured_input(c,x['snapshot_id'])]*x['count'])
 assert len(reads)==row['actual_reads']==17 and all(b==data for b in reads)
 assert p['decision']['victory_portfolio']['assigned_target']=='science' and (p['decision']['turn'],p['decision']['frame'])==(16,0)
 assert [o['verb'] for o in p['orders'] if o['kind']=='research']==['TECH_SAILING']
 g=None
 for line in (d/'stderr.log').read_text().splitlines():
  try:x=json.loads(line)
  except ValueError:continue
  if x.get('kind')=='genome':g=x;break
 assert g is not None and all(exact_fact(g.get(k),v) for k,v in row['genome'].items())
 assert all('science-writing-before-the-luxury' in g[k] for k in ['forced','treatments'])
 stable={k:p[k] for k in ['orders','decision']}
 if reference is None:reference=stable
 else:assert exact_fact(reference,stable)
print('Historical18readwitnessandboth17readoriginal-binarycoldcontrolsverified;nochangedcandidatequeried')
