from pathlib import Path
import copy,json,hashlib
from civ6_decision_trace import captured_input,validate_input_capture
r=Path(__file__).parent;load=lambda p:json.loads(p.read_text());rec=load(r/'native-record.json')
unsigned={k:v for k,v in rec.items() if k!='sha256'};assert hashlib.sha256(json.dumps(unsigned,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()==rec['sha256']
c=copy.deepcopy(rec['input_capture']);c['directory']=str(r/'sealed/source-capture-0');validate_input_capture(c);reads=[]
for x in c['reads']:reads.extend([captured_input(c,x['snapshot_id'])]*x['count'])
assert len(reads)==18 and all(b==reads[0] for b in reads) and reads[0]==(r/'input.events.jsonl').read_bytes()
s=next(e for line in reversed(reads[0].splitlines()) if (e:=json.loads(line)).get('kind')=='state');assert (s['turn'],s['frame'])==(16,0) and len(s['cities'])==1
assert 'TECH_POTTERY' in s['techs'] and 'TECH_WRITING' not in s['techs']
assert next(t for t in s['research_tree'] if t['t']=='TECH_WRITING')=={'can_research':True,'requires':['TECH_POTTERY'],'t':'TECH_WRITING'}
assert {'c':25,'p':0,'t':'TECH_WRITING'} in s['research_quotes']
g=load(r/'observed-context.json')['actual_genome'];assert all('science-writing-before-the-luxury' in g[k] for k in ['forced','treatments'])
assert rec['decision']['victory_portfolio']['assigned_target']=='science'
a=rec['decision']['native_actions'];research=next(i for i,x in enumerate(a) if x.get('type')=='research' and x.get('tech')=='sailing');found=next(i for i,x in enumerate(a) if x.get('type')=='found_city');assert research<found
n=load(r/'next-state.json');assert (n['turn'],n['frame'])==(16,1) and len(n['cities'])==2
print('Verified18actualreads:WritingofferedwithPotteryandonecity,Sailingchosenbeforecitytwofounded')
