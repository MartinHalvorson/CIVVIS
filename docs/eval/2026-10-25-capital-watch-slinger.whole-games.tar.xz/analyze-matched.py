"""Audit all registered model worlds without assigning causal strength to sampling."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
TAG = 'capital-watch-arms-the-slinger'


def load(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def without_seconds(row):
    return {key: value for key, value in row.items() if key != 'secs'}


def main():
    records = [json.loads(line) for line in (BASE / 'native-profile-proxy.jsonl').read_text().splitlines()]
    header, original = records[0], records[1:]
    assert len(original) == 32
    index = header['genes'].index(TAG)
    results = []
    for game in range(8):
        arms = {arm: BASE / f'matched-{game:02d}-{arm}' for arm in ('off', 'on')}
        contracts = {arm: load(path / 'contract.json') for arm, path in arms.items()}
        off, on = contracts['off'], contracts['on']
        measured = off['measured_seat']
        differences = [(seat, bit) for seat, (a, b) in enumerate(zip(off['genomes'], on['genomes']))
                       for bit, (x, y) in enumerate(zip(a, b)) if x != y]
        assert differences == [(measured, index)], differences
        rows = [row for row in original if row['game'] == game]
        assert len(rows) == 4 and {row['seat'] for row in rows} == set(range(4))
        sampled = next(row for row in rows if row['seat'] == measured)
        sampled_arm = 'on' if sampled['genome'][index] == '1' else 'off'
        replayed = load(arms[sampled_arm] / 'rows.json')
        assert sorted(map(without_seconds, rows), key=lambda r: r['seat']) == sorted(
            map(without_seconds, replayed), key=lambda r: r['seat']), game
        observations = {}
        for name in ('initial-game.json', 'trace.jsonl', 'terminal-game.json'):
            observations[name] = {'equal': (arms['off'] / name).read_bytes() == (arms['on'] / name).read_bytes(),
                                  'sha256': {arm: digest(path / name) for arm, path in arms.items()}}
        assert observations['initial-game.json']['equal'], 'different starting worlds'
        policies = {arm: [json.loads(line) for line in (path / 'policy-journal.jsonl').read_text().splitlines()]
                    for arm, path in arms.items()}
        result = {'game': game, 'seed': off['seed'], 'measured_seat': measured,
                  'only_genome_difference': differences, 'sampled_arm': sampled_arm,
                  'original_all_four_rows_reproduced_except_secs': True,
                  'observations': observations, 'policy_journals': policies,
                  'journal_status': {arm: load(path / 'journal-status.json') for arm, path in arms.items()},
                  'measured_rows': {arm: next(row for row in load(path / 'rows.json') if row['seat'] == measured)
                                    for arm, path in arms.items()}}
        results.append(result)
    output = {'scope': 'Eight registered matched model worlds. All rival genomes fixed; only the measured bit varies. Not Native execution or a Native win.',
              'build': header['build'], 'games': results,
              'equal_full_traces': sum(row['observations']['trace.jsonl']['equal'] for row in results),
              'equal_terminal_worlds': sum(row['observations']['terminal-game.json']['equal'] for row in results),
              'observed_policy_entries': {arm: sum(len(row['policy_journals'][arm]) for row in results) for arm in ('off', 'on')},
              'max_journal_dropped': max(row['journal_status'][arm]['maximum_dropped'] for row in results for arm in ('off', 'on'))}
    (BASE / 'matched-comparison.json').write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({key: value for key, value in output.items() if key != 'games'}))


if __name__ == '__main__':
    main()
