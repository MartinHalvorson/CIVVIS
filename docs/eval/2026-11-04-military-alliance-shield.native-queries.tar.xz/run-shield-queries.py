"""Paired decider queries on captured live boards for `military-alliance-shield`.

`military-alliance-shield` is the only bit that varies. Every case is a turn of
live Deity Korea Science `civvis-20261104T213449Z` (Online), read from that
run's own `events.jsonl` (byte-identical input for both arms; its sha256 is
recorded). Both arms run one frozen ci-profile `civvis_orders` built from the
branch with the run's own requested genome (`summary.json` `forced`, each as
`--with`); the on arm adds `--with military-alliance-shield`. Turns are the
seat's border-arm cadence (turn % 3 == 0) from Civil Service (t63). From
Scientific Theory (t107) the seat's own Research Alliance is legal and
`science-seat-allies` carries it to the host, so the border arm waits for it:
t108-t150 are the control that the gene leaves the lane's ask alone.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim. A fresh decider reads each turn
in isolation (no memory of earlier asks).
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'military-alliance-shield'
RUN = 'civvis-20261104T213449Z'
TURNS = list(range(63, 106, 3)) + list(range(108, 151, 3))
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

RUN_DIR = Path.home() / 'civvis-civ6-runs/control' / RUN


def one(index, turn, data, digest, forced):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    case = {'run': RUN, 'turn': turn, 'input': 'events.jsonl'}
    result = {'index': index, 'case': case, 'reads': []}
    try:
        record = {'descriptor': case, 'bytes': len(data), 'sha256': digest, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', 'science',
                   '--turn', str(turn)]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=600)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]') and 'Alliance' in line]
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
        off, on = record['arms']
        alliances = lambda arm: [o for o in arm.get('payload', {}).get('orders', [])
                                 if o.get('kind') == 'alliance']
        record['off_alliance_orders'] = alliances(off)
        record['on_alliance_orders'] = alliances(on)
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    for arm in ('off', 'on'):
        for suffix in ('.stdout', '.stderr'):
            path = root / (arm + suffix)
            if path.exists():
                path.unlink()
    return result


def main():
    OUT.mkdir(parents=True)
    summary = json.loads((RUN_DIR / 'summary.json').read_text())
    forced = list(summary['forced'])
    if GENE in forced:
        raise SystemExit('the live genome already carried the gene')
    data = (RUN_DIR / 'events.jsonl').read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'run': RUN, 'turns': TURNS,
        'input_sha256': digest, 'input_bytes': len(data),
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, t, data, digest, forced) for i, t in enumerate(TURNS)]
    rows = []
    for r in results:
        for v in r['reads']:
            rows.append({'turn': r['case']['turn'], 'complete': v.get('complete'),
                         'changed': v.get('orders_changed'),
                         'off': [(o.get('verb'), o.get('subject')) for o in v.get('off_alliance_orders', [])],
                         'on': [(o.get('verb'), o.get('subject')) for o in v.get('on_alliance_orders', [])]})
        if r.get('error'):
            rows.append({'turn': r['case']['turn'], 'error': r['error']})
    out = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
           'changed_order_reads': sum(bool(x.get('changed')) for x in rows), 'rows': rows}
    (OUT / 'summary.json').write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=1))


if __name__ == '__main__':
    main()
