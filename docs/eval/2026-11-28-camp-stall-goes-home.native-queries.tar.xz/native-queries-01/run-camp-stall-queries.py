"""Paired decider queries on the recorded boards of hotseat game
hotseat-20261128T031456Z (2026-11-27, 6 players, Small Continents, a person
in seat 0 and five CIVVIS seats), for `camp-stall-goes-home`.

`camp-stall-goes-home` is the only bit that varies. The gene reads a stall
over turns (three turns of a ClearCamp party beside a guarded camp without a
blow), so a one-shot `--resumed` query, which starts a fresh agent, cannot
show it. Each case therefore replays a seat's own events.jsonl, cut after
turn N+1, through one persistent decider the way the hotseat brain runs it
(`--serve --fresh-board --explain --victory V --civ C`, the seat's own
genome: forced none, as its brain.log line 1 records), asking for every turn
from S to N in order, every frame of each turn: before frame k of turn t is
asked, the mirror's events.jsonl is rewritten to the seat's own rows up to
the next `state` record after frame k's (through turn N for the last), so
the decider reads each board as the live decider did (the bytes and digest
recorded are the final cut, through turn N). The on arm adds
`--with camp-stall-goes-home`. The payload recorded is the reply to turn N's
last frame; every frame's orders are kept beside it (`frame_orders`).

Cases:
- stall: seat p4 (Phoenicia, domination), turns 1..N for N = 13..16. Its
  Warriors stood within two tiles of the Spearman's camp at civ6 (45,20)
  from turn 10 and struck no blow. The on arm should close the camp's row
  from turn 13 and send the party elsewhere.
- control: seat p4 turns 1..9 (the camp's guard unseen, no stall), and
  seat p2 (Poland, culture) turns 1..14 (no ClearCamp row in its journal). The on arm
  should change nothing.
- camp: seat p3 (Cree, science) turns 1..16, whose board held a ClearCamp
  row for the camp at civ6 (11,6) from turn 13; read, not predicted.

Read per arm: the orders, the unit move orders, and the gene's journal lines.
This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
RUN = Path(sys.argv[4])
GENE = 'camp-stall-goes-home'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

SEATS = {
    'p4': ('domination', 'CIVILIZATION_PHOENICIA'),
    'p2': ('culture', 'CIVILIZATION_POLAND'),
    'p3': ('science', 'CIVILIZATION_CREE'),
}
CASES = (
    [{'seat': 'p4', 'expect': 'stall', 'first': 1, 'turn': n} for n in (13, 14, 15, 16)]
    + [{'seat': 'p4', 'expect': 'control', 'first': 1, 'turn': 9},
       {'seat': 'p2', 'expect': 'control', 'first': 1, 'turn': 14},
       {'seat': 'p3', 'expect': 'camp', 'first': 1, 'turn': 16}]
)


def seat_lines(seat):
    return (RUN / f'{RUN.name}-{seat}' / 'events.jsonl').read_text(errors='replace').splitlines(True)


def frame_cuts(seat, first, last):
    """(turn, bytes) per frame of turns first..last, in order."""
    lines = seat_lines(seat)
    kinds = []
    for line in lines:
        try:
            e = json.loads(line)
        except ValueError:
            kinds.append((None, None))
            continue
        kinds.append((e.get('kind'), e.get('turn') or 0))
    states = [i for i, (kind, _) in enumerate(kinds) if kind == 'state']
    cuts = []
    for n, i in enumerate(states):
        turn = kinds[i][1]
        if turn < first or turn > last:
            continue
        end = states[n + 1] if n + 1 < len(states) else len(lines)
        if n + 1 >= len(states) or kinds[states[n + 1]][1] > last:
            end = next((j for j in range(i, len(lines)) if (kinds[j][1] or 0) > last), len(lines))
        cuts.append((turn, ''.join(lines[:end]).encode()))
    return cuts


def cut(seat, turn):
    """The seat's rows through `turn`."""
    rows = []
    with (RUN / f'{RUN.name}-{seat}' / 'events.jsonl').open(errors='replace') as f:
        for line in f:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > turn:
                break
            rows.append(line)
    return ''.join(rows).encode()


def unit_orders(payload):
    return [o for o in (payload or {}).get('orders', []) if o.get('kind') == 'unit']


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        victory, civ = SEATS[case['seat']]
        frames = frame_cuts(case['seat'], case['first'], case['turn'])
        turns = [turn for turn, _ in frames]
        data = frames[-1][1]
        record = {'descriptor': {'run': RUN.name, 'seat': case['seat'], 'turns':
                                 [case['first'], case['turn']], 'cut': 'through turn',
                                 'mode': 'serve, one persistent decider, the log grown and '
                                         'every frame asked in order'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            cmd = [str(BINARY), '--mirror', str(mirror), '--serve', '--fresh-board',
                   '--explain', '--victory', victory, '--civ', civ]
            if arm == 'on':
                cmd += ['--with', GENE]
            stderr = root / (arm + '.stderr')
            started = time.monotonic()
            replies = []
            with stderr.open('wb') as err:
                process = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                           stderr=err, text=True, bufsize=1)
                for t, frame in frames:
                    (mirror / 'events.jsonl').write_bytes(frame)
                    process.stdin.write(f'{t}\n')
                    process.stdin.flush()
                    line = process.stdout.readline()
                    if not line:
                        break
                    replies.append(json.loads(line))
                process.stdin.close()
                process.wait(timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'stdin_turns': turns, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0 and len(replies) == len(turns):
                row['payload'] = replies[-1]
                row['frame_orders'] = [[t, r.get('orders')] for t, r in zip(turns, replies)]
            else:
                row['replies'] = len(replies)
                row['stderr_tail'] = stderr.read_text(errors='replace')[-2000:]
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if GENE + ':' in line]
            row['unit_orders'] = len(unit_orders(row.get('payload')))
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
             'on_gene_lines': 0, 'off_gene_lines': 0}
    for r in results:
        c = r['case']
        if r.get('error'):
            print(c, 'ERROR', r['error'])
            continue
        for v in r['reads']:
            off, on = v['arms']
            total['on_gene_lines'] += len(on.get('journal_gene', []))
            total['off_gene_lines'] += len(off.get('journal_gene', []))
            print(f"{c['seat']} t{c['first']}-{c['turn']:<3} {c['expect']:<8} "
                  f"{'CHANGED' if v.get('orders_changed') else 'same   '} "
                  f"unit orders off {off.get('unit_orders')} on {on.get('unit_orders')} "
                  f"gene lines on {len(on.get('journal_gene', []))} off {len(off.get('journal_gene', []))} "
                  f"exit {off.get('exit')}/{on.get('exit')}")
            for line in on.get('journal_gene', [])[:3]:
                print('      ', line[:300])
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
