#!/usr/bin/env python3
"""A gene that cannot fire is not a null, and this is the CI ratchet that says so.

★★★★ THE SIGNATURE WAS ALREADY WRITTEN DOWN; NOTHING CHECKED FOR IT.

`docs/GENE_SCREEN.md` records it in a section of its own -- *"A Δ of exactly
zero is a gene that never fired, not a null"*. A retired host-only flag screened
**+0.0 [+0.0, +0.0]** on both axes over 204 pairs because its only code path
lived on a parallel unit planner no evaluator installed, so every pair's two
games ended identically. `treatment_flags.rs` carries the same warning from the
other direction: a repair gene whose enable is missing from
the bundle is off in BOTH arms, "the two arms play byte-identical games", and
*"three tags reached the tables before this line and burned 30 games saying
nothing"*. `competition-victory-points` is in the tables today and cannot fire
at all, because `native_competitions` ships off.

Four instruments already implement a fires-check for themselves -- `ai_eval`'s
"nothing differed" note, `battle_bench` and `doctrine_arena`'s `diverged`
counts, and `gene_census`, whose docstring states the principle: *does this gene
change anything at all -- which is far cheaper to establish than a win rate and
is a precondition for the win rate meaning anything*. What was missing is a
**gate**. Nothing stopped a tag reaching the three gene tables with no evidence
it fires, and nothing failed when a committed screen contained a zero-width row.
A gene in that state consumes screen games and returns nothing.

So: **every gene in the tables must be shown to have fired in at least one game,
or carry a waiver that says why it has not been.** `--max 0` is the CI ratchet,
in the shape `civvis_inert.py --max 0` already runs at.

WHAT COUNTS AS PROOF, and why it is read rather than asserted
-------------------------------------------------------------
The gate retains its historical acceptance of a screen JSON row with any
non-zero statistic. That rule alone does not establish activation when games
draw treatment independently: seed and seat variation can create a contrast
without a changed policy action. A matched action comparison is stronger.

`captured_native_action_pairs_v1` artifacts can instead name a hash-bound
archive and raw result members. The gate checks complete, successful queries,
a shared captured-input digest, identical observed genomes and command lines
except the named bit, and a changed proposed order. Journal text or a claimed
changed count cannot pass. This proves recorded proposal activation, not host
execution, a whole-game effect, or strength. Probes remain outside the ledger.

⚠ A gene priced by a MULTI-gene screen is proven too, but for a weaker reason:
its arms differ on other genes as well, so a non-zero contrast there is not
attributable. It is still evidence the tag reached an analysis with real
variance, and every such gene here also has non-zero variance in its own row.
The single-gene probe is what a NEW gene should bring.

WHAT A WAIVER IS FOR
--------------------
`tools/gene_fire_waivers.json`, in the shape of `tools/inert_waivers.json`: a
flat `{tag: reason}` map. Two kinds of entry live there and the reasons say
which -- a gene that predates this gate and has not been screened yet, and a
gene that genuinely cannot fire in the regime the screen plays. Unlike
`inert_waivers.json` the reason is enforced: it must be long enough to be a
reason. A waiver goes **stale** the moment its gene is proven or leaves the
tables, and a stale waiver fails the same ratchet -- so the list can only
shrink, and cannot quietly outlive what it was written for.

Usage:
    python3 tools/gene_fires.py                # report
    python3 tools/gene_fires.py --max 0        # CI ratchet
    python3 tools/gene_fires.py --json         # machine-readable
    python3 tools/gene_fires.py --prune-proven # delete waivers a screen proves
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import tarfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
import genes  # noqa: E402

REGISTRY = ROOT / genes.REGISTRY
SCREENS = ROOT / "docs" / "gene_screens"
WAIVERS = Path(__file__).resolve().parent / "gene_fire_waivers.json"

# Historical statistics accepted by the gate. With an independent treatment
# draw, variation here alone does not prove a changed policy action.
STATISTICS = ("win_delta_pp", "win_se_pp", "share_delta_pp", "share_se_pp",
              "adjusted_se_pp")

# Long enough to be a reason rather than a shrug. `test_ci_wiring.py` uses the
# same bar for `CANNOT_RUN_IN_CI`.
REASON_CHARACTERS = 40


def captured_action_pair_fired(artifact: dict[str, Any]) -> bool:
    """Check recorded same-input proposals, never claim a host effect or win.

    The archive is hash-bound and read without extraction. Inspect the raw
    decider results rather than trusting a declared changed/fired boolean.
    Both observed genomes and arguments must vary only the named gene; mirror
    directory names may differ because each arm uses a disposable copy.
    """
    def require(condition):
        if not condition:
            raise ValueError("paired-query controls do not match")

    try:
        tag = artifact["tag"]
        require(isinstance(tag, str) and tag)
        spec = artifact["archive"]
        relative = Path(spec["path"])
        require(not relative.is_absolute() and ".." not in relative.parts)
        path = (ROOT / relative).resolve()
        require(path.is_relative_to(ROOT.resolve()))
        require(hashlib.sha256(path.read_bytes()).hexdigest() == spec["sha256"])
        names = artifact["members"]
        require(isinstance(names, list) and names and len(names) == len(set(names)))
        changed = False
        with tarfile.open(path, "r:*") as archive:
            for name in names:
                member = archive.getmember(name)
                require(member.isfile() and member.size <= 16 * 1024 * 1024)
                record = json.load(archive.extractfile(member))
                require(record["complete"] is True and record["reads"])
                for read in record["reads"]:
                    require(read["complete"] is True)
                    require(re.fullmatch(r"[0-9a-f]{64}", read["sha256"]))
                    require(type(read["bytes"]) is int and read["bytes"] > 0)
                    arms = read["arms"]
                    require(len(arms) == 2 and {a["arm"] for a in arms} == {"off", "on"})
                    off, on = [next(a for a in arms if a["arm"] == arm) for arm in ("off", "on")]
                    for arm in arms:
                        require(type(arm["exit"]) is int and arm["exit"] == 0)
                        require(isinstance(arm["payload"]["orders"], list))
                    genomes = [dict(a["genome"]) for a in (off, on)]
                    for field in ("treatments", "forced"):
                        before, after = [g.pop(field) for g in genomes]
                        require(isinstance(before, list) and isinstance(after, list))
                        require(all(isinstance(t, str) for t in before + after))
                        require(len(set(before)) == len(before) and len(set(after)) == len(after))
                        require(tag not in before and tag in after)
                        require(set(after) - {tag} == set(before))
                    require(genomes[0] == genomes[1])

                    def arguments(arm):
                        args = list(arm["argv"])
                        require(args and args.count("--mirror") == 1)
                        index = args.index("--mirror")
                        require(index + 1 < len(args))
                        args[index + 1] = "<same-captured-input>"
                        if arm["arm"] == "on":
                            matches = [i for i in range(len(args) - 1)
                                       if args[i:i + 2] == ["--with", tag]]
                            require(len(matches) == 1)
                            del args[matches[0]:matches[0] + 2]
                        return args

                    require(arguments(off) == arguments(on))
                    changed |= off["payload"]["orders"] != on["payload"]["orders"]
        return changed
    except (KeyError, TypeError, ValueError, OSError, tarfile.TarError) as error:
        raise SystemExit(f"invalid captured action-pair evidence: {error}") from error


def gene_tables() -> dict[str, str]:
    """Every gene `gene_screen` can vary, tag -> the kind of registry row it is.

    ⚠ Discovered, never listed. This is `gene_screen::gene_table` in Python:
    every screenable row of the gene registry (`src/ai/advanced/genes.rs`). A
    gene added there reaches this gate without touching this file, which is
    the whole point -- a hand-written list here would be complete on the day
    it was written and silently shrink afterwards.
    """
    try:
        rows = genes.genes_from_text(REGISTRY.read_text(encoding="utf-8"))
    except (ValueError, IndexError) as error:
        raise SystemExit(f"{REGISTRY} yielded no registry rows; the scrape broke: {error}")
    return {row.tag: row.kind for row in rows if row.screenable}


def _screen_files() -> list[Path]:
    files = sorted(SCREENS.rglob("*.json"))
    if not files:
        raise SystemExit(
            f"{SCREENS} holds no screen JSON; the glob came up empty rather "
            "than finding a repository with no screens")
    return files


def firing_evidence() -> tuple[dict[str, list[str]], list[tuple[str, str]]]:
    """(tag -> screens whose row for it is non-zero, [(screen, tag) zero-width]).

    A row missing every statistic is not evidence either way and is ignored;
    a row carrying them and reading exactly zero on all five is the never-fired
    signature and is reported.
    """
    fired: dict[str, list[str]] = {}
    flat: list[tuple[str, str]] = []
    for path in _screen_files():
        try:
            screen = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as broken:
            raise SystemExit(f"{path} is not readable JSON: {broken}") from broken
        name = str(path.relative_to(SCREENS))
        if screen.get("kind") == "captured_native_action_pairs_v1":
            if captured_action_pair_fired(screen):
                fired.setdefault(screen["tag"], []).append(name)
            continue
        for row in screen.get("genes", []):
            tag = row.get("tag")
            if not tag:
                continue
            present = [row[key] for key in STATISTICS if key in row]
            if not present:
                continue
            if any(value for value in present):
                fired.setdefault(tag, []).append(name)
            else:
                flat.append((name, tag))
    return fired, flat


def waivers() -> dict[str, str]:
    if not WAIVERS.exists():
        return {}
    return json.loads(WAIVERS.read_text(encoding="utf-8"))["waivers"]


def survey() -> dict[str, Any]:
    genes = gene_tables()
    fired, flat = firing_evidence()
    waived = waivers()

    unproven = sorted(tag for tag in genes if tag not in fired and tag not in waived)
    # A waiver outlives its reason two ways, and both are failures: the gene has
    # since been shown to fire, or it is not a gene any more.
    stale = sorted(
        (tag, "now proven by " + fired[tag][0] if tag in fired else "no longer a gene")
        for tag in waived if tag in fired or tag not in genes)
    thin = sorted(tag for tag, reason in waived.items()
                  if len(reason.strip()) <= REASON_CHARACTERS)
    return {
        "genes": len(genes),
        "proven": sorted(tag for tag in genes if tag in fired),
        "unproven": unproven,
        "waived": sorted(tag for tag in genes if tag in waived),
        "stale_waivers": stale,
        "reasonless_waivers": thin,
        "zero_width_rows": flat,
        "tables": genes,
        "evidence": {tag: fired[tag] for tag in genes if tag in fired},
    }


def prune_proven_waivers() -> list[str]:
    """Delete every waiver a committed screen row now proves; return the tags.

    ⚠ A batch publication is where most of them go stale at once: the
    2026-10-25 report was the first screen with rows for 223 waived genes,
    and the ratchet failed CI on "223 waivers have outlived their reason"
    after the scheduler's own checks had passed. Only the proven kind is
    deleted here; a waiver for a gene that left the tables is a different
    change's business. The file is rewritten in its own two-space layout.
    """
    found = survey()
    proven = [tag for tag, why in found["stale_waivers"] if why.startswith("now proven by")]
    if not proven:
        return []
    raw = WAIVERS.read_text(encoding="utf-8")
    data = json.loads(raw)
    data["waivers"] = {tag: reason for tag, reason in data["waivers"].items()
                       if tag not in proven}
    WAIVERS.write_text(json.dumps(data, indent=2, ensure_ascii=False)
                       + ("\n" if raw.endswith("\n") else ""), encoding="utf-8")
    return proven


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--max", type=int, default=None,
                        help="fail when more than this many genes are unproven, "
                             "or any waiver has gone stale (CI runs --max 0)")
    parser.add_argument("--json", action="store_true",
                        help="write the survey as JSON instead of prose")
    parser.add_argument("--prune-proven", action="store_true",
                        help="delete the waivers a committed screen row now proves, then exit")
    args = parser.parse_args()
    if args.prune_proven:
        pruned = prune_proven_waivers()
        print(f"deleted {len(pruned)} waiver(s) a committed screen now proves"
              + (": " + ", ".join(pruned) if pruned else ""))
        return 0

    found = survey()
    if args.json:
        print(json.dumps({key: value for key, value in found.items()
                          if key != "tables"}, indent=2, sort_keys=True))
    else:
        print(f"{found['genes']} genes in the tables, "
              f"{len(found['proven'])} shown to fire, "
              f"{len(found['waived'])} waived, "
              f"{len(found['unproven'])} with neither")
        for tag in found["unproven"]:
            print(f"  {tag:44} no screen row and no waiver")
        for tag, why in found["stale_waivers"]:
            print(f"  stale waiver {tag:38} {why}")
        for tag in found["reasonless_waivers"]:
            print(f"  waiver too short to be a reason: {tag}")
        if found["zero_width_rows"]:
            print(f"{len(found['zero_width_rows'])} zero-width screen rows "
                  "(a gene that never fired in that run, not a null):")
            for screen, tag in found["zero_width_rows"]:
                print(f"  {tag:44} {screen}")

    if args.max is None:
        return 0
    failed = 0
    if len(found["unproven"]) > args.max:
        print(f"FAIL: {len(found['unproven'])} genes have no evidence they fire "
              f"and no waiver, which exceeds the ratchet of {args.max}. Run "
              "`gene_screen --genes <tag> --games 6`, then `--analyze … --json "
              "docs/gene_screens/fires/<tag>.json` and commit the result, or "
              "add a waiver naming the reason it cannot fire.", file=sys.stderr)
        failed = 1
    if found["stale_waivers"]:
        print(f"FAIL: {len(found['stale_waivers'])} waivers have outlived their "
              "reason and must be deleted.", file=sys.stderr)
        failed = 1
    if found["reasonless_waivers"]:
        print(f"FAIL: {len(found['reasonless_waivers'])} waivers give no reason "
              f"longer than {REASON_CHARACTERS} characters.", file=sys.stderr)
        failed = 1
    return failed


if __name__ == "__main__":
    raise SystemExit(main())
