"""Paired decider queries on live frames of the person-played hotseat game
`hotseat-20261128T031456Z` (2026-11-27, 6 players, Small Continents, Online),
on turns where a CIVVIS seat's city trained a Settler on a Food surplus of 4 or
more at a Production of 5 or less.

`settler-pump-leans-on-production` is the only bit that varies. Each case is a
CIVVIS seat's own `events.jsonl` (`hotseat-20261128T031456Z-p<N>/`) cut after
turn N+1, replayed at turn N. Both arms run one `civvis_orders --resumed` built
from the branch by the `hotseat-bundle` workflow (macOS arm64, release profile
with LTO off), with the seat's own victory target and civilization (its
`brain.log`; the seats played the stock genome, `forced=none`); the on arm adds
`--with settler-pump-leans-on-production`.

Cases:
- fires: seat p3 (Cree, Science) turns 7-16, whose capital trained its first
  Settler at 3-4 Production on +4-8 Food, and seat p2 (Poland, Culture) turns 8
  and 11 (+4 Food, 4-5 Production). The on arm should add one `city_focus`
  `FAVOR_PRODUCTION` order for that city.
- control: p3 turn 5 (a Warrior, +3 Food), p2 turn 13 (a Warrior), p1 turn 8
  (a Settler at 8 Production, +3 Food), p4 turn 8 (a Settler at 7, +2) and p5
  turn 10 (a Settler at 7, +2). The on arm should change nothing.

Read per arm: the orders and the `city_focus` orders. This records proposal
activation on captured live input only. It does not execute in Civ VI (the
agent mod takes only a Food focus today) and makes no strength claim.
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
RUN = Path(sys.argv[4])
CASES_FILE = Path(sys.argv[5])
GENE = 'settler-pump-leans-on-production'
SEATS = {
    1: ('religious', 'CIVILIZATION_GREECE'),
    2: ('culture', 'CIVILIZATION_POLAND'),
    3: ('science', 'CIVILIZATION_CREE'),
    4: ('domination', 'CIVILIZATION_PHOENICIA'),
    5: ('civvis', 'CIVILIZATION_KHMER'),
}
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CASES = []
for line in CASES_FILE.read_text().splitlines():
    if line.strip():
        seat, expect, turn = line.split()
        CASES.append({'seat': int(seat), 'expect': expect, 'turn': int(turn)})


def cut(seat, turn):
    """Rows through turn+1 (the replay recipe)."""
    rows = []
    path = RUN / f'{RUN.name}-p{seat}' / 'events.jsonl'
    with path.open('rt', errors='replace') as f:
        for line in f:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > turn + 1:
                break
            rows.append(line)
    return ''.join(rows).encode()


def focus_orders(row):
    return [o for o in row.get('payload', {}).get('orders', []) if o.get('kind') == 'city_focus']


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        victory, civ = SEATS[case['seat']]
        data = cut(case['seat'], case['turn'])
        run = f"{RUN.name}-p{case['seat']}"
        record = {'descriptor': {'run': run, 'turn': case['turn'], 'cut': 'after turn+1'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', victory, '--civ', civ]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            else:
                row['stderr_tail'] = stderr.read_text(errors='replace')[-2000:]
            row['focus_orders'] = focus_orders(row)
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
             'on_focus_orders': 0, 'off_focus_orders': 0}
    for r in results:
        c = r['case']
        if r.get('error'):
            print(c, 'ERROR', r['error'])
            continue
        for v in r['reads']:
            off, on = v['arms']
            total['on_focus_orders'] += len(on.get('focus_orders', []))
            total['off_focus_orders'] += len(off.get('focus_orders', []))
            print(f"p{c['seat']} t{c['turn']:<3} {c['expect']:<8} "
                  f"{'CHANGED' if v.get('orders_changed') else 'same   '} "
                  f"focus off {off.get('focus_orders')} on {on.get('focus_orders')} "
                  f"exit {off.get('exit')}/{on.get('exit')}")
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
