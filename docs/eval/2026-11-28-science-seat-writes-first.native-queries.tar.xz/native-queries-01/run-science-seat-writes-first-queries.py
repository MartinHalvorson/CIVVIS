"""Paired decider queries on the recorded boards of the hotseat game
`hotseat-20261128T031456Z` (2026-11-27, Small Continents, a person at seat 0
and five CIVVIS seats), on the turns a seat chose its research.

`science-seat-writes-first` is the only bit that varies. Each case is one
seat's own events.jsonl cut after turn N's opening (frame 0) state, the board
the seat chose its research on (its later frames already carry that research),
replayed at turn N. Both arms run
one frozen `civvis_orders --resumed --explain` built from the gene's branch
(the macOS arm64 release binary of the `hotseat-bundle` workflow run named in
registration.json), with the seat's own victory target and civilization as
the live worker passed them (`--victory`, `--civ`; the seats ran
`forced=none`, so no `--with`); the on arm adds
`--with science-seat-writes-first`.

Cases:
- fire: seat p3 (Science, Cree) at turn 12, where it chose Sailing with
  Animal Husbandry, Mining and Pottery known. The on arm should research
  Writing.
- same: p3 at turn 10 (two techs, no Pottery: the walk to Writing takes
  Pottery, which the off arm took too) and at turn 6 (one tech known).
- control: seats on other targets on a research turn (p2 Culture t14, p4
  Domination t14, p5 adaptive t14). The on arm should change nothing.

Read per arm: the orders, the research order, and the gene's journal lines.
This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
RUN = Path(sys.argv[4])
BUILD = sys.argv[5]
GENE = 'science-seat-writes-first'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CASES = [
    {'seat': 'p3', 'victory': 'science', 'civ': 'CIVILIZATION_CREE', 'turn': 12, 'expect': 'fire'},
    {'seat': 'p3', 'victory': 'science', 'civ': 'CIVILIZATION_CREE', 'turn': 10, 'expect': 'same'},
    {'seat': 'p3', 'victory': 'science', 'civ': 'CIVILIZATION_CREE', 'turn': 6, 'expect': 'same'},
    {'seat': 'p2', 'victory': 'culture', 'civ': 'CIVILIZATION_POLAND', 'turn': 14, 'expect': 'control'},
    {'seat': 'p4', 'victory': 'domination', 'civ': 'CIVILIZATION_PHOENICIA', 'turn': 14, 'expect': 'control'},
    {'seat': 'p5', 'victory': 'civvis', 'civ': 'CIVILIZATION_KHMER', 'turn': 14, 'expect': 'control'},
]


def cut(seat, turn):
    """Rows through turn N's first state record (frame 0)."""
    rows = []
    with open(RUN / f'{RUN.name}-{seat}' / 'events.jsonl', 'rt', errors='replace') as f:
        for line in f:
            rows.append(line)
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if e.get('kind') == 'state' and e.get('turn') == turn and (e.get('frame') or 0) == 0:
                return ''.join(rows).encode()
    raise ValueError(f'no frame-0 state for turn {turn}')


def research(row):
    return [o.get('verb') for o in row.get('payload', {}).get('orders', []) if o.get('kind') == 'research']


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        data = cut(case['seat'], case['turn'])
        record = {'descriptor': {'run': RUN.name, 'seat': case['seat'], 'turn': case['turn'],
                                 'cut': 'after the turn\'s frame-0 state'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', case['victory'], '--civ', case['civ']]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            else:
                row['stderr_tail'] = stderr.read_text(errors='replace')[-2000:]
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if GENE + ':' in line]
            row['journal_research'] = [line for line in journal if 'Research/Decision Researching' in line]
            row['research_orders'] = research(row)
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES, 'build': BUILD,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
             'on_gene_lines': 0, 'off_gene_lines': 0}
    for r in results:
        c = r['case']
        if r.get('error'):
            print(c, 'ERROR', r['error'])
            continue
        for v in r['reads']:
            off, on = v['arms']
            total['on_gene_lines'] += len(on.get('journal_gene', []))
            total['off_gene_lines'] += len(off.get('journal_gene', []))
            print(f"{c['seat']} t{c['turn']:<3} {c['expect']:<8} "
                  f"{'CHANGED' if v.get('orders_changed') else 'same   '} "
                  f"research off {off.get('research_orders')} on {on.get('research_orders')} "
                  f"gene lines on {len(on.get('journal_gene', []))} off {len(off.get('journal_gene', []))} "
                  f"exit {off.get('exit')}/{on.get('exit')}")
            for line in on.get('journal_gene', [])[:2]:
                print('      ', line[:300])
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
