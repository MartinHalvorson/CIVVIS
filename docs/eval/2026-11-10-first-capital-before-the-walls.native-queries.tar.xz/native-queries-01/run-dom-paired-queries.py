"""Paired decider queries on captured live Deity boards, Domination lane.

usage: rs-paired-queries.py REPO BINARY OUT GENE RUN:TURN [RUN:TURN...]

GENE is the only bit that varies. Each case is a turn of a live Deity Online
Small Continents run (Russia or Sweden seats) on which a rival capital on our
landmass within 20 tiles was already charted. Both arms run one frozen
ci-profile `civvis_orders` built from the branch, on the run's own
`events.jsonl` cut just before the second state frame of the turn (the cut
bytes are hashed below), with that run's own requested genome (`summary.json`
`forced`, each as `--with`), `--victory domination` (the lane the gene is
for) and `--resumed`. The on arm adds `--with GENE`.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = sys.argv[4]
CASES = [(c.split(':')[0], int(c.split(':')[1])) for c in sys.argv[5:]]
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CONTROL = Path.home() / 'civvis-civ6-runs/control'


OPENING = ('Opening a conquest against', 'First capital before the walls', 'Not opening a conquest against')


def opening_lines(journal):
    return [line for line in journal if any(key in line for key in OPENING)]


def changed_orders(off, on):
    a = [json.dumps(o, sort_keys=True) for o in off.get('orders', [])]
    b = [json.dumps(o, sort_keys=True) for o in on.get('orders', [])]
    return {'off_only': [json.loads(o) for o in a if o not in b],
            'on_only': [json.loads(o) for o in b if o not in a]}


def one(index, run, turn, data_path, digest, size, forced):
    RUN = run
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': {'run': RUN, 'turn': turn}, 'reads': []}
    try:
        record = {'descriptor': {'run': RUN, 'file': 'events.jsonl cut before the second state frame of the turn', 'turn': turn},
                  'bytes': size, 'sha256': digest, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            subprocess.run(['cp', '-c', str(data_path), str(mirror / 'events.jsonl')], check=True)
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', 'domination',
                   '--turn', str(turn), '--resumed']
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=600)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]')]
            record['arms'].append(row)
            shutil.rmtree(mirror)
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['off_opening'] = opening_lines(off.get('journal', []))
        record['on_opening'] = opening_lines(on.get('journal', []))
        record['order_diff'] = changed_orders(off.get('payload', {}), on.get('payload', {}))
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    results = []
    reg = {'scope': __doc__, 'gene': GENE, 'cases': [], 'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
           'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    for i, (run, turn) in enumerate(CASES):
        source = CONTROL / run
        forced = list(json.loads((source / 'summary.json').read_text())['forced'])
        if GENE in forced:
            raise SystemExit('the live genome already carried the gene')
        cut = OUT / f'cut-{i:04d}.jsonl'
        seen_first = False
        with (source / 'events.jsonl').open('rb') as src, cut.open('wb') as dst:
            for line in src:
                if line.startswith(b'{"available_policies"') or b'"kind": "state"' in line[:4096]:
                    try:
                        e = json.loads(line)
                    except Exception:
                        e = {}
                    if e.get('kind') == 'state':
                        if e.get('turn', 0) > turn or (e.get('turn') == turn and seen_first):
                            break
                        if e.get('turn') == turn:
                            seen_first = True
                dst.write(line)
        data_path = cut
        data = data_path.read_bytes()
        digest, size = hashlib.sha256(data).hexdigest(), len(data)
        reg['cases'].append({'run': run, 'turn': turn, 'input_sha256': digest, 'input_bytes': size,
                             'cut': 'events.jsonl up to the second state frame of the turn'})
        r = one(i, run, turn, data_path, digest, size, forced)
        results.append(r)
        for v in r['reads']:
            print(run[-16:], turn, 'complete', v.get('complete'), 'changed', v.get('orders_changed'),
                  'diff', len(v.get('order_diff', {}).get('on_only', [])),
                  'off', [l[:160] for l in v.get('off_opening', [])][:2],
                  'on', [l[:220] for l in v.get('on_opening', [])][:3], flush=True)
        if r.get('error'):
            print(run, turn, 'ERROR', r['error'], flush=True)
    (OUT / 'registration.json').write_text(json.dumps(reg, indent=2))
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
