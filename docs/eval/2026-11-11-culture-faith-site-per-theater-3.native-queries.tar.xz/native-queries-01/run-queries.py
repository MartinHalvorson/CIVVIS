"""Paired decider queries for `culture-faith-site-per-theater-3` on captured live boards.

Each case is a live Deity Online Culture-target game of 2026-11-10/11 with six
or more cities: Pericles 232642Z and 000134Z (armed with
`culture-faith-site-per-theater-2`), Kristina 205256Z (version one) and
173750Z (neither). The board is the run's events.jsonl cut at the named turn's
first state frame (frame 0), the run's other files linked beside it. Every arm
runs one frozen `civvis_orders --resumed` built from the branch with the run's
own requested genome (`summary.json` `forced`, each as `--with`, less tags the
binary does not know) with every version of the family removed, then
`--with culture-faith-site-per-theater-2` (the `off` arm; 232642Z and 000134Z
were armed with it live, 205256Z with version one, 173750Z with neither); the
`on` arm adds `--with culture-faith-site-per-theater-3`, which carries version
two. A case's `extra` tags go to both arms: the 000134Z boards run twice, the
second time with `culture-faith-braves-the-barbarians` (#5025) on both arms.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
REVISION = sys.argv[4]
CASES = json.loads(Path(sys.argv[5]).read_text())
RUNS = Path.home() / 'civvis-civ6-runs/control'
FAMILY = ['culture-faith-site-per-theater', 'culture-faith-site-per-theater-2',
          'culture-faith-site-per-theater-3']
GENE = 'culture-faith-site-per-theater-3'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402


def known_tags():
    text = subprocess.run(['git', '-C', str(REPO), 'show', f'{REVISION}:src/ai/advanced/genes.rs'],
                          capture_output=True, text=True, check=True).stdout
    return set(re.findall(r'Gene \{ tag: "([^"]+)"', text))


def cut(src, dst, turn):
    with open(src, 'rb') as f, open(dst, 'wb') as g:
        for line in f:
            g.write(line)
            if line.startswith(b'{"available_policies"'):
                try:
                    if json.loads(line).get('turn') == turn:
                        break
                except Exception:
                    pass


def produce_orders(payload):
    return [o for o in payload.get('orders', []) if 'produce' in str(o.get('verb', '')).lower()
            or 'build' in str(o.get('verb', '')).lower()]


def journal(stderr_path):
    keep = []
    for line in stderr_path.read_text(errors='replace').splitlines():
        if ('Faith source' in line or "Culture's Faith economy" in line
                or 'keeps its last district slot' in line or 'Researching' in line
                or ' starts ' in line or 'claims its' in line or 'district at' in line):
            keep.append(line[:600])
    return keep


def one(index, case, known):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        run = RUNS / case['run']
        summary = json.loads((run / 'summary.json').read_text())
        forced = list(summary['forced'])
        dropped = [t for t in forced if known and t not in known]
        base = [t for t in forced if (not known or t in known) and t not in FAMILY]
        arms = ['off', 'on']
        base = base + ['culture-faith-site-per-theater-2'] + list(case.get('extra', []))
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'],
                                 'extra': list(case.get('extra', []))},
                  'live_family': [t for t in forced if t in FAMILY],
                  'dropped_unknown_tags': dropped, 'arms': []}
        result['reads'].append(record)
        for arm in arms:
            mirror = root / arm
            mirror.mkdir()
            for f in run.iterdir():
                if f.name == 'events.jsonl' or f.suffix == '.png' or not f.is_file():
                    continue
                os.symlink(f, mirror / f.name)
            cut(run / 'events.jsonl', mirror / 'events.jsonl', case['turn'])
            data = (mirror / 'events.jsonl').read_bytes()
            record['bytes'] = len(data)
            record['sha256'] = hashlib.sha256(data).hexdigest()
            cmd = [str(BINARY), '--explain', '--resumed', '--mirror', str(mirror),
                   '--victory', 'culture', '--turn', str(case['turn'])]
            for tag in base:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=2400)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played,
                   'journal': journal(stderr)}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            else:
                row['stderr_tail'] = stderr.read_text()[-1500:]
            record['arms'].append(row)
            for f in mirror.iterdir():
                f.unlink()
            mirror.rmdir()
        by = {a['arm']: a for a in record['arms']}
        for arm in arms:
            record[arm + '_produce_orders'] = produce_orders(by[arm].get('payload', {}))
        record['produce_orders_changed'] = record['off_produce_orders'] != record['on_produce_orders']
        record['orders_changed'] = by['off'].get('payload', {}).get('orders') != by['on'].get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    known = known_tags()
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(), 'binary_revision': REVISION,
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=int(os.environ.get('JOBS', '3'))) as pool:
        results = list(pool.map(lambda pair: one(pair[0], pair[1], known), enumerate(CASES)))
    reads = [v for r in results for v in r['reads']]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'produce_orders_changed': sum(v.get('produce_orders_changed', False) for v in reads),
               'changed_order_reads': sum(v.get('orders_changed', False) for v in reads)}
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
