"""Paired decider queries on captured live boards for `military-alliance-shield-2`.

`military-alliance-shield-2` is the only bit that varies between the `off`
and `on` arms. Cases are border-cadence turns of two live Deity Korea Science
games (Online) that played version one (`military-alliance-shield`) and read
its faults: civvis-20261105T155735Z-deterrence-matched-01-on (t102 and t105 Military
asks to rivals the agent never sent them to; t108 a refused Military ask) and
civvis-20261105T154934Z (t87 the same; t108 refused). Each turn is read from
the run's own events.jsonl (byte-identical input, sha256 recorded). Both arms
run one frozen ci-profile `civvis_orders` built from the branch with the run's
own requested genome (`summary.json` `forced`, each as `--with`) MINUS
version one (enabling version two turns version one off, so a pair carrying
it would vary two bits); the `on` arm adds `--with military-alliance-shield-2`.
A third query with version one in place of version two is recorded beside
each pair as `v1_alliance_orders` (not part of the pair).

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim. A fresh decider reads each turn
in isolation (no memory of earlier asks).
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'military-alliance-shield-2'
V1 = 'military-alliance-shield'
CASES = [('civvis-20261105T155735Z-deterrence-matched-01-on', t) for t in range(90, 121, 3)] + \
        [('civvis-20261105T154934Z', t) for t in range(84, 112, 3)]
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CONTROL = Path.home() / 'civvis-civ6-runs/control'


def query(root, name, data, cmd):
    mirror = root / name
    mirror.mkdir()
    (mirror / 'events.jsonl').write_bytes(data)
    cmd = [str(BINARY), '--explain', '--mirror', str(mirror)] + cmd
    stdout, stderr = root / (name + '.stdout'), root / (name + '.stderr')
    started = time.monotonic()
    with stdout.open('wb') as out, stderr.open('wb') as err:
        process = subprocess.run(cmd, stdout=out, stderr=err, timeout=600)
    row = {'argv': cmd, 'exit': process.returncode,
           'wall_seconds': time.monotonic() - started, 'genome': decider_genome(stderr)}
    if process.returncode == 0:
        row['payload'] = json.loads(stdout.read_text())
    row['journal'] = [line for line in stderr.read_text().splitlines()
                      if line.startswith('[why]') and 'lliance' in line]
    (mirror / 'events.jsonl').unlink()
    stdout.unlink()
    stderr.unlink()
    return row


def alliances(row):
    return [o for o in row.get('payload', {}).get('orders', []) if o.get('kind') == 'alliance']


def one(index, run, turn, cache):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    case = {'run': run, 'turn': turn, 'input': 'events.jsonl'}
    result = {'index': index, 'case': case, 'reads': []}
    try:
        if run not in cache:
            summary = json.loads((CONTROL / run / 'summary.json').read_text())
            data = (CONTROL / run / 'events.jsonl').read_bytes()
            cache[run] = (summary, data, hashlib.sha256(data).hexdigest())
        summary, data, digest = cache[run]
        forced = [tag for tag in summary['forced'] if tag not in (V1, GENE)]
        base = ['--victory', 'science', '--turn', str(turn)]
        for tag in forced:
            base += ['--with', tag]
        record = {'descriptor': case, 'bytes': len(data), 'sha256': digest, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            cmd = base + (['--with', GENE] if arm == 'on' else [])
            row = query(root, arm, data, cmd)
            row['arm'] = arm
            record['arms'].append(row)
        v1 = query(root, 'v1', data, base + ['--with', V1])
        off, on = record['arms']
        record['off_alliance_orders'] = alliances(off)
        record['on_alliance_orders'] = alliances(on)
        record['v1_alliance_orders'] = alliances(v1)
        record['v1_journal'] = v1['journal']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    cache = {}
    results = [one(i, run, t, cache) for i, (run, t) in enumerate(CASES)]
    rows = []
    for r in results:
        for v in r['reads']:
            short = lambda os: [(o.get('verb'), o.get('subject')) for o in os]
            rows.append({'run': r['case']['run'][16:31], 'turn': r['case']['turn'], 'complete': v.get('complete'),
                         'changed': v.get('orders_changed'), 'off': short(v.get('off_alliance_orders', [])),
                         'v2': short(v.get('on_alliance_orders', [])), 'v1': short(v.get('v1_alliance_orders', []))})
        if r.get('error'):
            rows.append({'turn': r['case']['turn'], 'error': r['error']})
    out = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
           'changed_order_reads': sum(bool(x.get('changed')) for x in rows), 'rows': rows}
    (OUT / 'summary.json').write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=1))


if __name__ == '__main__':
    main()
