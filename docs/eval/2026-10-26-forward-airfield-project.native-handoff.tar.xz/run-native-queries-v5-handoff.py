"""Compare every registered Native captured read in disposable mirrors.

Production-path fresh serve arms use one frozen CI-optimized integrated-source adapter and each actual played genome;
only the new forward-field flag varies. Retain failures, all responses
and exact input/genome controls. Fresh queries lack historical controller
memory and do not execute in Civ VI. No performance or strength claim.
"""
import collections
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

BASE=Path('/tmp/civvis-forward-airfield-project-8c23')
REPO=Path('/Users/martbot-mbp-m5-max-128/civvis-forward-airfield-project-8c23')
sys.path.insert(0,str(REPO/'tools'))
from civ6_decision_trace import captured_input
from civ6_ladder import decider_genome

GENE='forward-airfield-project'
BINARY=BASE/'handoff-optimized-build/civvis_orders'
MANIFEST=BASE/'native-selection/manifest.json'
OUT=BASE/'native-queries-04-handoff'


def normalized_genome(genome):
    if genome is None:return None
    value=json.loads(json.dumps(genome))
    for field in ('treatments','forced','ledger_withheld'):
        if isinstance(value.get(field),list):value[field]=[tag for tag in value[field] if tag!=GENE]
    return value

def last_state(data):
    state=None
    for line in data.splitlines():
        event=json.loads(line)
        if event.get('kind')=='state':state=event
    if state is None:raise ValueError('no captured native state')
    return state


def one(index,case):
    root=OUT/f'{index:04d}'
    root.mkdir()
    result={'index':index,'case':case,'reads':[]}
    try:
        capture=case['capture']
        if case['state_count']!=1:raise ValueError('ambiguous native event frame')
        if not capture.get('complete') or not capture.get('reads'):raise ValueError('incomplete captured input')
        genome=json.loads(Path(case['genome']).read_text())
        for read in capture['reads']:
            if 'error' in read:raise ValueError('failed captured read')
            rdir=root/f'read-{read["snapshot_id"]}'
            rdir.mkdir()
            record={'descriptor':read,'arms':[]}
            result['reads'].append(record)
            data=captured_input(capture,read['snapshot_id'])
            state=last_state(data)
            if (state['turn'],state['frame'])!=(case['turn'],case['frame']):raise ValueError('captured decision frame differs')
            record.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
            prefix=rdir/'input.jsonl'
            prefix.write_bytes(data)
            del data
            for arm in ('off','on','off-repeat'):
                mirror=rdir/arm
                mirror.mkdir()
                os.link(prefix,mirror/'events.jsonl')
                cmd=[str(BINARY),'--explain','--serve','--fresh-board','--mirror',str(mirror),'--victory','domination','--turn',str(case['turn'])]
                for tag in genome['forced']:cmd+=['--with',tag]
                for tag in genome['_summary_withheld']:cmd+=['--without',tag]
                if arm=='on':cmd+=['--with',GENE]
                stdout,stderr=rdir/(arm+'.stdout'),rdir/(arm+'.stderr')
                started=time.monotonic()
                with stdout.open('wb') as out,stderr.open('wb') as err:
                    process=subprocess.run(cmd,input=(str(case['turn'])+'\n').encode(),stdout=out,stderr=err,timeout=300)
                played=decider_genome(stderr)
                expected=set(genome['treatments'])|({GENE} if arm=='on' else set())
                actual=set(played.get('treatments',[])) if played else set()
                row={'arm':arm,'argv':cmd,'exit':process.returncode,'wall_seconds':time.monotonic()-started,
                     'genome_matches':actual==expected,'unexpected_added':sorted(actual-expected),
                     'unexpected_removed':sorted(expected-actual),'genome':played}
                record['arms'].append(row)
                if process.returncode==0:
                    row['payload']=json.loads(stdout.read_text())
                row['journal']=[line for line in stderr.read_text().splitlines() if line.startswith('[why]')]
            off,on,repeat=record['arms']
            pair_complete=all(a['exit']==0 and a['genome_matches'] and 'payload' in a for a in (off,on))
            record['orders_changed']=(off['payload']['orders']!=on['payload']['orders']) if pair_complete else None
            record['off_repeat_orders_equal']=(off.get('payload',{}).get('orders')==repeat.get('payload',{}).get('orders')) if all(a['exit']==0 and a['genome_matches'] for a in (off,repeat)) else None
            record['off_matches_historical_orders']=(off['payload']['orders']==case['actual_orders']) if pair_complete else None
            record['on_matches_historical_orders']=(on['payload']['orders']==case['actual_orders']) if pair_complete else None
            record['planned_actions_changed']=(off['payload'].get('decision',{}).get('native_actions')!=on['payload'].get('decision',{}).get('native_actions')) if pair_complete else None
            record['journal_changed']=off['journal']!=on['journal']
            record['genomes_only_gene_changed']=normalized_genome(off['genome'])==normalized_genome(on['genome'])
            record['off_repeat_genome_equal']=off['genome']==repeat['genome']
            prior=json.loads((BASE/f'native-queries-03-positions/{index:04d}/result.json').read_text())
            prior_read=next(v for v in prior['reads'] if v['descriptor']['snapshot_id']==read['snapshot_id'])
            record['prior_position_source_orders_equal']={a['arm']:a.get('payload',{}).get('orders')==next(v for v in prior_read['arms'] if v['arm']==a['arm']).get('payload',{}).get('orders') for a in record['arms']}
            record['prior_position_source_genomes_equal']={a['arm']:a['genome']==next(v for v in prior_read['arms'] if v['arm']==a['arm'])['genome'] for a in record['arms']}

            record['complete']=all(a['exit']==0 and a['genome_matches'] and 'payload' in a for a in record['arms']) and record['off_repeat_orders_equal'] is True and record['genomes_only_gene_changed'] and record['off_repeat_genome_equal']
            # Exact source reads are reconstructible from already committed
            # cohort archives; avoid retaining hundreds of duplicate prefixes.
            for arm in ('off','on','off-repeat'):(rdir/arm/'events.jsonl').unlink()
            prefix.unlink()
        result['complete']=all(r.get('complete') for r in result['reads'])
    except Exception as exc:
        result.update(complete=False,error=f'{type(exc).__name__}: {exc}')
    (root/'result.json').write_text(json.dumps(result,sort_keys=True,indent=2))
    return result


def main():
    OUT.mkdir()
    manifest=json.loads(MANIFEST.read_text())
    (OUT/'registration.json').write_text(json.dumps({'scope':__doc__,'manifest_sha256':hashlib.sha256(MANIFEST.read_bytes()).hexdigest(),
        'binary_sha256':hashlib.sha256(BINARY.read_bytes()).hexdigest(),'build':json.loads((BASE/'handoff-optimized-build/build.json').read_text()),
        'cases':len(manifest['cases']),'jobs':2,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2))
    results=[]
    with (OUT/'results.jsonl').open('w') as stream,concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(one,i,c) for i,c in enumerate(manifest['cases'])]
        for future in concurrent.futures.as_completed(futures):
            result=future.result();results.append(result);stream.write(json.dumps(result,sort_keys=True)+'\n');stream.flush()
            changed=sum(r.get('orders_changed') is True for r in result['reads'])
            print(json.dumps({'index':result['index'],'completed_cases':len(results),'complete':result['complete'],'reads':len(result['reads']),'changed_order_reads':changed,'error':result.get('error')}),flush=True)
    summary={'cases':len(results),'complete_cases':sum(r['complete'] for r in results),
        'reads':sum(len(r['reads']) for r in results),
        'changed_order_reads':sum(v.get('orders_changed') is True and v.get('complete') is True for r in results for v in r['reads']),
        'off_repeat_order_mismatches':sum(v.get('off_repeat_orders_equal') is False for r in results for v in r['reads']),
        'historical_off_matches':sum(v.get('off_matches_historical_orders') is True for r in results for v in r['reads']),
        'historical_on_matches':sum(v.get('on_matches_historical_orders') is True for r in results for v in r['reads']),
        'changed_planned_reads':sum(v.get('planned_actions_changed') is True and v.get('complete') is True for r in results for v in r['reads']),
        'prior_position_source_order_mismatches':sum(not all(v.get('prior_position_source_orders_equal',{}).values()) for r in results for v in r['reads']),
        'prior_position_source_genome_mismatches':sum(not all(v.get('prior_position_source_genomes_equal',{}).values()) for r in results for v in r['reads'])}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)


if __name__=='__main__':main()
