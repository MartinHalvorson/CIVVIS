"""Paired decider queries on live frames of the first live game with
`foreign-site-buys-the-open-border` armed: civvis-t7-20261127T075243Z (Lv 8
Deity Science seat, 6p Continents, Online; Diplomatic and Religious victory
off). Margaret Mead stood idle from t132 while the gene journaled every six
turns that none of the 2-3 seats holding a Campus sold passage. England and
Ethiopia were declared friends at 1.9-5.3 times our military (Australia at war
until t150, Rome denounced and Campus-less), and the armed
`passage-waits-past-the-opening` withholds passage from any rival over 1.5
times ours.

Control: civvis-t7-20261127T081553Z (Lv 8 Science seat, gene armed), where
Darwin stood idle t102-t151 and the journal held no gene line. No natural
wonder was on the exported map until t152 (Giant's Causeway, unowned), so
there was no passage to buy; the on arm should change nothing and now say
so.

The gene is the only bit that varies. Each case is the run's own
events.jsonl cut after turn N+1, replayed at turn N. Both arms run one frozen
`civvis_orders --resumed` built from the branch, with the run's requested
genome less the gene (why.log line 1 `forced`, each as `--with`) and its own
victory target and civilization (summary.json); the on arm adds
`--with foreign-site-buys-the-open-border`.

The branch waives the passage gate's military hold for a declared friend or
ally, and on the six-turn trade slot of a purchase turn the alliance desks
wait: the bridge's `hold_deals_beside_an_alliance` held every purchase beside
the Research Alliance ask to Georgia that the seat sent every turn.

Read per arm: the orders, the Open Borders `buy` orders, the deal and
alliance orders, and the gene's own journal lines, which name the filter that
refused each seller. This records
proposal activation on captured live input only. It does not execute in Civ
VI and makes no strength claim.
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'foreign-site-buys-the-open-border'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

GAMES = [
    ('civvis-t7-20261127T075243Z', 'stranded', 'mead', [132, 138, 144, 150]),
    ('civvis-t7-20261127T081553Z', 'unknown', 'darwin', [114, 132]),
]
CASES = [{'run': r, 'expect': e, 'person': p, 'turn': t} for r, e, p, turns in GAMES for t in turns]


def cut(run, turn):
    """Rows through turn+1 (the replay recipe)."""
    rows = []
    with open(RUNS / run / 'events.jsonl', errors='replace') as f:
        for line in f:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > turn + 1:
                break
            rows.append(line)
    return ''.join(rows).encode()


def border_buys(row):
    return [f"{o.get('subject')}:{o.get('x')}" for o in row.get('payload', {}).get('orders', [])
            if o.get('kind') == 'buy' and o.get('verb') == 'OPEN_BORDERS']


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        # The live genome armed the gene (05:29Z); the off arm is that
        # genome without it, the on arm puts it back.
        forced = [tag for tag in header['forced'] if tag != GENE]
        summary = json.loads((RUNS / case['run'] / 'summary.json').read_text())
        victory, civ = summary['victory_target'], summary['seat']['civ']
        data = cut(case['run'], case['turn'])
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'cut': 'after turn+1'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', victory, '--civ', civ]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if GENE + ':' in line]
            row['border_buys'] = border_buys(row)
            row['deal_orders'] = [f"{o.get('kind')}:{o.get('subject')}:{o.get('verb')}"
                                  for o in row.get('payload', {}).get('orders', [])
                                  if o.get('kind') in ('buy', 'sell', 'alliance', 'friendship')]
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
             'on_gene_lines': 0, 'off_gene_lines': 0}
    for r in results:
        c = r['case']
        if r.get('error'):
            print(c['run'], c['turn'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            off, on = v['arms']
            total['on_gene_lines'] += len(on.get('journal_gene', []))
            total['off_gene_lines'] += len(off.get('journal_gene', []))
            print(f"{c['run'][-21:]} t{c['turn']:<3} {c['person']:<6} {c['expect']:<8} "
                  f"{'CHANGED' if v.get('orders_changed') else 'same   '} "
                  f"buys off {off.get('border_buys')} on {on.get('border_buys')} "
                  f"gene lines on {len(on.get('journal_gene', []))} off {len(off.get('journal_gene', []))}")
            print('       deals off', off.get('deal_orders'), 'on', on.get('deal_orders'))
            for line in on.get('journal_gene', [])[:2]:
                print('      ', line[:260])
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
