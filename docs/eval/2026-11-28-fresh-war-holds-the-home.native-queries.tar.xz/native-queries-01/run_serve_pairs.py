"""Paired persistent-decider queries on a captured hotseat board.

One gene varies. The captured input is a live seat's own events.jsonl cut
after a given line; both arms run the same frozen `civvis_orders` built from
the gene's branch the way the live brain runs it (`--serve --fresh-board
--explain`, one process kept for the whole game), fed the same turns one per
line, with the run's own requested genome (why.log line 1 `forced`, each as
`--with`; empty in the hotseat game). The on arm adds `--with <gene>`. Each
served turn's reply is one read: the orders both arms proposed for it.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.

    python3 run_serve_pairs.py SPEC.json BINARY OUT_DIR
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

SPEC = json.loads(Path(sys.argv[1]).read_text())
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = SPEC["gene"]
EVENTS = Path(SPEC["events"]).expanduser()


def cut():
    with EVENTS.open("rb") as handle:
        lines = handle.readlines()
    return b"".join(lines[: SPEC["through_line"]])


def genome(stderr: Path):
    with stderr.open(errors="replace") as handle:
        for _ in range(40):
            line = handle.readline()
            if not line:
                break
            line = line.strip()
            if line.startswith("{"):
                try:
                    record = json.loads(line)
                except ValueError:
                    continue
                if record.get("kind") == "genome":
                    return record
    return None


def serve(arm: str, mirror: Path, data: bytes):
    mirror.mkdir(parents=True)
    (mirror / "events.jsonl").write_bytes(data)
    cmd = [str(BINARY), "--mirror", str(mirror), "--serve", "--fresh-board", "--explain",
           "--victory", SPEC["victory"], "--civ", SPEC["civ"]]
    for tag in SPEC.get("forced", []):
        cmd += ["--with", tag]
    if arm == "on":
        cmd += ["--with", GENE]
    stderr = mirror.parent / f"{arm}.stderr"
    started = time.monotonic()
    with stderr.open("wb") as err:
        process = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                   stderr=err, text=True, bufsize=1)
        replies = []
        for turn in SPEC["turns"]:
            process.stdin.write(f"{turn}\n")
            process.stdin.flush()
            while True:
                line = process.stdout.readline()
                if not line:
                    replies.append(None)
                    break
                try:
                    payload = json.loads(line)
                except ValueError:
                    continue
                if "orders" in payload:
                    replies.append(payload)
                    break
        process.stdin.close()
        code = process.wait(timeout=600)
    played = genome(stderr)
    journal = [line for line in stderr.read_text(errors="replace").splitlines()
               if line.startswith("[why]")]
    gene_lines = [line for line in journal if GENE + ":" in line]
    (mirror / "events.jsonl").unlink()
    return cmd, code, time.monotonic() - started, played, replies, gene_lines, stderr


def main():
    OUT.mkdir(parents=True)
    data = cut()
    digest = hashlib.sha256(data).hexdigest()
    root = OUT / "0000"
    arms = {}
    for arm in ("off", "on"):
        arms[arm] = serve(arm, root / arm, data)
    reads = []
    for index, turn in enumerate(SPEC["turns"]):
        read = {"descriptor": {"run": SPEC["run"], "seat": SPEC["seat"], "turn": turn,
                               "cut": f"events.jsonl lines 1-{SPEC['through_line']}",
                               "served": SPEC["turns"]},
                "bytes": len(data), "sha256": digest, "arms": []}
        for arm in ("off", "on"):
            cmd, code, seconds, played, replies, gene_lines, _ = arms[arm]
            row = {"arm": arm, "argv": cmd, "exit": code, "wall_seconds": seconds,
                   "genome": played, "journal_gene": gene_lines if index == 0 else []}
            if replies[index] is not None:
                row["payload"] = replies[index]
            read["arms"].append(row)
        off, on = read["arms"]
        read["orders_changed"] = (off.get("payload", {}).get("orders")
                                  != on.get("payload", {}).get("orders"))
        read["complete"] = all(a["exit"] == 0 and "payload" in a and a["genome"]
                               for a in read["arms"])
        reads.append(read)
    result = {"index": 0, "case": {k: SPEC[k] for k in ("run", "seat", "civ", "victory")},
              "reads": reads, "complete": all(r["complete"] for r in reads)}
    (root / "result.json").write_text(json.dumps(result, sort_keys=True, indent=2))
    for arm in ("off", "on"):
        arms[arm][6].unlink()
    (OUT / "registration.json").write_text(json.dumps(
        {"gene": GENE, "binary_sha256": hashlib.sha256(BINARY.read_bytes()).hexdigest(),
         "spec": SPEC}, sort_keys=True, indent=2))
    summary = {"turns": SPEC["turns"],
               "changed": [r["descriptor"]["turn"] for r in reads if r["orders_changed"]],
               "complete": result["complete"],
               "on_journal": arms["on"][5], "off_journal": arms["off"][5]}
    (OUT / "summary.json").write_text(json.dumps(summary, sort_keys=True, indent=2))
    print(json.dumps(summary, indent=1))


main()
