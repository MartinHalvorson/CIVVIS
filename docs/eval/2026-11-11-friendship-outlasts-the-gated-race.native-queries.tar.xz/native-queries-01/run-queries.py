"""Paired decider queries for `friendship-outlasts-the-gated-race` on captured live boards.

Each case is a live Deity Online Culture-target game of 2026-11-10/11 at the
first turn whose why.log reads "Not renewing the friendship with X |
friendship-keeps-the-peace: friendship-ends-at-the-race: ...". The renewal
needs the expiry the decider remembered from the frames before the lapse
(the live mirror drops a friendship the turn it ends), so each arm runs the
decider exactly as the live bridge does (`--serve --fresh-board --explain`,
one persistent agent) on the run's events.jsonl cut after that turn's first
state frame, fed the turns `turn - 3` through `turn`; the payload is the
reply for `turn`. Both arms run one frozen `civvis_orders` built from the
branch with the run's own requested genome (the `forced` list on the first
line of its why.log, each as `--with`, less tags the binary does not know);
the on arm adds `--with <gene>`.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
REVISION = sys.argv[4]
GENE = sys.argv[5]
RUNS = Path.home() / 'civvis-civ6-runs/control'
CASES = json.loads(Path(sys.argv[6]).read_text())
LEAD = 3
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402


def known_tags():
    text = subprocess.run(['git', '-C', str(REPO), 'show', f'{REVISION}:src/ai/advanced/genes.rs'],
                          capture_output=True, text=True, check=True).stdout
    return set(re.findall(r'Gene \{ tag: "([^"]+)"', text))


def cut(src, dst, turn):
    turns = set()
    with open(src, 'rb') as f, open(dst, 'wb') as g:
        for line in f:
            g.write(line)
            if line.startswith(b'{"available_policies"'):
                try:
                    t = json.loads(line).get('turn')
                except Exception:
                    continue
                turns.add(t)
                if t == turn:
                    break
    return turns


def diplomacy_orders(payload):
    return [o for o in payload.get('orders', []) if o.get('kind') in ('friendship', 'war', 'denounce', 'alliance')]


def one(index, case, known):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        run = RUNS / case['run']
        forced = json.loads((run / 'why.log').open().readline())['forced']
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        dropped = [t for t in forced if known and t not in known]
        forced = [t for t in forced if not known or t in known]
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'rival': case['rival'],
                                 'fed_turns': list(range(case['turn'] - LEAD, case['turn'] + 1))},
                  'dropped_unknown_tags': dropped, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            for f in run.iterdir():
                if f.name == 'events.jsonl' or f.suffix == '.png' or not f.is_file():
                    continue
                os.symlink(f, mirror / f.name)
            turns = cut(run / 'events.jsonl', mirror / 'events.jsonl', case['turn'])
            missing = [t for t in record['descriptor']['fed_turns'] if t not in turns]
            if missing:
                raise ValueError(f'the cut board lacks turns {missing}')
            data = (mirror / 'events.jsonl').read_bytes()
            record['bytes'] = len(data)
            record['sha256'] = hashlib.sha256(data).hexdigest()
            cmd = [str(BINARY), '--mirror', str(mirror), '--serve', '--fresh-board', '--explain',
                   '--victory', 'culture']
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdin = ''.join(f'{t}\n' for t in record['descriptor']['fed_turns'])
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, input=stdin.encode(), stdout=out, stderr=err, timeout=2400)
            played = decider_genome(stderr)
            why = [line for line in stderr.read_text(errors='replace').splitlines()
                   if line.startswith('[why]') and re.search(r'friendship|denial-war', line)]
            replies = [json.loads(line) for line in stdout.read_text().splitlines() if line.startswith('{')]
            row = {'arm': arm, 'argv': cmd, 'stdin': stdin, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played,
                   'gene_in_genome': GENE in (played or {}).get('forced', []), 'why': why,
                   'reply_turns': [r.get('turn') for r in replies]}
            if process.returncode == 0 and replies:
                row['payload'] = replies[-1]
            else:
                row['stderr_tail'] = stderr.read_text()[-1500:]
            record['arms'].append(row)
            for f in mirror.iterdir():
                f.unlink()
            mirror.rmdir()
        off, on = record['arms']
        civ = case['rival']
        last = f"t{case['turn']} "
        record['off_diplomacy_orders'] = diplomacy_orders(off.get('payload', {}))
        record['on_diplomacy_orders'] = diplomacy_orders(on.get('payload', {}))
        record['off_race_line'] = any(last in l and f'Not renewing the friendship with {civ} ' in l
                                      and 'friendship-ends-at-the-race' in l for l in off['why'])
        record['on_keep_lines'] = [l for l in on['why'] if last in l and f'Keeping the friendship with {civ} ' in l]
        record['on_renew_line'] = any(last in l and f'Renewing the friendship with {civ} ' in l for l in on['why'])
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    for name in ('off.stdout', 'off.stderr', 'on.stdout', 'on.stderr'):
        (root / name).unlink(missing_ok=True)
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    known = known_tags()
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(), 'binary_revision': REVISION,
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda pair: one(pair[0], pair[1], known), enumerate(CASES)))
    reads = [v for r in results for v in r['reads']]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'off_race_line': sum(v.get('off_race_line', False) for v in reads),
               'on_kept': sum(bool(v.get('on_keep_lines')) for v in reads),
               'changed_order_reads': sum(v.get('orders_changed', False) for v in reads)}
    for r in results:
        c = r['case']
        for v in r['reads']:
            brief = lambda orders: [(o.get('kind'), o.get('subject'), o.get('verb')) for o in orders or []]
            print(c['run'][-15:], c['turn'], c['rival'], 'off_race', v.get('off_race_line'),
                  'off', brief(v.get('off_diplomacy_orders')), 'on', brief(v.get('on_diplomacy_orders')))
            for line in v.get('on_keep_lines', [])[:1]:
                print('    ', line)
        if r.get('error'):
            print(c['run'], 'ERROR', r['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
