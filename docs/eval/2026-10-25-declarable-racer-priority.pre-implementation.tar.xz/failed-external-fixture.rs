//! Public serial planner development fixture; model actions are not native permission.
use civvis::ai::{gene, AdvancedAi, GrandStrategy, StrategicPlan, VictoryTarget};
use civvis::game::{Action, Game};
use civvis::reasoning::Journal;
use civvis::Pos;
use serde_json::json;
use std::sync::Arc;
fn fixture() -> (Game, AdvancedAi, StrategicPlan, [u32; 2], [Pos; 2]) {
    let mut g = Game::new_full(4, 36, 24, 59002899, 500, 0, false);
    for uid in g.units.keys().copied().collect::<Vec<_>>() {
        g.remove_unit(uid);
    }
    g.barb_camps.clear();
    for tile in g.map.tiles.values_mut() {
        tile.terrain = civvis::name!("grassland");
        tile.feature = None;
        tile.resource = None;
        tile.hills = false;
    }
    let base = (6, 8);
    let own = g.found_city_for(0, (5, 8), None);
    g.cities
        .get_mut(&own)
        .unwrap()
        .districts
        .insert(civvis::name!("aerodrome"), base);
    let tile = g.map.tiles.get_mut(&base).unwrap();
    tile.owner_city = Some(own);
    tile.district = Some(civvis::name!("aerodrome"));
    tile.pillaged = false;
    g.found_city_for(0, (2, 14), None);
    g.found_city_for(1, (25, 16), None);
    let town = g.found_city_for(1, (11, 16), None);
    g.cities.get_mut(&town).unwrap().is_capital = false;
    let cities = [
        g.found_city_for(2, (15, 8), None),
        g.found_city_for(2, (16, 4), None),
    ];
    g.found_city_for(3, (29, 20), None);
    let theaters = [(14, 8), (15, 4)];
    for (city, pos) in cities.into_iter().zip(theaters) {
        g.cities
            .get_mut(&city)
            .unwrap()
            .districts
            .insert(civvis::name!("theater_square"), pos);
        let tile = g.map.tiles.get_mut(&pos).unwrap();
        tile.owner_city = Some(city);
        tile.district = Some(civvis::name!("theater_square"));
        tile.pillaged = false;
    }
    for rival in [1, 2, 3] {
        g.record_contact(0, rival);
    }
    g.at_war.clear();
    g.at_war.insert((0, 1));
    g.players[1].dvp = 16;
    g.current = 0;
    g.turn = 185;
    g.players[0].gold = 10000.0;
    g.players[0]
        .strategic_resources
        .insert(civvis::name!("aluminum"), 100.0);
    let bombers = [
        g.spawn_test_unit("bomber", 0, base),
        g.spawn_test_unit("bomber", 0, base),
    ];
    for pos in [(13, 8), (14, 4), (10, 16)] {
        g.spawn_test_unit("scout", 0, pos);
    }
    let powers = Arc::make_mut(&mut g.observed_military_power);
    powers.insert(0, 1307.0);
    powers.insert(1, 200.0);
    powers.insert(2, 2506.0);
    let stats = Arc::make_mut(&mut g.observed_public_empire_stats);
    stats.entry(0).or_default().domestic_tourists = Some(100);
    let racer = stats.entry(2).or_default();
    racer.foreign_tourists = Some(85);
    racer.culture_turns_to_victory = Some(10.0);
    let mut ai = AdvancedAi::targeting(VictoryTarget::Domination);
    ai.enable_one_war_at_a_time();
    ai.enable_diplomatic_contender_eliminated();
    ai.enable_elimination_yields_to_a_launch();

    let plan = StrategicPlan {
        strategy: GrandStrategy::Conquest,
        target_player: Some(1),
        target_city: Some(town),
        threatened_city: None,
        desired_cities: 2,
        assessed_turn: g.turn,
        rush: false,
    };
    (g, ai, plan, bombers, theaters)
}

fn main() {
    let arm = std::env::args().nth(1).expect("off|v1|v2");
    assert!(["off", "v1", "v2"].contains(&arm.as_str()));
    let (g, mut ai, _, bombers, theaters) = fixture();
    assert!(g.air_capacity_at(0, g.units[&bombers[0]].pos) >= 2);
    ai.disable_elimination_yields_to_a_launch();
    if arm != "off" {
        let tag = if arm == "v1" {
            "elimination-yields-to-a-launch"
        } else {
            "elimination-yields-to-a-launch-2"
        };
        (gene(tag).expect("arm exists in this build").enable)(&mut ai);
    }
    let mut physical = g.speculative_clone();
    let opening = physical
        .legal_actions(0)
        .into_iter()
        .find(|a| {
            matches!(
                a,
                Action::DeclareWar { player: 2 }
                    | Action::DeclareWarWithCasusBelli { player: 2, .. }
            )
        })
        .expect("legal declaration");
    physical.apply(0, &opening).unwrap();
    for (uid, target) in bombers.into_iter().zip(theaters) {
        physical
            .apply(0, &Action::AirPillage { unit: uid, target })
            .unwrap();
        assert!(physical.units[&uid].hp >= 60);
        assert!(physical.map.get(target).unwrap().pillaged);
    }
    let journal = Journal::recording();
    ai.attach_journal(journal.handle());
    let mut view = g.player_decision_view(0);
    ai.plan_observed_turn(&mut view, 0);
    println!(
        "{}",
        json!({"scope":"constructed public model-planner fixture, not a native replay", "arm":arm,
        "plan":format!("{:?}",ai.current_plan()),"war_racer":view.is_at_war(0,2),
        "theaters":theaters.map(|p|view.map.get(p).map(|t|t.pillaged)),
        "actions":view.log.iter().collect::<Vec<_>>(),"thoughts":journal.since(0).thoughts,
        "counters":view.players[0].counters})
    );
}
