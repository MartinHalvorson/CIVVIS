//! Version-two Culture air-interception integration fixtures.
use super::*;

#[cfg(test)]
mod tests;
