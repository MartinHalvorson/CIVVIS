use super::*;
use std::sync::Arc;

fn fixture() -> (Game, AdvancedAi, StrategicPlan, [u32; 2], [Pos; 2]) {
    let mut g = Game::new_full(4, 36, 24, 59002899, 500, 0, false);
    for uid in g.units.keys().copied().collect::<Vec<_>>() {
        g.remove_unit(uid);
    }
    g.barb_camps.clear();
    for tile in g.map.tiles.values_mut() {
        tile.terrain = crate::name!("grassland");
        tile.feature = None;
        tile.resource = None;
        tile.hills = false;
    }
    let base = (5, 8);
    g.found_city_for(0, base, None);
    g.found_city_for(0, (2, 14), None);
    g.found_city_for(1, (25, 16), None);
    let town = g.found_city_for(1, (11, 16), None);
    g.cities.get_mut(&town).unwrap().is_capital = false;
    let cities = [
        g.found_city_for(2, (15, 8), None),
        g.found_city_for(2, (16, 4), None),
    ];
    g.found_city_for(3, (29, 20), None);
    let theaters = [(14, 8), (15, 4)];
    for (city, pos) in cities.into_iter().zip(theaters) {
        g.cities
            .get_mut(&city)
            .unwrap()
            .districts
            .insert(crate::name!("theater_square"), pos);
        let tile = g.map.tiles.get_mut(&pos).unwrap();
        tile.owner_city = Some(city);
        tile.district = Some(crate::name!("theater_square"));
        tile.pillaged = false;
    }
    for rival in [1, 2, 3] {
        g.record_contact(0, rival);
    }
    g.at_war.clear();
    g.at_war.insert((0, 1));
    g.players[1].dvp = 16;
    g.current = 0;
    g.turn = 185;
    g.players[0].gold = 10000.0;
    g.players[0]
        .strategic_resources
        .insert(crate::name!("aluminum"), 100.0);
    let bombers = [
        g.spawn_test_unit("bomber", 0, base),
        g.spawn_test_unit("bomber", 0, base),
    ];
    for pos in [(13, 8), (14, 4)] {
        g.spawn_test_unit("scout", 0, pos);
    }
    let powers = Arc::make_mut(&mut g.observed_military_power);
    powers.insert(0, 1307.0);
    powers.insert(1, 200.0);
    powers.insert(2, 2506.0);
    let stats = Arc::make_mut(&mut g.observed_public_empire_stats);
    stats.entry(0).or_default().domestic_tourists = Some(100);
    let racer = stats.entry(2).or_default();
    racer.foreign_tourists = Some(85);
    racer.culture_turns_to_victory = Some(10.0);
    let mut ai = AdvancedAi::targeting(VictoryTarget::Domination);
    ai.enable_one_war_at_a_time();
    ai.enable_diplomatic_contender_eliminated();
    ai.enable_elimination_yields_to_a_launch();
    ai.one_war_observe(&g, 0);
    let plan = StrategicPlan {
        strategy: GrandStrategy::Conquest,
        target_player: Some(1),
        target_city: Some(town),
        threatened_city: None,
        desired_cities: 2,
        assessed_turn: g.turn,
        rush: false,
    };
    (g, ai, plan, bombers, theaters)
}

#[test]
fn baseline_keeps_the_elimination_war_beside_a_declarable_outgunning_culture_racer() {
    let (mut g, mut ai, plan, bombers, theaters) = fixture();
    assert!(g.military_power(0) < g.military_power(2));
    assert!(ai.urgent_victory_threat(&g, 2));
    assert!(ai.preferred_war_opening(&g, 0, 2).is_some_and(|a| matches!(
        a,
        Action::DeclareWar { .. } | Action::DeclareWarWithCasusBelli { .. }
    )));
    assert_eq!(ai.diplomatic_contender_to_eliminate(&g, 0), Some(1));
    assert!(!ai.elimination_yields_to_a_launch(&g, 0, 1));
    assert!(ai.one_war_holds_declaration(&g, 0, 2));
    let opening = ai.preferred_war_opening(&g, 0, 2).unwrap();
    let mut physical = g.speculative_clone();
    physical.apply(0, &opening).unwrap();
    for (uid, target) in bombers.into_iter().zip(theaters) {
        physical
            .apply(0, &Action::AirPillage { unit: uid, target })
            .unwrap();
        assert!(physical.units[&uid].hp >= 60);
        assert!(physical.map.get(target).unwrap().pillaged);
    }
    ai.advanced_diplomacy(&mut g, 0, &plan);
    assert!(g.is_at_war(0, 1));
    assert!(!g.is_at_war(0, 2));
}
