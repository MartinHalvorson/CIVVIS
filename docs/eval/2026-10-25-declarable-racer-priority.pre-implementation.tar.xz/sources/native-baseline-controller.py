import pathlib,json,hashlib,subprocess,time,resource,shutil
root=pathlib.Path('/tmp/civvis-declarable-racer-priority-5684');work=pathlib.Path.cwd();out=root/'native-baseline-queries';out.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
deps=work/'target/ci/deps';lib=deps/'libcivvis-e26cdcfa7a10e4e6.rlib';frozen=root/'frozen-baseline-library';frozen.mkdir();shutil.copy2(lib,frozen/lib.name)
source=work/'docs/eval/2026-10-25-declarable-racer-priority.native-query.rs';genome=work/'docs/eval/2026-10-25-declarable-racer-priority.genome.json';manifest=root/'mission-inputs/manifest.json';binary=root/'baseline-native-query'
command=['rustc','--edition=2021','-C','opt-level=3','-C','debug-assertions=yes','-C','codegen-units=16','-L',f'dependency={deps}','--extern',f'civvis={frozen/lib.name}','--extern',f'serde_json={deps}/libserde_json-5d92e8a1d79db490.rlib','--crate-name','culture_air_native_query',str(source),'-o',str(binary)]
meta={'scope':'new-main baseline, test-only fixture module and rustfmt; no new behavior flag or policy', 'checkout_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'library_sha256':sha(frozen/lib.name),'library_path':str(frozen/lib.name),'source_sha256':sha(source),'command':command,'genome_sha256':sha(genome),'manifest_sha256':sha(manifest),'fingerprint':json.loads((work/'target/ci/.fingerprint/civvis-e26cdcfa7a10e4e6/lib-civvis.json').read_text())}
meta['build_script_outputs']={str(p):p.read_text() for p in (work/'target/ci/build').glob('civvis-*/output')}
meta['checkout_diff']=subprocess.check_output(['git','diff','HEAD','--','src'],text=True)
with (out/'build.log').open('wb') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
meta['build_exit_code']=r.returncode
if r.returncode: print((out/'build.log').read_text()); raise SystemExit(r.returncode)
meta['binary_sha256']=sha(binary);(out/'build.json').write_text(json.dumps(meta,indent=2)+'\n')
case_manifest=json.loads(manifest.read_text());records=[]
ledger={'scope':'registered fresh-controller baseline; not original native planner history','build':meta,'cases':records,'status':'running','started_at':time.time()}
def save(): (out/'ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
save()
for index,case in enumerate(case_manifest['cases']):
 p=pathlib.Path(case['path']);assert sha(p)==case['input_sha256'];assert p.stat().st_size==case['input_bytes']
 for arm in ['off','v1']:
  cmd=[str(binary),str(manifest),str(genome),str(index),arm];name=f'{index:02d}-{arm}';rec={'index':index,'tag':case['tag'],'turn':case['turn'],'arm':arm,'command':cmd,'started_at':time.time()};before=resource.getrusage(resource.RUSAGE_CHILDREN)
  with (out/f'{name}.json').open('wb') as stdout,(out/f'{name}.log').open('wb') as stderr:
   try:
    r=subprocess.run(cmd,stdout=stdout,stderr=stderr,timeout=120);rec['exit_code']=r.returncode;rec['status']='complete' if r.returncode==0 else 'failed'
   except subprocess.TimeoutExpired:rec.update(status='timeout',exit_code=None)
  after=resource.getrusage(resource.RUSAGE_CHILDREN);rec.update(finished_at=time.time(),user_cpu_seconds=after.ru_utime-before.ru_utime,system_cpu_seconds=after.ru_stime-before.ru_stime,output_sha256=sha(out/f'{name}.json'),stderr_sha256=sha(out/f'{name}.log'))
  if rec['status']=='complete':
   d=json.loads((out/f'{name}.json').read_text());rec['plan']=d['plan'];rec['new_air_rebases']=[a for a in d['actions'] if 'AirRebase' in json.dumps(a)];rec['interception_counters']={k:v for k,v in d['counters'].items() if 'elimination-yields-to-a-launch-2:' in k}
  records.append(rec);save();print(json.dumps({k:rec[k] for k in ['index','tag','turn','arm','status']}),flush=True)
ledger.update(status='complete',finished_at=time.time());save()
