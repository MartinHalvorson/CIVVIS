"""Paired decider queries on live frames of the eight wars that took our
original capital on 2026-11-18, from three turns before the declaration to
the last turn the capital was held.

`shooters-man-the-capital` is the only bit that varies. Each case is a live
run's own events.jsonl cut after the FIRST state row of turn N (the board the
seat saw at the start of its turn, every unit's movement and attack unspent),
replayed at turn N. Both arms run one frozen `civvis_orders --resumed` built
from the branch (profile ci), with that run's own requested genome (why.log
line 1 `forced`, each as `--with`); the on arm adds
`--with shooters-man-the-capital`.

Read per arm, from the proposed orders and the board's state row:
- our land shooters (ranged class, reach two or more, not embarked), how many
  stand in or beside the original capital's City Center on the board, and how
  many the arm's orders leave there (the last MOVE_TO of each, or its tile);
- RANGE_ATTACK orders of those shooters on the tile of a siege gun of a power
  at war with us standing within eight tiles of the capital, and elsewhere;
- shooters ordered nearer the capital and farther from it;
- the gene's journal lines.

Cases: Xanadu in civvis-20261118T073734Z (Khmer, t37-t42), Tenochtitlan in
-074013Z (Rome, t71-t75), Washington in -083517Z (Persia, t82-t87), Mbanza
Kongo in -090535Z (England, t85-t92), Beijing in -093554Z (Hungary, t63-t73),
Stirling in -101656Z (Russia, t100-t104), Stockholm in -051302Z (England,
t84-t95) and Rio de Janeiro in -104821Z (Norway, t24-t30).

This records proposal activation on captured live input only. It does not
execute in Civ VI, replays one turn at a time from the live board (so no
order's outcome carries to the next board), and makes no claim that a city
holds.
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'shooters-man-the-capital'
RUNS = Path.home() / 'civvis-score-tools/deity-18/capital'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

GAMES = [
    ('civvis-20261118T073734Z', 'diplomatic', 'CIVILIZATION_MONGOLIA', range(37, 43)),
    ('civvis-20261118T074013Z', 'science', 'CIVILIZATION_AZTEC', range(71, 76)),
    ('civvis-20261118T083517Z', 'culture', 'CIVILIZATION_AMERICA', range(82, 88)),
    ('civvis-20261118T090535Z', 'culture', 'CIVILIZATION_KONGO', range(85, 93)),
    ('civvis-20261118T093554Z', 'science', 'CIVILIZATION_CHINA', range(63, 74)),
    ('civvis-20261118T101656Z', 'science', 'CIVILIZATION_SCOTLAND', range(100, 105)),
    ('civvis-20261118T051302Z', 'diplomatic', 'CIVILIZATION_SWEDEN', range(84, 96)),
    ('civvis-20261118T104821Z', 'science', 'CIVILIZATION_BRAZIL', range(24, 31)),
]
if len(sys.argv) > 4:  # a smoke run: RUN-SUFFIX:TURN[,TURN...]
    suffix, turns = sys.argv[4].split(':')
    GAMES = [(r, v, c, [int(t) for t in turns.split(',')]) for r, v, c, _ in GAMES if r.endswith(suffix)]
CASES = [{'run': r, 'victory': v, 'civ': c, 'turn': t} for r, v, c, turns in GAMES for t in turns]
GUNS = ('CATAPULT', 'TREBUCHET', 'BOMBARD', 'ARTILLERY', 'DOMREY', 'ROCKET')
HOLDS = ('FORTIFY', 'SKIP', 'SLEEP', 'ALERT', 'HEAL')


def ax(x, y):
    return x - (y - (y & 1)) // 2, y


def axd(a, b):
    dq, dr = a[0] - b[0], a[1] - b[1]
    return (abs(dq) + abs(dr) + abs(dq + dr)) // 2


def cut(run, turn):
    """Rows through the first state row of `turn`, and that row."""
    rows = []
    with open(RUNS / run / 'events.jsonl', errors='replace') as f:
        for line in f:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > turn:
                break
            rows.append(line)
            if e.get('kind') == 'state' and e.get('turn') == turn:
                return ''.join(rows).encode(), e
    raise ValueError(f'{run} has no state row for turn {turn}')


def board(state):
    capital = next(c for c in state['cities']
                   if c.get('original_capital') and c.get('original_owner') in (0, None))
    cpos = ax(capital['x'], capital['y'])
    shooters = {}
    for u in state['units']:
        cls = u.get('class') or ''
        if 'RANGED' in cls and (u.get('range') or 0) >= 2 and not u.get('embarked'):
            shooters[u['id']] = (u['x'], u['y'])
    guns, party, engines_peace = set(), 0, 0
    for r in state['rivals']:
        for u in r.get('units') or []:
            d = axd(ax(u['x'], u['y']), cpos)
            kind = u.get('kind') or ''
            if d <= 8 and any(k in kind for k in GUNS):
                if r.get('at_war'):
                    guns.add((u['x'], u['y']))
                else:
                    engines_peace += 1
            elif d <= 8 and ('BATTERING_RAM' in kind or 'SIEGE_TOWER' in kind) and not r.get('at_war'):
                engines_peace += 1
            elif d <= 6 and (u.get('combat') or 0) > 0 and 'RECON' not in (u.get('class') or '') and u.get('class'):
                party += 1
    return capital, cpos, shooters, guns, party, engines_peace


def read_arm(row, state):
    capital, cpos, shooters, guns, party, engines_peace = board(state)
    last_move, shots_gun, shots_other, held = {}, 0, 0, set()
    for o in row.get('payload', {}).get('orders', []):
        if o.get('kind') != 'unit' or o.get('subject') not in shooters:
            continue
        verb = o.get('verb')
        if verb == 'MOVE_TO' and o.get('x') is not None:
            last_move[o['subject']] = (o['x'], o['y'])
        elif verb == 'RANGE_ATTACK':
            if (o.get('x'), o.get('y')) in guns:
                shots_gun += 1
            else:
                shots_other += 1
        elif verb in HOLDS:
            held.add(o['subject'])
    start = {u: axd(ax(*p), cpos) for u, p in shooters.items()}
    end = {u: axd(ax(*last_move.get(u, p)), cpos) for u, p in shooters.items()}
    journal = row['journal_gene']
    return {
        'shooters': len(shooters),
        'within1_on_the_board': sum(1 for d in start.values() if d <= 1),
        'within1_after_orders': sum(1 for d in end.values() if d <= 1),
        'ordered_nearer': sum(1 for u in shooters if end[u] < start[u]),
        'ordered_farther': sum(1 for u in shooters if end[u] > start[u]),
        'shots_at_guns': shots_gun,
        'shots_elsewhere': shots_other,
        'guns_at_war_within_8': len(guns),
        'party_within_6': party,
        'engines_at_peace_within_8': engines_peace,
        'journal_called': sum(1 for line in journal if 'Shooters man the capital' in line),
        'journal_fires': sum(1 for line in journal if 'fires on the' in line),
        'journal_stands': sum(1 for line in journal if 'takes its stand' in line),
        'journal_comes_home': sum(1 for line in journal if 'comes home to the capital' in line),
    }


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data, state = cut(case['run'], case['turn'])
        capital = board(state)[0]
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'],
                                 'cut': 'through the first state row of the turn'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                  'capital': {k: capital.get(k) for k in ('name', 'x', 'y', 'damage', 'wall_damage',
                                                          'max_wall_damage')},
                  'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', case['victory'], '--civ', case['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if 'shooters-man-the-capital' in line
                                   or 'Shooters man the capital' in line]
            row['read'] = read_arm(row, state)
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


KEYS = ('shooters', 'within1_on_the_board', 'within1_after_orders', 'ordered_nearer', 'ordered_farther',
        'shots_at_guns', 'shots_elsewhere', 'journal_called', 'journal_fires', 'journal_stands',
        'journal_comes_home')


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
             'boards_with_a_gun_at_war': 0, 'boards_the_watch_reads': 0}
    for arm in ('off', 'on'):
        for key in KEYS:
            total[f'{arm}_{key}'] = sum(a['read'][key] for r in results for v in r['reads']
                                        for a in v['arms'] if a['arm'] == arm)
    for r in results:
        c = r['case']
        if r.get('error'):
            print(c['run'], c['turn'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            off, on = (a['read'] for a in v['arms'])
            total['boards_with_a_gun_at_war'] += bool(off['guns_at_war_within_8'])
            total['boards_the_watch_reads'] += bool(on['journal_called'])
            print(f"{c['run'][-8:]} t{c['turn']:<3} {v['capital']['name'][:12]:12} "
                  f"{'CHANGED' if v['orders_changed'] else 'same   '} | shooters {off['shooters']} within1 {off['within1_on_the_board']}"
                  f" guns {off['guns_at_war_within_8']} party {off['party_within_6']} peace-engines {off['engines_at_peace_within_8']}"
                  f" | off: end within1 {off['within1_after_orders']} nearer {off['ordered_nearer']} farther {off['ordered_farther']}"
                  f" gun-shots {off['shots_at_guns']} other {off['shots_elsewhere']}"
                  f" | on: end within1 {on['within1_after_orders']} nearer {on['ordered_nearer']} farther {on['ordered_farther']}"
                  f" gun-shots {on['shots_at_guns']} other {on['shots_elsewhere']}"
                  f" (journal: called {on['journal_called']} fires {on['journal_fires']} stands {on['journal_stands']} home {on['journal_comes_home']})")
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
