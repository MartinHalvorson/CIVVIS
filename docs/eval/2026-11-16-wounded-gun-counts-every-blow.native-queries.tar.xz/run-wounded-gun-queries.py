#!/usr/bin/env python3
"""Paired one-frame queries for `wounded-gun-counts-every-blow` on live boards.

run-wounded-gun-queries.py BIN OUTDIR FRAMES_JSON [REPO] [LANE NLANES]

FRAMES_JSON: [[run, turn, civ6 unit id, kind, hp, city, killer], ...] (one board
per (run, turn)). Each board is the live run's events.jsonl cut after the turn's
FIRST agent `state` row (`--turn T` alone reads the turn's last state row,
which is the replan after the live orders), with its summary.json. Both arms
run one civvis_orders binary: `--mirror <copy> --turn T --resumed --explain
--victory domination --civ <the run's civ>` plus the run's own requested genome
(summary.json `forced`, each as `--with`); the on arm adds `--with
wounded-gun-counts-every-blow`. Each board writes OUTDIR/native-queries-01/NNNN/
result.json in the `captured_native_action_pairs_v1` member shape
(`tools/gene_fires.py`), plus the arms' stderr journals beside it.
"""
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

TAG = "wounded-gun-counts-every-blow"
CONTROL = Path.home() / "civvis-civ6-runs/control"


def cut(run: str, turn: int) -> bytes:
    out = []
    with open(CONTROL / run / "events.jsonl", "rb") as handle:
        for line in handle:
            out.append(line)
            if b'"kind": "state"' in line:
                row = json.loads(line)
                if row.get("kind") == "state" and row.get("turn") == turn:
                    return b"".join(out)
    raise SystemExit(f"{run} has no state row for turn {turn}")


def civ_of(run: str) -> str:
    with open(CONTROL / run / "events.jsonl") as handle:
        for line in handle:
            if '"civ": "CIVILIZATION_' in line:
                return json.loads(line)["civ"]
    raise SystemExit(f"{run}: no civ")


def main():
    binary, outdir, frames = sys.argv[1], Path(sys.argv[2]), json.load(open(sys.argv[3]))
    repo = Path(sys.argv[4]) if len(sys.argv) > 4 else Path.home() / "civvis-guns-survive-58"
    lane, lanes = (int(sys.argv[5]), int(sys.argv[6])) if len(sys.argv) > 6 else (0, 1)
    sys.path.insert(0, str(repo / "tools"))
    import civ6_ladder  # noqa: E402

    boards = sorted({(f[0], f[1]) for f in frames})
    root = outdir / "native-queries-01"
    root.mkdir(parents=True, exist_ok=True)
    shutil.copy(__file__, outdir / "run-wounded-gun-queries.py")
    for index, (run, turn) in enumerate(boards):
        if index % lanes != lane:
            continue
        events = cut(run, turn)
        digest = hashlib.sha256(events).hexdigest()
        summary = (CONTROL / run / "summary.json").read_bytes()
        forced = json.loads(summary)["forced"]
        civ = civ_of(run)
        arms = []
        member = root / f"{index:04d}"
        member.mkdir(exist_ok=True)
        for arm in ("off", "on"):
            with tempfile.TemporaryDirectory(prefix=f"wg-{arm}-") as tmp:
                board = Path(tmp) / run
                board.mkdir()
                (board / "events.jsonl").write_bytes(events)
                (board / "summary.json").write_bytes(summary)
                argv = [binary, "--mirror", str(board), "--turn", str(turn), "--resumed", "--explain",
                        "--victory", "domination", "--civ", civ]
                for tag in forced:
                    argv += ["--with", tag]
                if arm == "on":
                    argv += ["--with", TAG]
                done = subprocess.run(argv, capture_output=True, timeout=900)
                why = member / f"{arm}.why"
                why.write_bytes(done.stderr)
                genome = civ6_ladder.decider_genome(why)
                try:
                    payload = json.loads(done.stdout)
                except ValueError:
                    payload = {"orders": None, "raw": done.stdout.decode(errors="replace")[:2000]}
                arms.append({"arm": arm, "argv": argv, "exit": done.returncode, "genome": genome,
                             "payload": payload})
        record = {"complete": True, "board": {"run": run, "turn": turn, "civ": civ},
                  "reads": [{"complete": True, "sha256": digest, "bytes": len(events), "arms": arms}]}
        (member / "result.json").write_text(json.dumps(record))
        changed = arms[0]["payload"].get("orders") != arms[1]["payload"].get("orders")
        print(f"{index:04d} {run} t{turn} exit {arms[0]['exit']}/{arms[1]['exit']} changed={changed}", flush=True)


if __name__ == "__main__":
    main()
