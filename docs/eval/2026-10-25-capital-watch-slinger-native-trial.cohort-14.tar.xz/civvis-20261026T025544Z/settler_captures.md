# Settler captures — civvis-20261026T025544Z

1 capture(s). Mechanism is the first match in the operator's order; every match is listed.

## t124 settler 5373968 at (25,17) — `alone-in-fog`

- detected by: `unit_captured`, captor player 3
- mechanisms matched: alone-in-fog
- nearest hostile: none
- guard: none

### Settler t-2..t

| turn | pos | moves | activity | hostiles within 3 | ours within 2 |
|---|---|---|---|---|---|
| t122 | (not in frame) | | | | |
| t123 | (25,17) | 0 | awake | none | none |
| t124 | (25,17) | 3 | awake | none | none |

### Orders (settler and guard)

- `{"checked_on": 123, "kind": "order_failed", "order_kind": "city_strike", "reason": "target_unharmed", "subject": 327684, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z"}`
- `{"checked_on": 123, "kind": "order_failed", "order_kind": "unit", "reason": "host_refused_strike", "subject": 5242887, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "RANGE_ATTACK"}`
- `{"checked_on": 123, "kind": "order_failed", "order_kind": "unit", "reason": "unit_gone", "subject": 5177360, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "FORTIFY"}`
- `{"checked_on": 123, "kind": "order_failed", "order_kind": "unit", "reason": "superseded_by_move", "subject": 2686996, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "FORTIFY"}`
- `{"checked_on": 123, "kind": "order_failed", "order_kind": "combat_policy", "reason": "combat_policy_not_acknowledged", "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.910Z", "verb": "CONGRESS_GUARDS_THE_LEADER"}`
- `{"checked_on": 123, "kind": "order_failed", "order_kind": "unit", "reason": "host_refused_strike", "subject": 5242887, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.910Z", "verb": "RANGE_ATTACK"}`
- `{"checked_on": 123, "kind": "order_failed", "order_kind": "unit", "reason": "unit_gone", "subject": 5177360, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.910Z", "verb": "MOVE_TO"}`
- `{"checked_on": 123, "kind": "order_failed", "order_kind": "combat_policy", "reason": "combat_policy_not_acknowledged", "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.910Z", "verb": "CONGRESS_GUARDS_THE_LEADER"}`
- `{"checked_on": 123, "kind": "order_failed", "order_kind": "unit", "reason": "not_fortified", "subject": 5242887, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.910Z", "verb": "FORTIFY"}`
- `{"checked_on": 123, "kind": "order_failed", "order_kind": "combat_policy", "reason": "combat_policy_not_acknowledged", "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.910Z", "verb": "CONGRESS_GUARDS_THE_LEADER"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "produce", "subject": 262147, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "BUILDING_CASTLE"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "produce", "subject": 393221, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "BUILDING_UNIVERSITY"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "produce", "subject": 327684, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "PROJECT_ENHANCE_DISTRICT_CAMPUS"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "city_strike", "subject": 131073, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "city_strike", "subject": 196610, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "city_strike", "subject": 262147, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "unit", "subject": 5308442, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "TRADE_ROUTE"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "unit", "subject": 4980758, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "MOVE_TO"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "unit", "subject": 4390935, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "MOVE_TO"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "unit", "subject": 4784134, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "MOVE_TO"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "unit", "subject": 4587529, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "MOVE_TO"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "unit", "subject": 4587529, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "SPREAD_RELIGION"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "unit", "subject": 3473436, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "MOVE_TO"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "unit", "subject": 3735567, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "MOVE_TO"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "unit", "subject": 5177360, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "MOVE_TO"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "unit", "subject": 2686996, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "MOVE_TO"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "unit", "subject": 4915218, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.909Z", "verb": "MOVE_TO"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "combat_policy", "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.910Z", "verb": "DOOMED_BLOW_VETO"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "combat_policy", "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.910Z", "verb": "DIALOGUE_NEVER_DECLARES_WAR"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "unit", "subject": 4784134, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.910Z", "verb": "MOVE_TO"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "unit", "subject": 1114114, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.910Z", "verb": "MOVE_TO"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "unit", "subject": 2686996, "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.910Z", "verb": "MOVE_TO"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "combat_policy", "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.910Z", "verb": "DOOMED_BLOW_VETO"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "combat_policy", "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.910Z", "verb": "DIALOGUE_NEVER_DECLARES_WAR"}`
- `{"checked_on": 123, "kind": "order_verified", "order_kind": "combat_policy", "t": 1792983759, "turn": 122, "utc": "2026-10-26T03:02:39.910Z", "verb": "DIALOGUE_NEVER_DECLARES_WAR"}`
- `{"checked_on": 124, "kind": "order_failed", "order_kind": "unit", "reason": "host_refused_strike", "subject": 5242887, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "RANGE_ATTACK"}`
- `{"checked_on": 124, "kind": "order_failed", "order_kind": "unit", "reason": "did_not_move", "subject": 1114114, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "MOVE_TO"}`
- `{"checked_on": 124, "kind": "order_failed", "order_kind": "combat_policy", "reason": "combat_policy_not_acknowledged", "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "CONGRESS_GUARDS_THE_LEADER"}`
- `{"checked_on": 124, "kind": "order_failed", "order_kind": "unit", "reason": "not_fortified", "subject": 5242887, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "FORTIFY"}`
- `{"checked_on": 124, "kind": "order_failed", "order_kind": "combat_policy", "reason": "combat_policy_not_acknowledged", "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "CONGRESS_GUARDS_THE_LEADER"}`
- `{"checked_on": 124, "kind": "order_failed", "order_kind": "combat_policy", "reason": "combat_policy_not_acknowledged", "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "CONGRESS_GUARDS_THE_LEADER"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "produce", "subject": 327684, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.292Z", "verb": "UNIT_MUSKETMAN"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "city_strike", "subject": 327684, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.292Z"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "produce", "subject": 196610, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.292Z", "verb": "UNIT_BOMBARD"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "city_strike", "subject": 262147, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.292Z"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "unit", "subject": 3735567, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.292Z", "verb": "MOVE_TO"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "unit", "subject": 4980758, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.292Z", "verb": "MOVE_TO"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "unit", "subject": 4390935, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "MOVE_TO"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "unit", "subject": 4784134, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "MOVE_TO"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "unit", "subject": 4587529, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "SPREAD_RELIGION"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "unit", "subject": 3473436, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "MOVE_TO"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "unit", "subject": 1114114, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "CAPTURE"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "unit", "subject": 1114114, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "MOVE_TO"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "unit", "subject": 1114114, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "MOVE_TO"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "unit", "subject": 2686996, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "MOVE_TO"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "unit", "subject": 4915218, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "ACTIVATE_GREAT_PERSON"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "combat_policy", "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "DOOMED_BLOW_VETO"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "combat_policy", "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "DIALOGUE_NEVER_DECLARES_WAR"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "unit", "subject": 4980758, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "MOVE_TO"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "unit", "subject": 4784134, "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "MOVE_TO"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "combat_policy", "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "DIALOGUE_NEVER_DECLARES_WAR"}`
- `{"checked_on": 124, "kind": "order_verified", "order_kind": "combat_policy", "t": 1792983764, "turn": 123, "utc": "2026-10-26T03:02:44.293Z", "verb": "DIALOGUE_NEVER_DECLARES_WAR"}`
- `{"checked_on": 125, "kind": "order_failed", "order_kind": "produce", "reason": "city_gone", "subject": 262147, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z", "verb": "UNIT_MUSKETMAN"}`
- `{"checked_on": 125, "kind": "order_failed", "order_kind": "unit", "reason": "unit_gone", "subject": 5373968, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z", "verb": "MOVE_TO"}`
- `{"checked_on": 125, "kind": "order_failed", "order_kind": "unit", "reason": "host_refused_strike", "subject": 5242887, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z", "verb": "RANGE_ATTACK"}`
- `{"checked_on": 125, "kind": "order_failed", "order_kind": "unit", "reason": "unit_gone", "subject": 2686996, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z", "verb": "MOVE_TO"}`
- `{"checked_on": 125, "kind": "order_failed", "order_kind": "peace", "reason": "no_peace_response", "subject": 2, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z", "verb": "MAKE_PEACE"}`
- `{"checked_on": 125, "kind": "order_failed", "order_kind": "peace", "reason": "no_peace_response", "subject": 3, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z", "verb": "MAKE_PEACE"}`
- `{"checked_on": 125, "kind": "order_failed", "order_kind": "combat_policy", "reason": "combat_policy_not_acknowledged", "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.715Z", "verb": "CONGRESS_GUARDS_THE_LEADER"}`
- `{"checked_on": 125, "kind": "order_failed", "order_kind": "unit", "reason": "host_noop_cannot_start", "subject": 4390935, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.715Z", "verb": "MOVE_TO"}`
- `{"checked_on": 125, "kind": "order_failed", "order_kind": "unit", "reason": "unit_gone", "subject": 2686996, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.715Z", "verb": "MOVE_TO"}`
- `{"checked_on": 125, "kind": "order_failed", "order_kind": "combat_policy", "reason": "combat_policy_not_acknowledged", "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.715Z", "verb": "CONGRESS_GUARDS_THE_LEADER"}`
- `{"checked_on": 125, "kind": "order_verified", "order_kind": "purchase_faith", "subject": 327684, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z", "verb": "UNIT_MISSIONARY"}`
- `{"checked_on": 125, "kind": "order_verified", "order_kind": "produce", "subject": 393221, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z", "verb": "DISTRICT_COMMERCIAL_HUB"}`
- `{"checked_on": 125, "kind": "order_verified", "order_kind": "city_strike", "subject": 196610, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z"}`
- `{"checked_on": 125, "kind": "order_verified", "order_kind": "city_strike", "subject": 327684, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z"}`
- `{"checked_on": 125, "kind": "order_verified", "order_kind": "unit", "subject": 4980758, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z", "verb": "MOVE_TO"}`
- `{"checked_on": 125, "kind": "order_verified", "order_kind": "unit", "subject": 4390935, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z", "verb": "MOVE_TO"}`
- `{"checked_on": 125, "kind": "order_verified", "order_kind": "unit", "subject": 4784134, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z", "verb": "MOVE_TO"}`
- `{"checked_on": 125, "kind": "order_verified", "order_kind": "unit", "subject": 3473436, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z", "verb": "MOVE_TO"}`
- `{"checked_on": 125, "kind": "order_verified", "order_kind": "unit", "subject": 3735567, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z", "verb": "MOVE_TO"}`
- `{"checked_on": 125, "kind": "order_verified", "order_kind": "unit", "subject": 4849668, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z", "verb": "MOVE_TO"}`
- `{"checked_on": 125, "kind": "order_verified", "order_kind": "combat_policy", "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.714Z", "verb": "DOOMED_BLOW_VETO"}`
- `{"checked_on": 125, "kind": "order_verified", "order_kind": "combat_policy", "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.715Z", "verb": "DIALOGUE_NEVER_DECLARES_WAR"}`
- `{"checked_on": 125, "kind": "order_verified", "order_kind": "unit", "subject": 5242887, "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.715Z", "verb": "FORTIFY"}`
- `{"checked_on": 125, "kind": "order_verified", "order_kind": "combat_policy", "t": 1792983769, "turn": 124, "utc": "2026-10-26T03:02:49.715Z", "verb": "DIALOGUE_NEVER_DECLARES_WAR"}`

### why.log t-2..t

- t122 Strategy/Strategy Campaign remains aimed at Bilbao | the major-war army stays committed until it captures the city or its war target changes  [civ6 (32,26) = axial (19,26)]
- t122 Military/Strategy Board: Defend Quito (value 1167, need 206, force #81 of 3, deadline 2) · Relieve Quito (value 1167, need 74, force #82 of 2, deadline 2) · Defend Caracas (value 1009, need 256, no force, deadline 2) · Relieve Caracas (value 1009, need 76, no force, deadline 2) · Defend Popayán (value 983, need 353, no force, deadline 2) | rows 17 [4 Defend, 4 Relieve, 1 Siege, 1 Escort, 7 Recon], 3 force(s), 0 reassigned, short: 2 Defend, 6 Defend, 2 Relieve, 9 Defend, 6 Relieve, 12 Defend, 6 Relieve, 5 Siege, 1 Recon, 1 Escort, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t122 Strategy/Strategy Campaign remains aimed at Bilbao | the major-war army stays committed until it captures the city or its war target changes  [civ6 (32,26) = axial (19,26)]
- t122 Strategy/Strategy Campaign remains aimed at Bilbao | the major-war army stays committed until it captures the city or its war target changes  [civ6 (32,26) = axial (19,26)]
- t123 Strategy/Strategy Campaign remains aimed at Bilbao | the major-war army stays committed until it captures the city or its war target changes  [civ6 (32,26) = axial (19,26)]
- t123 Cities/Detail Settler held in Maracaibo | the recovery plan holds Settlers while a city is threatened; 5 cities and 0 settlers against a target of 8
- t123 Cities/Detail Settler held in Caracas | the recovery plan holds Settlers while a city is threatened; 5 cities and 0 settlers against a target of 8
- t123 Military/Strategy Board: Defend Quito (value 1167, need 203, force #81 of 2, deadline 2) · Relieve Quito (value 1167, need 144, force #82 of 2, deadline 2) · Defend Caracas (value 1009, need 96, no force, deadline 2) · Defend Popayán (value 983, need 371, no force, deadline 2) · Relieve Popayán (value 983, need 312, no force, deadline 2) | rows 15 [4 Defend, 2 Relieve, 1 Siege, 1 Escort, 7 Recon], 3 force(s), 0 reassigned, short: 4 Defend, 2 Relieve, 3 Defend, 10 Defend, 9 Relieve, 5 Defend, 6 Siege, 1 Recon, 1 Escort, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t123 Strategy/Strategy Campaign remains aimed at Bilbao | the major-war army stays committed until it captures the city or its war target changes  [civ6 (32,26) = axial (19,26)]
- t123 Cities/Detail Settler held in Maracaibo | the recovery plan holds Settlers while a city is threatened; 5 cities and 1 settler against a target of 8
- t123 Cities/Detail Settler held in Caracas | the recovery plan holds Settlers while a city is threatened; 5 cities and 1 settler against a target of 8
- t123 Strategy/Strategy Campaign remains aimed at Bilbao | the major-war army stays committed until it captures the city or its war target changes  [civ6 (32,26) = axial (19,26)]
- t123 Cities/Detail Settler held in Maracaibo | the recovery plan holds Settlers while a city is threatened; 5 cities and 1 settler against a target of 8
- t123 Cities/Detail Settler held in Caracas | the recovery plan holds Settlers while a city is threatened; 5 cities and 1 settler against a target of 8
- t124 Strategy/Strategy Campaign remains aimed at Bilbao | the major-war army stays committed until it captures the city or its war target changes  [civ6 (32,26) = axial (19,26)]
- t124 Military/Strategy Board: Defend Popayán (value 983, need 534, force #84 of 4, deadline 2) · Defend Quito (value 1167, need 441, no force, deadline 2) · Relieve Quito (value 1167, need 377, no force, deadline 2) · Defend Caracas (value 1009, need 259, no force, deadline 2) · Relieve Caracas (value 1009, need 82, no force, deadline 2) | rows 18 [5 Defend, 4 Relieve, 1 Siege, 1 Escort, 7 Recon], 2 force(s), 4 reassigned, short: 10 Defend, 12 Defend, 10 Relieve, 7 Defend, 3 Relieve, 12 Relieve, 13 Defend, 8 Relieve, 3 Defend, 6 Siege, 1 Recon, 2 Escort, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t124 Expansion/Detail Settler retreats from a hostile's reach | 8 raider(s) could take (17, 17) next turn; (18, 17) is out of reach  [civ6 (26,17) = axial (18,17)]
- t124 Strategy/Strategy Campaign remains aimed at Bilbao | the major-war army stays committed until it captures the city or its war target changes  [civ6 (32,26) = axial (19,26)]
- t124 Expansion/Detail Settler retreats from a hostile's reach | 8 raider(s) could take (17, 17) next turn; (18, 17) is out of reach  [civ6 (26,17) = axial (18,17)]

