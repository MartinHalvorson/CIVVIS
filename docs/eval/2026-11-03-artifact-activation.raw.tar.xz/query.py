"""Fresh fixed-board activation proposals; never publishes to a live host."""
from pathlib import Path
import argparse,datetime,hashlib,json,subprocess,sys
repo=Path('/Users/martbot-mbp-m5-max-128/civvis-main-managed');sys.path.insert(0,str(repo/'tools'))
from civ6_decision_trace import captured_input
from civ6_ladder import decider_genome
from civ6_captured_read_replay import exact_fact,control_payload
sha=lambda raw:hashlib.sha256(raw).hexdigest()
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--candidate',type=Path,required=True)
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args();out=args.out.resolve();out.mkdir(exist_ok=False)
root=Path(__file__).parent
run=Path('/Users/martbot-mbp-m5-max-128/civvis-civ6-runs/control/civvis-20261103T002240Z')
before=Path('/Users/martbot-mbp-m5-max-128/civvis-runs/2026-11-02-native-process-context/civvis-20261102T232731Z/frozen-observed-orders')
candidate=args.candidate.resolve();tag='artifact-before-more-museums'
genome=decider_genome(run/'why.log');profile=sorted(genome['forced']);assert tag not in genome['treatments']
seat=json.loads((run/'summary.json').read_text())['seat']
records=[json.loads(x) for x in (run/'decisions.jsonl').read_bytes().splitlines()]
intent={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_run':run.name,'turns':[153,160,175,176],'binary_sha256':{'before':sha(before.read_bytes()),'candidate':sha(candidate.read_bytes())},'arms':['before-off','candidate-off','candidate-on','candidate-on-repeat','candidate-off-repeat'],'scope':'Disposable fresh-board proposal comparisons, not persistent native replay, host execution, artifact delivery, Great Person activation or strength evidence. No live policy or flag is changed.'}
assert intent['binary_sha256']['before']=='3a26064884da5f21285c279a3e8105b05fa99c6e880376f6849c24fb99514d6d'
(out/'intent.json').write_text(json.dumps(intent,indent=2)+'\n')
report={'intent':intent,'cases':[]}
for turn in intent['turns']:
 record=next(r for r in records if (r['decision']['turn'],r['decision']['frame'])==(turn,0));cap=record['input_capture'];assert cap['complete'] and record['binary_on_disk_sha256']==intent['binary_sha256']['before']
 selected=None
 for read in cap['reads']:
  raw=captured_input(cap,read['snapshot_id']);states=[json.loads(line) for line in raw.splitlines() if json.loads(line).get('kind')=='state']
  if states and (states[-1]['turn'],states[-1].get('frame',0))==(turn,0):selected=(raw,read['snapshot_id']);break
 assert selected
 raw,snapshot=selected;directory=out/f'case-{turn}';directory.mkdir();(directory/'captured-events.jsonl').write_bytes(raw)
 case={'turn':turn,'source_decision_sha256':record['sha256'],'snapshot':snapshot,'complete':False,'reads':[{'complete':True,'sha256':sha(raw),'bytes':len(raw),'arms':[]}],'controls':[]};report['cases'].append(case);arms={}
 for label in intent['arms']:
  binary=before if label=='before-off' else candidate;on=label in ['candidate-on','candidate-on-repeat'];d=directory/label;d.mkdir();(d/'events.jsonl').write_bytes(raw)
  argv=[str(binary),'--mirror',str(d),'--turn',str(turn),'--victory','culture','--civ',seat['civ'],'--fresh-board','--explain']
  for flag in sorted(profile+([tag] if on else [])):argv+=['--with',flag]
  p=subprocess.run(argv,cwd=repo,capture_output=True,timeout=60);(d/'stdout').write_bytes(p.stdout);(d/'stderr').write_bytes(p.stderr)
  realized=decider_genome(d/'stderr');a={'label':label,'argv':argv,'exit':p.returncode,'genome':realized};case['controls'].append(a)
  (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
  assert p.returncode==0 and realized and sorted(realized['treatments'])==sorted(genome['treatments']+([tag] if on else [])) and sorted(realized['forced'])==sorted(profile+([tag] if on else []))
  a['payload']=json.loads(p.stdout);arms[label]=a;(d/'events.jsonl').unlink()
 for left,right in [('before-off','candidate-off'),('candidate-off','candidate-off-repeat'),('candidate-on','candidate-on-repeat')]:
  assert exact_fact(control_payload(arms[left]['payload']),control_payload(arms[right]['payload'])),(turn,left,right,'full payload differs')
 for arm,label in [('off','candidate-off'),('on','candidate-on')]:case['reads'][0]['arms'].append({'arm':arm,**{k:v for k,v in arms[label].items() if k!='label'}})
 old=arms['candidate-off']['payload']['orders'];new=arms['candidate-on']['payload']['orders'];case['changed']=old!=new;case['removed_orders']=[o for o in old if o not in new];case['added_orders']=[o for o in new if o not in old];case['complete']=True
 (directory/'result.json').write_text(json.dumps(case,indent=2)+'\n');(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:case[k] for k in ['turn','changed','removed_orders','added_orders']}),flush=True)
assert any(c['changed'] for c in report['cases']),'No demonstrated proposal activation; withhold the candidate.'
