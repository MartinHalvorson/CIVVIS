"""Validate matched genomes and original reproduction; distinguish model wins from host outcomes."""
import argparse, hashlib, json, pathlib
P=argparse.ArgumentParser();P.add_argument('--out',required=True);args=P.parse_args()
B=pathlib.Path('/tmp/civvis-forward-airfield-project-8c23');root=B/'paired-models-02-positions'
original=[json.loads(l) for l in (B/'native-profile-proxy.jsonl').read_text().splitlines()]
header=original[0];gene=header['genes'].index('forward-airfield-project')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(row,genome=False):return {k:v for k,v in row.items() if k!='secs' and (not genome or k!='genome')}
report={'scope':__doc__,'original_sha256':sha(B/'native-profile-proxy.jsonl'),'cases':[],'pending':[]}
for game in range(8):
 dirs={a:root/f'{game:02}-{a}' for a in ['off','on']}
 if any(not (d/'rows.json').exists() for d in dirs.values()):report['pending'].append(game);continue
 contracts={a:read(d/'contract.json') for a,d in dirs.items()};seat=contracts['off']['measured_seat']
 assert contracts['on']['measured_seat']==seat
 changes=[(s,i) for s,(off,on) in enumerate(zip(contracts['off']['genomes'],contracts['on']['genomes'])) for i,(x,y) in enumerate(zip(off,on)) if x!=y]
 assert changes==[(seat,gene)],changes
 assert contracts['off']['genomes'][seat][gene]=='0' and contracts['on']['genomes'][seat][gene]=='1'
 assert (dirs['off']/'initial-game.json').read_bytes()==(dirs['on']/'initial-game.json').read_bytes()
 rows={a:read(d/'rows.json') for a,d in dirs.items()};old=sorted([r for r in original[1:] if r['game']==game],key=lambda r:r['seat'])
 for a in rows:rows[a]=sorted(rows[a],key=lambda r:r['seat'])
 old_arm='on' if old[seat]['genome'][gene]=='1' else 'off'
 reproduction=all(canonical(x)==canonical(y) for x,y in zip(old,rows[old_arm])) and len(old)==len(rows[old_arm])==4
 assert reproduction,('original gameplay not reproduced',game)
 case={'game':game,'seed':contracts['off']['seed'],'seat':seat,'genome_changes':changes,'original_arm':old_arm,'original_rows_reproduced_excluding_seconds':reproduction,'initial_worlds_equal':True,'actions_equal':(dirs['off']/'trace.jsonl').read_bytes()==(dirs['on']/'trace.jsonl').read_bytes(),'terminal_worlds_equal':(dirs['off']/'terminal-game.json').read_bytes()==(dirs['on']/'terminal-game.json').read_bytes(),'all_rows_equal_except_seconds_and_genome':all(canonical(x,True)==canonical(y,True) for x,y in zip(rows['off'],rows['on'])),'arms':{}}
 for a,d in dirs.items():
  world=read(d/'terminal-game.json');r=rows[a][seat];players=world['players']
  caps=[c for c in world['cities'] if c['is_capital'] and not any(players[c['original_owner']][k] for k in ['is_minor','is_barbarian','is_free_city'])]
  case['arms'][a]={'row':r,'terminal':{k:world.get(k) for k in ['turn','winner','victory_type','decided']},'held_foreign_original_major_capitals':[c['id'] for c in caps if c['owner']==seat and c['original_owner']!=seat],'home_original_capital_owner':[c['owner'] for c in caps if c['original_owner']==seat],'observed_candidate_journal_entries':len((d/'policy-journal.jsonl').read_text().splitlines()),'journal_status':read(d/'journal-status.json'),'identities':{name:sha(d/name) for name in ['contract.json','rows.json','trace.jsonl','policy-journal.jsonl','initial-game.json','terminal-game.json','journal-status.json']}}
 case['prior_id_based_source_actions_equal']={a:(dirs[a]/'trace.jsonl').read_bytes()==(B/f'paired-models-01/{game:02}-{a}/trace.jsonl').read_bytes() for a in ['off','on']}
 report['cases'].append(case)
report['complete_pairs']=len(report['cases']);report['changed_action_pairs']=sum(not c['actions_equal'] for c in report['cases'])
report['model_wins']={a:sum(c['arms'][a]['row']['win'] for c in report['cases']) for a in ['off','on']}
report['model_domination_wins']={a:sum(c['arms'][a]['row']['win'] and c['arms'][a]['row']['victory'].lower()=='domination' for c in report['cases']) for a in ['off','on']}
report['limitations']=['These are model worlds, not Native execution.','Observed journal absence is not proof of no branch activation; the instrument retained only cumulative ring-drop counts and no per-turn truncation audit.','Eight fixed worlds do not estimate a Native win rate.']
out=pathlib.Path(args.out);assert not out.exists();out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['cases']},indent=2))
