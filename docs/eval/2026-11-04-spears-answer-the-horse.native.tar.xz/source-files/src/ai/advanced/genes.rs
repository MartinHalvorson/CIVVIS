//! ⭐ THE GENE REGISTRY — the **gene pool**: every gene there is, on or off,
//! declared once.
//!
//! Vocabulary (operator, 2026-08-23): the **gene pool** is the collection of
//! all genes, whether on or off — this table is it. A **genome** is one
//! player's set of on genes, a subset of the pool: the deployment genome is
//! the set the ledger ships on, and a screen seat draws its own.
//!
//! A gene is one boolean flag on `AdvancedAi` with a published tag. This table
//! is the one place a gene is declared — its tag, its flag, what kind of gene
//! it is, and the two toggles that set it — and everything that needs the
//! list reads it from here:
//!
//! - `AdvancedAi::enable_live_bridge_universe` turns on every `live` gene
//!   (what the Civilization VI seat ships), `enable_engine_repairs_universe`
//!   every `Repair` (the native half of that bundle), and the war/economy
//!   halves filter by `Axis`; `apply_gene_ledger` then sets each gene to the
//!   deployment default the ledger derived (`gene_ledger.rs`).
//! - `gene_screen` screens every `screenable()` gene; `civvis_orders --without`
//!   withholds any `live()` gene on the live seat.
//! - `tools/genes.py` (the ledger, the ranking) and
//!   `tools/eval_manifest.py` scrape the rows below, so a row added here is
//!   priced, ranked and counted without touching them.
//!
//! Until 2026-08-23 the same facts were spread over three tuple tables
//! (`LIVE_TREATMENTS`, `PRODUCTION_TREATMENTS`, `PRODUCTION_OPT_INS`) and
//! five tag lists in `src/elo.rs` (`LIVE_BRIDGE_TREATMENTS`,
//! `FIRAXIS_ONLY_TREATMENTS`, `ENGINE_REPAIR_*`), held in step by tests.
//! They are columns of one row now. The `treatment` vocabulary went with
//! them: a treatment was a gene seen from the evaluator's side, and the
//! evaluator is gone.
//!
//! ⚠ The tags are published: `docs/gene_ledger.json`, every
//! `docs/gene_screens/*.json` header and every round under `docs/eval/` file
//! results under them, so renaming a row silently unfinds a recorded result.
//! Add rows; do not rewrite them. A tag `<base>-<n>` (`war-economy-2`) is
//! version `n` of `<base>` — see `docs/GENE_SCREEN.md`, *Versioning a gene*.
//!
//! ⚠ Existing rows are never re-ordered: the screen writes genes in this
//! order, and `tools/genes.py` re-derives a batch's gene set from this file
//! at the commit the batch names. Add a row below the tail append marker for
//! its tag's first-letter range. Every marker follows the existing rows, so
//! the distinct append points let concurrent gene PRs merge without moving a
//! positional bit that a running screen already wrote.
//!
//! Every row's comment is the note its old table row or its old bundle line
//! carried — the reason the gene exists and the measurement that motivated
//! it — moved here with the row.

use super::AdvancedAi;
#[allow(unused_imports)]
use super::{GeneVerdict, Measure, Verdict};

/// Which half of the native repair bundle a `Repair` belongs to. Split so the
/// bundle's interaction stays measurable: if the whole bundle beats stock by
/// more than the halves do separately, the repairs compound.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Axis {
    War,
    Economy,
}

/// What kind of gene a row is — the one fact the old tables encoded by which
/// table a row sat in.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Kind {
    /// An engine repair the Civilization VI seat ships and a native board can
    /// play: on in the genome's universe, screenable, withholdable live.
    Repair(Axis),
    /// Fixed bridge-era behavior, enabled in both production adapters. Some
    /// rows adapt host-only representation; others are strategic safeguards.
    /// Kept out of the variable genome for bit-order compatibility.
    HostOnly,
    /// Production ships it on before the ledger says anything (the stock
    /// agent carries it).
    Production,
    /// Off everywhere until the ledger turns it on; screenable.
    OptIn,
}

/// One gene, declared once.
pub struct Gene {
    /// The published name: the ledger, the screen and every recorded round
    /// file results under it.
    pub tag: &'static str,
    /// The flag on `AdvancedAi` it sets.
    pub field: &'static str,
    pub kind: Kind,
    pub enable: fn(&mut AdvancedAi),
    pub disable: fn(&mut AdvancedAi),
}

impl Gene {
    /// Shipped by the Civilization VI seat (`enable_live_bridge_universe`).
    pub const fn live(&self) -> bool {
        matches!(self.kind, Kind::Repair(_) | Kind::HostOnly)
    }
    /// Reads host state a native board does not have.
    pub const fn host_only(&self) -> bool {
        matches!(self.kind, Kind::HostOnly)
    }
    /// A native engine repair in the live bundle.
    pub const fn repair(&self) -> bool {
        matches!(self.kind, Kind::Repair(_))
    }
    pub const fn repair_axis(&self) -> Option<Axis> {
        match self.kind {
            Kind::Repair(axis) => Some(axis),
            _ => None,
        }
    }
    /// Production ships it on before the ledger.
    pub const fn production(&self) -> bool {
        matches!(self.kind, Kind::Production)
    }
    /// Off until the ledger turns it on.
    pub const fn opt_in(&self) -> bool {
        matches!(self.kind, Kind::OptIn)
    }
    /// On after setup among the variable genes. HostOnly rows are fixed on
    /// outside the variable genome in both production adapters.
    pub const fn universe_on(&self) -> bool {
        self.repair() || self.production()
    }
    /// On in the production agent alone, before any bundle.
    pub const fn stock_on(&self) -> bool {
        self.production()
    }
    /// Whether `gene_screen` can price it on a native board.
    pub const fn screenable(&self) -> bool {
        self.universe_on() || self.opt_in()
    }
}

/// The gene by its published tag.
pub fn gene(tag: &str) -> Option<&'static Gene> {
    GENES.iter().find(|gene| gene.tag == tag)
}

/// Every `live()` tag, in registry order — what the live bundle stamps on a
/// run so an old binary's list reads as shorter.
pub fn live_tags() -> Vec<&'static str> {
    GENES.iter().filter(|g| g.live()).map(|g| g.tag).collect()
}

/// Every `host_only()` tag, in registry order.
pub fn host_only_tags() -> Vec<&'static str> {
    GENES
        .iter()
        .filter(|g| g.host_only())
        .map(|g| g.tag)
        .collect()
}

/// Every `repair()` tag, in registry order — the native half of the bundle.
pub fn repair_tags() -> Vec<&'static str> {
    GENES.iter().filter(|g| g.repair()).map(|g| g.tag).collect()
}

/// The repairs of one half, in registry order.
pub fn repair_tags_on(axis: Axis) -> Vec<&'static str> {
    GENES
        .iter()
        .filter(|g| g.repair_axis() == Some(axis))
        .map(|g| g.tag)
        .collect()
}

/// Every `screenable()` gene, in registry order — the genome `gene_screen`
/// varies and `tools/genes.py` fingerprints.
pub fn screenable_genes() -> Vec<&'static Gene> {
    GENES.iter().filter(|g| g.screenable()).collect()
}

#[rustfmt::skip]
pub const GENES: &[Gene] = &[
    // ── Repairs: the native half of the live bundle, war then economy ──
    // ⚠ Reinforcements never reach the front. Force groups are cliques at
    // `command_radius`, so the trickle of fresh and released units forms
    // one- and two-body groups at home that can never clear
    // `LOCAL_SUPERIORITY_FLOOR` at the objective. Measured on run
    // `civvis-20260808T033223Z`, t217-t225: land forces of one, two and
    // three against the same objective, every one "too weak locally to
    // advance", while the empire fielded 10-14 units.
    // Force assembly and movement.
    Gene { tag: "war-reinforcement", field: "war_reinforcement", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_war_reinforcement, disable: AdvancedAi::disable_war_reinforcement },
    // ⚠ `unit_can_traverse` says yes to open water for every land unit as
    // soon as embarkation unlocks, so the unexplored ocean becomes a legal
    // exploration goal for the whole army — and the only rule that brought
    // a unit back was welded to `modernization_step`, which does nothing
    // for a unit with no upgrade waiting. Measured across 133 live runs:
    // land combat units spend a mean 15% of their unit-turns embarked, and
    // 21.7% while one of our own cities is taking damage (92.8% in the
    // worst run). An embarked unit cannot attack. On run
    // `civvis-20260803T130831Z` the capital sat at 179/200 damage for 38
    // turns while 11 of 12 land combat units swam. The tournament
    // controller stays frozen.
    Gene { tag: "come-ashore", field: "come_ashore", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_come_ashore, disable: AdvancedAi::disable_come_ashore },
    Gene { tag: "recorded-tactical-step", field: "recorded_tactical_step", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_recorded_tactical_step, disable: AdvancedAi::disable_recorded_tactical_step },
    // And a three-hop loop back to the start is no better than a two-hop
    // one. See `whole_turn_backtrack_guard`.
    // And a three-hop loop back to the start is no better than a two-hop
    // one. See `whole_turn_backtrack_guard`.
    Gene { tag: "whole-turn-backtrack-guard", field: "whole_turn_backtrack_guard", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_whole_turn_backtrack_guard, disable: AdvancedAi::disable_whole_turn_backtrack_guard },
    // Reading the enemy. The `3.0` "we dominate here" sentinel fires on
    // 53.3% of force decisions, and two thirds of those are objectives
    // that are not cities.
    Gene { tag: "blind-objective-strength", field: "blind_objective_strength", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_blind_objective_strength, disable: AdvancedAi::disable_blind_objective_strength },
    Gene { tag: "blind-objective-units", field: "blind_objective_units", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_blind_objective_units, disable: AdvancedAi::disable_blind_objective_units },
    Gene { tag: "relief-targets-the-siege", field: "relief_targets_the_siege", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_relief_targets_the_siege, disable: AdvancedAi::disable_relief_targets_the_siege },
    // ⚠ `desired_military` is `2 * city_count` at war — a headcount keyed to
    // OUR empire that never asks how strong the rival is. Once it is met,
    // `force_gap` hits zero and the military arm of `production_value` drops
    // from a 4.0 multiplier to 0.65, so units lose to buildings. Measured on
    // run `civvis-20260803T005930Z`: 94 of 188 war turns had the target
    // already satisfied, CIVVIS ordered 17 military units in the whole war
    // (8 land combat, 2 siege) against Korea's five walled cities, and at t240
    // the rival fielded 1050 military against our 658 while the target still
    // read satisfied at 11 against a wanted 10.
    // Sizing the army against the rival rather than against our own city
    // count, before as well as during the war.
    Gene { tag: "army-target-weighs-enemy", field: "army_target_weighs_enemy", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_army_target_weighs_the_enemy, disable: AdvancedAi::disable_army_target_weighs_the_enemy },
    // ⚠ And the wartime repair above still wakes up only once the war has
    // started. Measured on run `civvis-20260803T220954Z` (Rome, 250 turns):
    // seven cities founded by t123, Mali declared at t157 holding **894
    // military against our 481**, and six of the seven were taken at
    // loyalty 100 — sieges, not revolts — including Rome itself at t225.
    // We issued zero war orders and sixteen refused peace requests. A
    // target that asks "who could kill me" only after the declaration is
    // asking too late; this floor asks it of the strongest MET major in
    // peacetime, under its own far smaller ceiling.
    Gene { tag: "peacetime-deterrence", field: "peacetime_deterrence", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_peacetime_deterrence, disable: AdvancedAi::disable_peacetime_deterrence },
    // ⚠⚠ WARS ARE REACHED BUT NEVER CONVERTED. Across the fifteen live
    // Settler games of 2026-08-07/08 the ledger records four war
    // declarations and ZERO city captures, and the score losses (639-1317,
    // 457 at 3 cities on `civvis-20260808T033223Z`) are the direct result:
    // the games are decided on score at the 250-turn cap, and captures are
    // the one lever never pulled. Three repairs, separately ablatable,
    // one causal story — the agent that reaches its own declaration must
    // also fight the war it declared:
    // ⚠ An adaptive Conquest plan never reaches `advanced_production` —
    // it falls through to the Basic governor and an army target of
    // `mil_per_city * cities` (≈1.4/city on the deployed genome), so the
    // war is fought on a peacetime economy. `docs/RUSH.md` measured the
    // routing trap from the other side: raising the army in
    // `production_value` was twice byte-identical to a no-op.
    Gene { tag: "war-economy", field: "war_economy", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_war_economy, disable: AdvancedAi::disable_war_economy },
    Gene { tag: "bounded-recovery", field: "bounded_recovery", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_bounded_recovery, disable: AdvancedAi::disable_bounded_recovery },
    // ⚠ And the war it keeps prosecuting still has to end on a captured
    // city. The campaign re-picks its objective from scratch every turn and
    // prices fifteen turns of siege at ~37 points, less than the distance
    // terms swing; the army walks off a city at 25 hp with its walls down
    // and Civ 6 heals it back at 20 hp a turn. Live run
    // `civvis-20260808T142724Z` dealt 338 hp of city damage over t73-t105,
    // handed 200 of it back, and took nothing — the shape behind 25 live
    // games and 0 captures on 7.7x the field's military.
    Gene { tag: "siege-commitment", field: "siege_commitment", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_siege_commitment, disable: AdvancedAi::disable_siege_commitment },
    // ⚠ Barbarians are excluded from `at_major_war` by design, so every defensive
    // escalation in the production picker reads a barbarian siege as no threat at
    // all: a one-city empire's standing-army floor stays at `mil_per_city` (1.0)
    // and it cannot want a third defender while horsemen stand on its doorstep.
    // Measured on run `civvis-20260802T202501Z` — four settlers built into that
    // siege and captured, two on the capital tile without ever moving, one city
    // until t80, score 140 against a best rival's 416. The tournament controller
    // stays frozen so its recorded ladders remain comparable.
    // The other half of the same three-defeat measurement: the capital that
    // fell bleeding with an empty hostile list. See garrison_under_fire.
    Gene { tag: "garrison-under-fire", field: "garrison_under_fire", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_garrison_under_fire, disable: AdvancedAi::disable_garrison_under_fire },
    // ⚠ `local_strength_ratio` prices an objective city only while it is
    // currently in sight, and returns its `hostile <= 0.0` sentinel of 3.0 —
    // the maximum — otherwise. Under live fog that makes a walled enemy
    // capital score identically to an empty meadow, four times over the
    // superiority floor, so the army engages. Measured on run
    // `civvis-20260803T005930Z`: Seoul (walled, 22 pop, defense 101) was the
    // objective of 426 force-group decisions from t65 to t231 and 294 of them
    // read exactly 3.00, 108 with a force of one. No Korean city ever passed
    // 27% damage in 173 turns of war. The repair reads only this controller's
    // own last sighting, which the defensive half already trusts.
    // ⚠ And once the army is sent, something has to make it close. The
    // movement score charges `mv_threat * threat_caution * 30.0` for
    // standing where an enemy can reach — -15.0 at parity for a Vanguard —
    // and credits the attack that position buys with nothing, while
    // closing one hex is worth +2.9. Measured on run
    // `civvis-20260803T005930Z`: **7 melee ATTACK orders in 188 turns of
    // war** against 1546 MOVE_TO, with 622 military unit-turns sitting 2-4
    // hexes from a target and 52% of those under an Engage posture. The
    // tournament controller stays frozen so its recorded ladders remain
    // comparable.
    // Tactical quality on the tile the unit actually stands on.
    Gene { tag: "strike-opening", field: "strike_opening", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_strike_opening, disable: AdvancedAi::disable_strike_opening },
    // ⚠ The empire goes blind and the build order never notices. Recon is
    // not among the counts `pick_item` receives, and `OPENING_MENU` is the
    // only place a scout is named, so once the openers die nothing replaces
    // them. Live run `civvis-20260808T142724Z`: zero recon units from turn
    // ~100 to 251 while the army grew to 22, 77% of the map never seen, and
    // the eventual winner first met on turn 215 already holding 927 points.
    Gene { tag: "recon-replacement", field: "recon_replacement", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_recon_replacement, disable: AdvancedAi::disable_recon_replacement },
    // And a barbarian scout does not pin the opening. See
    // `barbarian_scouts_are_scouts`.
    // And a barbarian scout is a scout in both regimes — it can neither
    // attack nor capture, so nothing retreats from one. See
    // `barbarian_scouts_are_scouts`.
    Gene { tag: "barbarian-scouts-are-scouts", field: "barbarian_scouts_are_scouts", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_barbarian_scouts_are_scouts, disable: AdvancedAi::disable_barbarian_scouts_are_scouts },
    // And a raider is cheaper to kill than a major: over the repaired
    // bridge our 225 melee attacks killed 119 and cost 6 attackers, while
    // the barbarians attacked us 867 times to our 290. See
    // `BasicAi::barbarian_bargain`.
    // And a raider is cheaper to kill than a major: 225 melee attacks over
    // the repaired bridge killed 119 and cost 6 attackers, while the
    // barbarians attacked us 867 times to our 290. See
    // `BasicAi::barbarian_bargain`.
    Gene { tag: "barbarian-bargain", field: "barbarian_bargain", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_barbarian_bargain, disable: AdvancedAi::disable_barbarian_bargain },
    // And a ring of shooters is answered by a shooter: they field 45 % of
    // their attacks ranged to our 22 %, and our ranged attacks have never
    // lost the attacker. See `BasicAi::barbarian_ranged_answer`.
    // And a ring of shooters is answered by a shooter: they field 45 % of
    // their attacks ranged to our 22 %, and our ranged attacks have never
    // lost the attacker. See `BasicAi::barbarian_ranged_answer`.
    Gene { tag: "barbarian-ranged-answer", field: "barbarian_ranged_answer", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_barbarian_ranged_answer, disable: AdvancedAi::disable_barbarian_ranged_answer },
    // And the sea gets one eye of its own. See `BasicAi::naval_recon`.
    // And the sea gets one eye of its own. See `BasicAi::naval_recon`.
    Gene { tag: "naval-recon", field: "naval_recon", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_naval_recon, disable: AdvancedAi::disable_naval_recon },
    // And in peacetime the whole field army clears it. See
    // `BasicAi::camp_party`.
    // And in peacetime the whole field army clears it. See
    // `BasicAi::camp_party`.
    Gene { tag: "camp-party", field: "camp_party", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_camp_party, disable: AdvancedAi::disable_camp_party },
    // And the settler decides on the real board, prices capture as
    // capture and trusts only a guard on its tile; see
    // settler_stack_discipline.
    // The religion lane was structurally blocked by its own wars; see
    // religion_sues_peace.
    // A Religion plan that keeps its wars blockades its own lane.
    Gene { tag: "religion-sues-peace", field: "religion_sues_peace", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_religion_sues_peace, disable: AdvancedAi::disable_religion_sues_peace },
    // The other half of that same capital's diagnosis: garrison_under_fire
    // reacts to a city already bleeding, but the capital that fell had
    // NEVER ORDERED WALLS — max_wall_damage 0 at t115 with production on
    // the culture lane and the fog hiding every attacker until adjacency.
    // See BasicAi::garrison_walls_item.
    // Settler conversion is the score frontier the first seven live games
    // isolated; see escort_unstick.
    // Getting a settler to a site it can keep.
    Gene { tag: "escort-unstick", field: "escort_unstick", kind: Kind::Repair(Axis::Economy), enable: AdvancedAi::enable_escort_unstick, disable: AdvancedAi::disable_escort_unstick },
    // And the Library and University come before the Great Merchant race.
    // See `buildings_before_projects`.
    // The cheap half of a research city before the race in it. See
    // `buildings_before_projects`.
    Gene { tag: "buildings-before-projects", field: "buildings_before_projects", kind: Kind::Repair(Axis::Economy), enable: AdvancedAi::enable_buildings_before_projects, disable: AdvancedAi::disable_buildings_before_projects },
    // And the guard on the settler's tile holds there, and only a guard
    // that can hold counts — both settlers of civvis-20260819T025840Z were
    // taken one tile outside Rome from a tile a warrior had just left.
    // See `settler_guard_holds`.
    // And a stacked guard holds, and only one that can hold counts. See
    // `settler_guard_holds`.
    Gene { tag: "settler-guard-holds", field: "settler_guard_holds", kind: Kind::Repair(Axis::Economy), enable: AdvancedAi::enable_settler_guard_holds, disable: AdvancedAi::disable_settler_guard_holds },
    // ⚠ THE EXPANSION GATE ASKS `settlers == 0`, so a settler that never
    // founds anything answers "one is already in flight" for the rest of
    // the game. Across the 25 live runs of 2026-08-07/08 that reason is
    // 86% of every refusal to build a settler (1,548 of 1,767), the median
    // game's longest-lived single settler survives 86 turns of 250 without
    // founding, and nine runs carried one alive for 82-171 turns having
    // moved five times or fewer. Those empires finished on a median of 5
    // cities against a `city_target` of 7.8 with the window open to turn
    // 198 — neither was binding, this was — and lost all 21 completed
    // games at a median score 0.46x the leader's, with final score
    // tracking city count at r = 0.81. The mod's fallback ladder already
    // made this repair; under `--civvis-decides` it is not the decider.
    Gene { tag: "stranded-settler-discount", field: "stranded_settler_discount", kind: Kind::Repair(Axis::Economy), enable: AdvancedAi::enable_stranded_settler_discount, disable: AdvancedAi::disable_stranded_settler_discount },
    // Three straight Settler losses were an eight-city empire against
    // ten- and eleven-city rivals; the stock nine-ceiling was the binding
    // constant. See `wide_map_capacity`.
    Gene { tag: "wide-map-capacity", field: "wide_map_capacity", kind: Kind::Repair(Axis::Economy), enable: AdvancedAi::enable_wide_map_capacity, disable: AdvancedAi::disable_wide_map_capacity },
    // ⚠⚠ AND THE EMPIRE STOPS BUILDING CAMPUSES AT HALF ITS CITIES.
    // `balanced_core` pays a Campus +130 only while `district_count * 2 <
    // city_count`, so the term switches off at half coverage — and measured
    // over 19 live runs, end-of-game Campus coverage is **exactly 50 of 100
    // cities**. The counterweight #958 added is per-city and lane-
    // independent, but it is scaled by a GAME-FRACTION horizon while every
    // term it competes against is a flat constant, so it decays to 120 by
    // turn 150 against a Theatre Square's 850. The cities that never get a
    // Campus are the late-founded ones, and the science funnel cascades
    // from it: 50% Campus, 39% Library, 20% University, 3% Research Lab.
    // ⚠⚠ AND THE TWO HOUSING CARDS THE EMPIRE CAN REACH ARE NEVER PLAYED.
    // `medina_quarter` (+2 Housing at 3+ specialty districts) is slotted in
    // **0 of 107 live runs** and appears nowhere in `src/`; `insulae` (+1 at
    // 2+) in **1**. Housing is the dominant growth cap — 71.7% of 13,214
    // host-exported city-turns sit under it at a mean multiplier of 0.510,
    // against the Amenity band's 0.872 — and 60.3% / 40.0% of city-turns
    // already carry the 2 / 3 specialty districts these cards need.
    // ⚠⚠ THE SCIENCE PROJECT LOOP CAN MAKE THE AMENITY REPAIR UNREACHABLE.
    // On live run `civvis-20260815T051714Z`, every one of five cities sat
    // between -3 and -5 Amenities from t140 onward, costing 10–30% of its
    // yields, while adaptive Science restarted Campus Research Grants 39
    // times from t176 to t233. `BasicAi::pick_item` already ranks an
    // Entertainment Complex above ordinary district lanes, but explicit
    // Science production bypasses that picker whenever it fills a queue.
    // The repair pauses one repeatable project only after at least two
    // cities enter the -3 band; it preserves victory projects, force gaps,
    // and the rest of the Science queue while the district/building chain
    // completes.
    Gene { tag: "amenity-project-preemption", field: "amenity_project_preemption", kind: Kind::Repair(Axis::Economy), enable: AdvancedAi::enable_amenity_project_preemption, disable: AdvancedAi::disable_amenity_project_preemption },
    Gene { tag: "amenity-district-path", field: "amenity_district_path", kind: Kind::Repair(Axis::Economy), enable: AdvancedAi::enable_amenity_district_path, disable: AdvancedAi::disable_amenity_district_path },
    // ⚠⚠ AND THE REPAIR IS BEHIND A TECH THE ARGMAX NEVER AIMS AT. Over 94
    // live runs the median empire ends on **30 techs of 77**, `engineering`
    // is reached by only **73%** and at a median turn **116** — which is why
    // the live median Aqueduct order lands at turn 164. Making the district
    // reachable in the build lists cannot beat the tech that gates it.
    Gene { tag: "housing-research", field: "housing_research", kind: Kind::Repair(Axis::Economy), enable: AdvancedAi::enable_housing_research, disable: AdvancedAi::disable_housing_research },
    // ⚠ PENDING MEASUREMENT. First arm at deployment shape (74x46, 9 city-states,
    // 16 games, 200 turns) read +35 Elo (CI -61..+130), direction 7-2, sign
    // p=0.1797 — inconclusive, the promotion gate did not fire, terminal score
    // flat at 23-22. A weak positive is not a result. A 40-game arm is running;
    // if it does not clear, this call and its `live_without_` arm come back out
    // rather than sitting here unpriced.
    //
    // ⚠ It cannot be parked "off but registered": `each_live_without_arm_holds_
    // exactly_one_treatment_off` and `live_bridge_treatments_name_every_flag_
    // the_helper_sets` (#988) require the treatment list, the arms and this
    // helper to agree exactly. A flag the deployment does not set has no
    // `live_without_` arm — which is the invariant working, and the reason a
    // gated-off flag here would be dead code of the `culture_focus` kind.
    Gene { tag: "district-coverage", field: "district_coverage", kind: Kind::Repair(Axis::Economy), enable: AdvancedAi::enable_district_coverage, disable: AdvancedAi::disable_district_coverage },
    Gene { tag: "slot-kind-tiebreak", field: "slot_kind_tiebreak", kind: Kind::Repair(Axis::Economy), enable: AdvancedAi::enable_slot_kind_tiebreak, disable: AdvancedAi::disable_slot_kind_tiebreak },
    // ⚠ Faith buys the soldier; GOLD pays for it every turn forever, and
    // `military_faith_spending` never asks about gold — it gates on the faith
    // bank alone. Measured on run `civvis-20260803T014330Z`: faith military
    // purchases walked down the gold curve (t124 at 60 gold, t141 at 48, t165 at
    // 51), the treasury hit zero on t168, Civilization VI disbanded the army
    // from 29 units to 19 by t173, and on t174 — at FIVE gold, one turn after
    // losing a third of the army — CIVVIS bought another Field Cannon. The
    // tournament controller stays frozen so its recorded ladders stay
    // comparable.
    // ⚠ Loyalty is the LARGEST single cause of city loss and the AI was
    // reading only the level. Classified over every recorded run, 125 city
    // losses: 52 (41.6%) below loyalty 50, 37 (29.6%) loyal-and-damaged, and
    // 36 (28.8%) gone from FULL health and full loyalty in one round. 66 of
    // the 125 were carrying a negative loyalty rate when last seen, and
    // `Game::city_loyalty_per_turn` — mirrored from Civilization VI all along
    // — had zero consumers in the whole AI. The tournament controller stays
    // frozen so its recorded ladders remain comparable.
    // Keeping it loyal.
    Gene { tag: "loyalty-rate-alarm", field: "loyalty_rate_alarm", kind: Kind::Repair(Axis::Economy), enable: AdvancedAi::enable_loyalty_rate_alarm, disable: AdvancedAi::disable_loyalty_rate_alarm },
    // And the race that does fit needs one launch pad, not one per city.
    // See `one_launch_pad`.
    // And the race that does fit needs one launch pad, not one per city.
    // See `one_launch_pad`.
    Gene { tag: "one-launch-pad", field: "one_launch_pad", kind: Kind::Repair(Axis::Economy), enable: AdvancedAi::enable_one_launch_pad, disable: AdvancedAi::disable_one_launch_pad },
    // And a settler target dropped for danger stays dropped for a while.
    // See `settler_target_hysteresis`.
    // And a settler target dropped for danger stays dropped for a while.
    // See `settler_target_hysteresis`.
    Gene { tag: "settler-target-hysteresis", field: "settler_target_hysteresis", kind: Kind::Repair(Axis::Economy), enable: AdvancedAi::enable_settler_target_hysteresis, disable: AdvancedAi::disable_settler_target_hysteresis },
    // And the buildings that chain hangs off. See `culture_building_debt`.
    // ★★★★ A TAG IN `ENGINE_REPAIR_TREATMENTS` WHOSE ENABLE IS MISSING
    // HERE SCREENS AS EXACTLY INERT, AND SAYS SO IN A WAY THAT IS EASY TO
    // READ AS A RESULT. `gene_screen` builds its treated seat from
    // `enable_engine_repairs_universe` and then flips only the genes whose
    // drawn bit differs from `Gene::after_setup_on` — which the table
    // asserts is `true` for every engine repair. A repair this bundle
    // never turns on is therefore off in BOTH arms of every pair, the two
    // arms play byte-identical games, and the screen reports `Δ +0.0
    // [+0.0, +0.0] z +0.00` for the gene. That is the signature: a
    // zero-width confidence interval is not a null, it is a gene that was
    // never varied. Three tags reached the tables before this line and
    // burned 30 games saying nothing.
    //
    // The research economy's two counterparts on the culture tree, and the
    // chain that fills every specialty district. `enable_engine_repairs`
    // applies the ledger after this, so an unmeasured one is still off at
    // deployment.
    Gene { tag: "culture-building-debt", field: "culture_building_debt", kind: Kind::Repair(Axis::Economy), enable: AdvancedAi::enable_culture_building_debt, disable: AdvancedAi::disable_culture_building_debt },
    // ── Host-only: shipped by the Civilization VI seat, inert headless ──
    Gene { tag: "live-trader-route", field: "live_trader_route_adapter", kind: Kind::HostOnly, enable: AdvancedAi::enable_live_trader_route_adapter, disable: AdvancedAi::disable_live_trader_route_adapter },
    Gene { tag: "live-religious-purchase", field: "live_religious_purchase_guard", kind: Kind::HostOnly, enable: AdvancedAi::enable_live_religious_purchase_guard, disable: AdvancedAi::disable_live_religious_purchase_guard },
    // ⚠ `assess` drops the empire into Recovery whenever it is at war and
    // `my_power * 1.25 < strongest_rival`, and Recovery does not build an army —
    // so the test stays true because of the choice it caused. Measured on run
    // `civvis-20260802T205959Z`: the journal names that arm 160 times, the
    // posture held from t65 to t229 (72% of the game), and the empire finished
    // with ONE warrior at military 34 against the Mapuche's 1354. The bound
    // releases only the power-gap half, and only after the posture has had
    // `RECOVERY_POSTURE_LIMIT` standard turns to work.
    // ⚠ A tactical step applied raw records nothing, so when a unit with
    // movement left is stepped a second time in the same turn, the reversal
    // guard inside `path_move` cannot see where it came from — and round two
    // walks straight back onto the tile round one just left. Measured on the
    // replay of run `civvis-20260801T224944Z`: 217 of 217 refused moves were
    // exactly that out-and-back pair; self-tile orders fell 43 → 1 with the
    // steps recorded.
    Gene { tag: "live-motion-turn-accounting", field: "live_motion_turn_accounting", kind: Kind::HostOnly, enable: AdvancedAi::enable_live_motion_turn_accounting, disable: AdvancedAi::disable_live_motion_turn_accounting },
    Gene { tag: "solvent-faith-army", field: "solvent_faith_army", kind: Kind::HostOnly, enable: AdvancedAi::enable_solvent_faith_army, disable: AdvancedAi::disable_solvent_faith_army },
    // And the formation channel that escort depends on went 0-for-7 on
    // the live bridge while two unescorted settlers were captured one
    // turn short of founding; see stacked_escort.
    // The native genome now withholds `stacked_escort`, but that result
    // does not make the host's formation channel work.  Keep live
    // settlers on the already-tested ordinary-unit shadow instead.
    Gene { tag: "live-formationless-settler-shadow", field: "live_formationless_settler_shadow", kind: Kind::HostOnly, enable: AdvancedAi::enable_live_formationless_settler_shadow, disable: AdvancedAi::disable_live_formationless_settler_shadow },
    // Zero wonder orders in twenty live Settler runs that all ended on the
    // host's score tally, 15 points a wonder. See `live_wonder_race`.
    Gene { tag: "live-wonder-race", field: "live_wonder_race", kind: Kind::HostOnly, enable: AdvancedAi::enable_live_wonder_race, disable: AdvancedAi::disable_live_wonder_race },
    Gene { tag: "expansion-before-prophet", field: "expansion_before_prophet", kind: Kind::HostOnly, enable: AdvancedAi::enable_expansion_before_prophet, disable: AdvancedAi::disable_expansion_before_prophet },
    Gene { tag: "no-elective-war", field: "no_elective_war", kind: Kind::HostOnly, enable: AdvancedAi::enable_no_elective_war, disable: AdvancedAi::disable_no_elective_war },
    // And that ceiling was still priced off the revealed quarter of the
    // map. See `fog_land_capacity`.
    Gene { tag: "fog-land-capacity", field: "fog_land_capacity", kind: Kind::HostOnly, enable: AdvancedAi::enable_fog_land_capacity, disable: AdvancedAi::disable_fog_land_capacity },
    // And the last-quarter score-leader alarm asks for a race, not a war.
    // See `counter_in_lane`.
    Gene { tag: "counter-in-lane", field: "counter_in_lane", kind: Kind::HostOnly, enable: AdvancedAi::enable_counter_in_lane, disable: AdvancedAi::disable_counter_in_lane },
    // And the city target climbs at the Settler game's own era pace. See
    // `era_paced_expansion`.
    Gene { tag: "era-paced-expansion", field: "era_paced_expansion", kind: Kind::HostOnly, enable: AdvancedAi::enable_era_paced_expansion, disable: AdvancedAi::disable_era_paced_expansion },
    // And a civic is three points on that tally to a tech's two. See
    // `tally_culture`.
    Gene { tag: "tally-culture", field: "tally_culture", kind: Kind::HostOnly, enable: AdvancedAi::enable_tally_culture, disable: AdvancedAi::disable_tally_culture },
    // And no colony beyond the empire's Loyalty reach on fogged ground.
    // See `frontier_loyalty`.
    Gene { tag: "frontier-loyalty", field: "frontier_loyalty", kind: Kind::HostOnly, enable: AdvancedAi::enable_frontier_loyalty, disable: AdvancedAi::disable_frontier_loyalty },
    // And banked Faith buys the Great People the tally pays five for. See
    // `tally_great_people`.
    Gene { tag: "tally-great-people", field: "tally_great_people", kind: Kind::HostOnly, enable: AdvancedAi::enable_tally_great_people, disable: AdvancedAi::disable_tally_great_people },
    // ⚠ The live seat plays under an assigned lane (`--victory science`),
    // and `victory_denial` stands down entirely for a targeted seat — so
    // five of the twelve runs the seat was LEADING on 2026-08-16/17 ended
    // at t229-245 on a rival's culture, technology or diplomatic victory
    // with the whole counter apparatus gated off. Match point overrides
    // the lane's focus; ordinary pressure still never does.
    Gene { tag: "deny-while-targeted", field: "deny_while_targeted", kind: Kind::HostOnly, enable: AdvancedAi::enable_deny_while_targeted, disable: AdvancedAi::disable_deny_while_targeted },
    // ⚠ And the alarm must reach the two lanes it cannot answer late.
    // Four of the five stolen games above were Culture; the general 90
    // bar had not fired when the game ended. See `STOCK_DENIAL_BAR`.
    Gene { tag: "stock-denial-lead-time", field: "stock_denial_lead_time", kind: Kind::HostOnly, enable: AdvancedAi::enable_stock_denial_lead_time, disable: AdvancedAi::disable_stock_denial_lead_time },
    // ⚠ And the stock bar must fire BEFORE the last Congress, not at it.
    // The first game on the repaired economy (231407Z) crossed the bar at
    // ~t221; the final Congress sat at t222 with nothing reading urgent
    // when its ballot was priced, and Egypt won Culture at t232. The
    // projection carries the recorded slope fifteen turns forward and
    // feeds the same gate. See `projected_stock_denial`.
    Gene { tag: "projected-stock-denial", field: "projected_stock_denial", kind: Kind::HostOnly, enable: AdvancedAi::enable_projected_stock_denial, disable: AdvancedAi::disable_projected_stock_denial },
    // These host-facing controls used to be applied by `civvis_orders`
    // after this bundle. They belong here: `live` and every
    // `live_without_*` arm must construct the controller that deployment
    // actually plays.
    Gene { tag: "parallel-settlers", field: "parallel_settlers", kind: Kind::HostOnly, enable: AdvancedAi::enable_parallel_settlers, disable: AdvancedAi::disable_parallel_settlers },
    Gene { tag: "host-settler-pop", field: "host_settler_pop", kind: Kind::HostOnly, enable: AdvancedAi::enable_host_settler_pop, disable: AdvancedAi::disable_host_settler_pop },
    Gene { tag: "explore-dead-targets", field: "explore_dead_targets", kind: Kind::HostOnly, enable: AdvancedAi::enable_explore_dead_targets, disable: AdvancedAi::disable_explore_dead_targets },
    Gene { tag: "explore-commit", field: "explore_commit", kind: Kind::HostOnly, enable: AdvancedAi::enable_explore_commit, disable: AdvancedAi::disable_explore_commit },
    Gene { tag: "bank-envoys", field: "bank_envoys", kind: Kind::HostOnly, enable: AdvancedAi::enable_bank_envoys, disable: AdvancedAi::disable_bank_envoys },
    // And the rung clock itself: the seat leads the count at t50, loses
    // it by t150 and stops settling at t116 under an assigned lane. See
    // `land_grab`.
    Gene { tag: "land-grab", field: "land_grab", kind: Kind::HostOnly, enable: AdvancedAi::enable_land_grab, disable: AdvancedAi::disable_land_grab },
    // And a Spy order the host is still running is not re-sent every
    // turn: the rebuilt mirror cannot see a running operation, so the
    // first run with a working spy chain (civvis-20260818T155500Z)
    // re-ordered SPY_GAIN_SOURCES 35 times. See `spy_mission_patience`.
    Gene { tag: "spy-mission-patience", field: "spy_mission_patience", kind: Kind::HostOnly, enable: AdvancedAi::enable_spy_mission_patience, disable: AdvancedAi::disable_spy_mission_patience },
    // And the pantheon is the one that founds a city, bought with the
    // Faith card the portfolio used to throw away at the first civic
    // swap: Divine Spark 40 of 40 times at median t22 (t108 at worst)
    // where Religious Settlements is a free Settler at ~t20. See
    // `expansion_pantheon`.
    Gene { tag: "expansion-pantheon", field: "expansion_pantheon", kind: Kind::HostOnly, enable: AdvancedAi::enable_expansion_pantheon, disable: AdvancedAi::disable_expansion_pantheon },
    // And the plaza the seat builds by t29–57 in every game gets the one
    // building the land grab is made of — a free Builder in every new
    // city, +50% Settlers — instead of standing empty to turn 250. See
    // `expansion_hall`.
    Gene { tag: "expansion-hall", field: "expansion_hall", kind: Kind::HostOnly, enable: AdvancedAi::enable_expansion_hall, disable: AdvancedAi::disable_expansion_hall },
    // And the book's own Settler slot survives the host's population
    // floor: half the recorded openings burned it and ordered the first
    // Settler four turns later. See `opening_settler_waits`.
    Gene { tag: "opening-settler-waits", field: "opening_settler_waits", kind: Kind::HostOnly, enable: AdvancedAi::enable_opening_settler_waits, disable: AdvancedAi::disable_opening_settler_waits },
    // ── Production: on before the ledger ──
    Gene { tag: "strategic-wonders", field: "strategic_wonders", kind: Kind::Production, enable: AdvancedAi::enable_strategic_wonders, disable: AdvancedAi::disable_strategic_wonders },
    // ── Opt-ins: off until the ledger turns one on ──
    // A Builder does not walk into a visible Barbarian-capture envelope; its
    // target and retreat both use the same fog-honest risk model as Settlers.
    // `gene_screen` discovers this native opt-in directly from this row.
    Gene { tag: "builder-barbarian-safety", field: "builder_barbarian_safety", kind: Kind::OptIn, enable: AdvancedAi::enable_builder_barbarian_safety, disable: AdvancedAi::disable_builder_barbarian_safety },
    Gene { tag: "apostle-promotion-by-role", field: "apostle_promotion_by_role", kind: Kind::OptIn, enable: AdvancedAi::enable_apostle_promotion_by_role, disable: AdvancedAi::disable_apostle_promotion_by_role },
    Gene { tag: "founder-temple", field: "founder_temple", kind: Kind::OptIn, enable: AdvancedAi::enable_founder_temple, disable: AdvancedAi::disable_founder_temple },
    Gene { tag: "holy-lane-parity", field: "holy_lane_parity", kind: Kind::OptIn, enable: AdvancedAi::enable_holy_lane_parity, disable: AdvancedAi::disable_holy_lane_parity },
    // Half the seats never found a religion and bank ~1,000 Faith they
    // cannot spend; see `AdvancedAi::idle_faith_patronage`.
    Gene { tag: "idle-faith-patronage", field: "idle_faith_patronage", kind: Kind::OptIn, enable: AdvancedAi::enable_idle_faith_patronage, disable: AdvancedAi::disable_idle_faith_patronage },
    // The rest of the same chain: the founder's corps cannot answer more than
    // two cities, cannot heal when it is defending, and spends charges at a
    // fraction of their strength. See `advanced/religion.rs`.
    Gene { tag: "religious-defence-scales", field: "religious_defence_scales", kind: Kind::OptIn, enable: AdvancedAi::enable_religious_defence_scales, disable: AdvancedAi::disable_religious_defence_scales },
    Gene { tag: "religious-units-heal-first", field: "religious_units_heal_first", kind: Kind::OptIn, enable: AdvancedAi::enable_religious_units_heal_first, disable: AdvancedAi::disable_religious_units_heal_first },
    Gene { tag: "holy-site-where-the-threat-is", field: "holy_site_where_the_threat_is", kind: Kind::OptIn, enable: AdvancedAi::enable_holy_site_where_the_threat_is, disable: AdvancedAi::disable_holy_site_where_the_threat_is },
    Gene { tag: "enhancer-for-the-corps", field: "enhancer_for_the_corps", kind: Kind::OptIn, enable: AdvancedAi::enable_enhancer_for_the_corps, disable: AdvancedAi::disable_enhancer_for_the_corps },
    // Every major adopts Early Empire on turns 23-30, and a Scout's sight of 2
    // cannot see a city-state's seat from outside its border. The land route
    // to first contact closes once and never reopens; see
    // `AdvancedAi::early_contact_window`.
    Gene { tag: "early-contact-window", field: "early_contact_window", kind: Kind::OptIn, enable: AdvancedAi::enable_early_contact_window, disable: AdvancedAi::disable_early_contact_window },
    Gene { tag: "early-contact-window-2", field: "early_contact_window_2", kind: Kind::OptIn, enable: AdvancedAi::enable_early_contact_window_2, disable: AdvancedAi::disable_early_contact_window_2 },
    // Promoted 2026-09-10: the repeated standard screen measured +1.50 pp
    // wins (z +3.46), +0.375 pp score share (z +4.12), and +1.11% ±1.02%
    // compute. A Great Person earned and blocked is a race forfeited: build
    // the slot space ahead of the person, sell duplicate works when nothing
    // can be built; see `AdvancedAi::great_person_housing`.
    Gene { tag: "great-person-housing", field: "great_person_housing", kind: Kind::Production, enable: AdvancedAi::enable_great_person_housing, disable: AdvancedAi::disable_great_person_housing },
    // Promoted 2026-09-10: the repeated standard screen measured +1.53 pp
    // wins (z +3.56) and +0.482 pp score share (z +5.45). The bounded raid
    // takes an exposed civilian or nearby prize and sues for peace; see
    // `AdvancedAi::opportunistic_war`.
    Gene { tag: "opportunistic-war", field: "opportunistic_war", kind: Kind::Production, enable: AdvancedAi::enable_opportunistic_war, disable: AdvancedAi::disable_opportunistic_war },
    // V2 rejects prizes without a short post-declaration route.
    Gene { tag: "opportunistic-war-2", field: "opportunistic_war_2", kind: Kind::OptIn, enable: AdvancedAi::enable_opportunistic_war_2, disable: AdvancedAi::disable_opportunistic_war_2 },
    // The pillage half of the raid remains separately screened: inert unless
    // the row above is on, and still opt-in until a current screen confirms
    // its older positive standard result. See
    // `AdvancedAi::raid_pillage_prizes`.
    Gene { tag: "raid-pillage-prizes", field: "raid_pillage_prizes", kind: Kind::OptIn, enable: AdvancedAi::enable_raid_pillage_prizes, disable: AdvancedAi::disable_raid_pillage_prizes },
    // A target can be excellent while a visible hostile makes its next route
    // step unsafe. This holds that corridor aside briefly and sends the
    // Settler to the best safe runner-up; see `settler_threat_detour`.
    Gene { tag: "settler-threat-detour", field: "settler_threat_detour", kind: Kind::OptIn, enable: AdvancedAi::enable_settler_threat_detour, disable: AdvancedAi::disable_settler_threat_detour },
    // The site ranking is indifferent between founding now and founding the
    // same value later; this prices every turn of the walk, dearer the longer
    // the Settler has been out. See `settle_sooner`.
    Gene { tag: "settle-sooner", field: "settle_sooner", kind: Kind::OptIn, enable: AdvancedAi::enable_settle_sooner, disable: AdvancedAi::disable_settle_sooner },
    // A Library bought after Rationalism earns twice a Library bought before
    // it, and the price never noticed. See
    // `AdvancedAi::science_multiplier_payoff`.
    Gene { tag: "science-multiplier-payoff", field: "science_multiplier_payoff", kind: Kind::OptIn, enable: AdvancedAi::enable_science_multiplier_payoff, disable: AdvancedAi::disable_science_multiplier_payoff },
    // The chain's rungs are 2, 4 and 3-plus-5 and the debt that buys them is
    // flat. See `AdvancedAi::research_tier_premium`.
    Gene { tag: "research-tier-premium", field: "research_tier_premium", kind: Kind::OptIn, enable: AdvancedAi::enable_research_tier_premium, disable: AdvancedAi::disable_research_tier_premium },
    // `withdraw_hp` is a constant and the enemy's damage is not: a unit the
    // strongest thing in reach would kill in one blow recovers whatever its
    // hit points say, and healing ground that comes under a shooter's reach
    // is left. See `BasicAi::one_shot_recovery`.
    Gene { tag: "one-shot-recovery", field: "one_shot_recovery", kind: Kind::OptIn, enable: AdvancedAi::enable_one_shot_recovery, disable: AdvancedAi::disable_one_shot_recovery },
    // The four victory-lane genes (`advanced/victory_lane.rs`,
    // `docs/VICTORY_GENES.md`) and the competition value they enable. A
    // targeted seat spends about a fifth of the game — and an adaptive one
    // 15% — with `Expansion` in its plan, and `take_turn_inner` hands that
    // to every lane-shaped decider. The first two substitute the victory the
    // empire is actually racing at one decider; the next two enable the
    // Culture and Science passes, and the last prices the Diplomatic Victory
    // Points a scored competition pays, which nothing priced.
    Gene { tag: "lane-great-people", field: "lane_great_people", kind: Kind::OptIn, enable: AdvancedAi::enable_lane_great_people, disable: AdvancedAi::disable_lane_great_people },
    Gene { tag: "lane-policy-deck", field: "lane_policy_deck", kind: Kind::OptIn, enable: AdvancedAi::enable_lane_policy_deck, disable: AdvancedAi::disable_lane_policy_deck },
    Gene { tag: "lane-culture-spending", field: "lane_culture_spending", kind: Kind::OptIn, enable: AdvancedAi::enable_lane_culture_spending, disable: AdvancedAi::disable_lane_culture_spending },
    Gene { tag: "lane-space-race", field: "lane_space_race", kind: Kind::OptIn, enable: AdvancedAi::enable_lane_space_race, disable: AdvancedAi::disable_lane_space_race },
    Gene { tag: "competition-victory-points", field: "competition_victory_points", kind: Kind::OptIn, enable: AdvancedAi::enable_competition_victory_points, disable: AdvancedAi::disable_competition_victory_points },
    // ⚠ Barbarians take 7.0 major cities a game -- 65% of everything a major
    // loses -- at a median city age of TEN TURNS, and `settle_value`
    // explicitly filters barbarians out of its proximity penalty, so a site
    // beside a barbarian city scores exactly as well as an empty one. Cities
    // held correlate with final score at r = +0.89; cities FOUNDED at -0.03.
    // The A/B moved cities held +1.09 (p = 0.0001) and barbarian losses -0.48
    // (p < 0.0001), both replicated; its 35-37 win count over 72 games is
    // underpowered, not a null. See `defensible_sites`.
    Gene { tag: "defensible-sites", field: "defensible_sites", kind: Kind::OptIn, enable: AdvancedAi::enable_defensible_sites, disable: AdvancedAi::disable_defensible_sites },
    // ⚠ "Strong enough to take what a neighbour has" never asks WHICH
    // neighbour: `weakest_rival` is the minimum power over every met major
    // with no proximity test, so the branch really asks "am I 1.8x the
    // feeblest empire in the world?" -- true from t55 onward for anyone doing
    // well, next door or on another continent. `city_campaign` already has
    // the reach this wants (`CAMPAIGN_REACH`, "the same reach the
    // declaration's `close_enough` already asks for") and branch nine uses
    // it. See `elective_war_in_reach`.
    Gene { tag: "elective-war-in-reach", field: "elective_war_in_reach", kind: Kind::OptIn, enable: AdvancedAi::enable_elective_war_in_reach, disable: AdvancedAi::disable_elective_war_in_reach },
    // ⚠ The same shape as the row above, on the branch beside it. Recovery's
    // power gap reads `strongest_rival` -- the maximum over every MET major,
    // at peace or not, next door or on another continent -- so an empire at
    // war with a weak neighbour takes the defensive posture because a distant
    // superpower exists. The file already names this ("the power-gap Recovery
    // a strong third party would trigger") and exempts only `raid_only_war`.
    // Recovery is 19% of the board's planner-turns under
    // `audit --genome deployment`. See `recovery_reads_the_war`.
    Gene { tag: "recovery-reads-the-war", field: "recovery_reads_the_war", kind: Kind::OptIn, enable: AdvancedAi::enable_recovery_reads_the_war, disable: AdvancedAi::disable_recovery_reads_the_war },
    // ⚠⚠ THE BIGGEST NUMBER IN THIS REPOSITORY SITS BEHIND A FLAG NOTHING
    // COULD SET. #554: a free settler while short of the city target more than
    // DOUBLES the win rate, 23.0% -> 52.3% at p=0.0000 over 300 games. #559:
    // the shut expansion window is the SOLE blocker on 31.2% of the city-turns
    // an empire spends short of its own target. `settler_expansion_window_open`
    // takes the payback branch only under `land_grab` (HostOnly) or this flag
    // (an orphaned evaluator arm), so the native board has only ever shut the
    // window on a clock. See `expansion_pays_back`.
    Gene { tag: "expansion-pays-back", field: "expansion_pays_back", kind: Kind::OptIn, enable: AdvancedAi::enable_expansion_pays_back, disable: AdvancedAi::disable_expansion_pays_back },
    // ⚠ The last blind lane in the threat model: Domination is read as
    // `100 * foreign CAPITALS held / foreign capitals`, five values twenty
    // points apart, and ZERO for a rival that has taken any number of ordinary
    // cities. Captured cities are production, population, districts and techs
    // -- the currency of every other lane -- so the empire eating the board
    // reads as a pacifist right up to the first palace. See
    // `domination_city_count`.
    Gene { tag: "domination-city-count", field: "domination_city_count", kind: Kind::OptIn, enable: AdvancedAi::enable_domination_city_count, disable: AdvancedAi::disable_domination_city_count },
    // ⚠ The largest branch in the grand-strategy cascade and it has no exit:
    // any war at all pins the plan on Conquest for its whole duration.
    // Conquest takes 40% of the planner-turns while domination finishes 2/16
    // and is 1 of 107 recorded
    // rival victories. Withdrawn once on a -22.2 pp reading that #2452 proved
    // was a degenerate-block artifact; measured here on the repaired
    // instrument. See `unchosen_war_keeps_the_lane`.
    Gene { tag: "unchosen-war-keeps-the-lane", field: "unchosen_war_keeps_the_lane", kind: Kind::OptIn, enable: AdvancedAi::enable_unchosen_war_keeps_the_lane, disable: AdvancedAi::disable_unchosen_war_keeps_the_lane },
    // ⚠ The row above's construction, applied to the two branches below it in
    // the cascade. That gene is the only one of eleven written this week with
    // persistent signal (+4.7 pp, z +2.09 over 271 games) and what it does is
    // refuse to let a war a RIVAL started take the plan from a live lane.
    // These branches take the plan for a war WE choose, and `no_elective_war`
    // records that they never converted in eight live runs -- 0 cities taken,
    // 16 lost -- while being Firaxis-only, so the native board runs them bare.
    // See `elective_war_yields_to_a_lane`.
    Gene { tag: "elective-war-yields-to-a-lane", field: "elective_war_yields_to_a_lane", kind: Kind::OptIn, enable: AdvancedAi::enable_elective_war_yields_to_a_lane, disable: AdvancedAi::disable_elective_war_yields_to_a_lane },
    // ⚠ The planner judges its OWN diplomatic position by `dvp * 5 +
    // suzerain * 6` and a RIVAL's by `dvp * 5`. A rival holding every
    // city-state -- the whole Favor engine that manufactures the points --
    // contributes nothing to its threat reading until the points land, and
    // diplomatic victories are 58 of the 107 recorded losses to a rival. The
    // missing term is the one the file already has. See
    // `rival_suzerainty_alarm`.
    Gene { tag: "rival-suzerainty-alarm", field: "rival_suzerainty_alarm", kind: Kind::OptIn, enable: AdvancedAi::enable_rival_suzerainty_alarm, disable: AdvancedAi::disable_rival_suzerainty_alarm },
    // ⚠ This decides WHO the three targeted penalties are pointed at -- the empire
    // `victory_denial` names, instead of the diplomatic leader. The Congress
    // is the only counter in this game not paid for in development
    // (`resolve_congress` refunds a losing vote in full), which is exactly
    // what the war-shaped counters in `docs/COUNTERING_LEADERS.md` could not
    // say. See `congress_counter_leader`.
    Gene { tag: "congress-counter-leader", field: "congress_counter_leader", kind: Kind::OptIn, enable: AdvancedAi::enable_congress_counter_leader, disable: AdvancedAi::disable_congress_counter_leader },
    // ⚠ Eighteen of 32 screened games today ended on a Science Victory, and
    // the threat model reads that race as a five-step ladder off launches
    // already made: a rival one tech from Rocketry with a Spaceport standing
    // reads ZERO. `rocketry_readiness` is the same chain this planner uses to
    // judge itself, off public tech-screen information. See
    // `science_chain_alarm`.
    Gene { tag: "science-chain-alarm", field: "science_chain_alarm", kind: Kind::OptIn, enable: AdvancedAi::enable_science_chain_alarm, disable: AdvancedAi::disable_science_chain_alarm },
    // ⚠ Two thirds of native games end by religious conversion, and the alarm
    // for it has five values twenty points apart: `religious_conversion_tally`
    // counts whole civilizations already lost, so a rival holding 45% of every
    // rival's cities reads zero. The victory rule is a count of cities and
    // counting them is smooth. See `conversion_majority_alarm`.
    Gene { tag: "conversion-majority-alarm", field: "conversion_majority_alarm", kind: Kind::OptIn, enable: AdvancedAi::enable_conversion_majority_alarm, disable: AdvancedAi::disable_conversion_majority_alarm },
    // ⚠ The same lock `diplomatic-lane-forecast` opened, on the second-best
    // lane this engine has: `victory_eval` finishes culture 12/16 and `audit`
    // gives it 2% of 14,376 planner-turns, below a twentieth of the board's
    // planning in eleven of twelve games. The lane reads a ratio of the
    // finished race, and foreign tourists are near zero until the Renaissance.
    // Unlike Diplomacy, both curves move, so this projects both. See
    // `culture_lane_forecast`.
    Gene { tag: "culture-lane-forecast", field: "culture_lane_forecast", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_lane_forecast, disable: AdvancedAi::disable_culture_lane_forecast },
    Gene { tag: "culture-cold-war-window", field: "culture_cold_war_window", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_cold_war_window, disable: AdvancedAi::disable_culture_cold_war_window },
    // ⚠ The lane this engine finishes most often is the lane the planner never
    // picks. `victory_eval` at the ladder's profile: diplomatic 14/16, culture
    // 12/16, religious 8/16, domination 2/16, science 0/16. `audit` over the
    // same profile: diplomacy 0% of 14,376 planner-turns in 12 of 12 games,
    // culture 2% -- against conquest 43%. Science reads a readiness ramp and
    // Religion a 46-point commitment floor; Diplomacy reads points already
    // banked and so cannot be chosen until it has already been played. See
    // `diplomatic_lane_forecast`.
    Gene { tag: "diplomatic-lane-forecast", field: "diplomatic_lane_forecast", kind: Kind::OptIn, enable: AdvancedAi::enable_diplomatic_lane_forecast, disable: AdvancedAi::disable_diplomatic_lane_forecast },
    // ⚠ `city_pressure_with_visibility` counts hostile strength only from
    // civilizations we are ALREADY AT WAR WITH, so a rival massing on our
    // border at peace reads exactly zero and no city is ever "threatened"
    // before the declaration. (The -22.2 pp this row used to cite from the
    // withdrawn `unchosen-war-keeps-the-lane` probe is retracted: it was a
    // degenerate-block artifact, see `docs/GENE_SCREEN.md`. The filter is
    // still a fact about the code.)
    // See `frontier_massing_alarm`.
    Gene { tag: "frontier-massing-alarm", field: "frontier_massing_alarm", kind: Kind::OptIn, enable: AdvancedAi::enable_frontier_massing_alarm, disable: AdvancedAi::disable_frontier_massing_alarm },
    // Nothing in this controller reaches the air layer: the melee package
    // skips `domain == "air"` and ranks its unlocks by cheapest remaining
    // research, so it can appoint the next technology and never a chain.
    // This beelines Advanced Flight from three technologies out, raises an
    // Aerodrome and a bomber wing, and takes the appointed city with the
    // cavalry behind it. See `advanced/air_surge.rs`.
    Gene { tag: "air-surge", field: "air_surge", kind: Kind::OptIn, enable: AdvancedAi::enable_air_surge, disable: AdvancedAi::disable_air_surge },
    // ⭐ APPENDED AT THE END ON PURPOSE. A gene inserted into the middle of
    // this table renumbers every row after it, and `gene_screen` writes the
    // genome as a POSITIONAL bit string — so a screen already running against
    // an older binary cannot be pooled with one running against this. That
    // cost the 83,000,000 run its analysis; see
    // `tools/gene_quantity_contrast.py`.
    //
    // The Research Lab's larger half is switched off until something generates
    // power, and nothing in the controller buys the switch. See
    // `AdvancedAi::power_the_laboratory`.
    Gene { tag: "power-the-laboratory", field: "power_the_laboratory", kind: Kind::OptIn, enable: AdvancedAi::enable_power_the_laboratory, disable: AdvancedAi::disable_power_the_laboratory },
    // Rationalism is slotted and NOT ONE Campus in the empire clears the
    // adjacency half it pays. Appended at the end, for the reason above. See
    // `AdvancedAi::campus_adjacency_threshold`.
    Gene { tag: "campus-adjacency-threshold", field: "campus_adjacency_threshold", kind: Kind::OptIn, enable: AdvancedAi::enable_campus_adjacency_threshold, disable: AdvancedAi::disable_campus_adjacency_threshold },
    // ★★★★ FOURTEEN BEHAVIOURS THAT NO SCREEN COULD REACH, AND THE COUNT THAT
    // FOUND THEM. `docs/EVAL_STATUS.md`'s "Genome coverage" section read 165
    // capability toggles on the controller, 100 reachable as a gene and **65
    // unreachable by any screen** — a number published because
    // `precise_evacuation` shipped ON for every seat, held roughly half the
    // simulator's main thread, and had no gene row, no evaluator arm and no
    // mention in any round. Neither gate could address it and nothing said so.
    // These fourteen are the part of that 65 a native screen can honestly
    // price. Every one is off in `promoted_policy_envoy`, so an opt-in row is
    // the whole change: `apply_gene_ledger` enables an opt-in only on a
    // `default_on` ledger row and there is none, so each ships off and
    // unmeasured and NOTHING about the deployed agent moves.
    //
    // ⭐ EIGHTEEN ROWS WERE WRITTEN AND FOUR WERE TAKEN BACK OUT, BY THE GATE
    // THIS SAME CHANGE ADDS. `camp_bounty`, `great_work_veto_by_district`,
    // `sea_answers` and `settler_founds_when_stalled` each left both arms of a
    // single-gene probe byte-identical — win Δ, share Δ and both standard
    // errors exactly zero — so they would have consumed a genome bit and
    // returned the zero-width interval `docs/GENE_SCREEN.md` warns about.
    // `tools/gene_fires.py` is what says so; their probes and their reasons are
    // in `docs/gene_screens/fires/` and `docs/genome_reach_debt.json`. The rest
    // of the residual is accounted for one line at a time in
    // `docs/GENE_SCREEN.md` (§"The toggles no screen can reach"); it is
    // examined work, not an unexamined ceiling.
    //
    // ⭐ APPENDED AT THE END, for the reason four rows up: `gene_screen` writes
    // the genome as a POSITIONAL bit string.
    //
    // ⚠⚠ AND THE TABLE ABOVE IS DELIBERATELY THE ONLY DOOR USED HERE. Six more
    // of the 65 — `explore_commit`, `open_water_navy`, `amenity_districts`,
    // `hut_collection`, `village_seeking`, `legal_tactical_candidates` — are
    // native behaviours production ships ON, whose door is `PRODUCTION_TREATMENTS`.
    // That row is NOT neutral: `apply_gene_ledger` disables every production
    // treatment whose `ledger_default_on` is `Some(false)`, and a screenable tag
    // with no ledger row is exactly that. Adding those six would switch six
    // shipped behaviours off at deployment — `open_water_navy` alone was
    // promoted at +61 Elo — which is a genome change wearing an instrument's
    // clothes. They need their first screen row before they can have a gene row.
    //
    // The friendly-volley extension lets a force finish a defender together
    // without reopening the closed war-half bundle.
    Gene { tag: "coordinated-finish", field: "coordinated_finish", kind: Kind::OptIn, enable: AdvancedAi::enable_coordinated_finish, disable: AdvancedAi::disable_coordinated_finish },
    Gene { tag: "unit-objective-memory", field: "unit_objective_memory", kind: Kind::OptIn, enable: AdvancedAi::enable_unit_objective_memory, disable: AdvancedAi::disable_unit_objective_memory },
    // Choose the pantheon from the land the empire actually holds rather than
    // from a fixed order.
    Gene { tag: "pantheon-board", field: "pantheon_board", kind: Kind::OptIn, enable: AdvancedAi::enable_pantheon_board, disable: AdvancedAi::disable_pantheon_board },
    // The policy counterfactual sees the unit-maintenance bill, so the cards
    // that pay it stop scoring zero.
    Gene { tag: "maintenance-aware-deck", field: "maintenance_aware_deck", kind: Kind::OptIn, enable: AdvancedAi::enable_maintenance_aware_deck, disable: AdvancedAi::disable_maintenance_aware_deck },
    // Credit strength-per-production, and the civilization's unique unit, in
    // military production.
    Gene { tag: "unit-cost-efficiency", field: "unit_cost_efficiency", kind: Kind::OptIn, enable: AdvancedAi::enable_unit_cost_efficiency, disable: AdvancedAi::disable_unit_cost_efficiency },
    // The settlement-gap redirect and the Settler ranking read the same city
    // target, instead of two that can disagree.
    Gene { tag: "settlement-gap-target", field: "settlement_gap_target", kind: Kind::OptIn, enable: AdvancedAi::enable_settlement_gap_target, disable: AdvancedAi::disable_settlement_gap_target },
    // Let the envoy scorer see the suzerainty it is walking toward.
    Gene { tag: "price-the-suzerainty", field: "price_the_suzerainty", kind: Kind::OptIn, enable: AdvancedAi::enable_price_the_suzerainty, disable: AdvancedAi::disable_price_the_suzerainty },
    // Read the Faith price from the engine instead of the Standard-speed
    // literal, which overquotes by 2x at Online — the screen's own speed.
    Gene { tag: "engine-faith-price", field: "engine_faith_price", kind: Kind::OptIn, enable: AdvancedAi::enable_engine_faith_price, disable: AdvancedAi::disable_engine_faith_price },
    // A wounded unit may still take its promotion.
    Gene { tag: "promote-when-wounded", field: "promote_when_wounded", kind: Kind::OptIn, enable: AdvancedAi::enable_promote_when_wounded, disable: AdvancedAi::disable_promote_when_wounded },
    // ⚠ The production menu offers each district's top TWO fresh sites
    // ranked by unweighted yield total, districts claim plots independently
    // with nothing reserving ground between them, and no path buys the plot
    // a high-adjacency site sits on — while the best legal owned Campus
    // plot measured ≤2 across three seeds and plots at adjacency ≥4 are
    // under 1% of the map: the ground worth planning for is almost never
    // owned ground. The plan assigns the city's wished districts their
    // plots together over rings 1-3, reserves them, puts its sites on the
    // menu, and buys the tile a very valuable site needs. Appended at the
    // END so a running screen keeps its positional genome. See
    // `AdvancedAi::district_planning` / `advanced/district_planning.rs`.
    Gene { tag: "district-planning", field: "district_planning", kind: Kind::OptIn, enable: AdvancedAi::enable_district_planning, disable: AdvancedAi::disable_district_planning },
    // ⭐ A WONDER LANE ANY CIVILIZATION CAN REACH ON MERIT. The `Item::Wonder`
    // arm refuses every wonder in a 53-wonder roster unless the plan is
    // Culture, the target is Score, or the seat is an UNTARGETED EGYPT OR
    // CHINA. `Game::score_parts` pays 15 points a wonder — the densest line of
    // a tally that decides three quarters of standard-screen games — and no
    // native gate says so: `live-wonder-race` is `Kind::HostOnly` and inert
    // headless, and `strategic-wonders` prices only the lane's own payload,
    // zero for Conquest, Expansion and Recovery. This gene tells the queue: a
    // developed city may take a wonder whose ordinary value plus its fifteen
    // points clears `WONDER_TALLY_MIN_DENSITY` per point of production cost,
    // with no flat lane bonus, so it still loses to a Settler or a district
    // worth more per turn.
    // ⚠ MEASURED AND OFF. The premise that four of six civilizations never
    // build a wonder is false — 91.6% of deployment seats finish one, 6.54 a
    // seat, and the Culture disjunct beside the identity clause is what opens
    // the lane — and the gene's own 462-seat batch is `~` on both axes. The
    // numbers, and the live corpus that says the same lane is open there too,
    // are in
    // `docs/eval/2026-08-24-the-wonder-lane-is-already-open-in-both-regimes.md`;
    // the row is kept so the next standard screen prices it for free.
    // Appended at the END so a running screen keeps its positional genome. See
    // `AdvancedAi::wonder_score_tally`.
    Gene { tag: "wonder-score-tally", field: "wonder_score_tally", kind: Kind::OptIn, enable: AdvancedAi::enable_wonder_score_tally, disable: AdvancedAi::disable_wonder_score_tally },
    // Operator goal 2026-08-24: "a heuristic for exploring with missionaries
    // with 1 charge remaining". The third charge deletes the unit, so a
    // four-move, border-ignoring Missionary explores the fog within ten
    // tiles for up to twelve turns before spending it — unless a city of ours
    // is slipping or an untouched city stands beside it. See
    // `AdvancedAi::missionary_last_charge_explores`.
    Gene { tag: "missionary-last-charge-explores", field: "missionary_last_charge_explores", kind: Kind::OptIn, enable: AdvancedAi::enable_missionary_last_charge_explores, disable: AdvancedAi::disable_missionary_last_charge_explores },
    // Same goal: "missionaries should be smart enough to evade barbarians
    // using their fast movement". Since 2026-08-24 the barbarian seat walks
    // onto religious units and condemns them (`BasicAi::barbarian_heretic_
    // hunt`); with this gene a religious unit steps out of, and never steps
    // into, the exact tiles a visible raider can reach next turn
    // (`Game::threat_reach`). See `AdvancedAi::missionary_evades_raiders`.
    Gene { tag: "missionary-evades-raiders", field: "missionary_evades_raiders", kind: Kind::OptIn, enable: AdvancedAi::enable_missionary_evades_raiders, disable: AdvancedAi::disable_missionary_evades_raiders },
    // Operator goal 2026-08-24: "a gene for defending against religion, to
    // the extent we care about that". A religious victory needs more than
    // half of EVERY living major's cities, so each civilization is a veto;
    // the gene reads how much of a rival's victory is done (civs held +
    // progress toward half of ours), names and targets that faith from half
    // a victory and scales the defensive corps and the reserve by it from
    // match point, never withholding the shipped defence; the Inquisitor
    // goes to the heresy. See `AdvancedAi::religious_veto_defence`.
    Gene { tag: "religious-veto-defence", field: "religious_veto_defence", kind: Kind::OptIn, enable: AdvancedAi::enable_religious_veto_defence, disable: AdvancedAi::disable_religious_veto_defence },
    // Operator 2026-08-24: "very bad deals and just giving stuff away when
    // more optimally we'd get more in exchange". Three leaks, one gene each.
    // The trade objective was FAIRNESS: `bilateral_trade` picked the quote
    // maximising `min(our gain, their gain)`, discarding the ordering
    // `quick_deals` already produced by our gain. See
    // `BasicAi::deals_for_our_gain`.
    Gene { tag: "deals-for-our-gain", field: "deals_for_our_gain", kind: Kind::OptIn, enable: AdvancedAi::enable_deals_for_our_gain, disable: AdvancedAi::disable_deals_for_our_gain },
    // Every peacetime quote split the surplus down the middle
    // (`quote_asset_trade`); the war-eve lane prices at the buyer's ceiling
    // and proves the engine can. The chosen quote's Gold moves to the
    // counterparty's walk-away less two; the midpoint is the fallback. See
    // `BasicAi::deals_at_the_ceiling`.
    Gene { tag: "deals-at-the-ceiling", field: "deals_at_the_ceiling", kind: Kind::OptIn, enable: AdvancedAi::enable_deals_at_the_ceiling, disable: AdvancedAi::disable_deals_at_the_ceiling },
    // Both alliance proposals bundled one-way Open Borders once Early Empire
    // was in, and `do_accept_deal` grants them proposer → recipient: passage
    // through the whole empire for nothing, on every friendship ask. See
    // `BasicAi::no_free_passage`.
    Gene { tag: "no-free-passage", field: "no_free_passage", kind: Kind::OptIn, enable: AdvancedAi::enable_no_free_passage, disable: AdvancedAi::disable_no_free_passage },
    // Operator directive 2026-08-24: "one war at a time — some defences on
    // the home front, the rest concentrated on a single war; fight while
    // benefit > cost, sue for peace when the tide is no longer in our
    // favour consistently". Every offensive opening already refuses a second
    // front; this decides what happens once a second war ARRIVES — peace on
    // every front but one, the plan and the force planner held to that one,
    // the fatigue clause stood down while a city is breaking or tiles are in
    // reach, and peace sued for once the war ledger's exchange has run
    // against us for `ONE_WAR_TIDE_PATIENCE` turns. See
    // `AdvancedAi::one_war_observe` and `advanced/one_war.rs`.
    Gene { tag: "one-war-at-a-time", field: "one_war_at_a_time", kind: Kind::OptIn, enable: AdvancedAi::enable_one_war_at_a_time, disable: AdvancedAi::disable_one_war_at_a_time },
    Gene { tag: "pass-picket", field: "pass_picket", kind: Kind::OptIn, enable: AdvancedAi::enable_pass_picket, disable: AdvancedAi::disable_pass_picket },
    Gene { tag: "pass-picket-2", field: "pass_picket_2", kind: Kind::OptIn, enable: AdvancedAi::enable_pass_picket_2, disable: AdvancedAi::disable_pass_picket_2 },
    // Run civvis-20260824T204654Z opened trade capacity around turn 17 and
    // still held zero Traders and zero routes at turn 65, by then at -6 Gold
    // per turn. The safety gate asked whether EVERY city was quiet, so a
    // remote coastal alarm vetoed a safe capital's route. Reserve the first
    // usable empty slot after immediate local defence and test the producing
    // origin itself; ordinary and frozen controllers keep the global veto.
    // Appended at the END so a running screen keeps its positional genome.
    // Promoted 2026-09-10: the three latest standard screens keep this gene
    // first, at +92/+101/+104 scaled wins per 10,000 seats, with a +5.17 pp
    // aggregate on/off difference over 47,640 measured seats. The local fire
    // above still pins the remote-alarm safety boundary.
    Gene { tag: "solvency-first-trade-slot", field: "solvency_first_trade_slot", kind: Kind::Production, enable: AdvancedAi::enable_solvency_first_trade_slot, disable: AdvancedAi::disable_solvency_first_trade_slot },
    // 2026-08-24 operator goal: "much stronger tactical smarts and planning
    // for taking enemy cities, particularly for weaker enemies … analyze
    // neighboring enemies' military strength (public information) and their
    // progress in science … pick a city or two or more that we can likely
    // take and hold … units to spare … quickly pillage the tiles we can if
    // we have time". Two genes, `advanced/city_campaign.rs`.
    // The neighbour appraised on public power and tech count, the holdable
    // city priced with the spare, the launch on the city's own bill.
    Gene { tag: "city-campaign", field: "city_campaign", kind: Kind::OptIn, enable: AdvancedAi::enable_city_campaign, disable: AdvancedAi::disable_city_campaign },
    // A soldier at war pillages with the movement its march does not use.
    Gene { tag: "campaign-pillage", field: "campaign_pillage", kind: Kind::OptIn, enable: AdvancedAi::enable_campaign_pillage, disable: AdvancedAi::disable_campaign_pillage },
    // Run civvis-20260824T204654Z had a useful wide early pipeline but offered
    // its next Settlers from factories finishing in roughly 3, 7 and 29 turns,
    // while walkers repeatedly held or lost a site to another founding. Keep
    // `settler_in_flight_allowed` unchanged; admit only competitive factories
    // and reserve a distinct, lawful route and site for each live or queued
    // Settler. Appended at the END so a running screen keeps its positional
    // genome.
    Gene { tag: "settler-factory-coordination", field: "settler_factory_coordination", kind: Kind::OptIn, enable: AdvancedAi::enable_settler_factory_coordination, disable: AdvancedAi::disable_settler_factory_coordination },
    // Run civvis-20260824T204654Z let offshore barbarian hulls read as the
    // same emergency as land raiders: they preempted city queues and recruited
    // land defenders even where coastline and attack domain gave them no
    // serious next-turn target. Price the engine's terrain-accurate attack
    // envelope against actual assets; harmless hulls create no alarm or chase,
    // but a ranged unit already holding a legal shot gets a bounded XP credit.
    // Appended at the END so a running screen keeps its positional genome.
    Gene { tag: "naval-threat-triage", field: "naval_threat_triage", kind: Kind::OptIn, enable: AdvancedAi::enable_naval_threat_triage, disable: AdvancedAi::disable_naval_threat_triage },
    // A surprise declaration arrives after the aggressor has chosen the
    // timing, while the target still carries peaceful queues, policies and
    // old units. For six Standard-speed turns, buy one frontline land body,
    // modernize, prioritize land-unit production cards, and redirect at most
    // half the empire's unfinished non-Settler queues toward the fastest
    // credible defenders until live plus queued land force reaches two per
    // city. The declaration direction and hard expiry keep this distinct from
    // the removed permanent war-economy routing. See
    // `advanced/surprise_defense.rs`.
    // Appended at the END so a running screen keeps its positional genome.
    Gene { tag: "surprise-war-mobilization", field: "surprise_war_mobilization", kind: Kind::OptIn, enable: AdvancedAi::enable_surprise_war_mobilization, disable: AdvancedAi::disable_surprise_war_mobilization },
    // Operator 2026-08-24: the live seat led the field in science (334 a turn,
    // 71 techs) and never ran a launch project — the stock horizon refused
    // the race from t150 at the city's raw production, ignoring the engine's
    // +100% on Spaceport projects, and nothing built production for it. A
    // seat that dominates science drives the race: the chain beeline, the
    // launch city's zone chain, a horizon priced as the engine runs it, two
    // pads by the Earth Satellite. Pinned on by the operator before its
    // first screen. Appended at the END so a running screen keeps its
    // positional genome.
    Gene { tag: "science-victory-drive", field: "science_victory_drive", kind: Kind::OptIn, enable: AdvancedAi::enable_science_victory_drive, disable: AdvancedAi::disable_science_victory_drive },
    // Over 218 completed live runs every one of the nine wins came from an
    // empire holding four to six cities at turn 60, and none of the 128 runs
    // outside that band won (Fisher p = 2.6e-4); the median loss loses the
    // lead for good at turn 61. The target is not the problem — `assess`
    // already asks for seven cities by then — and neither is the price, which
    // a 96-game census settled by scoring the Settler at four times its value
    // and leaving 97% of games identical. The pipeline is: one walker at a
    // time, and both flags that widen it are host-only. Appended at the END so
    // a running screen keeps its positional genome.
    Gene { tag: "expansion-schedule", field: "expansion_schedule", kind: Kind::OptIn, enable: AdvancedAi::enable_expansion_schedule, disable: AdvancedAi::disable_expansion_schedule },
    // The other half of the same defect, named in `production_value`'s own
    // note: a Settler needs a city at population two, and there is none on
    // 23.8% of seat-turns — "a growth constraint no price can buy past". The
    // citizen governor reads one empire scalar the engine never writes.
    // Scoped to the opening, to being behind the pace, and to an empire that
    // genuinely cannot build, because the unscoped version of this idea
    // (`city_strategy`) measured Elo -53 by building a smaller empire.
    Gene { tag: "growth-to-settle", field: "growth_to_settle", kind: Kind::OptIn, enable: AdvancedAi::enable_growth_to_settle, disable: AdvancedAi::disable_growth_to_settle },
    // 37.8% of recorded turns carry at least one refused order (`produce`
    // 24.9%, `trade` 67.3%) while the seat's judgement at matched states is
    // intact — it loses by not landing orders. Of the ~137 sites that discard
    // an `apply` error, not one tries an alternative. This is the repair
    // `docs/AI_GAPS.md` names after `fog-honest-2` lost with the ambitious
    // one: skip only the refused decision, no re-plan and no early EndTurn.
    Gene { tag: "order-retry", field: "order_retry", kind: Kind::OptIn, enable: AdvancedAi::enable_order_retry, disable: AdvancedAi::disable_order_retry },
    // The same shape one layer down: `builder_step` ranks every improvable
    // owned tile by straight-line `wdist`, then asks `step_toward` for the
    // single nearest one and returns `false` if it refuses. A ridge, a zone of
    // control or a unit in the way is enough, and the sweep re-picks the same
    // unreachable tile every turn after. Census at the deployment genome:
    // 22 Builders stood still 25+ turns across 8 games; at t180, 25 Builders
    // were alive holding 73 charges with NOT ONE of them in an empire that had
    // run out of improvable tiles. One caught directly -- builder 312, seat 5,
    // 30 turns at (10, 29), 3 charges, work 5 tiles away on its own landmass.
    // The gene tries the next-nearest candidate instead of the turn.
    Gene { tag: "builder-tries-the-next-tile", field: "builder_tries_the_next_tile", kind: Kind::OptIn, enable: AdvancedAi::enable_builder_tries_the_next_tile, disable: AdvancedAi::disable_builder_tries_the_next_tile },
    // Version two pays for only an actual opening escort's fresh vision and
    // leaves the normal settlement candidate filter intact. It replaces v1
    // within a seat, so a screen can compare their distinct mechanisms.
    Gene { tag: "opening-warrior-recon-2", field: "opening_warrior_recon_2", kind: Kind::OptIn, enable: AdvancedAi::enable_opening_warrior_recon_2, disable: AdvancedAi::disable_opening_warrior_recon_2 },
    // ⚠ Settlers are lost by CAPTURE — a raider stepping onto the tile —
    // and in a native game the settler's capture model is a geometric disk
    // priced as a soft score under the MILITARY model, its retreat block and
    // the stacked-guard system both host-only; the builder's exact flood
    // (`builder-barbarian-safety`) credits no guard and never flees a job.
    // Eight settlers were taken in 104 turns on civvis-20260821T130446Z,
    // both of civvis-20260815T081505Z's within a tile of their site, and a
    // run that loses settlers ends with half the cities. This gene reads
    // the tiles every visible raider could END its next move on
    // (`threat_reach`; barbarians move after us in the same world turn), and
    // a Settler or Builder flees such a tile first, never steps into one
    // alone, and — the settler — summons the nearest healthy land unit onto
    // its own tile and walks with it: a stacked civilian cannot be taken.
    // Appended at the END so a running screen keeps its positional genome.
    // See `AdvancedAi::civilian_out_of_reach` / `advanced/civilian_safety.rs`.
    Gene { tag: "civilian-out-of-reach", field: "civilian_out_of_reach", kind: Kind::OptIn, enable: AdvancedAi::enable_civilian_out_of_reach, disable: AdvancedAi::disable_civilian_out_of_reach },
    // ⭐ DEITY HABITS (operator, 2026-08-24: "study expert level deity civ 6
    // tips and tricks and implement the best as heuristics"). The third habit,
    // `chop-into-the-queue`, left the code on 2026-09-09 under the batch rule
    // (-23/-22/-11). See `advanced/deity_habits.rs`.
    // Sixty-two technologies and fifty-three civics carry a boost worth 40%
    // of their cost; `tech_value` pays +28 for a boost in hand and nothing
    // ever earned one. A Deity player builds the quarry for Masonry, the
    // pasture for Horseback Riding, the sixth farm for Feudalism. The
    // improvement that completes a trigger is worth the research it grants,
    // spread over the steps the trigger still needs. Appended at the END so
    // a running screen keeps its positional genome. See
    // `advanced/deity_habits.rs`.
    Gene { tag: "eureka-chasing-builder", field: "eureka_chasing_builder", kind: Kind::OptIn, enable: AdvancedAi::enable_eureka_chasing_builder, disable: AdvancedAi::disable_eureka_chasing_builder },
    // The same boost table read by the production queue: two Galleys for
    // Shipbuilding, three Archers for Machinery, Walls for Engineering, an
    // Aqueduct for Military Engineering, two Markets for Guilds. The unit,
    // building or district that completes a trigger is worth the research it
    // grants on `production_value`'s raw scale. Appended at the END so a
    // running screen keeps its positional genome. See
    // `advanced/deity_habits.rs`.
    Gene { tag: "eureka-chasing-production", field: "eureka_chasing_production", kind: Kind::OptIn, enable: AdvancedAi::enable_eureka_chasing_production, disable: AdvancedAi::disable_eureka_chasing_production },

    // The war desk prepares an army and nothing else: an appointed war spends
    // its phases on a tech, a package and a march, an elective one waits for
    // `ready && staged`, and neither spends a turn of the lead on who else
    // will be fighting the target. `propose_strategic_alliance` picks its
    // partner from OUR strategy on a 12-turn cadence, the envoy scorer reads
    // a city-state's place only against our own cities, and
    // `Action::ProposeJointWar` -- the one action that makes a second empire
    // declare the turn we do -- is issued by no controller at all. The gene
    // opens a coalition window from the turn a target is held: an alliance a
    // turn with the target's neighbours (military first), envoys to the
    // city-states beside the target (a suzerain's clients fight its wars),
    // and joint-war invitations the turn the desk would declare, holding the
    // declaration while an answer is due. Operator request, 2026-08-25.
    Gene { tag: "coalition-before-war", field: "coalition_before_war", kind: Kind::OptIn, enable: AdvancedAi::enable_coalition_before_war, disable: AdvancedAi::disable_coalition_before_war },
    // Version 2 of `amenity-project-preemption` (2026-08-24): one gated delta on version 1; the
    // family draw is biased toward the best version and the ledger ships the
    // best by pooled Diff. See `AdvancedAi::enable_amenity_project_preemption_2`.
    Gene { tag: "amenity-project-preemption-2", field: "amenity_project_preemption_2", kind: Kind::OptIn, enable: AdvancedAi::enable_amenity_project_preemption_2, disable: AdvancedAi::disable_amenity_project_preemption_2 },
    // Version 2 of `campus-adjacency-threshold` (2026-08-24): one gated delta on version 1; the
    // family draw is biased toward the best version and the ledger ships the
    // best by pooled Diff. See `AdvancedAi::enable_campus_adjacency_threshold_2`.
    Gene { tag: "campus-adjacency-threshold-2", field: "campus_adjacency_threshold_2", kind: Kind::OptIn, enable: AdvancedAi::enable_campus_adjacency_threshold_2, disable: AdvancedAi::disable_campus_adjacency_threshold_2 },
    // Version 2 of `district-coverage` (2026-08-24): one gated delta on version 1; the
    // family draw is biased toward the best version and the ledger ships the
    // best by pooled Diff. See `AdvancedAi::enable_district_coverage_2`.
    Gene { tag: "district-coverage-2", field: "district_coverage_2", kind: Kind::OptIn, enable: AdvancedAi::enable_district_coverage_2, disable: AdvancedAi::disable_district_coverage_2 },
    // A damaged religious corps may hold one Guru for its only field heal.
    // See `AdvancedAi::enable_guru_heals_the_corps_2`.
    Gene { tag: "guru-heals-the-corps-2", field: "guru_heals_the_corps_2", kind: Kind::OptIn, enable: AdvancedAi::enable_guru_heals_the_corps_2, disable: AdvancedAi::disable_guru_heals_the_corps_2 },
    // Version 2 of `holy-site-where-the-threat-is` (2026-08-24): one gated delta on version 1; the
    // family draw is biased toward the best version and the ledger ships the
    // best by pooled Diff. See `AdvancedAi::enable_holy_site_where_the_threat_is_2`.
    Gene { tag: "holy-site-where-the-threat-is-2", field: "holy_site_where_the_threat_is_2", kind: Kind::OptIn, enable: AdvancedAi::enable_holy_site_where_the_threat_is_2, disable: AdvancedAi::disable_holy_site_where_the_threat_is_2 },
    // Version 2 of `naval-recon` (2026-08-24): one gated delta on version 1; the
    // family draw is biased toward the best version and the ledger ships the
    // best by pooled Diff. See `AdvancedAi::enable_naval_recon_2`.
    Gene { tag: "naval-recon-2", field: "naval_recon_2", kind: Kind::OptIn, enable: AdvancedAi::enable_naval_recon_2, disable: AdvancedAi::disable_naval_recon_2 },
    // Version 2 of `power-the-laboratory` (2026-08-24): one gated delta on version 1; the
    // family draw is biased toward the best version and the ledger ships the
    // best by pooled Diff. See `AdvancedAi::enable_power_the_laboratory_2`.
    Gene { tag: "power-the-laboratory-2", field: "power_the_laboratory_2", kind: Kind::OptIn, enable: AdvancedAi::enable_power_the_laboratory_2, disable: AdvancedAi::disable_power_the_laboratory_2 },
    // Version 2 of `settler-guard-holds` (2026-08-24): one gated delta on version 1; the
    // family draw is biased toward the best version and the ledger ships the
    // best by pooled Diff. See `AdvancedAi::enable_settler_guard_holds_2`.
    Gene { tag: "settler-guard-holds-2", field: "settler_guard_holds_2", kind: Kind::OptIn, enable: AdvancedAi::enable_settler_guard_holds_2, disable: AdvancedAi::disable_settler_guard_holds_2 },
    // Version 2 of `settler-target-hysteresis` (2026-08-24): one gated delta on version 1; the
    // family draw is biased toward the best version and the ledger ships the
    // best by pooled Diff. See `AdvancedAi::enable_settler_target_hysteresis_2`.
    Gene { tag: "settler-target-hysteresis-2", field: "settler_target_hysteresis_2", kind: Kind::OptIn, enable: AdvancedAi::enable_settler_target_hysteresis_2, disable: AdvancedAi::disable_settler_target_hysteresis_2 },
    // The first land unit within two tiles of an at-war city resets the
    // fatigue clock once, so a campaign still walking to its target is not
    // offered away as stalled. See `AdvancedAi::enable_siege_is_progress_2`.
    Gene { tag: "siege-is-progress-2", field: "siege_is_progress_2", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_is_progress_2, disable: AdvancedAi::disable_siege_is_progress_2 },
    // Every tier-2 government is gated on one civic and `strategic_government`
    // already ranks all three above `classical_republic` in every lane. The
    // civic never arrives: past `political_philosophy` the `forced_goal` match
    // falls through to `civic_value`, whose `(value + 32) / sqrt(cost)` pays a
    // tier-2 gate 153 over sqrt(440) against Political Philosophy's three
    // governments plus a flat +70 over sqrt(110). Live King seat, 2026-08-25:
    // the three gate civics were reached in 0 of 59 games and all 24 readable
    // late snapshots were still Classical Republic -- four policy slots for the
    // whole game instead of six, and the one tier-1 government with no military
    // slot at all.
    Gene { tag: "government-ladder", field: "government_ladder", kind: Kind::OptIn, enable: AdvancedAi::enable_government_ladder, disable: AdvancedAi::disable_government_ladder },
    // The repair was written, documented, and half-applied. `research_debt`,
    // `culture_debt` and `research_coverage` are all multiplied by
    // `research_horizon`, a straight line to zero at the turn limit, while
    // `RESEARCH_CAMPUS_PAYBACK` and `campus_payback_horizon` sitting beside them
    // say what the code means to ask -- "whether it can REPAY, not what
    // fraction of the game is left" -- and the comment over `research_coverage`
    // claims outright to BE a payback horizon. Only `adjacency_threshold` was
    // ever migrated. 88% of standard Emperor games end on a science victory at
    // a median turn 193, where the game fraction is already down to 0.23: the
    // Library that decides the race is priced at under a quarter of its debt
    // exactly when the race is decided, against rival terms that never decay.
    Gene { tag: "chain-payback-window", field: "chain_payback_window", kind: Kind::OptIn, enable: AdvancedAi::enable_chain_payback_window, disable: AdvancedAi::disable_chain_payback_window },
    // The order is the bug, not the floor. `upgrade_units` ranks by strength
    // gained per gold and stops at a treasury floor, and `take_turn_inner` calls
    // it LAST -- after `advanced_gold_spending` has bought until the bank hits
    // its reserve, so what survives is by construction about equal to that
    // reserve and only the cheapest upgrades clear the floor. An upgrade costs
    // base plus twice the production difference; buying the same unit fresh
    // costs four times its production, so the inversion spends several times
    // the gold for the same strength. Live King seat, 2026-08-25: about three
    // UPGRADE orders per whole game, Heavy Chariots still the commonest unit at
    // turn 150, and 28 of 40 lost cities lost to conquest.
    Gene { tag: "upgrade-the-garrison", field: "upgrade_the_garrison", kind: Kind::OptIn, enable: AdvancedAi::enable_upgrade_the_garrison, disable: AdvancedAi::disable_upgrade_the_garrison },
    // `advanced_production` ranks the menu, walks it while the score clears
    // -1,000, and then `if let Some(..)` -- with no `else`. A city whose whole
    // menu is priced at a refusal sentinel produces NOTHING, silently, with no
    // journal line. `BasicAi::pick_item` returns `None` the same way out of its
    // economic-recovery arm and its tail, and its caller has no `else` either.
    // Live King seat, 2026-08-25: 3,094 of 36,975 city-turns before turn 104
    // carried no production item at all, 8.4% of the early empire's output.
    Gene { tag: "never-an-empty-queue", field: "never_an_empty_queue", kind: Kind::OptIn, enable: AdvancedAi::enable_never_an_empty_queue, disable: AdvancedAi::disable_never_an_empty_queue },
    // Two Builder quotas exist and the measured one is not the one that binds.
    // `production_builder_floor` raises 0.5 to 0.75 inside `delegated_cities`,
    // the baseline governor the strategic path reaches only for a city it has
    // already left empty; the quota that decides almost every Builder is
    // hardcoded in `production_value`'s own arm as `city_count.div_ceil(2)` and
    // has never been screened. Its 260 also loses to a monument's flat 240 plus
    // yields and to a district's `balanced_core` 130 plus yields x 60. Live
    // King seat, 2026-08-25: Builders 3% of early city production against
    // Settlers' 22%, 13% of owned land improved by turn 100.
    Gene { tag: "builder-supply-floor", field: "builder_supply_floor", kind: Kind::OptIn, enable: AdvancedAi::enable_builder_supply_floor, disable: AdvancedAi::disable_builder_supply_floor },
    // Version two of `chain-payback-window`, which moved all three chain terms
    // to the payback horizon and whose 24-game probe came back negative on both
    // axes. The three are not the same purchase: `research_debt` and
    // `culture_debt` are a Library and an Amphitheater owed to a district
    // already paid for -- the case `RESEARCH_CAMPUS_PAYBACK` was written for --
    // while `research_coverage` is 300 points for a whole Campus in a city with
    // none, and holding THAT at full value to within forty turns of the end
    // lets it outbid the Spaceport that actually ends the game. Version two
    // takes the repaired horizon for the cheap rung only.
    Gene { tag: "chain-payback-window-2", field: "chain_payback_window_2", kind: Kind::OptIn, enable: AdvancedAi::enable_chain_payback_window_2, disable: AdvancedAi::disable_chain_payback_window_2 },
    // Version two of `never-an-empty-queue`, whose 24-game probe read negative
    // on both axes. The preference version one carries cannot bind: the scorer
    // issues -10,000 for a hard veto and -2,000 for a soft one, and every soft
    // refusal it actually issues is a UNIT -- a saturated domain, a second
    // Scout, a body weaker than the best in its role. So an idle city has its
    // infrastructure at -10,000 and soldiers at -2,000, and "prefer
    // infrastructure" never fires: version one answers an idle turn with a
    // surplus soldier the empire owes upkeep on. Version two lets a Builder,
    // Trader, Settler, building, district or project answer the turn and lets a
    // refused soldier not.
    Gene { tag: "never-an-empty-queue-2", field: "never_an_empty_queue_2", kind: Kind::OptIn, enable: AdvancedAi::enable_never_an_empty_queue_2, disable: AdvancedAi::disable_never_an_empty_queue_2 },
    // The measured pattern, applied where it should also hold. The 2026-08-25
    // King-rung screen priced `solvency-first-trade-slot` at +4.04 pp wins
    // (z +3.02) and +1.09 pp share (z +4.65) -- helps on both axes -- while its
    // own version two, which fills EVERY empty slot instead of the first,
    // measured -1.93 pp on the same games. The win is buying ONE compounding
    // asset ahead of an argmax that will never choose it, not buying more of
    // it. A Builder is priced 260 and a Library about 960 against a Settler's
    // 1,560 by that same argmax; live King seat, Builders were 3% of early city
    // production and only 40% of Campus cities held a Library at turn 100.
    Gene { tag: "first-builder-reserve", field: "first_builder_reserve", kind: Kind::OptIn, enable: AdvancedAi::enable_first_builder_reserve, disable: AdvancedAi::disable_first_builder_reserve },
    // V2 reserves one Builder only for an owned, immediately connectable
    // first-copy luxury while Amenities are short and expansion is covered;
    // after the first Builder appears, it retains a lifetime receipt.
    Gene { tag: "first-builder-reserve-2", field: "first_builder_reserve_2", kind: Kind::OptIn, enable: AdvancedAi::enable_first_builder_reserve_2, disable: AdvancedAi::disable_first_builder_reserve_2 },
    // The same sentence for the cheap rung of the research chain, in a city
    // that has already paid for the Campus. 91% of standard Emperor games end
    // on a science victory, so this is the win condition itself.
    Gene { tag: "first-research-building-reserve", field: "first_research_building_reserve", kind: Kind::OptIn, enable: AdvancedAi::enable_first_research_building_reserve, disable: AdvancedAi::disable_first_research_building_reserve },
    // A camp's Scout reports the nearest major settlement it sees and the
    // camp raises its party against that report, so a camp nearer a rival's
    // city than ours raids the rival -- and five deliberate clears (the
    // adjacent clear, the camp errand, the barbarian-response threat list, the
    // near-home chase, the presence alarm) took it down anyway, each
    // measuring distance from OUR cities only. The envoy scorer and the
    // alliance partner score likewise read a city-state's or a major's place
    // against our own cities, so the one ACROSS a rival -- the front that
    // rival cannot cover while facing us -- scored nothing for being there.
    // The gene leaves the neighbours' camps standing, pays envoys and
    // alliance partners on the far side of every rival, and refuses a
    // rival's joint war against the major on its far side. Operator
    // request, 2026-08-25.
    Gene { tag: "enemy-of-my-enemy", field: "enemy_of_my_enemy", kind: Kind::OptIn, enable: AdvancedAi::enable_enemy_of_my_enemy, disable: AdvancedAi::disable_enemy_of_my_enemy },
    // A Barbarian Outpost inside a city's own three rings is bought out. The
    // shipped plot appraisal prices a camp hex as its bare terrain, so the
    // one plot in the empire whose ownership is about a threat is the one
    // plot Gold never reaches; and Culture will not reach it either, because
    // `border_influence_cost` charges a camp the shipped +100, a whole ring
    // of distance, and the city grows around the hole instead. The gene buys
    // it when being rid of the outpost is worth more than the quote — the
    // outpost visible, and a soldier of ours in reach to walk in and
    // disperse it, since Civilization VI removes an outpost on entry and
    // never because the deed changed hands. Operator request, 2026-08-25.
    Gene { tag: "camp-tile-buyout", field: "camp_tile_buyout", kind: Kind::OptIn, enable: AdvancedAi::enable_camp_tile_buyout, disable: AdvancedAi::disable_camp_tile_buyout },
    // 2026-08-25, run civvis-20260825T162542Z: Mount Roraima three tiles from
    // Rome, every Settler walked the other way. The site model read the
    // wonder as lost jobs and the ground beside it was never scouted. See
    // `advanced/wonder_sites.rs`. Version 2 adds a small flat footprint
    // credit on top of the projection, kept small because #1419's flat wonder
    // credit lost at scale (#2464); version 1 (the projection alone) left the
    // code on 2026-09-09 under the batch rule (-12/-19/-19).
    Gene { tag: "wonder-adjacent-sites-2", field: "wonder_adjacent_sites_2", kind: Kind::OptIn, enable: AdvancedAi::enable_wonder_adjacent_sites_2, disable: AdvancedAi::disable_wonder_adjacent_sites_2 },
    Gene { tag: "wonder-ring-recon", field: "wonder_ring_recon", kind: Kind::OptIn, enable: AdvancedAi::enable_wonder_ring_recon, disable: AdvancedAi::disable_wonder_ring_recon },
    // Three site terms run from every neighbour (six a tile under six from
    // a foreign city, four a tile for rival ground within three, isolation
    // on top) and nothing pays for the one thing the ground between two
    // empires has that the ground behind us does not: a rival's Settler is
    // walking toward it. While our military power is at least 0.8 of the
    // strongest neighbour's and two land units stand, a site between us and
    // a met neighbour within eight of their city earns 10 plus 3 a tile of
    // the gap it closes (cap 28) and pays no border provocation; an own city
    // within eight of a neighbour's is a frontier city whose first Walls are
    // worth 240 more and which holds a peacetime garrison. When no contested
    // site is left, the shipped ranking takes the uncontested one. Operator
    // request, 2026-08-25.
    Gene { tag: "contested-land-first", field: "contested_land_first", kind: Kind::OptIn, enable: AdvancedAi::enable_contested_land_first, disable: AdvancedAi::disable_contested_land_first },
    // Operator heuristic, 2026-08-25: Production is spent best on what a
    // slotted card boosts; Gold is flexible and immediate, so it belongs on
    // what no card boosts, on the young city that cannot yet build, and on
    // emergencies. The engine prices every card in `Game::item_prod_mult`
    // and NO controller read it: `gold_purchase_score` divides the remaining
    // cost by the raw yield, so a Settler under Colonization looks slower
    // than it is and becomes a BETTER purchase — the shipped purchaser buys
    // exactly what the deck already discounts. The rows below each own
    // one decision, so the screen can price them apart; all in
    // `advanced/gold_and_cards.rs`. Appended at the END so a running screen
    // keeps its positional genome.
    Gene { tag: "buy-what-cards-cannot-boost", field: "buy_what_cards_cannot_boost", kind: Kind::OptIn, enable: AdvancedAi::enable_buy_what_cards_cannot_boost, disable: AdvancedAi::disable_buy_what_cards_cannot_boost },
    // The production side of the same heuristic: a positive governor value
    // leans toward the item the slotted deck makes cheap, half the card's
    // bonus, capped at a doubling. A reorder, never a spend — a value at or
    // below zero is not raised.
    Gene { tag: "build-what-cards-boost", field: "build_what_cards_boost", kind: Kind::OptIn, enable: AdvancedAi::enable_build_what_cards_boost, disable: AdvancedAi::disable_build_what_cards_boost },
    // `emergency_city_defense_purchase` is gated on `garrison_under_fire`,
    // which only the live bridge sets — on a native board it has never fired
    // once. Version one adds a broad native damage timestamp that remains
    // actionable for four turns, even after an attacker has left the board.
    Gene { tag: "native-emergency-purchase", field: "native_emergency_purchase", kind: Kind::OptIn, enable: AdvancedAi::enable_native_emergency_purchase, disable: AdvancedAi::disable_native_emergency_purchase },
    // Version two keeps the Walls-or-defender answer. A host-confirmed hit in
    // the current turn is authoritative; a one-turn-old damage mark still
    // needs a visible at-war military unit with a legal City Center attack
    // envelope. This rejects stale scars and nearby contacts that cannot
    // actually attack; one family version plays.
    Gene { tag: "native-emergency-purchase-2", field: "native_emergency_purchase_2", kind: Kind::OptIn, enable: AdvancedAi::enable_native_emergency_purchase_2, disable: AdvancedAi::disable_native_emergency_purchase_2 },
    // Operator request, 2026-08-26: play the city-state quests for the Envoy
    // they pay. `src/game/quests.rs` has modelled the eight shipped
    // `Quests.xml` rows since #430 — every met city-state asks each
    // civilization for one thing and pays `envoys_free += 1` when it is done
    // — and NO controller has ever read one: `grep city_state_quest src/ai`
    // was empty. The four rows below each own one decision surface that can
    // already satisfy a quest without knowing it is being asked, so the
    // screen can price them apart; every one is a reorder rather than a
    // spend. All in `advanced/city_state_quests.rs`. Appended at the END so a
    // running screen keeps its positional genome.
    Gene { tag: "quest-production", field: "quest_production", kind: Kind::OptIn, enable: AdvancedAi::enable_quest_production, disable: AdvancedAi::disable_quest_production },
    // The Trader's destination score carries the Envoy of a `send_trade_route`
    // quest, on every city of the city-state asking, so the ordinary yield
    // terms still choose between them.
    Gene { tag: "quest-trade-route", field: "quest_trade_route", kind: Kind::OptIn, enable: AdvancedAi::enable_quest_trade_route, disable: AdvancedAi::disable_quest_trade_route },
    // Civilization VI names ONE outpost and pays for that one only, so the
    // camp errand prefers the named camp over a nearer unnamed one and
    // reaches six tiles further out for it.
    Gene { tag: "quest-camp-errand", field: "quest_camp_errand", kind: Kind::OptIn, enable: AdvancedAi::enable_quest_camp_errand, disable: AdvancedAi::disable_quest_camp_errand },
    // A boost quest is paid by the trigger, so the Envoy rides on the same
    // table `eureka-chasing-production` reads — the Envoy beside that gene's
    // research, and independent of it.
    Gene { tag: "quest-boost", field: "quest_boost", kind: Kind::OptIn, enable: AdvancedAi::enable_quest_boost, disable: AdvancedAi::disable_quest_boost },
    // Buildings are picked cheapest-first, so the Library — the win condition in
    // a regime that ends 89% science — queues behind every cheaper building.
    Gene { tag: "science-building-first", field: "science_building_first", kind: Kind::OptIn, enable: AdvancedAi::enable_science_building_first, disable: AdvancedAi::disable_science_building_first },

    // Sixty-two technologies and fifty-three civics carry a boost worth 40% of
    // their cost, and the whole of the agent's opinion about the order they
    // are taken in was one flat `+28` in `tech_value` and `civic_value`. Both
    // functions end `(value + k) / cost.sqrt()` -- they rank value per root
    // beaker -- and a boost makes the node cost `1 - frac` of its printed
    // price, so the score it buys is the old one times `1 / (1 - frac).sqrt()`,
    // 1.29 at the shipped 40%, with no free parameter. Operator request,
    // 2026-08-25. ⚠ The first cut ADDED the turns of research the boost saves
    // and its own probe resolved a score-share loss of -3.36 pp (z -3.21, run
    // resolves ±2.93): above a `sqrt(cost)` divisor of 7 for an ancient node,
    // an opening empire's two beakers a turn made every boost worth the
    // twelve-turn cap, and the gene took whatever was boosted rather than the
    // boosted one among comparable nodes. See
    // `docs/gene_screens/fires/boost-first-research-v1.json`. Appended at the
    // END so a running screen keeps its positional genome. See
    // `advanced/boost_research.rs`.
    Gene { tag: "boost-first-research", field: "boost_first_research", kind: Kind::OptIn, enable: AdvancedAi::enable_boost_first_research, disable: AdvancedAi::disable_boost_first_research },
    // Being intentional about earning the rest: `eureka-chasing-builder` and
    // `eureka-chasing-production` can only chase a trigger whose thing the
    // empire is already allowed to build, and nothing ever bought the
    // permission. Masonry's quarry wants Mining, Machinery's three Archers
    // want Archery, Guilds' two Markets want Currency. A node is credited the
    // boosts it makes chaseable, capped at `BOOST_UNLOCK_TURNS_CAP` turns.
    // Appended at the END so a running screen keeps its positional genome. See
    // `advanced/boost_research.rs`.
    Gene { tag: "boost-unlock-research", field: "boost_unlock_research", kind: Kind::OptIn, enable: AdvancedAi::enable_boost_unlock_research, disable: AdvancedAi::disable_boost_unlock_research },
    // ⭐ FIVE GENES FOR HARD POWER OVER THE MAP (operator, 2026-08-25:
    // "control over chokepoints — controlling with territory an important
    // narrow water passageway. placing a city on a single wide strip of land
    // to connect 2 bodies of water (through the city, for only me),
    // controlling important mountain passageways"). Nothing in this
    // controller has ever read the SHAPE of the map: a site is a bundle of
    // yields, a plot a bundle of yields, a district an adjacency. The four
    // engine facts these spend are quoted in the header of
    // `advanced/chokepoints.rs` — a city center is a naval passage only its
    // owner may enter (`class_can_traverse`, then `can_enter_past`'s city
    // arm); a border refuses entry without Open Borders and asks nothing
    // about the terrain, so owning the water of a strait closes it; an
    // unpillaged Encampment refuses a foreign unit with no exception at all,
    // war included; and one military body in a one-tile pass is a wall the
    // column has to break. Appended at the END so a running screen keeps its
    // positional genome.
    // A site is worth the passes and straits its own borders would cover.
    Gene { tag: "chokepoint-siting", field: "chokepoint_siting", kind: Kind::OptIn, enable: AdvancedAi::enable_chokepoint_siting, disable: AdvancedAi::disable_chokepoint_siting },
    // A city center on the strip of land between two seas joins them for our
    // fleet and for nobody else's, priced in the sea detour it saves.
    Gene { tag: "canal-city", field: "canal_city", kind: Kind::OptIn, enable: AdvancedAi::enable_canal_city, disable: AdvancedAi::disable_canal_city },
    // Gold buys the plot that closes a passage somebody else could use:
    // `expand_borders` is the engine's own influence picker and takes no
    // advice, so `BuyPlot` is the whole lever the seat has over a border.
    Gene { tag: "chokepoint-claim", field: "chokepoint_claim", kind: Kind::OptIn, enable: AdvancedAi::enable_chokepoint_claim, disable: AdvancedAi::disable_chokepoint_claim },
    // The Encampment lands on the pass, where it is a permanent wall.
    Gene { tag: "encampment-seals-the-pass", field: "encampment_seals_the_pass", kind: Kind::OptIn, enable: AdvancedAi::enable_encampment_seals_the_pass, disable: AdvancedAi::disable_encampment_seals_the_pass },
    // A surplus soldier — or a hull, for a strait — holds the gate on the
    // approach to one of our cities and fortifies. On the peacetime tail
    // alone: a stand-still posture in a major war screened NEGATIVELY at
    // 38,160 seats (the ranking's *Removed from the code* table).
    Gene { tag: "chokepoint-garrison", field: "chokepoint_garrison", kind: Kind::OptIn, enable: AdvancedAi::enable_chokepoint_garrison, disable: AdvancedAi::disable_chokepoint_garrison },
    // `strategic_government` chooses from a hand-written priority list per
    // lane, and a government missing from that list is invisible even when the
    // empire already owns its civic. Live King seat 2026-08-26 (run
    // `civvis-20260826T112920Z`): Corporate Libertarianism -- ten policy slots
    // -- was held from turn 222 and the seat played Classical Republic's four
    // to the end, because no lane list names it. Six of the thirteen
    // governments in `data/governments.json` appear in no Diplomacy or Culture
    // list at all. The lists rank comparable governments; they were never
    // meant to cap capacity.
    Gene { tag: "government-capacity-fallback", field: "government_capacity_fallback", kind: Kind::OptIn, enable: AdvancedAi::enable_government_capacity_fallback, disable: AdvancedAi::disable_government_capacity_fallback },
    // Version one of the ladder retires the moment any tier-2 gate civic
    // lands and refuses to climb past half the clock. The live King seat
    // (`civvis-20260826T112920Z`, 2026-08-26) shows which half of that is
    // binding: it reached NO tier-2 gate in 248 turns, so the retirement
    // clause never fired, while the gate civics that carry real policy
    // capacity all sit past turn 125 at Online speed. Version two ranks every
    // government whose gate it does not own and whose slots beat the one it is
    // playing, takes the cheapest such gate, and holds the window open to
    // three quarters of the clock for as long as a living major plays a
    // government with more slots than ours.
    Gene { tag: "government-ladder-2", field: "government_ladder_2", kind: Kind::OptIn, enable: AdvancedAi::enable_government_ladder_2, disable: AdvancedAi::disable_government_ladder_2 },
    // An explicit `victory_target` is a set of hard refusals, not a
    // preference: Great Work buildings score `-10_000` off the Culture lane,
    // space-race projects `-10_000` off the Science lane, the wonder gate
    // opens for Culture and Score alone, and `culture_spending` -- the only
    // Faith sink a religion-less empire has -- is dispatched on the Culture
    // lane only. Live King seat `civvis-20260826T112920Z`, 2026-08-26: 248
    // turns of `--victory diplomatic` at 2 diplomatic points against the
    // leader's 19, ending with no Museum in twelve cities, a Spaceport
    // finished at turn 225 with zero launches, 6,329 unspendable Faith, seven
    // wonders to the leader's thirteen, and a 448-point loss on score.
    Gene { tag: "lane-release-when-hopeless", field: "lane_release_when_hopeless", kind: Kind::OptIn, enable: AdvancedAi::enable_lane_release_when_hopeless, disable: AdvancedAi::disable_lane_release_when_hopeless },
    // Every solvency guard in the agent runs AFTER the declaration:
    // `live_war_economy_requires_recovery` reprices production, the
    // `maintenance_emergency` arm swaps a policy card, `war_treasury_floor`
    // reserves upgrade gold. Live King seat `civvis-20260826T112920Z`,
    // 2026-08-26: 25 Gold at -11 a turn at turn 100, an elective declaration
    // on the Maori at turn 110 (`source: civvis`, twenty-two turns after
    // accepting peace with them), fifty consecutive turns at a zero treasury,
    // military power 218 -> 30 as unpaid units disbanded, and a bankruptcy
    // amenity penalty of 18 across nine cities. This asks the same reserve
    // question one turn earlier, where the answer can still prevent the war.
    Gene { tag: "war-needs-a-treasury", field: "war_needs_a_treasury", kind: Kind::OptIn, enable: AdvancedAi::enable_war_needs_a_treasury, disable: AdvancedAi::disable_war_needs_a_treasury },
    // The peace desk's fatigue clause is written `!appointed_objective &&
    // fatigued && ...`, so an appointed campaign that never lands is a
    // permanent exemption from peace. Live King seat
    // `civvis-20260826T112920Z`, 2026-08-26: 172 of 248 turns at war with the
    // Maori behind one objective appointed at turn 100 and never taken, while
    // an air surge stood appointed against a third empire at a zero treasury.
    // Every peace the seat did ask for -- four of four -- was accepted.
    Gene { tag: "peace-when-the-war-does-not-pay", field: "peace_when_war_does_not_pay", kind: Kind::OptIn, enable: AdvancedAi::enable_peace_when_war_does_not_pay, disable: AdvancedAi::disable_peace_when_war_does_not_pay },
    // `assess` sizes the city target from a land census and never asks
    // whether that many sites exist; every settler gate downstream reads the
    // target. Live King seat `civvis-20260826T112920Z`, 2026-08-26: target
    // sixteen, twelve cities, **168 idle settler-turns**, five Settlers parked
    // from turn 180 to turn 230 with nowhere to walk, and the two sites that
    // were founded late scored 39.1 and 47.8 against the capital's 186.2.
    Gene { tag: "city-target-meets-the-map", field: "city_target_meets_the_map", kind: Kind::OptIn, enable: AdvancedAi::enable_city_target_meets_the_map, disable: AdvancedAi::disable_city_target_meets_the_map },
    // The Congress ballot is sized from `plan.strategy`, the posture `assess`
    // chose this turn, while the lane the seat plays lives in
    // `victory_target`. They disagree most of the time: live King seat
    // `civvis-20260826T112920Z` was assigned Diplomacy for all 248 turns and
    // held a Diplomacy posture on 66 of them against Expansion's 96 and
    // Recovery's 80, so it cast ONE vote on thirteen of twenty-five ballots
    // while holding 74-223 Favor at `spent: 0`, and ended with 238 Favor
    // banked and 2 Diplomatic Victory Points against the leader's 19.
    Gene { tag: "lane-votes-its-favor", field: "lane_votes_its_favor", kind: Kind::OptIn, enable: AdvancedAi::enable_lane_votes_its_favor, disable: AdvancedAi::disable_lane_votes_its_favor },
    // `pursue_religion` already discards the prize for a non-Religion lane,
    // but `skip_prophet_race` -- the reservation that stops the empire paying
    // for the race -- needs the `skip-the-prophet-race` family, which a stock
    // seat does not carry. Unlike that family's version 1, which was a prior,
    // measured -12 pp when it forced non-founding and left the code on
    // 2026-09-09, this reads the board: `religions_founded()` has
    // reached `max_religions()` and none of them is ours, so no prophet this
    // empire recruits can found anything. Live King seat
    // `civvis-20260826T112920Z`: four religions on a Small map capped at
    // four, none of them Rome's, and the seat still finished holding a Holy
    // Site, 228 Prophet points, two Missionaries and 6,329 unspendable Faith.
    Gene { tag: "religion-race-is-closed", field: "religion_race_is_closed", kind: Kind::OptIn, enable: AdvancedAi::enable_religion_race_is_closed, disable: AdvancedAi::disable_religion_race_is_closed },
    // `governor_priority` is keyed on the grand strategy alone and ranks
    // Moksha sixth of seven under Expansion and Recovery and seventh under
    // Diplomacy. For an empire that founded no religion that is backwards:
    // Moksha's `citadel_of_god` is the ONLY thing in the ruleset that stops a
    // foreign faith taking its cities -- `RemoveHeresy` needs an Inquisitor
    // that a religionless empire can never launch, a defensive Missionary
    // needs a faith to spread, `CondemnHeretic` needs a war, and `do_spread`
    // has no target-side gate at all. Live King seat
    // `civvis-20260826T112920Z`: no religion, eleven of twelve cities ended
    // under the score leader's faith paying that rival two points each, and
    // the fifteen governor titles it spent went to Amani, Victor, Pingala and
    // Reyna -- the top four of those same lists. The native screen carries the
    // same regime: own cities under a foreign faith at the end, 1.9 of 5.9.
    Gene { tag: "moksha-defends-the-faithless", field: "moksha_defends_the_faithless", kind: Kind::OptIn, enable: AdvancedAi::enable_moksha_defends_the_faithless, disable: AdvancedAi::disable_moksha_defends_the_faithless },
    // The ladder abandons a King game without three cities by turn 32 and that
    // rule fires on 39 of 87 King games -- the rung's dominant failure, ahead
    // of anything in the score gap. It is not production and it is not sites:
    // the second city lands at a median turn 18 whether the game lives or
    // dies, and across the 33 opening deaths of 2026-08-26 THIRTY still had a
    // settler alive at the abandon, TWENTY of them waiting for a guard in the
    // final five turns. `stacked_escort_pace` bounds that wait at
    // `STACKED_ESCORT_PATIENCE`, but writes the bound as `waited > PATIENCE &&
    // !unstacked_settler_step_is_capturable(..)`, so any visible hostile near
    // the next step suspends the ceiling -- and in the opening that is the
    // weather, not an exception: 1,083 waits against 458 guard arrivals across
    // those 46 games, one run waiting on 34 distinct turns.
    // HostOnly rather than OptIn because the whole path it sits in is gated by
    // `formationless_settler_escort()` -> `live_formationless_settler_shadow`,
    // itself HostOnly: a native board cannot reach this branch, so the screen
    // cannot price it and an OptIn row here would be dead code. The live
    // ladder measures it directly and at high frequency -- the abandon rule it
    // targets fires on 45% of King games, ~46 of which run a day.
    Gene { tag: "escort-patience-runs-out", field: "escort_patience_runs_out", kind: Kind::HostOnly, enable: AdvancedAi::enable_escort_patience_runs_out, disable: AdvancedAi::disable_escort_patience_runs_out },
    // Version two also buys one under-bought compounding asset ahead of the
    // argmax — the empire's first Builder, then a Monument where a city has
    // none — on `solvency-first-trade-slot`'s measured pattern (+4.65 pp for
    // ONE reserved slot, −2.80 for every slot).
    Gene { tag: "treasury-at-work-2", field: "treasury_at_work_2", kind: Kind::OptIn, enable: AdvancedAi::enable_treasury_at_work_2, disable: AdvancedAi::disable_treasury_at_work_2 },
    // The removed joint search measured its value mostly in ordering: its
    // static seed lost 700 kills on identical damage. The turn's kills are
    // planned once from the engine's arithmetic (no clone), their shooters
    // go first, ranged before the melee finisher, each biased toward its
    // planned target; the exact attack decision is unchanged.
    Gene { tag: "fire-plan", field: "fire_plan", kind: Kind::OptIn, enable: AdvancedAi::enable_fire_plan, disable: AdvancedAi::disable_fire_plan },
    // The doctrine arena's replicated finding: the share of the force up at
    // first contact predicts the swing (r +0.30 on central_position), and
    // the deployed controller arrives over twice the span `basic` does. On
    // an advance no unit ends the turn more than the body's pace plus one
    // closer to the objective than the anchor stood — no stand, every unit
    // spends its movement; the tile beside the line is the line.
    Gene { tag: "close-as-a-body", field: "close_as_a_body", kind: Kind::OptIn, enable: AdvancedAi::enable_close_as_a_body, disable: AdvancedAi::disable_close_as_a_body },
    // The same arena reads the deployed controller's shooters unscreened
    // 25–32 % of their turns against basic's 39–50 %. The arena's own
    // definition of screened — a friend beside the shooter and nearer the
    // enemy — paid to the shooter's tile; the melee side measured −19/seed.
    Gene { tag: "screen-the-shooters", field: "screen_the_shooters", kind: Kind::OptIn, enable: AdvancedAi::enable_screen_the_shooters, disable: AdvancedAi::disable_screen_the_shooters },
    // A settler in the barbarians' hands is plunder to take back — usually
    // our own — not a duplicate to refuse. The second writing: #2075's
    // `civilian-rescue` left in #2509, and the live seat went back to
    // fortifying beside a free settler for twenty turns
    // (civvis-20260826T194422Z). Exempt from the duplicate-settler guard,
    // first among adjacent captures, pursued within four tiles, and the
    // capture crosses to the host as `CAPTURE` — the attack-modifier move
    // #2075's bare `MOVE_TO` never was (65 sent, 0 captures).
    Gene { tag: "barbarian-settler-capture", field: "barbarian_settler_capture", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_barbarian_settler_capture, disable: AdvancedAi::disable_barbarian_settler_capture },
    // `exchange_score` — move ordering, the `military_step` accept, and the
    // force's focus target — reads bare combat strength, so a spearman is
    // priced against a horseman as if the anti-cavalry bonus did not exist
    // and a river crossing costs nothing. `melee_exchange_strengths` and
    // `ranged_strike_strengths` are the engine's own pair, and `do_attack`
    // calls them, so this cannot drift from the fight it will get.
    Gene { tag: "exchange-is-the-engines", field: "exchange_is_the_engines", kind: Kind::OptIn, enable: AdvancedAi::enable_exchange_is_the_engines, disable: AdvancedAi::disable_exchange_is_the_engines },
    // Both threat terms ask what the enemy would do to us on a candidate
    // tile and then price the defender where it is standing NOW, with no
    // tile defence at all — so a unit weighing a hill gets nothing for the
    // hill. `incoming_damage` has always cloned the unit onto the tile
    // first; the movers never learned.
    Gene { tag: "defend-where-you-stand", field: "defend_where_you_stand", kind: Kind::OptIn, enable: AdvancedAi::enable_defend_where_you_stand, disable: AdvancedAi::disable_defend_where_you_stand },
    // `Action::Swap` has been legal, tested and refused correctly in the
    // engine since `do_swap`, and no controller has ever chosen one —
    // `docs/MOVEMENT.md` names this gene as its obvious first use. Today a
    // wounded front-liner is walked away by recovery and the tile it held
    // goes with it; this trades it for the fresh unit behind, in one action.
    Gene { tag: "swap-rotation", field: "swap_rotation", kind: Kind::OptIn, enable: AdvancedAi::enable_swap_rotation, disable: AdvancedAi::disable_swap_rotation },
    // The full modern settlement score pays coastal Housing and a small,
    // half-weighted Harbor adjacency, but never the usable coast itself. The
    // global prefilter and legacy scorer retain a six-point coast credit;
    // this gene restores that scale where a neighbouring `coast` tile can
    // host the Harbor the rules define. Operator request, 2026-08-26. See
    // `advanced/coastal_sites.rs`.
    Gene { tag: "coastal-city-sites", field: "coastal_city_sites", kind: Kind::OptIn, enable: AdvancedAi::enable_coastal_city_sites, disable: AdvancedAi::disable_coastal_city_sites },
    // Version 2 keeps the port-coast baseline and adds the strongest local
    // `coast_resource` adjacency available to a prospective Harbor, so the
    // screen can price the generic coast repair separately from a resource
    // layout refinement.
    Gene { tag: "coastal-city-sites-2", field: "coastal_city_sites_2", kind: Kind::OptIn, enable: AdvancedAi::enable_coastal_city_sites_2, disable: AdvancedAi::disable_coastal_city_sites_2 },
    // `culture-floor` / `gold-income-floor` (2026-08-26): the live King seat
    // `civvis-20260826T184456Z` reached t150 at 46% of the leader with 57
    // culture to the Aztec 183 (Gaul: 180 from ONE city), one wonder to
    // seven, 34 techs to 45, still in Classical Republic, after 44 turns at
    // a treasury of 0 while the engine disbanded the army. Every one of
    // the day's fifteen King runs that reached t100 shows the same shape:
    // culture 16–62 against the best rival's 71–133, ZERO Amphitheatres
    // and ZERO Markets or Lighthouses, one trade route on a capacity of
    // one, six of them bankrupt for 31–73 turns. Three mechanisms in
    // `production_value`: the Great Work veto returns −10,000 for the
    // Amphitheatre (+2 culture, two slots) on every non-Culture seat; the
    // Theatre Square's lane bonus is 0 under Expansion and Recovery, where
    // the seat spends 165 of 184 readings; and nothing prices a gold
    // building or district by the income it is missing — a Market is worth
    // ≈76 under Expansion with the treasury at 0. See
    // `advanced/yield_floors.rs`.
    Gene { tag: "culture-floor", field: "culture_floor", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_floor, disable: AdvancedAi::disable_culture_floor },
    // The gold half: Markets and Lighthouses (a trade route each), any
    // gold-yielding building, and the Commercial Hub or Harbor while fewer
    // than half the cities hold one, priced by the shortfall under two
    // Gold a turn per city.
    Gene { tag: "gold-income-floor", field: "gold_income_floor", kind: Kind::OptIn, enable: AdvancedAi::enable_gold_income_floor, disable: AdvancedAi::disable_gold_income_floor },
    // `early-archers` (operator, 2026-08-26): an Archer for every city, the
    // frontier city first, while the world is Ancient and Classical. The
    // shipped army is sized by bodies (one land unit per city, the Scout
    // counted) and balanced one shooter per melee unit empire-wide, so a
    // one-city empire at its ceiling is refused a third body outright and
    // no city asks for a shooter of its own; Archery itself scores
    // `≈ 8.8` in `tech_value` against a Pottery at 13–17. The gene wants one
    // range-two land shooter per city, lifts the ceiling veto for a missing
    // one the way the contact window does for a Scout, pays a frontier city
    // with no shooter on or beside it the Walls credit on top, and chases
    // Archery until a city can train one. Closes with the first Medieval
    // technology. See `advanced/early_archers.rs`.
    Gene { tag: "early-archers", field: "early_archers", kind: Kind::OptIn, enable: AdvancedAi::enable_early_archers, disable: AdvancedAi::disable_early_archers },
    // `capture-go-or-stand-down` (operator, 2026-08-27, "decisions are slow to
    // be carried out or forgotten"): the commitment ledger read 263 conquest
    // decisions → 10 captures over 8 deployment maps, with nobody of ours
    // within three hexes of the objective on a third of the turns it was
    // held. A declared objective nobody has gone to for six consecutive
    // turns is stood down explicitly — excluded from the ranking for twenty
    // turns, strategy re-assessed now. See `docs/COMMITMENTS.md`.
    Gene { tag: "capture-go-or-stand-down", field: "capture_go_or_stand_down", kind: Kind::OptIn, enable: AdvancedAi::enable_capture_go_or_stand_down, disable: AdvancedAi::disable_capture_go_or_stand_down },
    // Version 2 (2026-08-28): the ledger's split of the 182 failed conquest
    // decisions on eight maps read 137 with bodies at the objective throughout
    // — the army was there and never took the city. A siege that has not
    // pushed the city to a new low for six stalled readings is stood down the
    // same way. One version of the family plays.
    Gene { tag: "capture-go-or-stand-down-2", field: "capture_go_or_stand_down_2", kind: Kind::OptIn, enable: AdvancedAi::enable_capture_go_or_stand_down_2, disable: AdvancedAi::disable_capture_go_or_stand_down_2 },
    // `commitment-patience` (operator, 2026-08-27, the follow-up): the ledger
    // read 2,684 civilian-turns frozen with a hostile within two, 1,713
    // Builder-turns holding a pin never walked to, and 150 of 309 settler
    // retargets after the walk had started — the threat drop reasons turn a
    // passing raider into a whole new walk. A target now survives a threat
    // (the unit holds or retreats as before) and is retired only after three
    // consecutive forgotten turns, parked for the hysteresis window. See
    // `docs/COMMITMENTS.md` §8.
    Gene { tag: "commitment-patience", field: "commitment_patience", kind: Kind::OptIn, enable: AdvancedAi::enable_commitment_patience, disable: AdvancedAi::disable_commitment_patience },
    // `relief-column-marches` / `threatened-city-reserve` (operator,
    // 2026-08-27): the live King seat `civvis-20260827T113726Z` lost
    // Aquileia (pop 15, walled) on t164 to a Chinese stack of seven while
    // holding 2.5× China's military. Its main army — seven units, 1.58 local
    // strength against the besiegers, objective the besieger's own hex —
    // logged "will hold — held back to cover a threat" on every frame from
    // t161 and stood nine hexes west, because `relieving` was
    // `plan.threatened_city.is_some()` for every group in the empire and a
    // Hold's mover target is the group's own centroid; the weak southern
    // group of three collapsed onto ITS centroid, away from the city. The
    // first gene restores #354's reach test (pruned by #1194) and adds the
    // march: a group beyond `THREAT_RELIEF_RADIUS` advances on the siege when
    // locally superior, holds at the city when not, and while a city is
    // threatened focuses only on combatants (the t160 army sat in "Engage"
    // against an Apostle it declined to strike).
    Gene { tag: "relief-column-marches", field: "relief_column_marches", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_relief_column_marches, disable: AdvancedAi::disable_relief_column_marches },
    // The treasury half: the same seat bought a Water Mill in Rome at t160
    // (399 Gold, Aquileia named under threat, a Line Infantry at 360) and a
    // Market in Aquileia itself at t162 with the walls half down, and had 29
    // Gold on t163 when the emergency purchase first became legal. While a
    // city is threatened or bleeding, both Gold buyers keep one emergency
    // defender's price back.
    Gene { tag: "threatened-city-reserve", field: "threatened_city_reserve", kind: Kind::Repair(Axis::War), enable: AdvancedAi::enable_threatened_city_reserve, disable: AdvancedAi::disable_threatened_city_reserve },
    // A nearly full capital landmass makes unexplored water an expansion
    // frontier: keep one sea scout and favor water that opens a known foreign
    // landfall, while the ordinary naval-recon policy stays unchanged.
    Gene { tag: "island-exploration", field: "island_exploration", kind: Kind::OptIn, enable: AdvancedAi::enable_island_exploration, disable: AdvancedAi::disable_island_exploration },
    // A discovered foreign landfall is time-sensitive. Once the capital's
    // connected land has two or fewer independent city sites remaining, send
    // a Settler to the nearest viable one before spending its last local room.
    Gene { tag: "overseas-settlement", field: "overseas_settlement", kind: Kind::OptIn, enable: AdvancedAi::enable_overseas_settlement, disable: AdvancedAi::disable_overseas_settlement },
    // `settler-never-idles` (operator, 2026-08-27): a Settler always has
    // somewhere to go. `advanced_settler_step` held a Settler on more than a
    // dozen branches — a Loyalty forecast, a fog guess, a safe-step guard, a
    // guard that has not come — and when every preferred site was refused it
    // held outright, with each refusal retired for thirty turns so the
    // refusals compounded. On the live seat's genome a native census read
    // 87% of settler-turns idle and 33% idle on an own city tile. The gene
    // asks two wider questions on exhaustion (the ranking with the guesses
    // set aside, then any legal site nearest first), founds where it stands
    // when nothing is reachable, and after `SETTLER_IDLE_PATIENCE` idle turns
    // marches on the exact-reach rule alone. See
    // `advanced/settler_never_idles.rs`.
    Gene { tag: "settler-never-idles", field: "settler_never_idles", kind: Kind::OptIn, enable: AdvancedAi::enable_settler_never_idles, disable: AdvancedAi::disable_settler_never_idles },
    // ⚠ 2026-08-28: the live seat lost twenty-four settlers in ten runs. Six
    // went to barbarian SCOUTS, which every capture model exempted on the
    // claim that Firaxis' scouts neither attack nor capture — run
    // civvis-20260828T122324Z shows one scout standing on our captured
    // settler and taking three more. Host-only: the native barbarian seat's
    // recon really cannot capture, so no screen can price this.
    Gene { tag: "live-barbarian-scouts-capture", field: "live_barbarian_scouts_capture", kind: Kind::HostOnly, enable: AdvancedAi::enable_live_barbarian_scouts_capture, disable: AdvancedAi::disable_live_barbarian_scouts_capture },
    // The other eighteen: eleven walked to a site beside a nest that had
    // already taken a settler (dead sites were per settler and six turns
    // long), six marched alone after "no visible hostile within 8 tiles"
    // beside a known camp, one held still beside a skirmisher two tiles from
    // a full-health archer. Every settler lost on the live seat is now a
    // reconstructed case and a fix (operator rule, 2026-08-28). See
    // `advanced/civilian_safety.rs`.
    Gene { tag: "live-settler-capture-lessons", field: "live_settler_capture_lessons", kind: Kind::HostOnly, enable: AdvancedAi::enable_live_settler_capture_lessons, disable: AdvancedAi::disable_live_settler_capture_lessons },
    // The host refuses ~14% of MOVE_TO orders as `did_not_move` with no
    // destination on the refusal event, so the same refused move was re-issued
    // for up to eleven straight turns (a settler frozen four turns at
    // (19,10) in run civvis-20260830T095742Z was captured on t47). The proof
    // is an issued step the next turn's board shows untaken — impossible in
    // the simulator, where every move applies, so no screen can price this.
    Gene { tag: "live-move-refusal-break", field: "live_move_refusal_break", kind: Kind::HostOnly, enable: AdvancedAi::enable_live_move_refusal_break, disable: AdvancedAi::disable_live_move_refusal_break },
    // A stranded Settler's wider search refuses a site beside an unresolved
    // rival border and forecasts its nearest-legal tier; see
    // `advanced/settler_never_idles.rs`.
    Gene { tag: "exhaustion-loyalty-guard", field: "exhaustion_loyalty_guard", kind: Kind::OptIn, enable: AdvancedAi::enable_exhaustion_loyalty_guard, disable: AdvancedAi::disable_exhaustion_loyalty_guard },
    // A parked Settler holds the Settler pipeline instead of opening it for a
    // replacement; see `BasicAi::settler_backlog_brake`.
    Gene { tag: "settler-backlog-brake", field: "settler_backlog_brake", kind: Kind::OptIn, enable: AdvancedAi::enable_settler_backlog_brake, disable: AdvancedAi::disable_settler_backlog_brake },
    // V2 keeps V1's full stop at six cities or more, but a parked walker no
    // longer ends the high-leverage three-to-five-city growth wave.
    Gene { tag: "settler-backlog-brake-2", field: "settler_backlog_brake_2", kind: Kind::OptIn, enable: AdvancedAi::enable_settler_backlog_brake_2, disable: AdvancedAi::disable_settler_backlog_brake_2 },
    // A housing-bound city builds its Granary ahead of the argmax; see
    // `advanced_production`.
    Gene { tag: "first-granary-reserve", field: "first_granary_reserve", kind: Kind::OptIn, enable: AdvancedAi::enable_first_granary_reserve, disable: AdvancedAi::disable_first_granary_reserve },
    // Research the tech that connects an owned, unimproved luxury before the
    // lane's beeline resumes; see `unconnected_luxury_tech`.
    Gene { tag: "connect-the-luxury", field: "connect_the_luxury", kind: Kind::OptIn, enable: AdvancedAi::enable_connect_the_luxury, disable: AdvancedAi::disable_connect_the_luxury },
    // Hold four fifths of the strongest bordering major's military power in
    // peacetime by buying the contact city's defender; see
    // `border_parity_purchase`.
    Gene { tag: "border-parity", field: "border_parity", kind: Kind::OptIn, enable: AdvancedAi::enable_border_parity, disable: AdvancedAi::disable_border_parity },
    // A few era points short of a Normal Age, any affordable Great Person is
    // worth its moment; see `era_points_short`.
    Gene { tag: "age-closer", field: "age_closer", kind: Kind::OptIn, enable: AdvancedAi::enable_age_closer, disable: AdvancedAi::disable_age_closer },
    // A boosted, prerequisite-met technology within two turns of science is
    // researched before the lane's beeline resumes; see `boosted_bargain_tech`.
    Gene { tag: "boosted-bargain-first", field: "boosted_bargain_first", kind: Kind::OptIn, enable: AdvancedAi::enable_boosted_bargain_first, disable: AdvancedAi::disable_boosted_bargain_first },
    // Version two is a one-turn, close-value fallback tiebreak and never
    // interrupts a forced lane goal; see `boosted_bargain_tech_2`.
    Gene { tag: "boosted-bargain-first-2", field: "boosted_bargain_first_2", kind: Kind::OptIn, enable: AdvancedAi::enable_boosted_bargain_first_2, disable: AdvancedAi::disable_boosted_bargain_first_2 },
    // A wonder twelve turns from done in a strong city opens the live race
    // without the ordinary guards; see `wonder_bargain_city`.
    Gene { tag: "cheapest-wonder-first", field: "cheapest_wonder_first", kind: Kind::OptIn, enable: AdvancedAi::enable_cheapest_wonder_first, disable: AdvancedAi::disable_cheapest_wonder_first },
    // Version two of border-parity: produce the defender when it cannot be
    // bought; see `border_parity_target`.
    Gene { tag: "border-parity-2", field: "border_parity_2", kind: Kind::OptIn, enable: AdvancedAi::enable_border_parity_2, disable: AdvancedAi::disable_border_parity_2 },
    Gene { tag: "first-district-first", field: "first_district_first", kind: Kind::OptIn, enable: AdvancedAi::enable_first_district_first, disable: AdvancedAi::disable_first_district_first },
    Gene { tag: "walls-after-districts", field: "walls_after_districts", kind: Kind::OptIn, enable: AdvancedAi::enable_walls_after_districts, disable: AdvancedAi::disable_walls_after_districts },
    // ⚠ THE HOSTILE LIST IS VISIBLE-ONLY AND THE SETTLERS DIE TO WHAT IS NOT
    // ON IT. Twenty-eight real settler losses over eleven live King runs
    // (2026-08-29): TEN walked into a hostile with none visible within three
    // tiles on the previous turn's state, eight were captured while parked
    // waiting for a guard, six moved inside a visible hostile's reach
    // unescorted, two were zone-of-control pinned, and TWO were taken by Free
    // Cities units (player 62), which `barbarian_reach` ignored outright
    // because it early-returned on `g.barb_pid` and skipped every unit whose
    // owner was not the Barbarian player. The envelope now counts every
    // at-war owner, and keeps pricing a hostile it has actually seen for
    // `HOSTILE_MEMORY_TURNS` after it walks back into the fog — projected
    // with `wdisk` from the last seen tile, padded by the turns since, never
    // from where the unit really is. See `advanced/civilian_safety.rs`.
    Gene { tag: "hostile-memory", field: "hostile_memory", kind: Kind::OptIn, enable: AdvancedAi::enable_hostile_memory, disable: AdvancedAi::disable_hostile_memory },
    // The other half of the same twenty-eight: eight settlers were captured
    // while PARKED waiting for a guard. `stacked_escort_pace` bounds that
    // wait at `STACKED_ESCORT_PATIENCE` = 2 turns and then suspends the bound
    // whenever `unstacked_settler_step_is_capturable` is true — the one
    // predicate in the wait that reads the visible frame alone, which in the
    // opening is the weather rather than the exception. Its fallback then
    // fortifies a settler bare on open ground on `risk > 0.0`, so a zero
    // reading (nothing VISIBLE can reach it) is treated as quiet ground when
    // it is just as often an empty vision frame — the march itself prices the
    // same step against `SETTLER_STEP_RISK_LIMIT` = 30. With the gene on the
    // cap releases on schedule and an unstacked settler already outside its
    // own city marches instead of standing still.
    // ⚠ OptIn rather than HostOnly, unlike `escort-patience-runs-out` above,
    // because the operator arms it as a labelled live arm (`--with`, which
    // only a held-off opt-in or a ledger-held live treatment can seat) rather
    // than shipping it on with the live universe. The path it sits in is
    // still gated by `formationless_settler_escort()` ->
    // `live_formationless_settler_shadow`, so a native screen cannot price it
    // and it carries a fire waiver saying exactly that; the live ladder
    // measures it directly, and the abandon rule it targets fires on 45% of
    // King games.
    Gene { tag: "escort-cap-holds", field: "escort_cap_holds", kind: Kind::OptIn, enable: AdvancedAi::enable_escort_cap_holds, disable: AdvancedAi::disable_escort_cap_holds },
    // The score gap on the live seat is a RESEARCH gap, and at FIXED city
    // count science goes as pop^1.21 — so a city only helps the science lane
    // if it is founded early enough to mature into that super-linear term.
    // Under the gene, until standard turn `SCIENCE_EXPANSION_UNTIL_TURN` =
    // 188 (~t125 Online), the science lane's land grab widens from
    // `LAND_GRAB_CITY_CEILING` = 16 to `SCIENCE_EXPANSION_CITY_CEILING` = 24
    // AND the Science contract's `SCIENCE_CITY_TARGET_CAP` = 8 — shipped
    // after this idea was written — is deferred; when the window closes both
    // revert and the empire grows what it holds. Reaches the board only
    // through `desired_cities` on the Science target — which #2824 made the
    // deployed lane — so it is the standing counter-hypothesis to the cap:
    // cap early and grow, versus widen early then grow.
    // Written for the live seat on 2026-08-19 (three patched games, one
    // stock: too small a read to ship on, so it ships OFF for the screen to
    // price). Carries a fire waiver: its single-gene probe is queued behind
    // the 08-28 operator halt on tournaments while this machine runs live
    // verification. Appended at the END so a running screen keeps its
    // positional genome.
    Gene { tag: "science-expansion-phase", field: "science_expansion_phase", kind: Kind::OptIn, enable: AdvancedAi::enable_science_expansion_phase, disable: AdvancedAi::disable_science_expansion_phase },
    Gene { tag: "first-luxury-first", field: "first_luxury_first", kind: Kind::OptIn, enable: AdvancedAi::enable_first_luxury_first, disable: AdvancedAi::disable_first_luxury_first },
    // Appended at the END so a running screen keeps its positional genome.
    Gene { tag: "science-opening-band", field: "science_opening_band", kind: Kind::OptIn, enable: AdvancedAi::enable_science_opening_band, disable: AdvancedAi::disable_science_opening_band },
    // Version 2 keeps the original science-drive phenotype and tournament
    // evidence intact, while pricing the continuation planner as its own
    // family member: meaningful adaptive leads, legal pads, research funnel,
    // and a live launch-chain estimate. Appended at the END so a running
    // screen keeps its positional genome.
    Gene { tag: "science-victory-drive-2", field: "science_victory_drive_2", kind: Kind::OptIn, enable: AdvancedAi::enable_science_victory_drive_2, disable: AdvancedAi::disable_science_victory_drive_2 },
    // A capital at population two can legally begin a Settler, yet the
    // ordinary production ranking may spend its newly empty queue on an
    // Archer or filler instead. Once its whole queue drains, reserve that
    // one next build for a Settler; repairs, emergencies, war, the city
    // target, the normal deadline, and the practical-site gate still decide
    // whether the reservation is allowed. See `BasicAi::pick_item`.
    // Appended at the END so a running screen keeps its positional genome.
    Gene { tag: "capital-settler-after-completion", field: "capital_settler_after_completion", kind: Kind::OptIn, enable: AdvancedAi::enable_capital_settler_after_completion, disable: AdvancedAi::disable_capital_settler_after_completion },
    // Opening project restraint is intentionally an opt-in while the
    // single-gene screen determines whether its production reallocation
    // improves the live universe. Appended at the END to preserve any
    // running screen's positional genome.
    Gene { tag: "early-project-restraint", field: "early_project_restraint", kind: Kind::OptIn, enable: AdvancedAi::enable_early_project_restraint, disable: AdvancedAi::disable_early_project_restraint },
    // `settler-site-gate` (live autopsy, 2026-09-01): a city starts a Settler
    // only while an acceptable, unclaimed site worth founding exists for it.
    // Run 182050Z held 5–6 cities from t45 to t105 with 2–4 Settlers alive:
    // one walked 37 orders to 31 targets worth 14–24 and never founded, two
    // were lost on the road, and three cities were building more at once —
    // the arm paid `920 + 4 × site` for ANY site within eleven tiles. The gate
    // drops the sites the walker would refuse, counts seats at settlement
    // spacing net of the targets live Settlers hold, and vetoes a Settler
    // unless a free seat worth the floor remains. See
    // `advanced/settler_site_gate.rs`.
    Gene { tag: "settler-site-gate", field: "settler_site_gate", kind: Kind::OptIn, enable: AdvancedAi::enable_settler_site_gate, disable: AdvancedAi::disable_settler_site_gate },
    // `settler-target-floor` (live autopsy, 2026-09-01): a Settler is never
    // sent to a site not worth the walk. Run 182050Z changed settler targets
    // on 61 of 100 marching turns; once the four-tile ring was empty, the
    // (since culled) first rapid-expansion version took the global best with
    // no premium and no floor and marched Settlers 14–18 tiles to sites worth −35.0, −4.1 and
    // 17.7 (founded sites: 96–140); two were lost on those roads. Candidates
    // are charged the walk beyond eight tiles at the extra-travel price and
    // must clear a floor of 10 to be a target, in the ranked and the
    // exhaustion search alike. See `advanced/settler_target_floor.rs`.
    Gene { tag: "settler-target-floor", field: "settler_target_floor", kind: Kind::OptIn, enable: AdvancedAi::enable_settler_target_floor, disable: AdvancedAi::disable_settler_target_floor },
    Gene { tag: "spaceport-surplus-veto", field: "spaceport_surplus_veto", kind: Kind::OptIn, enable: AdvancedAi::enable_spaceport_surplus_veto, disable: AdvancedAi::disable_spaceport_surplus_veto },
    Gene { tag: "district-planning-3", field: "district_planning_3", kind: Kind::OptIn, enable: AdvancedAi::enable_district_planning_3, disable: AdvancedAi::disable_district_planning_3 },
    Gene { tag: "air-surge-2", field: "air_surge_2", kind: Kind::OptIn, enable: AdvancedAi::enable_air_surge_2, disable: AdvancedAi::disable_air_surge_2 },
    // `commitment-owner-acts` (operator, 2026-08-27, "decisions are slow to
    // be carried out or forgotten"; 2026-09-01): the commitment ledger's
    // largest open class at the deployment genome is the owner that skips its
    // turn — a settle or improve decision open, the unit alive with movement,
    // and no order issued. After the unit pass, every such owner gets the
    // commitment's own next step (found, improve, or the route step toward the
    // target when no hostile can reach it) or the decision is released with a
    // recorded reason — an illegal step, or a tile inside a hostile's reach,
    // where the civilian-safety flee keeps priority. Appended at the END so a
    // running screen keeps its positional genome. See `docs/COMMITMENTS.md` §8.
    Gene { tag: "commitment-owner-acts", field: "commitment_owner_acts", kind: Kind::OptIn, enable: AdvancedAi::enable_commitment_owner_acts, disable: AdvancedAi::disable_commitment_owner_acts },
    // Appended at the END, above the markers, so a running screen keeps its
    // positional genome. The 2026-09-01 Emperor foundations: the Campus
    // through the Expansion plan, the trade network, the Industrial chain.
    Gene { tag: "campus-through-expansion", field: "campus_through_expansion", kind: Kind::OptIn, enable: AdvancedAi::enable_campus_through_expansion, disable: AdvancedAi::disable_campus_through_expansion },
    Gene { tag: "trade-route-network", field: "trade_route_network", kind: Kind::OptIn, enable: AdvancedAi::enable_trade_route_network, disable: AdvancedAi::disable_trade_route_network },
    Gene { tag: "industrial-chain-debt", field: "industrial_chain_debt", kind: Kind::OptIn, enable: AdvancedAi::enable_industrial_chain_debt, disable: AdvancedAi::disable_industrial_chain_debt },
    // Version 2 replaces v1's unconditional withdrawal with an observed,
    // last-call forecast: every remaining religion slot must have an active
    // rival projected to claim the current Prophet soon. Appended so the
    // published positional genome is unchanged.
    Gene { tag: "skip-the-prophet-race-2", field: "skip_the_prophet_race_2", kind: Kind::OptIn, enable: AdvancedAi::enable_skip_the_prophet_race_2, disable: AdvancedAi::disable_skip_the_prophet_race_2 },
    // `siege-preempts-the-queue` (2026-09-01): a raider within three tiles of a
    // city is answered before anything else is built — a queue holding a
    // Settler switches to the ring's unit answer, a city with no defender at
    // all buys it, and a Scout is not a defender. The live bridge also uses
    // this operator-armed flag to expose the existing major-war city handoff
    // for a named battlefront threat; the handoff runs before same-turn peace
    // can clear the planning clone's war state. Live run
    // civvis-20260901T193130Z: one city at t49, two Settlers pinned on the
    // capital tile for 14 and 7 turns by a Slinger adjacent to it, no military
    // unit at all t29–t35, 155–198 Gold banked. OptIn like `settler-site-gate`:
    // the operator arms it as a labelled live arm; the native screen prices
    // it. See `advanced/siege_response.rs`.
    Gene { tag: "siege-preempts-the-queue", field: "siege_preempts_the_queue", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_preempts_the_queue, disable: AdvancedAi::disable_siege_preempts_the_queue },
    // `guard-breaks-the-pin` (2026-09-01): the guard standing on its Settler's
    // tile strikes the raider whose zone of control pins the pair when the
    // trade is worth it, instead of fortifying beside it turn after turn (the
    // same run: "Guard stands with its settler" t38–t45 while the Settler
    // refused every step). HostOnly like `escort-patience-runs-out`: the path
    // is gated by `live_formationless_settler_shadow`, so a native board never
    // reaches it. See `advanced/siege_response.rs`.
    Gene { tag: "guard-breaks-the-pin", field: "guard_breaks_the_pin", kind: Kind::HostOnly, enable: AdvancedAi::enable_guard_breaks_the_pin, disable: AdvancedAi::disable_guard_breaks_the_pin },
    // Reach the measured five-city opening band with a bounded pipeline and
    // empty-capital reservation, refuse unworthy or already-claimed sites,
    // and leave ordinary queues, pantheons, site ranking and peace intact.
    Gene { tag: "rapid-city-expansion-2", field: "rapid_city_expansion_2", kind: Kind::OptIn, enable: AdvancedAi::enable_rapid_city_expansion_2, disable: AdvancedAi::disable_rapid_city_expansion_2 },
    // Version 3 of `naval-recon`: yield an idle queue to a simultaneously
    // missing land scout before reserving its one peacetime sea hull.
    Gene { tag: "naval-recon-3", field: "naval_recon_3", kind: Kind::OptIn, enable: AdvancedAi::enable_naval_recon_3, disable: AdvancedAi::disable_naval_recon_3 },
    // Repair only a persistent two-turn stall, accept only civilian work above
    // the hard veto, and ignore repeated observations of the same host turn.
    Gene { tag: "never-an-empty-queue-3", field: "never_an_empty_queue_3", kind: Kind::OptIn, enable: AdvancedAi::enable_never_an_empty_queue_3, disable: AdvancedAi::disable_never_an_empty_queue_3 },
    // V2 waits for a Eureka only when its final trigger is already queued and
    // the node is within two turns. The broad v1 remains measurable.
    Gene { tag: "boost-wait-research-2", field: "boost_wait_research_2", kind: Kind::OptIn, enable: AdvancedAi::enable_boost_wait_research_2, disable: AdvancedAi::disable_boost_wait_research_2 },
    // Version 2 of `diplomatic-lane-forecast`: Favor alone is not a race;
    // require an earned foothold and cap the Congress projection below a real opening.
    Gene { tag: "diplomatic-lane-forecast-2", field: "diplomatic_lane_forecast_2", kind: Kind::OptIn, enable: AdvancedAi::enable_diplomatic_lane_forecast_2, disable: AdvancedAi::disable_diplomatic_lane_forecast_2 },
    // Appended at the END so a running screen keeps its positional genome.
    // 461 of our units died in combat across the 32 live runs of 2026-08-30..09-01,
    // 408 to barbarians; 352 were at or below 50 HP at the killing blow, 334 had been
    // hit on an earlier turn and left in reach, 135 were shooters a melee unit walked
    // onto. The recovery withdraws on the mean blow from visible units; this withdraws
    // on the top of the roll, remembers raiders in the fog, and screens shooters.
    // See `advanced/wounded_out_of_reach.rs`.
    Gene { tag: "wounded-out-of-reach", field: "wounded_out_of_reach", kind: Kind::OptIn, enable: AdvancedAi::enable_wounded_out_of_reach, disable: AdvancedAi::disable_wounded_out_of_reach },
    // Version 2 of `coalition-before-war`: court only a credible military
    // partner, spend Envoys only to flip the target's client, and make one
    // joint-war invitation at the ready strike.
    Gene { tag: "coalition-before-war-2", field: "coalition_before_war_2", kind: Kind::OptIn, enable: AdvancedAi::enable_coalition_before_war_2, disable: AdvancedAi::disable_coalition_before_war_2 },
    // Version 3 asks only a neighbour already fighting the planned target
    // for a military alliance: a proven second front and an immediate combat
    // bonus, without a speculative joint-war offer or declaration delay.
    Gene { tag: "coalition-before-war-3", field: "coalition_before_war_3", kind: Kind::OptIn, enable: AdvancedAi::enable_coalition_before_war_3, disable: AdvancedAi::disable_coalition_before_war_3 },

    // Forensic of 2026-09-01 over the 08-31 King and 09-01 Emperor live runs
    // (`advanced/settler_walk_deadline.rs`): with every host-only expansion
    // gene live the seat builds its Settlers on schedule and they do not
    // convert — walks of 13–15 turns, a third of Emperor Settlers taken —
    // so a walker past twelve turns founds the best site within reach.
    Gene { tag: "settler-walk-deadline", field: "settler_walk_deadline", kind: Kind::OptIn, enable: AdvancedAi::enable_settler_walk_deadline, disable: AdvancedAi::disable_settler_walk_deadline },
    // `battle-planner` (2026-09-02): the force's turn planned jointly instead
    // of unit by unit — a danger field from the engine's exact pair on a
    // probe of the board, a beam-searched kill sequence (ranged before the
    // melee finisher, kills at 1.15× the hit points, return damage and every
    // end tile's danger priced, three vetoes) replayed on one clone before it
    // lands, and a heal rotation that steps the wounded and the exposed to a
    // tile nothing can strike. Replaces `prioritize_immediate_kills` and
    // `fire-plan` at their seam; the ladder leaves the planned units alone.
    // Priced on the arena first. See `advanced/battle_planner.rs`.
    Gene { tag: "battle-planner", field: "battle_planner", kind: Kind::OptIn, enable: AdvancedAi::enable_battle_planner, disable: AdvancedAi::disable_battle_planner },

    // Version one expands every boost trigger across research, production,
    // Builders, and combat. It remains the broad family control for direct
    // comparison with the selective successor below.
    Gene { tag: "chase-every-boost", field: "chase_every_boost", kind: Kind::OptIn, enable: AdvancedAi::enable_chase_every_boost, disable: AdvancedAi::disable_chase_every_boost },
    // Version two pays only an active study's final city-production trigger,
    // and only when the city can complete it before that study. It does not
    // steer research, Builder actions, or combat; one family version plays.
    Gene { tag: "chase-every-boost-2", field: "chase_every_boost_2", kind: Kind::OptIn, enable: AdvancedAi::enable_chase_every_boost_2, disable: AdvancedAi::disable_chase_every_boost_2 },
    // Replace v1's global opening timer with a concrete, currently buildable
    // first-building debt in the project's own district. Lane-aligned points
    // and immediate race swings stay live; only off-lane churn waits.
    Gene { tag: "early-project-restraint-2", field: "early_project_restraint_2", kind: Kind::OptIn, enable: AdvancedAi::enable_early_project_restraint_2, disable: AdvancedAi::disable_early_project_restraint_2 },
    // Version 2 of `battle-planner` (2026-09-02): the positions plan joins the
    // kill plan and the heal rotation — slots laid against the enemy contact
    // and the objective, a minimum-cost assignment with reservations, moves
    // front to rear, pacing on the approach. One version of the family plays.
    // Priced on the arena against version 1. See
    // `AdvancedAi::enable_battle_planner_2`.
    Gene { tag: "battle-planner-2", field: "battle_planner_2", kind: Kind::OptIn, enable: AdvancedAi::enable_battle_planner_2, disable: AdvancedAi::disable_battle_planner_2 },
    // `siege-train` (2026-09-02): the siege as a state machine per objective
    // city — stage on the 3–5 ring out of the city's strike reach until the
    // strength there meets the bill (defenders within six, city, walls,
    // ×1.25), seal the ring spread-first so `city_under_siege` reads true,
    // siege on the walls then the garrison, shooters on relievers and the
    // open city, melee holding the ring, one reserved taker walking in when
    // the city is within its expected blow. `the_storming` found `advanced`
    // takes the city three times in forty assaults and loses the position on
    // an arrival spread of 10.9 turns; nothing in the tree but the rush's
    // ring seal decided when or how a train closes. See
    // `advanced/siege_train.rs`.
    Gene { tag: "siege-train", field: "siege_train", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_train, disable: AdvancedAi::disable_siege_train },
    // `anvil` (2026-09-02): the threatened city held as a formation — a
    // shooter on the City Center for the garrison bonus and the city strike,
    // melee on the two or three adjacent tiles facing the enemy with the best
    // defence, everyone else within two so the city strike joins their fight,
    // never an empty ring while a hostile is within six, the wounded rotated
    // into the city by swap. Replaces the relief hold point for that group;
    // engages relievers only on a favourable exchange. See
    // `advanced/siege_train.rs`.
    Gene { tag: "anvil", field: "anvil", kind: Kind::OptIn, enable: AdvancedAi::enable_anvil, disable: AdvancedAi::disable_anvil },
    // Version 2 only pays a Builder for a boost it can cash immediately: the
    // final matching improvement for the technology or civic the empire is
    // researching now, capped below the improvement's own value. V1 remains
    // the separately measurable broad future-boost control.
    Gene { tag: "eureka-chasing-builder-2", field: "eureka_chasing_builder_2", kind: Kind::OptIn, enable: AdvancedAi::enable_eureka_chasing_builder_2, disable: AdvancedAi::disable_eureka_chasing_builder_2 },
    // ★★★ APPEND POINTS, SO THAT TWO GENE PRS DO NOT APPEND TO ONE LINE.
    //
    // The registry order is positional, so these all stay after the existing
    // rows: a new tag goes below the marker for its first-letter range. That
    // preserves every existing bit while giving independent new tags distinct
    // insertion lines. `tools/test_treatment_append_points.py` proves the
    // claim by constructing and merging two synthetic Gene-row pull requests.
    // Version 3 of `border-parity`: one local garrison against an actually
    // visible two-body staging group; buy it without touching production.
    Gene { tag: "border-parity-3", field: "border_parity_3", kind: Kind::OptIn, enable: AdvancedAi::enable_border_parity_3, disable: AdvancedAi::disable_border_parity_3 },
    // Version 2 smooths each civilization's majority separately, then reads
    // the least-converted holdout. One enormous converted empire can no longer
    // outweigh several untouched civilizations the victory still requires.
    Gene { tag: "conversion-majority-alarm-2", field: "conversion_majority_alarm_2", kind: Kind::OptIn, enable: AdvancedAi::enable_conversion_majority_alarm_2, disable: AdvancedAi::disable_conversion_majority_alarm_2 },
    // Version 2 enters only after the existing religious-opening rank proves
    // the seat has two cities, a real Holy Site path, and one of the remaining
    // Prophet slots. The four-part commitment still moves as one package.
    Gene { tag: "enter-the-prophet-race-2", field: "enter_the_prophet_race_2", kind: Kind::OptIn, enable: AdvancedAi::enable_enter_the_prophet_race_2, disable: AdvancedAi::disable_enter_the_prophet_race_2 },
    // The generic upgrade pass runs after the purchase pass has spent the
    // treasury, so the army never modernizes: ~3 UPGRADE orders per live
    // game, Heavy Chariot the commonest unit at t150. Upgrade FIRST at the
    // moments that matter (major war, threatened city, barbarian gap, or a
    // one-era breakthrough), veterans first. Default on.
    Gene { tag: "modernize-before-spending", field: "modernize_before_spending", kind: Kind::Production, enable: AdvancedAi::enable_modernize_before_spending, disable: AdvancedAi::disable_modernize_before_spending },
    // A promoted unit withdraws with 10 hp per promotion (max 30) in hand:
    // the withdrawal line, the one-blow test and the lethal-pool retreat all
    // fire while it can still walk. 70% of live losses were already <50 hp.
    Gene { tag: "veterans-withdraw-early", field: "veteran_retreat_margin", kind: Kind::Production, enable: AdvancedAi::enable_veteran_retreat_margin, disable: AdvancedAi::disable_veteran_retreat_margin },
    // `objective-board` (2026-09-02): the army's turn planned from a ranked
    // Objective Board — Defend, Relieve, Siege, Destroy, ClearCamp, Escort,
    // Deter and Recon rows, each valued in hammers with a requirement and a
    // deadline, ranked by value over deadline with an urgent Defend above
    // every offensive row — and served by persistent task forces whose ids
    // survive their members (allocation by contribution per travel turn,
    // hysteresis, never stripping a served row). `force_groups` is built
    // from the forces, so the battle planner, the siege train and the
    // ladder read it unchanged. Replaces the proximity clustering and the
    // posture ladder of `rebuild_force_groups`, whose one empire-wide
    // objective left the second threatened city with nothing. Priced on the
    // arena first. See `advanced/objective_board.rs`.
    Gene { tag: "objective-board", field: "objective_board", kind: Kind::OptIn, enable: AdvancedAi::enable_objective_board, disable: AdvancedAi::disable_objective_board },
    // Who may be a target, when a war is declared and when peace is sued
    // for, read off the Objective Board's own requirements in place of
    // empire-wide power ratios: a rival whose nearest city's Siege bill is
    // over the whole roster is excluded from the target ranking; an
    // elective or campaign declaration waits until that bill is staged on
    // the objective's 3–5 ring with no other major war and every Defend row
    // served; and the `my_power < theirs × 0.62` "outmatched" peace term
    // becomes "no Siege row against them is feasible AND the tide ledger is
    // negative over its window (or an urgent Defend row has gone unserved
    // for three turns)" — a defensive war with a served Defend row is
    // fought, not begged. Every other peace term stands. See
    // `advanced/war_policy.rs`.
    Gene { tag: "war-policy-via-board", field: "war_policy_via_board", kind: Kind::OptIn, enable: AdvancedAi::enable_war_policy_via_board, disable: AdvancedAi::disable_war_policy_via_board },
    // Version three of `battle-planner`: version two plus the siege train's
    // reserved taker left alone by the kill plan, the heal rotation and the
    // positions plan (the Take blow is the siege's own), the host's own
    // strike preview (`Game::host_preview`, a `preview` order answered the
    // frame before) in place of the closed form for a pair it has priced —
    // a blow the host says kills the attacker is vetoed outright — and the
    // top 24 unpriced pairs by closed-form damage published through
    // `wanted_previews()` for `civvis_orders` to ask. Native boards hold no
    // previews, so the arena prices the taker rule alone. One version of the
    // family plays: `enable_battle_planner_3` turns one and two off. See
    // `advanced/battle_planner.rs`.
    Gene { tag: "battle-planner-3", field: "battle_planner_3", kind: Kind::OptIn, enable: AdvancedAi::enable_battle_planner_3, disable: AdvancedAi::disable_battle_planner_3 },
    // Version 3 grants one fatigue reset per enemy city only after a nearby
    // land force is observed reducing its walls or health. Mere arrival no
    // longer reads as progress, and repeated hits cannot postpone peace
    // indefinitely. One family version plays at a time.
    Gene { tag: "siege-is-progress-3", field: "siege_is_progress_3", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_is_progress_3, disable: AdvancedAi::disable_siege_is_progress_3 },
    // Version two keeps v1's strongest current-major comparison but requires
    // that opponent inside the campaign planner's reach. It does not sum weak
    // fronts into extra Recovery; immediate city danger still takes Recovery
    // independently, including city-state pressure. One family version plays.
    Gene { tag: "recovery-reads-the-war-2", field: "recovery_reads_the_war_2", kind: Kind::OptIn, enable: AdvancedAi::enable_recovery_reads_the_war_2, disable: AdvancedAi::disable_recovery_reads_the_war_2 },
    // Version two preserves V1 and adds a roll-top lethal rotation only when
    // the wounded destination is safer and the relief survives the front.
    // Geometry and the joint planner's own rotation policy stay unchanged.
    Gene { tag: "swap-rotation-2", field: "swap_rotation_2", kind: Kind::OptIn, enable: AdvancedAi::enable_swap_rotation_2, disable: AdvancedAi::disable_swap_rotation_2 },
    // Version 2 narrows an already-staged Conquest plan to one nearby,
    // holdable city, then keeps that objective rather than extending a war
    // from an empire-wide army estimate.
    Gene { tag: "city-campaign-2", field: "city_campaign_2", kind: Kind::OptIn, enable: AdvancedAi::enable_city_campaign_2, disable: AdvancedAi::disable_city_campaign_2 },
    // `strike-reach` (2026-09-02): the battle planner's danger field read a
    // hostile's reach off `Game::attack_reach`, whose movement flood writes
    // zero movement into a tile that enters our zone of control — so a melee
    // unit two tiles off, or a shooter one step out of range, read as no
    // danger at all. Measured on the seven live games of 2026-09-02 with
    // the planner on: of 58 units the rotation stood on a tile the field
    // read as zero and that died there anyway, 36 killers were in sight at
    // the start of the turn and 34 of them within one move and a blow. This
    // reads the reach the way the engine resolves the blow (`approach_reach`
    // keeps the movement a zone-of-control stop leaves), and on the
    // mirrored board drops the per-unit line-of-sight test a Civilization VI
    // ranged attack does not make. Priced on the arena beside
    // `battle-planner-2`. See `advanced/battle_planner.rs`.
    Gene { tag: "strike-reach", field: "strike_reach", kind: Kind::OptIn, enable: AdvancedAi::enable_strike_reach, disable: AdvancedAi::disable_strike_reach },
    // `safest-stand` (2026-09-02): the battle planner's heal rotation moved a
    // wounded or exposed unit to the nearest tile the danger field read as
    // zero — and when there was none, skipped the unit in silence, leaving it
    // to the ladder, which twelve times over the seven live games of 2026-09-02
    // attacked with it. The largest row of that day's loss taxonomy (38 of 145)
    // was a unit killed under 50 hp with no rotation line for it. With this
    // on, a unit with no zero-danger tile in reach takes the least dangerous
    // one — a heal tile preferred, its own tile if that is the least — and
    // fortifies there, unless even the least would remove it, when the
    // ladder keeps it for a last blow. An exposed but healthy unit falls back
    // only where the step cuts the danger by the rotation's margin. Priced on
    // the arena beside `battle-planner-2`. See `advanced/battle_planner.rs`.
    Gene { tag: "safest-stand", field: "safest_stand", kind: Kind::OptIn, enable: AdvancedAi::enable_safest_stand, disable: AdvancedAi::disable_safest_stand },
    // `doomed-blow-veto` (2026-09-02): the battle planner leaves every unit
    // with a legal blow it did not spend to the ladder, which prices the blow
    // on its own clone and takes it more often than the plan does — and the
    // ladder's reply price reads the movement flood, not the danger field.
    // Twelve of the 145 losses in the 2026-09-02 taxonomy were a ladder
    // attack by a unit that then stood beside its target and died; a
    // 94-hit-point Pikeman struck beside a Field Cannon and was removed the
    // same enemy turn. With this on, a unit whose EVERY candidate blow would
    // leave it dead next turn — return damage plus the field's danger at the
    // stand at or over its hit points — is not armed: the rotation treats it
    // as exposed and stands it out of reach (or on the least danger under
    // `safest-stand`) and fortifies, and the ladder leaves it alone. A unit
    // with one survivable blow keeps the ladder's freedom. Priced on the
    // arena beside `battle-planner-2`. See `advanced/battle_planner.rs`.
    Gene { tag: "doomed-blow-veto", field: "doomed_blow_veto", kind: Kind::OptIn, enable: AdvancedAi::enable_doomed_blow_veto, disable: AdvancedAi::disable_doomed_blow_veto },
    // Version two of `missionary-last-charge-explores`: a one-charge
    // Missionary searches a continent-scale horizon, ranks distant
    // high-reveal fog, and insists on a route the movement rules permit.
    // That lets its religious closed-border exception carry an expedition
    // across an ocean without guessing at hidden cities. Version one stays
    // intact for its existing screen history; one family version plays at a
    // time. See `advanced/missionary_field.rs`.
    Gene { tag: "missionary-last-charge-explores-2", field: "missionary_last_charge_explores_2", kind: Kind::OptIn, enable: AdvancedAi::enable_missionary_last_charge_explores_2, disable: AdvancedAi::disable_missionary_last_charge_explores_2 },
    // `route-block-is-a-wait` (2026-09-02): `commitment_owners_act` released a
    // settle or improve decision on the FIRST turn `route_step` found no
    // enterable neighbour, dropping the target and parking the site for the
    // hysteresis window. Over 53 live Civ VI runs that one-turn block is 502
    // of 547 releases (92%), and 18% of the settle drops land within two
    // tiles of the site. The gene holds instead, bounded by
    // COMMITMENT_PATIENCE consecutive forgotten turns. Appended at the END,
    // above the markers, so a running screen keeps its positional genome.
    Gene { tag: "route-block-is-a-wait", field: "route_block_is_a_wait", kind: Kind::OptIn, enable: AdvancedAi::enable_route_block_is_a_wait, disable: AdvancedAi::disable_route_block_is_a_wait },
    // `standing-still-is-a-risk` (2026-09-02): the safe-step guard's last
    // resort demanded a neighbour 5.0 risk points safer than the rejected
    // route step and otherwise did not move, never pricing the tile the unit
    // stands on. Over 39 live Civ VI runs that is 527 settler-turns standing
    // still, 13.5 a game — the largest single cause. The gene steps to the
    // safest neighbour that strictly improves on staying. Appended at the
    // END, above the markers, so a running screen keeps its positional genome.
    Gene { tag: "standing-still-is-a-risk", field: "standing_still_is_a_risk", kind: Kind::OptIn, enable: AdvancedAi::enable_standing_still_is_a_risk, disable: AdvancedAi::disable_standing_still_is_a_risk },
    // `detour-keeps-the-site-worth` (2026-09-02): the threat detour takes the
    // best site whose approach is SAFE, not a site of comparable worth. Over
    // 53 live Civ VI runs the median detour is +21% better, but 24% of them
    // give up more than 40% of the deferred site's value (worst -83%). The
    // gene refuses those and keeps the original target. Appended at the END,
    // above the markers, so a running screen keeps its positional genome.
    Gene { tag: "detour-keeps-the-site-worth", field: "detour_keeps_the_site_worth", kind: Kind::OptIn, enable: AdvancedAi::enable_detour_keeps_the_site_worth, disable: AdvancedAi::disable_detour_keeps_the_site_worth },
    // Version two of `wonder-ring-recon`: preserve every V1 trigger, then
    // choose the most revealing pocket goal among those no more than one tile
    // beyond V1's nearest. Information improves without a long detour.
    // Appended above the markers, so a running screen keeps its positional
    // genome.
    Gene { tag: "wonder-ring-recon-2", field: "wonder_ring_recon_2", kind: Kind::OptIn, enable: AdvancedAi::enable_wonder_ring_recon_2, disable: AdvancedAi::disable_wonder_ring_recon_2 },
    // `campus-before-halfway` (2026-09-08): a Science seat's Campus keeps the
    // lane's arm before the halfway clock and keeps asking in every city of
    // four past the coverage cliff. Appended above the markers, so a running
    // screen keeps its positional genome.
    Gene { tag: "campus-before-halfway", field: "campus_before_halfway", kind: Kind::OptIn, enable: AdvancedAi::enable_campus_before_halfway, disable: AdvancedAi::disable_campus_before_halfway },
    // Empire-wide building dividends compete with affordable diplomatic packages.
    Gene { tag: "envoy-building-dividends", field: "envoy_building_dividends", kind: Kind::OptIn, enable: AdvancedAi::enable_envoy_building_dividends, disable: AdvancedAi::disable_envoy_building_dividends },
    // Preserve every positional gene index and leave future append points at the tail.
    Gene { tag: "builder-workforce-recovery", field: "builder_workforce_recovery", kind: Kind::OptIn, enable: AdvancedAi::enable_builder_workforce_recovery, disable: AdvancedAi::disable_builder_workforce_recovery },
    Gene { tag: "culture-building-catchup", field: "culture_building_catchup", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_building_catchup, disable: AdvancedAi::disable_culture_building_catchup },
    Gene { tag: "expansion-best-idle-city", field: "expansion_best_idle_city", kind: Kind::OptIn, enable: AdvancedAi::enable_expansion_best_idle_city, disable: AdvancedAi::disable_expansion_best_idle_city },
    Gene { tag: "research-building-catchup", field: "research_building_catchup", kind: Kind::OptIn, enable: AdvancedAi::enable_research_building_catchup, disable: AdvancedAi::disable_research_building_catchup },
    Gene { tag: "trade-building-before-bankruptcy", field: "trade_building_before_bankruptcy", kind: Kind::OptIn, enable: AdvancedAi::enable_trade_building_before_bankruptcy, disable: AdvancedAi::disable_trade_building_before_bankruptcy },
    Gene { tag: "builder-workforce-recovery-2", field: "builder_workforce_recovery_2", kind: Kind::OptIn, enable: AdvancedAi::enable_builder_workforce_recovery_2, disable: AdvancedAi::disable_builder_workforce_recovery_2 },
    Gene { tag: "culture-building-catchup-2", field: "culture_building_catchup_2", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_building_catchup_2, disable: AdvancedAi::disable_culture_building_catchup_2 },
    Gene { tag: "expansion-best-idle-city-2", field: "expansion_best_idle_city_2", kind: Kind::OptIn, enable: AdvancedAi::enable_expansion_best_idle_city_2, disable: AdvancedAi::disable_expansion_best_idle_city_2 },
    Gene { tag: "research-building-catchup-2", field: "research_building_catchup_2", kind: Kind::OptIn, enable: AdvancedAi::enable_research_building_catchup_2, disable: AdvancedAi::disable_research_building_catchup_2 },
    Gene { tag: "trade-building-before-bankruptcy-2", field: "trade_building_before_bankruptcy_2", kind: Kind::OptIn, enable: AdvancedAi::enable_trade_building_before_bankruptcy_2, disable: AdvancedAi::disable_trade_building_before_bankruptcy_2 },
    // Reprice all strikers after each friendly kill; only a sequence whose
    // surviving enemy replies spare every striker can become the final plan.
    Gene { tag: "doomed-blow-veto-2", field: "doomed_blow_veto_2", kind: Kind::OptIn, enable: AdvancedAi::enable_doomed_blow_veto_2, disable: AdvancedAi::disable_doomed_blow_veto_2 },
    // Version two of `boost-first-research`: the discount scale as a tie-break
    // in the research argmax, among candidates within `BOOST_TIEBREAK_BAND` of
    // the ordinary winner and only after every forced goal has stood down. v1
    // read +0.42 techs at t150 (z +5.6) and -0.48 pp wins on the 2026-09-08
    // screen: more techs, the wrong ones. See `advanced/boost_research.rs`.
    Gene { tag: "boost-first-research-2", field: "boost_first_research_2", kind: Kind::OptIn, enable: AdvancedAi::enable_boost_first_research_2, disable: AdvancedAi::disable_boost_first_research_2 },
    // One safe first-slot Scout, independent of later recon replacement.
    Gene { tag: "scout-first-opening", field: "scout_first_opening", kind: Kind::OptIn, enable: AdvancedAi::enable_scout_first_opening, disable: AdvancedAi::disable_scout_first_opening },
    Gene { tag: "amani-follows-suzerainty", field: "amani_follows_suzerainty", kind: Kind::OptIn, enable: AdvancedAi::enable_amani_follows_suzerainty, disable: AdvancedAi::disable_amani_follows_suzerainty },
    Gene { tag: "liang-follows-builders", field: "liang_follows_builders", kind: Kind::OptIn, enable: AdvancedAi::enable_liang_follows_builders, disable: AdvancedAi::disable_liang_follows_builders },
    Gene { tag: "magnus-follows-settlers", field: "magnus_follows_settlers", kind: Kind::OptIn, enable: AdvancedAi::enable_magnus_follows_settlers, disable: AdvancedAi::disable_magnus_follows_settlers },
    Gene { tag: "pingala-follows-research", field: "pingala_follows_research", kind: Kind::OptIn, enable: AdvancedAi::enable_pingala_follows_research, disable: AdvancedAi::disable_pingala_follows_research },
    Gene { tag: "reyna-follows-revenue", field: "reyna_follows_revenue", kind: Kind::OptIn, enable: AdvancedAi::enable_reyna_follows_revenue, disable: AdvancedAi::disable_reyna_follows_revenue },
    // The culture defence armed at 30 percent of the victory bar instead of
    // 50, no sale of any kind to the threatening rival, and a denunciation.
    // The Emperor ladder lost most games to a rival culture finish at
    // t155-208, one with the 50-percent defence in place. See
    // `advanced/culture_strategy.rs`.
    Gene { tag: "culture-threat-early", field: "culture_threat_early", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_threat_early, disable: AdvancedAi::disable_culture_threat_early },
    // Retain hostile sightings for civilians and a land escort about to embark.
    Gene { tag: "hostile-memory-2", field: "hostile_memory_2", kind: Kind::OptIn, enable: AdvancedAi::enable_hostile_memory_2, disable: AdvancedAi::disable_hostile_memory_2 },
    // Version two also withdraws healthy units exposed to a nominal lethal
    // shot from one recently observed gun; v1 remains the deployed control.
    Gene { tag: "wounded-out-of-reach-2", field: "wounded_out_of_reach_2", kind: Kind::OptIn, enable: AdvancedAi::enable_wounded_out_of_reach_2, disable: AdvancedAi::disable_wounded_out_of_reach_2 },
    // A short, deadlined plan for the Eurekas and Inspirations the beeline is
    // about to walk past: the next six technologies and four civics, a trigger
    // cost table, and at most three cheap side objectives carrying the turn
    // they expire, each a share-of-value premium on the one production or
    // Builder choice that fires it. The live ladder triggers 13-40 percent of
    // tech boosts and 0-26 percent of civic boosts, and `chase-every-boost-2`
    // shows that pricing every reachable trigger instead measures negative.
    // See `advanced/boost_planner.rs`.
    Gene { tag: "boost-planner", field: "boost_planner", kind: Kind::OptIn, enable: AdvancedAi::enable_boost_planner, disable: AdvancedAi::disable_boost_planner },
    // Take a small neighbour's city in the opening. The live seat has never
    // won at Emperor: rivals there take +16% on every yield and a free
    // Settler an era, our combat trades at 0.45 kills per loss, and 234 of
    // 304 unit deaths had no visible threat. See
    // `advanced/early_conquest.rs`.
    Gene { tag: "early-conquest-opening", field: "early_conquest_opening", kind: Kind::OptIn, enable: AdvancedAi::enable_early_conquest_opening, disable: AdvancedAi::disable_early_conquest_opening },
    // `expansion-scales-with-difficulty` (2026-09-09): the measured 4-6 city
    // opening band was read off a King-level field. Above King the rivals take
    // +16/+24/+32 percent of every yield and free Settlers every era, so the
    // target, its deadline, the Settler cadence and the expansion cards scale
    // with the rung. Appended above the markers, so a running screen keeps its
    // positional genome. See `advanced/expansion_scales_with_difficulty.rs`.
    Gene { tag: "expansion-scales-with-difficulty", field: "expansion_scales_with_difficulty", kind: Kind::OptIn, enable: AdvancedAi::enable_expansion_scales_with_difficulty, disable: AdvancedAi::disable_expansion_scales_with_difficulty },
    // Deny a rival the science victory instead of only racing it, rungs 1-2:
    // no new alliance, passage or Great Work to a science threat and a
    // denunciation; one spy posted to the threat's launch city to disrupt
    // the pad. At Emperor the rivals finish the space race at t213-228 while
    // we stand at one to three of four launches; the Immortal and Deity
    // handicaps make speeding our own launch insufficient on its own. See
    // `advanced/science_threat_denial.rs`.
    Gene { tag: "science-threat-denial", field: "science_threat_denial", kind: Kind::OptIn, enable: AdvancedAi::enable_science_threat_denial, disable: AdvancedAi::disable_science_threat_denial },
    // Rungs 3-4 of the denial, priced apart: a two-soldier raid that
    // pillages the pad at war, and the cheapest legal war opened for that
    // raid when the threat is inside DENIAL_WAR_LAUNCH_HORIZON of finishing,
    // we are outside it, and a soldier can walk to the pad. Requires and
    // arms `science-threat-denial`. The first probe of all four rungs as one
    // tag opened 13 wars for 2 pillaged pads (2026-09-09).
    Gene { tag: "science-denial-war", field: "science_denial_war", kind: Kind::OptIn, enable: AdvancedAi::enable_science_denial_war, disable: AdvancedAi::disable_science_denial_war },
    // The stock alliance desk asks for a Research Alliance on any turn, ranks
    // the partner by science, holds the slot for it while Scientific Theory
    // is still short, and pays a premium for the first route to that ally
    // while its level still climbs. At Emperor and above every rival yield
    // carries a +16..+32 percent handicap; an alliance's shared tech boosts
    // and its level-three 10 percent of the ally's science do not. No declared
    // friendship is proposed ahead of it: that cost 3.5 points of score share.
    // See `advanced/research_alliance.rs`.
    Gene { tag: "research-alliance-first", field: "research_alliance_first", kind: Kind::OptIn, enable: AdvancedAi::enable_research_alliance_first, disable: AdvancedAi::disable_research_alliance_first },
    // Appended above the markers, so a running screen keeps its positional
    // gene index and the append points stay free at the tail.
    // The engine has modelled `Feature_Removes` and `Resource_Harvests` the
    // whole time — `builder_operations` offers them and `do_builder_operation`
    // pays them — and no controller has ever asked for one: `chop_woods` and
    // `harvest_resource` appeared nowhere in `src/ai.rs` or `src/ai/advanced/`
    // before this row. `expansion-scales-with-difficulty` recorded the leg as
    // unavailable off a grep of `src/game.rs` taken after #2668 had moved the
    // action layer to `src/game/actions.rs`. While a city builds a Settler, a
    // Builder clears the best-paying feature in reach instead of improving.
    Gene { tag: "chop-for-expansion", field: "chop_for_expansion", kind: Kind::OptIn, enable: AdvancedAi::enable_chop_for_expansion, disable: AdvancedAi::disable_chop_for_expansion },
    // Appended above the markers, so a running screen keeps its positional
    // gene index and the append points stay free at the tail.
    // `TargetRank` leads with `not_the_capital`, so the early conquest opening
    // aims at the one city on the board that is reliably defended and the
    // garrison field below it only breaks ties. 2 cities taken against 65 lost
    // over 111 Emperor games. This ranks by the visible garrison first and
    // demotes capital-ness to the field under it — same fields, same
    // tie-breaks, so the capital still wins among equally garrisoned cities.
    Gene { tag: "conquest-takes-the-soft-city", field: "conquest_takes_the_soft_city", kind: Kind::OptIn, enable: AdvancedAi::enable_conquest_takes_the_soft_city, disable: AdvancedAi::disable_conquest_takes_the_soft_city },
    // Every arm of `denial_response_for_pressure` reaches Conquest except
    // Culture, which answers a rival about to win by racing it and has no gene
    // to choose otherwise — and culture is the lane the live ladder loses to,
    // six rival finishes between standard turns 155 and 208. Capturing a city
    // takes its Great Works, so it removes the rival's tourism and adds it to
    // ours in one action; no other lane's counter does that. This gives Culture
    // the same Conquest answer on the same urgency bar, and aims
    // `victory_suppression_city` at the Theatre Square.
    Gene { tag: "counter-culture-by-conquest", field: "counter_culture_by_conquest", kind: Kind::OptIn, enable: AdvancedAi::enable_counter_culture_by_conquest, disable: AdvancedAi::disable_counter_culture_by_conquest },
    // `boost-planner` can only ever make an objective of three trigger
    // families — `improvement*`, `units_of:` and `district:`. `building:` is
    // the LARGEST family in the two trees, 21 of the 115 boost rows, and it is
    // classed as strategic spending beside wonders, war and religion, so the
    // planner never plans one. An ordinary building in a city that already has
    // its district is the same kind of decision as the next district, which is
    // planned. This admits exactly that case; `building_near_mountain:` and
    // `themed_buildings` keep their Expensive reading.
    Gene { tag: "boost-planner-builds", field: "boost_planner_builds", kind: Kind::OptIn, enable: AdvancedAi::enable_boost_planner_builds, disable: AdvancedAi::disable_boost_planner_builds },
    // `denial-outranks-expansion` (2026-09-10): `actionable_denial` — a rival
    // close to winning and a counter this seat can execute — was ranked BELOW
    // the assigned lane in the strategy chain, and that lane answers
    // "Expansion" while the empire is under its city target. On a four-civ
    // Tiny Pangaea the target is six and the land holds five, so the lane
    // never handed over and the denial never ran: two Emperor games lost to a
    // religious victory at t278 and t163 with the board reading "the first
    // half is reserved for expansion". With the gene on the denial is asked
    // first. Same counter, same actionable test; only the order moves. Off;
    // screen it, and force it on the live seat with `conversion-majority-alarm-2`
    // so the religious clock is actually read.
    Gene { tag: "denial-outranks-expansion", field: "denial_outranks_expansion", kind: Kind::OptIn, enable: AdvancedAi::enable_denial_outranks_expansion, disable: AdvancedAi::disable_denial_outranks_expansion },
    // `ranged-hp-reserve` (2026-09-10, operator: "asymmetric damage with
    // archers while not taking fatal hits"): a ranged, non-siege unit reads
    // the lethal pool with 20 hp in hand, so it leaves a tile the enemy's exact
    // next-turn attacks would nearly kill it on and shoots again from the next.
    // The lethal-pool test only; the healing line stays `one_shot_recovery`'s,
    // and `can_survive_by_attacking` still keeps a unit whose own shot ends the
    // threat. Off; screen it.
    Gene { tag: "ranged-hp-reserve", field: "ranged_hp_reserve", kind: Kind::OptIn, enable: AdvancedAi::enable_ranged_hp_reserve, disable: AdvancedAi::disable_ranged_hp_reserve },
    // `domination-lane-hands-over` (2026-09-10): the assigned lane keeps
    // answering Expansion while `cities < desired_cities`, and that target
    // scales with difficulty — 6, then 10 — on a four-civ Tiny Pangaea that
    // holds five or six. The live seat reached 8 and then 9 cities still reading
    // Expansion and declared no war in three Emperor games. With the gene on, a
    // Domination lane with `DOMINATION_HANDOVER_CITIES` (4, the opening band's
    // floor) in hand follows its lane. Off; screen it; forced on the live seat.
    Gene { tag: "domination-lane-hands-over", field: "domination_lane_hands_over", kind: Kind::OptIn, enable: AdvancedAi::enable_domination_lane_hands_over, disable: AdvancedAi::disable_domination_lane_hands_over },
    Gene { tag: "domination-siege-research", field: "domination_siege_research", kind: Kind::OptIn, enable: AdvancedAi::enable_domination_siege_research, disable: AdvancedAi::disable_domination_siege_research },
    Gene { tag: "domination-capital-focus", field: "domination_capital_focus", kind: Kind::OptIn, enable: AdvancedAi::enable_domination_capital_focus, disable: AdvancedAi::disable_domination_capital_focus },
    // Appended above the markers, so a running screen keeps its positional
    // gene index and the append points stay free at the tail.
    // `expansion_hall` prices the Ancestral Hall for the land grab and cannot
    // reach the plot it stands on: it prices a BUILDING and says so. Over the
    // 38 recorded live runs of 2026-09-10/11 a Government Plaza stands in 25 at
    // a median turn 112 and the Hall in 8 at a median turn 119, while the
    // fourth city the opening band needs by turn 60 arrives at a median 77 —
    // so the +50% Settlers land 59 turns late and 17 of 25 plazas never host
    // them. This is `amenity_district_path`'s empty-plot repair on the
    // expansion axis, at the building arm's own constants and its own
    // shortfall scale.
    Gene { tag: "expansion-hall-district", field: "expansion_hall_district", kind: Kind::OptIn, enable: AdvancedAi::enable_expansion_hall_district, disable: AdvancedAi::disable_expansion_hall_district },
    // Preserve the published order of these new rows; tail markers stay free
    // so the next registration is also an append.
    Gene { tag: "capture-hold-chain", field: "capture_hold_chain", kind: Kind::OptIn, enable: AdvancedAi::enable_capture_hold_chain, disable: AdvancedAi::disable_capture_hold_chain },
    Gene { tag: "capital-campaign-router", field: "capital_campaign_router", kind: Kind::OptIn, enable: AdvancedAi::enable_capital_campaign_router, disable: AdvancedAi::disable_capital_campaign_router },
    Gene { tag: "culture-faith-reservation", field: "culture_faith_reservation", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_faith_reservation, disable: AdvancedAi::disable_culture_faith_reservation },
    Gene { tag: "culture-tourism-payback", field: "culture_tourism_payback", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_tourism_payback, disable: AdvancedAi::disable_culture_tourism_payback },
    Gene { tag: "great-work-completion-value", field: "great_work_completion_value", kind: Kind::OptIn, enable: AdvancedAi::enable_great_work_completion_value, disable: AdvancedAi::disable_great_work_completion_value },
    Gene { tag: "reinforce-before-stall", field: "reinforce_before_stall", kind: Kind::OptIn, enable: AdvancedAi::enable_reinforce_before_stall, disable: AdvancedAi::disable_reinforce_before_stall },
    Gene { tag: "siege-positive-damage-budget", field: "siege_positive_damage_budget", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_positive_damage_budget, disable: AdvancedAi::disable_siege_positive_damage_budget },
    Gene { tag: "tourism-land-reservation", field: "tourism_land_reservation", kind: Kind::OptIn, enable: AdvancedAi::enable_tourism_land_reservation, disable: AdvancedAi::disable_tourism_land_reservation },
    Gene { tag: "upgrade-window-campaign", field: "upgrade_window_campaign", kind: Kind::OptIn, enable: AdvancedAi::enable_upgrade_window_campaign, disable: AdvancedAi::disable_upgrade_window_campaign },
    Gene { tag: "victory-deadline-budget", field: "victory_deadline_budget", kind: Kind::OptIn, enable: AdvancedAi::enable_victory_deadline_budget, disable: AdvancedAi::disable_victory_deadline_budget },
    // A one-turn boosted technology interrupts a peaceful lane beeline that is
    // not about to land its target; see `boosted_bargain_tech_3`.
    Gene { tag: "boosted-bargain-first-3", field: "boosted_bargain_first_3", kind: Kind::OptIn, enable: AdvancedAi::enable_boosted_bargain_first_3, disable: AdvancedAi::disable_boosted_bargain_first_3 },
    // Competitive economy hypotheses; see competitive_economy.rs.
    Gene { tag: "builder-charge-window", field: "builder_charge_window", kind: Kind::OptIn, enable: AdvancedAi::enable_builder_charge_window, disable: AdvancedAi::disable_builder_charge_window },
    Gene { tag: "trade-growth-to-district", field: "trade_growth_to_district", kind: Kind::OptIn, enable: AdvancedAi::enable_trade_growth_to_district, disable: AdvancedAi::disable_trade_growth_to_district },
    Gene { tag: "culture-lane-forecast-2", field: "culture_lane_forecast_2", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_lane_forecast_2, disable: AdvancedAi::disable_culture_lane_forecast_2 },
    Gene { tag: "trade-production-to-launch", field: "trade_production_to_launch", kind: Kind::OptIn, enable: AdvancedAi::enable_trade_production_to_launch, disable: AdvancedAi::disable_trade_production_to_launch },
    // Revise a stale sighting once its entire forecast area is visible and
    // empty of that unit; hidden units retain only their last observed facts.
    // Append new genes so the existing positional genome stays intact.
    Gene { tag: "hostile-memory-3", field: "hostile_memory_3", kind: Kind::OptIn, enable: AdvancedAi::enable_hostile_memory_3, disable: AdvancedAi::disable_hostile_memory_3 },
    Gene { tag: "connect-the-luxury-2", field: "connect_the_luxury_2", kind: Kind::OptIn, enable: AdvancedAi::enable_connect_the_luxury_2, disable: AdvancedAi::disable_connect_the_luxury_2 },
    // Version two checks usable building and district unlocks in the capped
    // cities and counts the whole missing research path, including its boosts.
    Gene { tag: "housing-research-2", field: "housing_research_2", kind: Kind::OptIn, enable: AdvancedAi::enable_housing_research_2, disable: AdvancedAi::disable_housing_research_2 },
    // V2 reserves housing only when construction plus growth brings the next
    // citizen materially earlier within a bounded investment window.
    Gene { tag: "first-granary-reserve-2", field: "first_granary_reserve_2", kind: Kind::OptIn, enable: AdvancedAi::enable_first_granary_reserve_2, disable: AdvancedAi::disable_first_granary_reserve_2 },
    // Persistent primary/secondary objectives, feasibility clocks and phased
    // investment. Independently measured; no deployment promotion is assumed.
    Gene { tag: "victory-portfolio", field: "victory_portfolio", kind: Kind::OptIn, enable: AdvancedAi::enable_victory_portfolio, disable: AdvancedAi::disable_victory_portfolio },
    // The treasury successor retains the reserve and puts the first Builder by local work.
    Gene { tag: "treasury-at-work-2-2", field: "treasury_at_work_2_2", kind: Kind::OptIn, enable: AdvancedAi::enable_treasury_at_work_2_2, disable: AdvancedAi::disable_treasury_at_work_2_2 },
    // Price one locally purchasable defender, with the engine's discounts
    // and refusals, rather than the empire's dearest buildable ranged unit.
    Gene { tag: "threatened-city-reserve-2", field: "threatened_city_reserve_2", kind: Kind::OptIn, enable: AdvancedAi::enable_threatened_city_reserve_2, disable: AdvancedAi::disable_threatened_city_reserve_2 },
    Gene { tag: "builder-workforce-recovery-3", field: "builder_workforce_recovery_3", kind: Kind::OptIn, enable: AdvancedAi::enable_builder_workforce_recovery_3, disable: AdvancedAi::disable_builder_workforce_recovery_3 },
    Gene { tag: "government-ladder-3", field: "government_ladder_3", kind: Kind::OptIn, enable: AdvancedAi::enable_government_ladder_3, disable: AdvancedAi::disable_government_ladder_3 },
    // A queued building services only the yield it can deliver soon enough;
    // a slow or undersized answer does not close the whole empire's deficit.
    Gene { tag: "culture-building-catchup-3", field: "culture_building_catchup_3", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_building_catchup_3, disable: AdvancedAi::disable_culture_building_catchup_3 },
    Gene { tag: "research-building-catchup-3", field: "research_building_catchup_3", kind: Kind::OptIn, enable: AdvancedAi::enable_research_building_catchup_3, disable: AdvancedAi::disable_research_building_catchup_3 },
    Gene { tag: "age-closer-2", field: "age_closer_2", kind: Kind::OptIn, enable: AdvancedAi::enable_age_closer_2, disable: AdvancedAi::disable_age_closer_2 },
    // `lane-delegates-production` (2026-09-24): an assigned lane sends every
    // city through the strategic scorer; an unassigned seat hands its routine
    // queues to the baseline governor. On the King ladder proxy the lane alone
    // cost 2.3-3.0 pp of score share (z -2.8/-4.1): Settlers 18% of Production
    // to turn 100 against 11%, military 14% against 10%, Granary 3.4 against
    // 4.2 and trade capacity 1.8 against 3.0. With the unassigned dispatch
    // until the development half ends the Science seat gained +1.39 pp (z
    // +2.86). See `advanced/lane_delegates_production.rs`.
    Gene { tag: "lane-delegates-production", field: "lane_delegates_production", kind: Kind::OptIn, enable: AdvancedAi::enable_lane_delegates_production, disable: AdvancedAi::disable_lane_delegates_production },
    // `lane-delegates-production-2` (2026-09-24): version one's dispatch for
    // the whole game rather than the development half. On the King ladder
    // proxy it beat version one by +0.96 pp on the Science lane (z +2.78) and
    // +0.41 pp on the Domination lane (z +0.95), and matched it at Emperor
    // (-0.03 pp, z -0.10); against the lane without either, +2.35 pp (z
    // +4.78) and +1.38 pp (z +1.67). See `advanced/lane_delegates_production.rs`.
    Gene { tag: "lane-delegates-production-2", field: "lane_delegates_production_2", kind: Kind::OptIn, enable: AdvancedAi::enable_lane_delegates_production_2, disable: AdvancedAi::disable_lane_delegates_production_2 },
    // `builders-work-through-raiders` (2026-09-26): the live capture
    // lessons' barbarian-reach holds were written for Settlers; on a Builder
    // they left worked first-copy luxuries unimproved for 40+ turns at
    // Immortal. With this on, Builders keep the native Builder safety and the
    // Settlers keep every lesson. See `AdvancedAi::builder_reach_safety_on`.
    Gene { tag: "builders-work-through-raiders", field: "builders_work_through_raiders", kind: Kind::OptIn, enable: AdvancedAi::enable_builders_work_through_raiders, disable: AdvancedAi::disable_builders_work_through_raiders },
    // `beeline-orders-by-value` (2026-09-26): a forced research or civic goal
    // walks its remaining prerequisites by `tech_value` / `civic_value`
    // rather than cheapest printed price with ties by name, which on the
    // Immortal Science seat took Writing at turn 27 behind Sailing. The goal
    // lands on the same turn either way. See `AdvancedAi::beeline_step`.
    Gene { tag: "beeline-orders-by-value", field: "beeline_orders_by_value", kind: Kind::OptIn, enable: AdvancedAi::enable_beeline_orders_by_value, disable: AdvancedAi::disable_beeline_orders_by_value },
    // `settler-detour-stays-near` (2026-09-26): the threat detour's fallback
    // was FARTHER than the deferred site in 11 of 18 Immortal-proxy detours
    // (4 tiles became 9), and each far walk met its own blocker; Settlers
    // walked 20–27 turns for sites four tiles from home. With this on, the
    // fallback must lie within the deferred site's distance plus one (floor
    // three, ceiling eight), else the target is kept and the guard holds.
    // See `SETTLER_DETOUR_NEAR_SLACK`.
    Gene { tag: "settler-detour-stays-near", field: "settler_detour_stays_near", kind: Kind::OptIn, enable: AdvancedAi::enable_settler_detour_stays_near, disable: AdvancedAi::disable_settler_detour_stays_near },
    // `befriend-the-strongest` (2026-09-26): a friendship-only offer to the
    // strongest met major at peace, every third turn. A friendship forbids a
    // war declaration between the pair; no major formed one on the ladder
    // proxy without it. Immortal against Domination-lane rivals (32 paired):
    // focal wins 4 -> 19, cities lost 3.1 -> 1.8. See
    // `advanced/protective_friendship.rs`.
    Gene { tag: "befriend-the-strongest", field: "befriend_the_strongest", kind: Kind::OptIn, enable: AdvancedAi::enable_befriend_the_strongest, disable: AdvancedAi::disable_befriend_the_strongest },
    // `domination-ignores-city-states` (2026-09-27): an assigned Domination
    // seat's campaign never ranks a city-state. On the King ladder proxy the
    // fallback ranking opened a city-state war in 7 of 16 games, which then
    // held the front; captured city-states count nothing toward Domination.
    // See `AdvancedAi::conquest_campaign_considers_city_states`.
    Gene { tag: "domination-ignores-city-states", field: "domination_ignores_city_states", kind: Kind::OptIn, enable: AdvancedAi::enable_domination_ignores_city_states, disable: AdvancedAi::disable_domination_ignores_city_states },
    // `domination-specializes-earlier` (2026-09-27): an assigned Domination
    // lane turns to Conquest at 40% of the clock instead of halfway, at King
    // and below. King ladder proxy, 64 paired games: foreign cities held
    // 8 -> 22, alive 49 -> 54, +0.90 pp; Emperor -1.06 pp, so not above King. See `AdvancedAi::phase_specialization_active`.
    Gene { tag: "domination-specializes-earlier", field: "domination_specializes_earlier", kind: Kind::OptIn, enable: AdvancedAi::enable_domination_specializes_earlier, disable: AdvancedAi::disable_domination_specializes_earlier },
    // The delegated city governor asked every coastal city for a Harbor before
    // any specialty district; live King Tiny Pangaea started no Campus between
    // turns 20 and 65 in two of three games. See `BasicAi::campus_before_harbor`.
    Gene { tag: "campus-before-harbor", field: "campus_before_harbor", kind: Kind::OptIn, enable: AdvancedAi::enable_campus_before_harbor, disable: AdvancedAi::disable_campus_before_harbor },
    // V2 also puts the capital's first Campus ahead of its next Settler once
    // the empire holds three cities: the capital trained eight Settlers by
    // turn 57 and opened no Campus until turn 66. See `BasicAi::capital_campus_first`.
    Gene { tag: "campus-before-harbor-2", field: "campus_before_harbor_2", kind: Kind::OptIn, enable: AdvancedAi::enable_campus_before_harbor_2, disable: AdvancedAi::disable_campus_before_harbor_2 },
    // Seven urgent counter declarations below parity took 0.14 cities in 40
    // turns and lost all seven games. See `one_war::COUNTER_WAR_PARITY`.
    Gene { tag: "counter-war-needs-parity", field: "counter_war_needs_parity", kind: Kind::OptIn, enable: AdvancedAi::enable_counter_war_needs_parity, disable: AdvancedAi::disable_counter_war_needs_parity },
    // The delegated city governor tried every district a city lacked before
    // any building: live King turn 100 held 15 of 45 Campuses without a
    // Library and 13 of 19 Commercial Hubs without a Market. See
    // `BasicAi::district_buildings_first`.
    Gene { tag: "district-buildings-first", field: "district_buildings_first", kind: Kind::OptIn, enable: AdvancedAi::enable_district_buildings_first, disable: AdvancedAi::disable_district_buildings_first },
    // Culture buys civics and is one bar of the culture-victory defense
    // (domestic Tourists are lifetime Culture over 100); our Culture ran a
    // third to a half of the strongest rival's and the bred district order
    // always ranks the Theater Square last. See `BasicAi::culture_defense_theater`.
    Gene { tag: "culture-defense-theater", field: "culture_defense_theater", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_defense_theater, disable: AdvancedAi::disable_culture_defense_theater },
    // Live King 2026-10-05: 11 of 55 housing-bound cities at t75 built the
    // reservation's Theater instead of a Granary; see `culture_defense.rs`.
    Gene { tag: "culture-defense-theater-2", field: "culture_defense_theater_2", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_defense_theater_2, disable: AdvancedAi::disable_culture_defense_theater_2 },
    // V3 carries version one's housing rule into the delegated city governor,
    // where most live builds are placed, and follows the Granary with an
    // Aqueduct while the city stays housing-bound.
    Gene { tag: "first-granary-reserve-3", field: "first_granary_reserve_3", kind: Kind::OptIn, enable: AdvancedAi::enable_first_granary_reserve_3, disable: AdvancedAi::disable_first_granary_reserve_3 },
    // The Monument sat behind the military floor, the Settler, the Builders
    // and the Trader: live King turn 60 to 100, only 54-57% of cities older
    // than 20 turns held one and culture trailed 10.6 against 27.3. See
    // `BasicAi::monument_first`.
    Gene { tag: "monument-first", field: "monument_first", kind: Kind::OptIn, enable: AdvancedAi::enable_monument_first, disable: AdvancedAi::disable_monument_first },
    Gene { tag: "shared-danger", field: "shared_danger", kind: Kind::OptIn, enable: AdvancedAi::enable_shared_danger, disable: AdvancedAi::disable_shared_danger },
    // V2 also gives the capital's Library the slot campus-before-harbor-2
    // gives its Campus, ahead of the next Settler: the best live game held 7
    // Campuses and 2 Libraries at turn 100. See `BasicAi::capital_library_first`.
    Gene { tag: "district-buildings-first-2", field: "district_buildings_first_2", kind: Kind::OptIn, enable: AdvancedAi::enable_district_buildings_first_2, disable: AdvancedAi::disable_district_buildings_first_2 },
    // Upgrades spent the treasury to 30 Gold at war; a one-turn upkeep swing
    // then bankrupted the empire (live King 040354Z t180-186, t207-213).
    // See `gold_and_cards::UPKEEP_RESERVE_TURNS`.
    Gene { tag: "upkeep-reserve", field: "upkeep_reserve", kind: Kind::OptIn, enable: AdvancedAi::enable_upkeep_reserve, disable: AdvancedAi::disable_upkeep_reserve },
    // The base governor's deck pass unslotted Levée en Masse before the
    // strategic deck read it, so the relief flipped out and the next turn's
    // bill bankrupted the empire; Liberalism and Aesthetics alternated every
    // turn. See `AdvancedAi::maintenance_relief_held`.
    Gene { tag: "policy-deck-hysteresis", field: "policy_deck_hysteresis", kind: Kind::OptIn, enable: AdvancedAi::enable_policy_deck_hysteresis, disable: AdvancedAi::disable_policy_deck_hysteresis },
    // Live King 052455Z drew no Oil or Aluminum at turn 182 while Spain, the
    // rival at war, held both; every modern upgrade and the bomber wing
    // waited on them. See `strategic_deposit_prey::STRATEGIC_DEPOSIT_PREY_VALUE`.
    Gene { tag: "strategic-deposit-prey", field: "strategic_deposit_prey", kind: Kind::OptIn, enable: AdvancedAi::enable_strategic_deposit_prey, disable: AdvancedAi::disable_strategic_deposit_prey },
    // Live King 060034Z lost on Culture to Sweden at turn 205: 40 percent at
    // 185, under the counter's bar, yet compounding to a finish in about 28
    // turns while the army fought the science leader. See
    // `denial_nearest_finish::DENIAL_FINISH_HORIZON`.
    Gene { tag: "denial-nearest-finish", field: "denial_nearest_finish", kind: Kind::OptIn, enable: AdvancedAi::enable_denial_nearest_finish, disable: AdvancedAi::disable_denial_nearest_finish },
    // Live King 072557Z stood in Stage before 400 walls for 46 turns: the
    // shortfall reservation stopped at three guns. See
    // `siege_production::HEAVY_WALL_SIEGE_CAP`.
    Gene { tag: "siege-train-scales-with-walls", field: "siege_train_scales_with_walls", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_train_scales_with_walls, disable: AdvancedAi::disable_siege_train_scales_with_walls },
    // V2 also researches the next stronger buildable land siege design once
    // the target's walls reach the Medieval tier: live King 072557Z stayed on
    // Trebuchets against 400-HP Cree walls from t123 to t142. See
    // `SIEGE_UPGRADE_WALL_HP`.
    Gene { tag: "domination-siege-research-2", field: "domination_siege_research_2", kind: Kind::OptIn, enable: AdvancedAi::enable_domination_siege_research_2, disable: AdvancedAi::disable_domination_siege_research_2 },
    // Live King 081800Z mustered for unwalled Helsingborg for 82 turns while
    // the rally flipped across the city. See
    // `objective_board::SIEGE_RALLY_SWITCH_MARGIN`.
    Gene { tag: "siege-rally-holds", field: "siege_rally_holds", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_rally_holds, disable: AdvancedAi::disable_siege_rally_holds },
    Gene { tag: "policy-deck-hysteresis-2", field: "policy_deck_hysteresis_2", kind: Kind::OptIn, enable: AdvancedAi::enable_policy_deck_hysteresis_2, disable: AdvancedAi::disable_policy_deck_hysteresis_2 },
    // Live King 090618Z kept Bhavapura at 43 Loyalty and -6.6 a turn; it
    // revolted at 73, seven turns after the capture, before the moved
    // Governor could hold it. See `DOOMED_CAPTURE_TURNS`.
    Gene { tag: "raze-a-doomed-capture", field: "raze_doomed_capture", kind: Kind::OptIn, enable: AdvancedAi::enable_raze_doomed_capture, disable: AdvancedAi::disable_raze_doomed_capture },
    // Live King 093332Z held zero Builders from t54 to t93; see
    // `BasicAi::builder_before_the_army`.
    Gene { tag: "builder-before-the-army", field: "builder_before_the_army", kind: Kind::OptIn, enable: AdvancedAi::enable_builder_before_the_army, disable: AdvancedAi::disable_builder_before_the_army },
    Gene { tag: "builder-before-the-army-2", field: "builder_before_the_army_2", kind: Kind::OptIn, enable: AdvancedAi::enable_builder_before_the_army_2, disable: AdvancedAi::disable_builder_before_the_army_2 },
    // Live King 103619Z: 5 of 6 cities without a Campus from t70 to t120;
    // see `BasicAi::campus_before_the_army`.
    Gene { tag: "campus-before-the-army", field: "campus_before_the_army", kind: Kind::OptIn, enable: AdvancedAi::enable_campus_before_the_army, disable: AdvancedAi::disable_campus_before_the_army },
    // Live King 103619Z had Tskhumi's walls 400 -> 276 and dropped to Stage;
    // they stood at 400 again eight turns later. See
    // `siege_train::HELD_BREACH_WALL_SHARE`.
    Gene { tag: "siege-holds-a-breach", field: "siege_holds_a_breach", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_holds_a_breach, disable: AdvancedAi::disable_siege_holds_a_breach },
    // Live King 021048Z stood down Kwadukuza as "not pushed to a new low"
    // while its new walls fell from 64 to 28. See
    // `commitments::rebase_capture_on_new_walls`.
    Gene { tag: "stall-rebases-on-new-walls", field: "stall_rebases_on_new_walls", kind: Kind::OptIn, enable: AdvancedAi::enable_stall_rebases_on_new_walls, disable: AdvancedAi::disable_stall_rebases_on_new_walls },
    // Live King 115745Z sieged unwalled Pest with one Archer shot a turn
    // while ten bodies held in reserve; the city walled at turn 78. See
    // `objective_board::SIEGE_RANGED_FLOOR`.
    Gene { tag: "siege-ranged-floor", field: "siege_ranged_floor", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_ranged_floor, disable: AdvancedAi::disable_siege_ranged_floor },
    // Live King 100536Z aimed its culture denial at India for 45 turns with
    // Phoenicia's closed borders between; no unit reached Delhi. See
    // `advanced/denial_needs_a_road.rs`.
    Gene { tag: "denial-needs-a-road", field: "denial_needs_a_road", kind: Kind::OptIn, enable: AdvancedAi::enable_denial_needs_a_road, disable: AdvancedAi::disable_denial_needs_a_road },
    Gene { tag: "campus-before-the-army-2", field: "campus_before_the_army_2", kind: Kind::OptIn, enable: AdvancedAi::enable_campus_before_the_army_2, disable: AdvancedAi::disable_campus_before_the_army_2 },
    Gene { tag: "campus-before-the-army-3", field: "campus_before_the_army_3", kind: Kind::OptIn, enable: AdvancedAi::enable_campus_before_the_army_3, disable: AdvancedAi::disable_campus_before_the_army_3 },
    // Live King 155014Z: 5 of 6 cities at their housing, no Granary, at t100;
    // see `BasicAi::granary_before_the_army`.
    Gene { tag: "granary-before-the-army", field: "granary_before_the_army", kind: Kind::OptIn, enable: AdvancedAi::enable_granary_before_the_army, disable: AdvancedAi::disable_granary_before_the_army },
    // Live King 124613Z: 79 Settler-turns afloat waiting on one Galley; see
    // `AdvancedAi::naval_escort_patience`.
    Gene { tag: "naval-escort-patience", field: "naval_escort_patience", kind: Kind::HostOnly, enable: AdvancedAi::enable_naval_escort_patience, disable: AdvancedAi::disable_naval_escort_patience },
    // Live King 160213Z: 69% of the siege army built more than 12 tiles from
    // the objective; see `BasicAi::front_weighted_floor`.
    Gene { tag: "front-weighted-floor", field: "front_weighted_floor", kind: Kind::OptIn, enable: AdvancedAi::enable_front_weighted_floor, disable: AdvancedAi::disable_front_weighted_floor },
    // Live King 235724Z: version 1 never bound (army 30-58% of its floor);
    // see `BasicAi::front_weighted_floor_2`.
    Gene { tag: "front-weighted-floor-2", field: "front_weighted_floor_2", kind: Kind::OptIn, enable: AdvancedAi::enable_front_weighted_floor_2, disable: AdvancedAi::disable_front_weighted_floor_2 },
    // Live King 024614Z: reserved catapults displaced and built far from
    // Lisbon; see `AdvancedAi::breaker_commitment_holds` and
    // `siege_production.rs`.
    Gene { tag: "breaker-keeps-its-queue", field: "breaker_keeps_its_queue", kind: Kind::OptIn, enable: AdvancedAi::enable_breaker_keeps_its_queue, disable: AdvancedAi::disable_breaker_keeps_its_queue },
    Gene { tag: "breaker-to-the-fastest", field: "breaker_to_the_fastest", kind: Kind::OptIn, enable: AdvancedAi::enable_breaker_to_the_fastest, disable: AdvancedAi::disable_breaker_to_the_fastest },
    // Live King 205431Z: Bogota alternated a Holy Site and a Theater Square
    // every frame from t251; see `BasicAi::activation_resume_waits`.
    Gene { tag: "activation-resume-waits", field: "activation_resume_waits", kind: Kind::HostOnly, enable: AdvancedAi::enable_activation_resume_waits, disable: AdvancedAi::disable_activation_resume_waits },
    // Live King 051413Z: Bogota switched the Art Museum and the Archaeological
    // Museum every turn t187-t214; see `BasicAi::activation_keeps_its_building`.
    Gene { tag: "activation-keeps-its-building", field: "activation_keeps_its_building", kind: Kind::HostOnly, enable: AdvancedAi::enable_activation_keeps_its_building, disable: AdvancedAi::disable_activation_keeps_its_building },
    // Native 002240Z: Mary Leakey needs an Artifact; two empty Museums are not that work.
    Gene { tag: "artifact-before-more-museums", field: "artifact_before_more_museums", kind: Kind::OptIn, enable: AdvancedAi::enable_artifact_before_more_museums, disable: AdvancedAi::disable_artifact_before_more_museums },
    // Live King 113755Z: Galleys and Quadriremes ahead of the walkers at
    // three cities; see `BasicAi::settler_before_the_navy`.
    Gene { tag: "settler-before-the-navy", field: "settler_before_the_navy", kind: Kind::OptIn, enable: AdvancedAi::enable_settler_before_the_navy, disable: AdvancedAi::disable_settler_before_the_navy },
    // Live King 110427Z-cont1: the budget read Tenochtitlan ready in 2.8
    // turns while Archers did 5 a shot and melee held the ring; it healed
    // to 200 every turn. See `conversion_siege_budget`.
    Gene { tag: "siege-budget-counts-what-fires", field: "siege_budget_counts_what_fires", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_budget_counts_what_fires, disable: AdvancedAi::disable_siege_budget_counts_what_fires },
    // Live King 135713Z held Kwadukuza's ring with two Knights and three
    // Men-at-Arms from turn 113 to 122 at 198/200 walls, reading "damage
    // ready" off a Bombard healing five tiles out; the two fresh Bombards and
    // the Siege Tower walked in circles in the Reserve. See
    // `siege_train::BreachReading`.
    Gene { tag: "siege-needs-a-breaker", field: "siege_needs_a_breaker", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_needs_a_breaker, disable: AdvancedAi::disable_siege_needs_a_breaker },
    // Live King civvis-20261004T025448Z: the Napata Siege force shrank from
    // seven to three as Destroy rows took its members each turn, and none of
    // seven to ten bodies reached its anchor in eighteen turns. See
    // `objective_board::SIEGE_MEMBER_STRIKE_REACH`.
    Gene { tag: "siege-force-keeps-its-members", field: "siege_force_keeps_its_members", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_force_keeps_its_members, disable: AdvancedAi::disable_siege_force_keeps_its_members },
    // Live King October 2026: the delegated governor's district list never
    // names the Industrial Zone, so 28 games held 0.1 zones at t100 and 0.9
    // at t200 against 7.9 Campuses, with ~95% of production from worked
    // tiles. See `BasicAi::industry_before_the_army`.
    Gene { tag: "industry-before-the-army", field: "industry_before_the_army", kind: Kind::OptIn, enable: AdvancedAi::enable_industry_before_the_army, disable: AdvancedAi::disable_industry_before_the_army },
    // Live King October 2026: Urban Planning in 11 of 26 games at t100; the
    // timed economy held a one-slot deck's Colonization through the whole
    // expansion phase. See `AdvancedAi::colonization_earns_its_slot`.
    // Version 1 over 22 domination pairs: +302 production by t150 (z +2.8),
    // -2.2 Gold a turn at t120 (z -2.6), rivals' Culture wins 12 of 22
    // against 6. See `BasicAi::industry_before_the_army_2`.
    Gene { tag: "industry-before-the-army-2", field: "industry_before_the_army_2", kind: Kind::OptIn, enable: AdvancedAi::enable_industry_before_the_army_2, disable: AdvancedAi::disable_industry_before_the_army_2 },
    // The zone in the stock district list, behind the floor: version 1 ahead
    // of the floor thinned the wartime army. See
    // `BasicAi::industry_in_the_district_list`.
    Gene { tag: "industry-in-the-district-list", field: "industry_in_the_district_list", kind: Kind::OptIn, enable: AdvancedAi::enable_industry_in_the_district_list, disable: AdvancedAi::disable_industry_in_the_district_list },
    // Live King since version 2 armed: 20.7 unimproved worked land tiles
    // against 14.5 improved at t100, 1.6 build charges on the map at t41-80.
    // See `BasicAi::builder_before_the_army_3`.
    Gene { tag: "builder-before-the-army-3", field: "builder_before_the_army_3", kind: Kind::OptIn, enable: AdvancedAi::enable_builder_before_the_army_3, disable: AdvancedAi::disable_builder_before_the_army_3 },
    Gene { tag: "colonization-earns-its-slot", field: "colonization_earns_its_slot", kind: Kind::OptIn, enable: AdvancedAi::enable_colonization_earns_its_slot, disable: AdvancedAi::disable_colonization_earns_its_slot },
    // Live King civvis-20261004T033533Z: Babylon's catapults held six to ten
    // tiles out for eighteen turns, each refusing any tile one archer could
    // reach. See `siege_train::STAGING_ESCORT_BODIES`.
    Gene { tag: "staging-gun-trusts-its-escort", field: "staging_gun_trusts_its_escort", kind: Kind::OptIn, enable: AdvancedAi::enable_staging_gun_trusts_its_escort, disable: AdvancedAi::disable_staging_gun_trusts_its_escort },
    // Live King civvis-20261004T070716Z (game 49): the opening on Kyoto had
    // its 4 Archers and 2 Warriors by turn 30, but a ClearCamp row and
    // Destroy rows against raiders kept four of them home and it released
    // at turn 40. See `AdvancedAi::conquest_force_member`.
    Gene { tag: "opening-force-keeps-its-members", field: "opening_force_keeps_its_members", kind: Kind::OptIn, enable: AdvancedAi::enable_opening_force_keeps_its_members, disable: AdvancedAi::disable_opening_force_keeps_its_members },
    // Live King 131343Z lost on Technology to a rival with fourteen cities
    // and twice our population that the campaign never touched. See
    // `advanced/runaway_expander.rs`.
    Gene { tag: "runaway-expander-counter", field: "runaway_expander_counter", kind: Kind::OptIn, enable: AdvancedAi::enable_runaway_expander_counter, disable: AdvancedAi::disable_runaway_expander_counter },
    // A Builder priced a Mine at its printed +1 Production after
    // Apprenticeship made it +2. See `AdvancedAi::improvement_upgrades_count`.
    Gene { tag: "improvement-upgrades-count", field: "improvement_upgrades_count", kind: Kind::OptIn, enable: AdvancedAi::enable_improvement_upgrades_count, disable: AdvancedAi::disable_improvement_upgrades_count },
    // Version 2 still flipped 5 rival Science wins to Culture over 32 pairs.
    // See `BasicAi::industry_before_the_army_3`.
    Gene { tag: "industry-before-the-army-3", field: "industry_before_the_army_3", kind: Kind::OptIn, enable: AdvancedAi::enable_industry_before_the_army_3, disable: AdvancedAi::disable_industry_before_the_army_3 },
    // One zone where its Factory reaches the most cities: 5.6 of 8.6 live
    // cities at t130. See `BasicAi::industrial_hub`.
    Gene { tag: "industrial-hub", field: "industrial_hub", kind: Kind::OptIn, enable: AdvancedAi::enable_industrial_hub, disable: AdvancedAi::disable_industrial_hub },
    // Version 1's test for the Builder cards too: builder-before-the-army-3
    // queues Builders often enough to hold Urban Planning out behind Ilkum.
    // See `AdvancedAi::colonization_earns_its_slot_2`.
    Gene { tag: "colonization-earns-its-slot-2", field: "colonization_earns_its_slot_2", kind: Kind::OptIn, enable: AdvancedAi::enable_colonization_earns_its_slot_2, disable: AdvancedAi::disable_colonization_earns_its_slot_2 },
    // Version 1's Granary/Aqueduct behind campus v2 and the Builder backlog:
    // 3.9 of 8.4 live cities sat at their housing cap at t100. See
    // `BasicAi::granary_before_the_army_2`.
    Gene { tag: "granary-before-the-army-2", field: "granary_before_the_army_2", kind: Kind::OptIn, enable: AdvancedAi::enable_granary_before_the_army_2, disable: AdvancedAi::disable_granary_before_the_army_2 },
    // Research and civics aimed at the cheapest assault-plus-breaker package
    // that beats the campaign target's defender and opens its wall tier, the
    // civilization's unique unit preferred. Live King: our breaker arrived one
    // wall tier late every tier (Trebuchet t105 vs Castles t76-88, Bombard
    // t139 vs Siege Tactics t96-106) and no Llanero was ever trained. See
    // `advanced/decisive_window.rs`.
    Gene { tag: "decisive-window", field: "decisive_window", kind: Kind::OptIn, enable: AdvancedAi::enable_decisive_window, disable: AdvancedAi::disable_decisive_window },
    // The build picker credits the civilization's own unique unit for the
    // abilities its strength column omits, so the Llanero is trained over the
    // Line Infantry, and the research scorer's +55 unique-unit credit reads
    // `unique_to` (civs.json named one for 14 of 105 civilizations). See
    // `BasicAi::unique_unit_preference`.
    Gene { tag: "unique-unit-preference", field: "unique_unit_preference", kind: Kind::OptIn, enable: AdvancedAi::enable_unique_unit_preference, disable: AdvancedAi::disable_unique_unit_preference },
    // Live King 20261004T094143Z (game 51) started religious-defense Holy
    // Sites in four cities by turn 98 as each one changed faith, and G49 made
    // thirty starts across six. See `AdvancedAi::adopted_faith_sanctuary_choice`.
    Gene { tag: "one-sanctuary", field: "one_sanctuary", kind: Kind::OptIn, enable: AdvancedAi::enable_one_sanctuary, disable: AdvancedAi::disable_one_sanctuary },
    // Live King 115745Z fought Hungary, the culture winner, for 133 turns and
    // pillaged no Theater Square. See `air_surge::raids::RAID_TOURISM_DENIAL`.
    Gene { tag: "raids-cut-tourism", field: "raids_cut_tourism", kind: Kind::OptIn, enable: AdvancedAi::enable_raids_cut_tourism, disable: AdvancedAi::disable_raids_cut_tourism },
    // Live King 070716Z staged for walled Kyoto from turn 15 and ordered its
    // first Catapult at 70, after the war began. See
    // `siege_production::breaker_war_with`.
    Gene { tag: "breaker-before-the-war", field: "breaker_before_the_war", kind: Kind::OptIn, enable: AdvancedAi::enable_breaker_before_the_war, disable: AdvancedAi::disable_breaker_before_the_war },
    // Live King 083931Z stood down Lisbon's 300 walls after fifteen turns
    // waiting on one Bombard while Artillery was unlocked. See
    // `siege_production::SUPPLY_WALL_HP`.
    Gene { tag: "breaker-supply-scales", field: "breaker_supply_scales", kind: Kind::OptIn, enable: AdvancedAi::enable_breaker_supply_scales, disable: AdvancedAi::disable_breaker_supply_scales },
    // Live King 20261004T111442Z (game 53): Madrid stood without walls from
    // turn 44 to 66, 186-200 health, with five to eight units staged and
    // "damage ready" — two Archers shot it and the melee held the ring, so it
    // healed every turn and built walls. See `siege_train::breach_assault_blow`.
    Gene { tag: "breach-assault", field: "breach_assault", kind: Kind::OptIn, enable: AdvancedAi::enable_breach_assault, disable: AdvancedAi::disable_breach_assault },
    // Live King 232618Z: unwalled The Hague at 95-134 health beside eleven
    // staged units, horsemen three tiles out; the assault counted only melee
    // already beside it. See `siege_train::closing_in`.
    Gene { tag: "breach-assault-closes-in", field: "breach_assault_closes_in", kind: Kind::OptIn, enable: AdvancedAi::enable_breach_assault_closes_in, disable: AdvancedAi::disable_breach_assault_closes_in },
    // Version 1 measured -9.7 +/- 5.3 pp: only the capitals Domination
    // needs, no displaced building. See `siege_production::SUPPLY_STRENGTH_WINDOW`.
    Gene { tag: "breaker-supply-scales-2", field: "breaker_supply_scales_2", kind: Kind::OptIn, enable: AdvancedAi::enable_breaker_supply_scales_2, disable: AdvancedAi::disable_breaker_supply_scales_2 },
    // Live King 201619Z offered Gaul "one war at a time" peace at 843 power
    // against 140; Gaul rebuilt to 911 and won on Religion. 223225Z offered
    // it to Canada at 407 against 138 after taking Brantford. See
    // `AdvancedAi::second_front_kept_when_winning`.
    Gene { tag: "second-front-kept-when-winning", field: "second_front_kept_when_winning", kind: Kind::OptIn, enable: AdvancedAi::enable_second_front_kept_when_winning, disable: AdvancedAi::disable_second_front_kept_when_winning },
    // Live King 232618Z offered the Netherlands that peace at 3.2 times with
    // The Hague, its capital, the next objective, and declared again eight
    // turns later. See `AdvancedAi::second_front_kept_when_winning_2`.
    Gene { tag: "second-front-kept-when-winning-2", field: "second_front_kept_when_winning_2", kind: Kind::OptIn, enable: AdvancedAi::enable_second_front_kept_when_winning_2, disable: AdvancedAi::disable_second_front_kept_when_winning_2 },
    // Live King 213648Z took Babylon's only known city at turn 81, at six
    // times its power, and offered peace; Babylon held six cities at 207.
    // See `one_war::unseen_prey`.
    Gene { tag: "peace-waits-for-unseen-prey", field: "peace_waits_for_unseen_prey", kind: Kind::OptIn, enable: AdvancedAi::enable_peace_waits_for_unseen_prey, disable: AdvancedAi::disable_peace_waits_for_unseen_prey },
    // Live King 212049Z left unwalled Viseu in Invest, damage ready in 3.2
    // turns, for an urgent counter sixteen tiles away. See
    // `one_war::front_siege_to_finish`.
    Gene { tag: "front-finishes-its-siege", field: "front_finishes_its_siege", kind: Kind::OptIn, enable: AdvancedAi::enable_front_finishes_its_siege, disable: AdvancedAi::disable_front_finishes_its_siege },
    // Live King 212049Z made peace with the Zulu beside unwalled
    // Umgungundlovu, a seized foothold, to declare on Portugal at even power.
    // See `one_war::one_war_foothold_at_hand`.
    Gene { tag: "peace-waits-for-the-foothold", field: "peace_waits_for_the_foothold", kind: Kind::OptIn, enable: AdvancedAi::enable_peace_waits_for_the_foothold, disable: AdvancedAi::disable_peace_waits_for_the_foothold },
    // Live King 212049Z: Guayaquil's Holy Site and its walls traded the queue
    // five times in five turns. See
    // `adopted_faith_sanctuary::sanctuary_queue_held`.
    Gene { tag: "sanctuary-yields-a-held-queue", field: "sanctuary_yields_a_held_queue", kind: Kind::OptIn, enable: AdvancedAi::enable_sanctuary_yields_a_held_queue, disable: AdvancedAi::disable_sanctuary_yields_a_held_queue },
    // Live King 205431Z held the Prophet race open from turn 30 to 60 and
    // opened two Campuses, no Holy Site, at the campus-first steps. See
    // `BasicAi::prophet_race_takes_a_district_slot`.
    Gene { tag: "prophet-race-takes-a-district-slot", field: "prophet_race_takes_a_district_slot", kind: Kind::OptIn, enable: AdvancedAi::enable_prophet_race_takes_a_district_slot, disable: AdvancedAi::disable_prophet_race_takes_a_district_slot },
    // Live King 183907Z: our faithless cities were converted by passive
    // pressure alone; game 70 left two religion slots open. See
    // `advanced/faith_veto.rs`.
    Gene { tag: "found-against-a-rival-faith", field: "found_against_a_rival_faith", kind: Kind::OptIn, enable: AdvancedAi::enable_found_against_a_rival_faith, disable: AdvancedAi::disable_found_against_a_rival_faith },
    // 19 of 29 live "Declaring war" lines on 2026-10-04 sent a denouncement;
    // the staged army waited. See `strike_when_staged`.
    Gene { tag: "domination-strikes-when-staged", field: "domination_strikes_when_staged", kind: Kind::OptIn, enable: AdvancedAi::enable_domination_strikes_when_staged, disable: AdvancedAi::disable_domination_strikes_when_staged },
    // Live King 174103Z stood down six Dutch objectives in 95 turns with the
    // army still on the road. See `advanced/capture_march.rs`.
    Gene { tag: "capture-waits-on-the-march", field: "capture_waits_on_the_march", kind: Kind::OptIn, enable: AdvancedAi::enable_capture_waits_on_the_march, disable: AdvancedAi::disable_capture_waits_on_the_march },
    // Live King 014503Z offered the Inca, its only war, Recovery peace at 321
    // power against 202 with Qusqu the objective. See
    // `one_war::recovery_keeps_the_war`.
    Gene { tag: "recovery-keeps-a-winning-war", field: "recovery_keeps_a_winning_war", kind: Kind::OptIn, enable: AdvancedAi::enable_recovery_keeps_a_winning_war, disable: AdvancedAi::disable_recovery_keeps_a_winning_war },
    // Live King 160213Z fought Germany for 92 turns without a capture while
    // the at-war Maori held the capital it needed. See
    // `one_war::stalled_front_swap`.
    Gene { tag: "one-war-swaps-a-stalled-front", field: "one_war_swaps_a_stalled_front", kind: Kind::OptIn, enable: AdvancedAi::enable_one_war_swaps_a_stalled_front, disable: AdvancedAi::disable_one_war_swaps_a_stalled_front },
    // Nine rout or turned-tide peace offers at 1.5 times our rival's power on
    // 2026-10-04/05; three were followed by a war on the same rival within
    // 25 turns. See `AdvancedAi::rout_spares_a_stronger_army`.
    Gene { tag: "rout-spares-a-stronger-army", field: "rout_spares_a_stronger_army", kind: Kind::OptIn, enable: AdvancedAi::enable_rout_spares_a_stronger_army, disable: AdvancedAi::disable_rout_spares_a_stronger_army },
    // Live King 122037Z held war on France "for staging" from turn 163 to its
    // Culture win at 181, at 2 to 4 times its power. See
    // `one_war::culture_counter_due`.
    Gene { tag: "culture-counter-declares", field: "culture_counter_declares", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_counter_declares, disable: AdvancedAi::disable_culture_counter_declares },
    // Live King 003728Z offered Phoenicia, holder of Tyre, the last capital
    // it lacked, "the war has stalled" peace at 1.6 times its power. See
    // `one_war::last_capital_war_kept`.
    Gene { tag: "last-capital-war-kept", field: "last_capital_war_kept", kind: Kind::OptIn, enable: AdvancedAi::enable_last_capital_war_kept, disable: AdvancedAi::disable_last_capital_war_kept },
    // Live King 100903Z: two Rocket Artillery stood in Loja through the war
    // on India, their Corps refused and re-planned every turn. Live-only: the
    // refused set is empty off the bridge. See `advanced/formation_refusals.rs`.
    Gene { tag: "formations-heed-refusals", field: "formations_heed_refusals", kind: Kind::OptIn, enable: AdvancedAi::enable_formations_heed_refusals, disable: AdvancedAi::disable_formations_heed_refusals },
    // Live King 003728Z stayed at peace with Sumeria at 17 Diplomatic Victory
    // points and 3 military while Persia won the Diplomatic Victory. See
    // `one_war::diplomatic_contender`.
    Gene { tag: "diplomatic-contender-kept", field: "diplomatic_contender_kept", kind: Kind::OptIn, enable: AdvancedAi::enable_diplomatic_contender_kept, disable: AdvancedAi::disable_diplomatic_contender_kept },
    // Live King 021048Z aimed the army at Indonesia (13 points, 988 military)
    // while at war with Portugal at 15 points and 172 military. See
    // `one_war::diplomatic_contender_front`.
    Gene { tag: "diplomatic-contender-kept-2", field: "diplomatic_contender_kept_2", kind: Kind::OptIn, enable: AdvancedAi::enable_diplomatic_contender_kept_2, disable: AdvancedAi::disable_diplomatic_contender_kept_2 },
    // Live King civvis-20261004T122037Z (game 62): Yaroslavl's walls went
    // 100 -> 84 in twelve turns while the journal read "shooters 6-16 wall a
    // turn": nine archers within five tiles were counted, but the range-2
    // band had room for few of them and those that fired shot units first.
    // G64's Canberra read "6.9 turns" at turn 125 and fell at 148. See
    // `siege_train::shooter_hits_walls`.
    Gene { tag: "siege-counts-posted-shooters", field: "siege_counts_posted_shooters", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_counts_posted_shooters, disable: AdvancedAi::disable_siege_counts_posted_shooters },
    // Live King 013110Z (game 91): Germany took Bogota at turn 42. Four
    // defenders raised the pressure ratio's denominator, the Defend row
    // lapsed at turn 40 with the capital at 20 of 200 and Germans
    // adjacent, and its bodies went to Siege Munich. See
    // `objective_board::capital_defense_contact`.
    Gene { tag: "capital-defense-holds", field: "capital_defense_holds", kind: Kind::OptIn, enable: AdvancedAi::enable_capital_defense_holds, disable: AdvancedAi::disable_capital_defense_holds },
    // Live King civvis-20261005T003728Z (game 89): Mashhad held in Stage
    // from turn 183 to 225; its guns, twelve to fourteen tiles out, stepped
    // between two tiles every frame behind one of ours in a ridge's only gap.
    // See `siege_train::siege_stage_step`.
    Gene { tag: "staging-column-passes-through", field: "staging_column_passes_through", kind: Kind::OptIn, enable: AdvancedAi::enable_staging_column_passes_through, disable: AdvancedAi::disable_staging_column_passes_through },
    // Live King civvis-20261005T024614Z (game 94): fielded Catapults went to
    // the Guayaquil anvil and heal rotations while Lisbon's siege held "for a
    // wall-breaker on its way". See `objective_board::breaker_rows_ask`.
    Gene { tag: "breakers-stay-with-the-siege", field: "breakers_stay_with_the_siege", kind: Kind::OptIn, enable: AdvancedAi::enable_breakers_stay_with_the_siege, disable: AdvancedAi::disable_breakers_stay_with_the_siege },
    // Live King civvis-20261005T033442Z (game 96) offered the Khmer, at 70%
    // of the culture bar, "the war has stalled" peace at turn 207; their
    // Tourism rose 240 -> 357 in the peace and they won on Culture at 223.
    // See `one_war::stalled_peace_spares`.
    Gene { tag: "stalled-peace-spares-the-counter", field: "stalled_peace_spares_the_counter", kind: Kind::OptIn, enable: AdvancedAi::enable_stalled_peace_spares_the_counter, disable: AdvancedAi::disable_stalled_peace_spares_the_counter },
    // Live King civvis-20261005T035848Z (game 97): version 1 opened the
    // race's Holy Site in a 3.6-production city (about 15 turns) and all
    // three religions were founded first. See
    // `BasicAi::prophet_race_takes_a_district_slot_2`.
    Gene { tag: "prophet-race-takes-a-district-slot-2", field: "prophet_race_takes_a_district_slot_2", kind: Kind::OptIn, enable: AdvancedAi::enable_prophet_race_takes_a_district_slot_2, disable: AdvancedAi::disable_prophet_race_takes_a_district_slot_2 },
    // Live King civvis-20261005T033442Z (game 96): Trebuchets marched alone
    // into the reach of Khmer Cuirassiers seen the turn before and lost in
    // the fog, and were one-shot at turns 145 and 146. See
    // `siege_train::siege_stage_step`.
    Gene { tag: "staging-gun-remembers-hostiles", field: "staging_gun_remembers_hostiles", kind: Kind::OptIn, enable: AdvancedAi::enable_staging_gun_remembers_hostiles, disable: AdvancedAi::disable_staging_gun_remembers_hostiles },
    // Live King civvis-20261005T024614Z (game 94) opened its conquest on
    // Lisbon at turn 9 with one city and released it at turn 40, "the commit
    // deadline passed before the force ever assembled" -- the release in 9 of
    // the last 24 live games. See `early_conquest::conquest_force_estimate`.
    Gene { tag: "conquest-opening-needs-the-production", field: "conquest_opening_needs_the_production", kind: Kind::OptIn, enable: AdvancedAi::enable_conquest_opening_needs_the_production, disable: AdvancedAi::disable_conquest_opening_needs_the_production },
    // Live King civvis-20261005T045443Z (game 101) planned Gwangju at 2.85
    // times Korea's power, five techs behind; Hwachas (60) one-shot four
    // Archers and the siege never brought the city under 181. See
    // `city_campaign::war_bill_tier_factor`.
    Gene { tag: "war-bill-prices-the-tier-gap", field: "war_bill_prices_the_tier_gap", kind: Kind::OptIn, enable: AdvancedAi::enable_war_bill_prices_the_tier_gap, disable: AdvancedAi::disable_war_bill_prices_the_tier_gap },
    // Live King civvis-20261005T045443Z (game 101) went to war with Korea at
    // t94 with no war order: AutoClose answered "too many troops near me" with
    // CHOICE_NEGATIVE, a surprise war (150 grievances). 100 such flips in 49 of
    // 74 October live games. See `CivvisControlAutoClose.lua`.
    Gene { tag: "dialogue-never-declares-war", field: "dialogue_never_declares_war", kind: Kind::OptIn, enable: AdvancedAi::enable_dialogue_never_declares_war, disable: AdvancedAi::disable_dialogue_never_declares_war },
    // Live King civvis-20261005T053701Z (game 103) declared on the Maori at
    // turn 74 with Opango behind 100 walls and its Catapult 17 tiles out;
    // the walls stood at 200 by 78 and the city fell at 118. See
    // `siege_train::declaration_breaker_at_hand`.
    Gene { tag: "declaration-waits-for-the-breaker", field: "declaration_waits_for_the_breaker", kind: Kind::OptIn, enable: AdvancedAi::enable_declaration_waits_for_the_breaker, disable: AdvancedAi::disable_declaration_waits_for_the_breaker },
    // Live King civvis-20261005T053701Z (game 103) left the Inca, at 12
    // military against ~600 with Qusqu behind 100 walls nine tiles from
    // Guayaquil, at peace from turn 95 to 125 while it fought the Maori and
    // Vietnam. See `one_war::capital_prey_beside_the_front`.
    Gene { tag: "capital-prey-opens-a-front", field: "capital_prey_opens_a_front", kind: Kind::OptIn, enable: AdvancedAi::enable_capital_prey_opens_a_front, disable: AdvancedAi::disable_capital_prey_opens_a_front },
    // Live King civvis-20261005T060002Z (game 104) aimed its campaign at
    // Greece, at peace and out of declaration range, from turn 147 to 182+
    // with no Siege row to fight. See `one_war::declarable_in_reach`.
    Gene { tag: "front-needs-a-declarable-rival", field: "front_needs_a_declarable_rival", kind: Kind::OptIn, enable: AdvancedAi::enable_front_needs_a_declarable_rival, disable: AdvancedAi::disable_front_needs_a_declarable_rival },
    // Live King civvis-20261005T060002Z (game 104) staged Canberra,
    // Australia's original capital and last city, at turns 85-90, damage
    // ready in 4.2 turns; an urgent counter took the army to Norway at 91
    // and Canberra had no siege again for sixty turns. See
    // `one_war::front_capital_to_finish`.
    Gene { tag: "front-finishes-its-capital", field: "front_finishes_its_capital", kind: Kind::OptIn, enable: AdvancedAi::enable_front_finishes_its_capital, disable: AdvancedAi::disable_front_finishes_its_capital },
    // The same game's counter was Norway's Orthodoxy, holding three majors
    // while all our cities kept Buddhism. See
    // `one_war::religious_threat_spares_the_front`.
    Gene { tag: "religious-threat-spares-the-front", field: "religious_threat_spares_the_front", kind: Kind::OptIn, enable: AdvancedAi::enable_religious_threat_spares_the_front, disable: AdvancedAi::disable_religious_threat_spares_the_front },
    // 58 live games of October 4-5 bounced the campaign A -> B -> A within
    // ten turns 89 times, 53 of them while countering a rival close to
    // winning. See `victory_heuristics::actionable_victory_denial_with_culture_pressures`.
    Gene { tag: "denial-keeps-its-rival", field: "denial_keeps_its_rival", kind: Kind::OptIn, enable: AdvancedAi::enable_denial_keeps_its_rival, disable: AdvancedAi::disable_denial_keeps_its_rival },
    // All 22 October culture losses fired with the winner below the
    // exported bar (median 94%). See
    // `denial_nearest_finish::projected_culture_finish_at`.
    Gene { tag: "culture-finish-at-the-observed-bar", field: "culture_finish_at_the_observed_bar", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_finish_at_the_observed_bar, disable: AdvancedAi::disable_culture_finish_at_the_observed_bar },
    // G104 (civvis-20261005T060002Z) Siege of Sparta: the air-assault barrier
    // withheld frame 0's ground orders, the frame-0 plan's watch and path
    // trail survived, and the next turn barred a step the host was never sent
    // (Rocket Artillery idle t216-223; another "going nowhere" t236). A step
    // our own column held at frame start is congestion, not a refusal either.
    // See `advanced/own_column.rs`.
    Gene { tag: "own-column-is-not-a-refusal", field: "own_column_is_not_a_refusal", kind: Kind::OptIn, enable: AdvancedAi::enable_own_column_is_not_a_refusal, disable: AdvancedAi::disable_own_column_is_not_a_refusal },
    // Live King civvis-20261005T045443Z (game 101): the Wak Kab'nal guns
    // stood 14-18 tiles out from turn 150 to 227, the end of the record,
    // stepping into the coast and back each turn: the strait was 10-15 tiles,
    // the land road 51-57, and `come-ashore` landed every embarked unit at
    // home the next turn.
    // See `siege_train::StageMarch`.
    Gene { tag: "stage-march-keeps-to-land", field: "stage_march_keeps_to_land", kind: Kind::OptIn, enable: AdvancedAi::enable_stage_march_keeps_to_land, disable: AdvancedAi::disable_stage_march_keeps_to_land },
    // Live King civvis-20261005T051413Z (game 102): Toronto's breach reading
    // counted only its own force's guns and read 0 while three healthy
    // Bombards of Uruk's force stood at its ring. See
    // `siege_train::nearby_gun_city`.
    Gene { tag: "breach-counts-nearby-guns", field: "breach_counts_nearby_guns", kind: Kind::OptIn, enable: AdvancedAi::enable_breach_counts_nearby_guns, disable: AdvancedAi::disable_breach_counts_nearby_guns },
    // 70 October live games offered peace at three times the rival's power
    // or more 239 times, every one white; 20 were accepted. See
    // `PEACE_CITY_ASK_RATIO` and `CivvisPeaceCityAsk` in the agent.
    Gene { tag: "peace-asks-a-city", field: "peace_asks_a_city", kind: Kind::OptIn, enable: AdvancedAi::enable_peace_asks_a_city, disable: AdvancedAi::disable_peace_asks_a_city },
    // Live King civvis-20261005T080337Z (game 111) declared no war through
    // turn 200 with Spain at 49 military against 1,080 and Madrid behind 100
    // walls 21 tiles out. See `one_war::capital_prey_reaches_far`.
    Gene { tag: "capital-prey-opens-a-front-2", field: "capital_prey_opens_a_front_2", kind: Kind::OptIn, enable: AdvancedAi::enable_capital_prey_opens_a_front_2, disable: AdvancedAi::disable_capital_prey_opens_a_front_2 },
    // Live King civvis-20261005T080337Z (game 111): the surge reached Strike
    // on urgent Persia by turn 185 and handed the war to a ground declaration
    // that waited on staging to 200. See `air_surge::air_surge_opening`.
    Gene { tag: "air-surge-strikes-through-urgency", field: "air_surge_strikes_through_urgency", kind: Kind::OptIn, enable: AdvancedAi::enable_air_surge_strikes_through_urgency, disable: AdvancedAi::disable_air_surge_strikes_through_urgency },
    // Live King civvis-20261005T081917Z (game 112) lost Xanadu, Mongolia's
    // capital, to Loyalty five turns after taking it, with no Loyalty card
    // and its Governor unestablished. See `one_war::bleeding_capital`.
    Gene { tag: "bleeding-capital-loyalty", field: "bleeding_capital_loyalty", kind: Kind::OptIn, enable: AdvancedAi::enable_bleeding_capital_loyalty, disable: AdvancedAi::disable_bleeding_capital_loyalty },
    // Live King civvis-20261005T081917Z (game 112) kept Singapore at turn
    // 191 with Kongo on 15 points and lost on Diplomacy at 202 by one vote's
    // Favor. See `one_war::liberation_funds_the_congress`.
    Gene { tag: "liberation-funds-the-congress", field: "liberation_funds_the_congress", kind: Kind::OptIn, enable: AdvancedAi::enable_liberation_funds_the_congress, disable: AdvancedAi::disable_liberation_funds_the_congress },
    // Live King civvis-20261005T051413Z (game 102): four fit Bombards stood
    // three tiles from walled Toronto from turn 137 to 145, one tile outside
    // their range, and never fired: every post inside the strike ring read
    // the city's whole blow (~108 against a Bombard) on each gun. See
    // `siege_train::entry_group`.
    Gene { tag: "guns-enter-together", field: "guns_enter_together", kind: Kind::OptIn, enable: AdvancedAi::enable_guns_enter_together, disable: AdvancedAi::disable_guns_enter_together },
    // Live King civvis-20261005T060002Z (game 104): Sparta's breach reading
    // counted land guns only and held "nothing to open the walls" while our
    // Bombers took its walls from 400 to 153. See
    // `siege_train::air_breach_walls`.
    Gene { tag: "breach-reads-the-air", field: "breach_reads_the_air", kind: Kind::OptIn, enable: AdvancedAi::enable_breach_reads_the_air, disable: AdvancedAi::disable_breach_reads_the_air },
    // Live King civvis-20261005T065548Z (game 107) countered France, which
    // read closer to a Culture Victory, and Babylon won on Culture at 206.
    // See `denial_nearest_finish::engine_culture_clock`.
    Gene { tag: "culture-reads-the-engine-clock", field: "culture_reads_the_engine_clock", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_reads_the_engine_clock, disable: AdvancedAi::disable_culture_reads_the_engine_clock },
    // Live King civvis-20261005T083500Z (game 113) offered Spain rout peace
    // at turn 216 at 1.16 times its power and named it the counter's second
    // front at 218. See `one_war::rout_spares_the_counter`.
    Gene { tag: "rout-spares-the-counter", field: "rout_spares_the_counter", kind: Kind::OptIn, enable: AdvancedAi::enable_rout_spares_the_counter, disable: AdvancedAi::disable_rout_spares_the_counter },
    // Live King civvis-20261005T080337Z (G111) missed a Normal Age by one era
    // point: `age-closer-2`'s window opened (era end t107, countdown read live)
    // but the gold operating reserve (650 at 10 cities) priced every closer
    // out. See `AdvancedAi::age_closer_spends_the_reserve`.
    Gene { tag: "age-closer-spends-the-reserve", field: "age_closer_spends_the_reserve", kind: Kind::OptIn, enable: AdvancedAi::enable_age_closer_spends_the_reserve, disable: AdvancedAi::disable_age_closer_spends_the_reserve },
    // Live King civvis-20261005T074521Z (game 110): Tarsus stood without
    // walls in Invest and Reduce from turn 67 to 73, "damage ready" in about
    // two turns, while its only melee beside it was the reserved taker, which
    // never struck a healthy city; the city went 200 -> 191 and built walls at
    // 74. See `siege_train::assault_pays`.
    Gene { tag: "melee-storms-an-open-city", field: "melee_storms_an_open_city", kind: Kind::OptIn, enable: AdvancedAi::enable_melee_storms_an_open_city, disable: AdvancedAi::disable_melee_storms_an_open_city },
    // Live King civvis-20261005T081917Z (game 112) held two of three
    // rival original capitals from turn 138 and never saw Kongo's: its
    // border was sealed and the passage purchase held on a 28 Gold book
    // against a 30 Gold minimum. See `find_the_capital`.
    Gene { tag: "find-the-capital", field: "find_the_capital", kind: Kind::OptIn, enable: AdvancedAi::enable_find_the_capital, disable: AdvancedAi::disable_find_the_capital },
    // 8 of 31 captures in ten live King games (October 5) were lost the very
    // next turn: G105 Vancouver 151 -> 152, walked into by one Pike and Shot
    // with ten of 22 staged; G112 Xanadu flipped to loyalty in five turns at
    // -13.5 a turn; G114 Curitiba sat at walls 0, health 1 with its body six
    // to twelve tiles out. See `siege_train::capture_hold`.
    Gene { tag: "capture-holds-the-ring", field: "capture_holds_the_ring", kind: Kind::OptIn, enable: AdvancedAi::enable_capture_holds_the_ring, disable: AdvancedAi::disable_capture_holds_the_ring },
    // Live King civvis-20261005T084952Z (game 114) bombed Curitiba to walls
    // 0, city 1 at turn 196 with no body able to walk in; it healed to 20.
    // See `air_city_assault::air_assault_followup_routed`.
    Gene { tag: "air-volley-needs-a-road", field: "air_volley_needs_a_road", kind: Kind::OptIn, enable: AdvancedAi::enable_air_volley_needs_a_road, disable: AdvancedAi::disable_air_volley_needs_a_road },
    // Live King civvis-20261005T093932Z (game 117) lost eleven siege guns
    // from turn 137, most to one blow of a hostile seen at turn start. See
    // `advanced/guns_stay_out_of_reach.rs`.
    Gene { tag: "guns-stay-out-of-reach", field: "guns_stay_out_of_reach", kind: Kind::OptIn, enable: AdvancedAi::enable_guns_stay_out_of_reach, disable: AdvancedAi::disable_guns_stay_out_of_reach },
    // Live King civvis-20261005T101841Z (game 120): Australia at 7% of our
    // power, Canberra behind 200 walls, failed the 100-wall gate. See
    // `one_war::capital_prey_walls`.
    Gene { tag: "capital-prey-scales-the-walls", field: "capital_prey_scales_the_walls", kind: Kind::OptIn, enable: AdvancedAi::enable_capital_prey_scales_the_walls, disable: AdvancedAi::disable_capital_prey_scales_the_walls },
    // 91 faith-counter declarations of October 4-5 took 9 cities against 8
    // of 39 other wars. See `one_war::faith_at_match_point`.
    Gene { tag: "faith-counter-waits-for-match-point", field: "faith_counter_waits_for_match_point", kind: Kind::OptIn, enable: AdvancedAi::enable_faith_counter_waits_for_match_point, disable: AdvancedAi::disable_faith_counter_waits_for_match_point },
    // Live King civvis-20261005T103704Z (game 121) read America at 4 for
    // one turn and declared on it. See `one_war::steady_rival_power`.
    Gene { tag: "prey-reads-a-steady-power", field: "prey_reads_a_steady_power", kind: Kind::OptIn, enable: AdvancedAi::enable_prey_reads_a_steady_power, disable: AdvancedAi::disable_prey_reads_a_steady_power },
    // Live King civvis-20261005T111622Z (game 124) declared on Norway at
    // turn 105 and offered it one-war peace the same turn. See
    // `one_war::second_front_recently_named`.
    Gene { tag: "second-front-keeps-its-war", field: "second_front_keeps_its_war", kind: Kind::OptIn, enable: AdvancedAi::enable_second_front_keeps_its_war, disable: AdvancedAi::disable_second_front_keeps_its_war },
    // Live King civvis-20261005T110504Z (game 123) held its Catholic
    // counterweight and spread Protestantism, the winner's faith, in its own
    // cities. See `adopted_faith_sanctuary::stronger_faith_than`.
    Gene { tag: "counterweight-faith-is-no-threat", field: "counterweight_faith_is_no_threat", kind: Kind::OptIn, enable: AdvancedAi::enable_counterweight_faith_is_no_threat, disable: AdvancedAi::disable_counterweight_faith_is_no_threat },
    // 315 Recovery-clause peace offers of October 4-5 came from spells with
    // a median of 2 turns; 7 were accepted at 1.5 times the rival's power.
    // See `one_war::recovery_peace_ready`.
    Gene { tag: "recovery-peace-waits", field: "recovery_peace_waits", kind: Kind::OptIn, enable: AdvancedAi::enable_recovery_peace_waits, disable: AdvancedAi::disable_recovery_peace_waits },
    // Live King civvis-20261005T114715Z (game 126): the culture counter's
    // surprise war drained 184 Favor to 0 while Sweden rose to 17 points. See
    // `one_war::favor_spares_surprise`.
    Gene { tag: "favor-spares-the-surprise-war", field: "favor_spares_the_surprise_war", kind: Kind::OptIn, enable: AdvancedAi::enable_favor_spares_the_surprise_war, disable: AdvancedAi::disable_favor_spares_the_surprise_war },
    // Live King openings of 2026-10-04/05: 4 of 7 named ten or fewer tiles
    // from the capital took their city, 0 of 42 named further out. See
    // `early_conquest::CONQUEST_NEAR_REACH_TILES`.
    Gene { tag: "conquest-opening-stays-near", field: "conquest_opening_stays_near", kind: Kind::OptIn, enable: AdvancedAi::enable_conquest_opening_stays_near, disable: AdvancedAi::disable_conquest_opening_stays_near },
    // Diplomatic losses of October 2-5: about half met the deciding session
    // at 0-40 Favor while holding 200-1,000 Gold, and rivals paid us about
    // 5.5 Gold a point. See `append_favor_buy_order` in `civvis_orders`.
    Gene { tag: "favor-bought-before-congress", field: "favor_bought_before_congress", kind: Kind::OptIn, enable: AdvancedAi::enable_favor_bought_before_congress, disable: AdvancedAi::disable_favor_bought_before_congress },
    // Live King civvis-20261005T124739Z (game 130): Delhi held the campaign
    // at an army median of 15-20 tiles while walled Jabalpur stood 4 from our
    // city. See `stale_domination_objective_city`.
    Gene { tag: "stale-swap-reads-the-march", field: "stale_swap_reads_the_march", kind: Kind::OptIn, enable: AdvancedAi::enable_stale_swap_reads_the_march, disable: AdvancedAi::disable_stale_swap_reads_the_march },
    // Live King civvis-20261005T130519Z (game 131): the war on the Inca held
    // from turn 105 to 125 at 5-13 times their power for a staged siege no
    // board row ordered. See `one_war::overwhelming_power_declares`.
    Gene { tag: "overwhelming-power-declares", field: "overwhelming_power_declares", kind: Kind::OptIn, enable: AdvancedAi::enable_overwhelming_power_declares, disable: AdvancedAi::disable_overwhelming_power_declares },
    // October 4-5 live: 644 luxury purchase asks, every one answered with a
    // refusal and nothing on our side; each held the rival's one working deal
    // and the shared trade cooldown. Off by default; on restores the asks.
    Gene { tag: "luxury-buy-asks", field: "luxury_buy_asks", kind: Kind::OptIn, enable: AdvancedAi::enable_luxury_buy_asks, disable: AdvancedAi::disable_luxury_buy_asks },
    // October 5 live: 452 denunciations, 294 before turn 160 on a technology
    // lead alone; game 131 denounced the Inca while Rome won the space race.
    // See `science_threat_denunciation`.
    Gene { tag: "science-denounce-waits-for-the-race", field: "science_denounce_waits_for_the_race", kind: Kind::OptIn, enable: AdvancedAi::enable_science_denounce_waits_for_the_race, disable: AdvancedAi::disable_science_denounce_waits_for_the_race },
    // Live King civvis-20261005T104725Z (game 122): Tenochtitlan's walls
    // went 13 -> 100 (turns 82-87), 59 -> 100 (98-102) and 40 -> 100
    // (111-116) while every shooter and the gun rotated out to heal at once
    // and nothing hit the walls. See `siege_train::siege_wall_keepers`.
    Gene { tag: "siege-keeps-a-shooter", field: "siege_keeps_a_shooter", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_keeps_a_shooter, disable: AdvancedAi::disable_siege_keeps_a_shooter },
    // 20 of 23 strike_frame_timeouts measured on October 5 were shots at a
    // target a melee blow earlier in the same frame had already killed (live
    // King civvis-20261005T091120Z, turn 20: a Warrior killed the Horse Archer
    // and the Slinger's queued shot was dropped). See `civvis_orders`
    // `ranged_before_melee`.
    Gene { tag: "ranged-before-melee", field: "ranged_before_melee", kind: Kind::OptIn, enable: AdvancedAi::enable_ranged_before_melee, disable: AdvancedAi::disable_ranged_before_melee },
    // Live King civvis-20261005T114715Z (game 126): a Siege Tower stood beside
    // Constantinople (Medieval Walls, 200) at turns 139-140 with a Pike and Shot
    // beside it, and the assault priced the walls and the city together (420)
    // although the tower lets the blow strike the city through the walls; the
    // city stayed at 197-200 from turn 128 to 141. See
    // `siege_train::tower_bypasses`.
    Gene { tag: "tower-assault", field: "tower_assault", kind: Kind::OptIn, enable: AdvancedAi::enable_tower_assault, disable: AdvancedAi::disable_tower_assault },
    // Opening census, 80 live runs October 4-5: of 16 early declared wars, 12
    // never beat the city's 20 a turn of heal; they put 0.03-0.47 shots a turn
    // into the city and the rest into units ahead of it, while the 4
    // captures fired 0.64-1.67 a turn at the city. See
    // `siege_train::ring_is_threatened`.
    Gene { tag: "ring-fires-on-the-city", field: "ring_fires_on_the_city", kind: Kind::OptIn, enable: AdvancedAi::enable_ring_fires_on_the_city, disable: AdvancedAi::disable_ring_fires_on_the_city },
    // October 5 live: new siege guns closed a median 0.80 tiles a turn on
    // their siege and were born 13 tiles out against 7 for our nearest city.
    // See `siege_production::BREAKER_MARCH_FACTOR`.
    Gene { tag: "breaker-reads-the-march", field: "breaker_reads_the_march", kind: Kind::OptIn, enable: AdvancedAi::enable_breaker_reads_the_march, disable: AdvancedAi::disable_breaker_reads_the_march },
    // Live King civvis-20261005T134450Z (game 133): the front left Byzantium
    // at 14 points and 6 cities for Korea's capital; Byzantium won on
    // Diplomacy. See `one_war::diplomatic_contender_to_eliminate`.
    Gene { tag: "diplomatic-contender-eliminated", field: "diplomatic_contender_eliminated", kind: Kind::OptIn, enable: AdvancedAi::enable_diplomatic_contender_eliminated, disable: AdvancedAi::disable_diplomatic_contender_eliminated },
    // Oct 4-5 live: 25 staged declarations under 1.5 times the target's
    // power took a city twice; game 135 declared on the Maya at 1.02 times.
    // See `one_war::declaration_has_the_edge`.
    Gene { tag: "declaration-needs-the-edge", field: "declaration_needs_the_edge", kind: Kind::OptIn, enable: AdvancedAi::enable_declaration_needs_the_edge, disable: AdvancedAi::disable_declaration_needs_the_edge },
    // Live King civvis-20261005T141932Z (game 135): one capital (Madrid)
    // from Domination, the front drifted to commitments and a second front;
    // the Maya won on Diplomacy. See `one_war::domination_finish_front`.
    Gene { tag: "domination-finish-holds-the-front", field: "domination_finish_holds_the_front", kind: Kind::OptIn, enable: AdvancedAi::enable_domination_finish_holds_the_front, disable: AdvancedAi::disable_domination_finish_holds_the_front },
    // Live King civvis-20261005T141932Z (game 135): a threatened city flipped
    // the war to Recovery at 1848 power against 645, one capital from
    // Domination. See `RECOVERY_THREAT_POWER_RATIO`.
    Gene { tag: "recovery-needs-the-deficit", field: "recovery_needs_the_deficit", kind: Kind::OptIn, enable: AdvancedAi::enable_recovery_needs_the_deficit, disable: AdvancedAi::disable_recovery_needs_the_deficit },
    // 22 of the 32 Culture losses of October 4-5 took no city in their last
    // 40 turns; the tourism leader 40 turns out was the winner 18 times in
    // 30. See `AdvancedAi::tourism_leader`.
    Gene { tag: "campaign-weighs-the-tourism-leader", field: "campaign_weighs_the_tourism_leader", kind: Kind::OptIn, enable: AdvancedAi::enable_campaign_weighs_the_tourism_leader, disable: AdvancedAi::disable_campaign_weighs_the_tourism_leader },
    // Live King civvis-20261005T150407Z (game 138): Ethiopia on 14 points at
    // a quarter of our power was passed for Mali at 201 and won on Diplomacy
    // at 235. See `one_war::diplomatic_contender_at_peace`.
    Gene { tag: "contender-at-peace-is-the-target", field: "contender_at_peace_is_the_target", kind: Kind::OptIn, enable: AdvancedAi::enable_contender_at_peace_is_the_target, disable: AdvancedAi::disable_contender_at_peace_is_the_target },
    // 7 of 30 live runs built a Government Plaza (October 5), so no Grand
    // Master's Chapel and no Faith-bought land units; up to 3,590 Faith
    // unspent. See `BasicAi::plaza_in_the_district_list`.
    Gene { tag: "plaza-in-the-district-list", field: "plaza_in_the_district_list", kind: Kind::OptIn, enable: AdvancedAi::enable_plaza_in_the_district_list, disable: AdvancedAi::disable_plaza_in_the_district_list },
    // Live King civvis-20261005T152615Z (game 139): Mongolia's Mars Base read
    // 65 under a culture clock that never finished; Mongolia won on Science.
    // See `AdvancedAi::science_race_pressure`.
    Gene { tag: "science-ladder-reads-the-clock", field: "science_ladder_reads_the_clock", kind: Kind::OptIn, enable: AdvancedAi::enable_science_ladder_reads_the_clock, disable: AdvancedAi::disable_science_ladder_reads_the_clock },
    // Staging marches took the router's single step and stood: 47-62% of
    // live frame-0 MOVE_TOs were one tile. See `march_moves`.
    Gene { tag: "march-uses-its-moves", field: "march_uses_its_moves", kind: Kind::OptIn, enable: AdvancedAi::enable_march_uses_its_moves, disable: AdvancedAi::disable_march_uses_its_moves },
    // Live King civvis-20261005T141932Z (game 135): the Siege of Wak Kab'nal
    // read Reduce at walls 15/100 for turns 71-78 with 1-2 of 4-10 members
    // staged, the rest one tile a turn behind. See `close_to_staging`.
    Gene { tag: "siege-members-use-their-moves", field: "siege_members_use_their_moves", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_members_use_their_moves, disable: AdvancedAi::disable_siege_members_use_their_moves },
    Gene { tag: "guns-grind-the-walls", field: "guns_grind_the_walls", kind: Kind::OptIn, enable: AdvancedAi::enable_guns_grind_the_walls, disable: AdvancedAi::disable_guns_grind_the_walls },
    // Under war-bill-prices-the-tier-gap the tech gap was priced three times:
    // in the city's own strength, in the tech edge, and by the tier factor
    // over both. Live G129 held off Kongo at 2.1x power behind a 304 bill;
    // armed games' siege bills ran a median 1.74x the rival's WHOLE military
    // at >=2x power (0.99x before). See `AdvancedAi::campaign_city_requirement`.
    Gene { tag: "tier-gap-priced-once", field: "tier_gap_priced_once", kind: Kind::OptIn, enable: AdvancedAi::enable_tier_gap_priced_once, disable: AdvancedAi::disable_tier_gap_priced_once },
    // Live King G136: decisive-window took Military Engineering at t87 for a
    // Bombard with no Niter income until t142, and "modernize the army"
    // spent t93-t103 on Field Cannons while the Victoria siege waited 77
    // turns for a breaker. Resources priced; modernization yields while a
    // siege is held for its breaker. See `advanced/decisive_window.rs`.
    Gene { tag: "breaker-research-first", field: "breaker_research_first", kind: Kind::OptIn, enable: AdvancedAi::enable_breaker_research_first, disable: AdvancedAi::disable_breaker_research_first },
    Gene { tag: "breach-support-reads-the-wall-tier", field: "breach_support_reads_the_wall_tier", kind: Kind::OptIn, enable: AdvancedAi::enable_breach_support_reads_the_wall_tier, disable: AdvancedAi::disable_breach_support_reads_the_wall_tier },
    Gene { tag: "second-front-waits-for-its-war", field: "second_front_waits_for_its_war", kind: Kind::OptIn, enable: AdvancedAi::enable_second_front_waits_for_its_war, disable: AdvancedAi::disable_second_front_waits_for_its_war },
    // Live King 10-04/05: 537 walled Invest/Reduce siege-turns had fit guns
    // within seven tiles that would open the walls in four turns or fewer,
    // and 58% saw no shot on the city: guns posted two tiles out walked to
    // three and held there, the approach charging each the city's whole
    // reply plus 20. See `siege_train::near_breach`.
    Gene { tag: "guns-post-for-a-near-breach", field: "guns_post_for_a_near_breach", kind: Kind::OptIn, enable: AdvancedAi::enable_guns_post_for_a_near_breach, disable: AdvancedAi::disable_guns_post_for_a_near_breach },
    // Live King 10-04/05 (88 games): a Golden or Heroic Age does not rank its
    // Dedication, so the alphabetical tie-break took Exodus of the
    // Evangelists in 57 of 81 Medieval Golden Ages, whose Golden half
    // (Missionaries, Great Prophet points) a seat with no religion never
    // spends. See `ai::choose_conquest_dedications`.
    Gene { tag: "golden-dedication-serves-the-conquest", field: "golden_dedication_serves_the_conquest", kind: Kind::OptIn, enable: AdvancedAi::enable_golden_dedication_serves_the_conquest, disable: AdvancedAi::disable_golden_dedication_serves_the_conquest },
    // The race's Holy Site builds its Shrine and Revelation takes the
    // wildcard while a Prophet is open. See `advanced/prophet_race_points.rs`.
    Gene { tag: "prophet-race-earns-its-points", field: "prophet_race_earns_its_points", kind: Kind::OptIn, enable: AdvancedAi::enable_prophet_race_earns_its_points, disable: AdvancedAi::disable_prophet_race_earns_its_points },
    // Version 2 of `declaration-needs-the-edge` (2026-10-05): a staged
    // declaration needs twice the target's 30-turn peak power, or version 1's
    // 1.5 times its steady power against a rival out-produced. Live King
    // October 4-5: 45 of 180 declarations were routs, the rival out-building
    // us (its Production over ours read AUC 0.80); the rule blocks 29 of the
    // 30 staged routs for 2 of 26 captures. See `one_war::declaration_edge_2`.
    Gene { tag: "declaration-needs-the-edge-2", field: "declaration_needs_the_edge_2", kind: Kind::OptIn, enable: AdvancedAi::enable_declaration_needs_the_edge_2, disable: AdvancedAi::disable_declaration_needs_the_edge_2 },
    // The religion counter's waiver of the staged siege needs 1.5 times the
    // rival's steady power. Live King game 152 countered Indonesia at 358
    // against 350, was routed, took nothing, and lost to its religion. See
    // `one_war::faith_counter_has_the_edge`.
    Gene { tag: "faith-counter-needs-the-edge", field: "faith_counter_needs_the_edge", kind: Kind::OptIn, enable: AdvancedAi::enable_faith_counter_needs_the_edge, disable: AdvancedAi::disable_faith_counter_needs_the_edge },
    // Live King G148 stood Mikisiw-Wacîhk down at turn 112, five turns after
    // its first fit gun came, with 10 of 16 staged, and was back there at
    // 145; G150 stood Karkar down at 92 on the turn its train stepped into
    // Invest reading "damage ready true". See
    // `commitments::muster_after_the_breaker` and
    // `commitments::rebase_capture_on_a_forward_step`.
    Gene { tag: "stall-waits-for-the-breach", field: "stall_waits_for_the_breach", kind: Kind::OptIn, enable: AdvancedAi::enable_stall_waits_for_the_breach, disable: AdvancedAi::disable_stall_waits_for_the_breach },
    // Live King civvis-20261005T191828Z (game 155): with Vietnam gone, 13
    // Missionaries bought in Confucian Bogota and Thang Long as the "safe"
    // counterfaith (Maya alone held out) took our cities from 0 of 10
    // Confucian at turn 100 to 10 of 11 at 178; Babylon won on Religion at
    // 232. See `adopted_faith_sanctuary::counterfaith_is_safe`.
    Gene { tag: "counterfaith-leaves-two-holdouts", field: "counterfaith_leaves_two_holdouts", kind: Kind::OptIn, enable: AdvancedAi::enable_counterfaith_leaves_two_holdouts, disable: AdvancedAi::disable_counterfaith_leaves_two_holdouts },
    // `flipped-capital-finishes`: a Free City holding the last original
    // capital Domination needs is the plan's finishing front. Live King
    // civvis-20261005T193504Z (game 156) held Canberra and took
    // Mikisiw-Wacîhk at 167 and Washington at 174; Mikisiw flipped to the
    // Free Cities at 172 and Washington at 182, and with the other two held
    // the campaign sieged Los Angeles, Pihtokahanapiwiyin and Mistawasis
    // instead. The Free Cities seat is barbarian-flagged, so no finishing
    // rule or wartime front ever named it. See
    // `victory_heuristics::free_city_finish`.
    Gene { tag: "flipped-capital-finishes", field: "flipped_capital_finishes", kind: Kind::OptIn, enable: AdvancedAi::enable_flipped_capital_finishes, disable: AdvancedAi::disable_flipped_capital_finishes },
    // `siege-target-needs-a-road`: half or more of a siege train held on land
    // for want of a road three turns running stands the capture down, and its
    // owner leaves the campaign while no land road reaches it. Live King
    // civvis-20261005T200350Z (game 158): Apu's road ran through Poland's
    // closed borders; 7 to 18 units mustered at 0% ready from turn 129 to 160.
    // See `advanced/siege_road.rs`.
    Gene { tag: "siege-target-needs-a-road", field: "siege_target_needs_a_road", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_target_needs_a_road, disable: AdvancedAi::disable_siege_target_needs_a_road },
    // `opening-yields-to-walls`: a declared conquest opening that has taken
    // nothing asks for terms and stands down when its target walls up with
    // no breaker held, or after the patience window with the city undented.
    // 13 of 16 openings on 10-04/05 took nothing, 9 of their targets walled
    // up 1-38 turns after the declaration, and each war ran until the strike
    // force was dead or the rival made peace, 20-130 turns later. See
    // `early_conquest::conquest_yields_to_walls`.
    Gene { tag: "opening-yields-to-walls", field: "opening_yields_to_walls", kind: Kind::OptIn, enable: AdvancedAi::enable_opening_yields_to_walls, disable: AdvancedAi::disable_opening_yields_to_walls },
    // Live King 10-05 (40 runs, t1-80): the floor built 157 units in a
    // Domination war's lent margin while the empire held under one Builder
    // per two cities; a third of worked tiles improved at t60. See
    // `BasicAi::builders_before_the_lent_floor`.
    Gene { tag: "builders-before-the-lent-floor", field: "builders_before_the_lent_floor", kind: Kind::OptIn, enable: AdvancedAi::enable_builders_before_the_lent_floor, disable: AdvancedAi::disable_builders_before_the_lent_floor },
    // Live King game 160 (civvis-20261005T203103Z): an early Settler bound to
    // six tiles of its capital stood stranded from turn 29 to 66 and the
    // empire held two cities at t60. See
    // `settler_never_idles::settler_stranded`.
    Gene { tag: "stranded-settler-leaves-the-corridor", field: "stranded_settler_leaves_the_corridor", kind: Kind::OptIn, enable: AdvancedAi::enable_stranded_settler_leaves_the_corridor, disable: AdvancedAi::disable_stranded_settler_leaves_the_corridor },
    // `blocker-becomes-the-target`: the major whose closed borders shut a
    // stood-down siege's road, when it passes the version-2 declaration edge
    // and holds an original capital, becomes the war (a second front, or the
    // campaign target at peace), declared on without a staged siege. 13 of
    // 50 border-blocked windows on 10-04/05 were shut by such a major; we
    // warred it later in 3. See `advanced/siege_road.rs`.
    Gene { tag: "blocker-becomes-the-target", field: "blocker_becomes_the_target", kind: Kind::OptIn, enable: AdvancedAi::enable_blocker_becomes_the_target, disable: AdvancedAi::disable_blocker_becomes_the_target },
    // Live King 10-04/05: 59% of the 3,926 land soldiers lost in combat died
    // while their siege read Stage, 772 on the staging ring itself, walking
    // in one by one. See `siege_train::muster_step`.
    Gene { tag: "stage-musters-out-of-reach", field: "stage_musters_out_of_reach", kind: Kind::OptIn, enable: AdvancedAi::enable_stage_musters_out_of_reach, disable: AdvancedAi::disable_stage_musters_out_of_reach },
    // siege_stage_step shared its danger field and then read the unshared
    // sum: each staging gun read every hostile's blow as its own and held
    // behind its train. See `siege_train::stage_gun_danger`.
    Gene { tag: "staging-gun-reads-the-shared-danger", field: "staging_gun_reads_the_shared_danger", kind: Kind::OptIn, enable: AdvancedAi::enable_staging_gun_reads_the_shared_danger, disable: AdvancedAi::disable_staging_gun_reads_the_shared_danger },
    // Live King G175 declared on Nubia at 1.4 times under the urgent waiver
    // and was routed within seven turns; staged wars under 1.5 times routed
    // 13 of 17 on October 4-5. See `one_war::urgent_denial_has_the_edge`.
    Gene { tag: "urgent-denial-needs-the-edge", field: "urgent_denial_needs_the_edge", kind: Kind::OptIn, enable: AdvancedAi::enable_urgent_denial_needs_the_edge, disable: AdvancedAi::disable_urgent_denial_needs_the_edge },
    // Live King 10-04/05: of 4,763 bomber combats flown while a 300+-wall
    // siege stood, 30% hit that city; the rest pillaged or struck units, most
    // nine or more tiles away. See `siege_train::siege_wall_sortie`.
    Gene { tag: "bombers-open-the-siege-walls", field: "bombers_open_the_siege_walls", kind: Kind::OptIn, enable: AdvancedAi::enable_bombers_open_the_siege_walls, disable: AdvancedAi::disable_bombers_open_the_siege_walls },
    // Live King 10-05/06: 83% of Stage siege-turns with air support read the
    // damage budget infinite; the bombers' blows counted on the walls only, so
    // a melee-and-air train never out-fired the city's heal. See
    // `victory_conversion::conversion_siege_budget_within`.
    Gene { tag: "air-fire-counts-on-the-city", field: "air_fire_counts_on_the_city", kind: Kind::OptIn, enable: AdvancedAi::enable_air_fire_counts_on_the_city, disable: AdvancedAi::disable_air_fire_counts_on_the_city },
    // After a rival's capital fell, a refused "required capital is secure"
    // peace kept the army on its towns (median 13 siege-turns in the losses
    // another rival won); the elimination front held on a contender while a
    // shorter clock ran out. See `capital_moves_on`.
    Gene { tag: "capital-taken-moves-on", field: "capital_taken_moves_on", kind: Kind::OptIn, enable: AdvancedAi::enable_capital_taken_moves_on, disable: AdvancedAi::disable_capital_taken_moves_on },
    // Live King G179 (civvis-20261006T011806Z) held off war with Nubia at 3x
    // its power: Sedeinga's ask was 566 because Nubia's Crossbows (40) over
    // our stale Archer (25) read a 1.82 tier factor while our Musketmen (55)
    // out-tiered every Nubian unit. See `city_campaign::war_bill_tier_gap`.
    Gene { tag: "tier-gap-reads-the-fielded-line", field: "tier_gap_reads_the_fielded_line", kind: Kind::OptIn, enable: AdvancedAi::enable_tier_gap_reads_the_fielded_line, disable: AdvancedAi::disable_tier_gap_reads_the_fielded_line },
    // Live 10-05/06: 176 sieges reached a city with no walls; 33 took it
    // unwalled, 107 never did, and 63% of those rows read "damage ready false
    // with inf turns" because a melee blow counted only as the finishing one.
    // Kish (G183, civvis-20261006T021637Z) took one blow at t96 and built
    // walls by t98. A breached wall (0/N) is the same city: Angkor Wat (G193,
    // civvis-20261006T042958Z) sat at 155-173 behind 0/200 from t96 to t99.
    // See `conversion_siege_budget_within`, `swarm_blow` and `swarm_close`.
    Gene { tag: "unwalled-city-takes-the-swarm", field: "unwalled_city_takes_the_swarm", kind: Kind::OptIn, enable: AdvancedAi::enable_unwalled_city_takes_the_swarm, disable: AdvancedAi::disable_unwalled_city_takes_the_swarm },
    // Live Emperor G186 (civvis-20261006T025742Z): Indonesia's Hinduism held
    // every major but the Aztecs from turn 52, its Missionaries and Apostles
    // stood beside our cities, no Indonesian city was ever located, and the
    // religious interception refused every turn from 53 because a war on
    // Sweden was running; Indonesia won on Religion at 84. See
    // `religious_interception::match_point_defence_has_the_edge`.
    Gene { tag: "religious-match-point-defence", field: "religious_match_point_defence", kind: Kind::OptIn, enable: AdvancedAi::enable_religious_match_point_defence, disable: AdvancedAi::disable_religious_match_point_defence },
    // Live Emperor G186 bought a Missionary in Hindu Bogota on the turn the
    // host refused our founding, so it came out Hindu, and as a founder spread
    // Hinduism from Bogota's tile on turns 49-51, two of them into our new
    // Buddhist Holy City. See `advanced/founder_faith.rs`.
    Gene { tag: "founder-spreads-only-its-faith", field: "founder_spreads_only_its_faith", kind: Kind::OptIn, enable: AdvancedAi::enable_founder_spreads_only_its_faith, disable: AdvancedAi::disable_founder_spreads_only_its_faith },
    // Emperor G185-G190 (civvis-20261006T024058Z..T035131Z) all lost to
    // Science at 202-237; the counter first named a Science race at G187
    // t190 (the Maya; the Zulu won). The Science-a-turn leader was the winner
    // in all five at t80/100/120, and in 15 of 23 Science losses of 10-05/06
    // at t110 (tech-count leader 9). See `advanced/science_leader.rs`.
    Gene { tag: "science-leader-is-the-target", field: "science_leader_is_the_target", kind: Kind::OptIn, enable: AdvancedAi::enable_science_leader_is_the_target, disable: AdvancedAi::disable_science_leader_is_the_target },
    // Emperor G188 (Mapuche, t170) and G192 (Greece, t160) declared the culture
    // counter at 1.6x: our military 1,062 -> 732 and Greece took 4 of our 10
    // cities. Of 53 culture/faith counter wars on 10-05/06, those under 2.5x
    // lost a city 3 times in 27, those over it 0 in 26. G191 embargoed India
    // with no city located. See `one_war::counter_war_has_the_emperor_edge`.
    Gene { tag: "counter-war-needs-the-emperor-edge", field: "counter_war_needs_the_emperor_edge", kind: Kind::OptIn, enable: AdvancedAi::enable_counter_war_needs_the_emperor_edge, disable: AdvancedAi::disable_counter_war_needs_the_emperor_edge },
    // Live Emperor 10-06: ten siege targets went from no walls to 100 or 400
    // in one turn once threatened, and 12 of 14 declarations on majors struck
    // nothing on the declaration turn; G201 declared on Poland with nobody
    // near Bydgoszcz, walled 400 the next turn. See
    // `siege_train::first_strike_blows`.
    Gene { tag: "unwalled-target-declares-into-the-strike", field: "unwalled_target_declares_into_the_strike", kind: Kind::OptIn, enable: AdvancedAi::enable_unwalled_target_declares_into_the_strike, disable: AdvancedAi::disable_unwalled_target_declares_into_the_strike },
    // Live 10-04..06: 1,206 raid orders rode out on turns a siege of ours
    // stood in Invest or Reduce (63 of 105 games); the raid kept only bodies
    // within two tiles of the city, so the train's cavalry on its ring rode
    // off. See `siege_train::siege_needs_the_unit`.
    Gene { tag: "invest-keeps-its-cavalry", field: "invest_keeps_its_cavalry", kind: Kind::OptIn, enable: AdvancedAi::enable_invest_keeps_its_cavalry, disable: AdvancedAi::disable_invest_keeps_its_cavalry },
    // Live Emperor 10-06: capitals defend at a median 90 against our melee's
    // 45 where our techs unlock 64; the few upgrades our Gold affords (9-34 a
    // game) went to whichever unit gained most per Gold, home garrison or not.
    // See `siege_train::upgrade_for_the_train`.
    Gene { tag: "siege-train-upgrades-first", field: "siege_train_upgrades_first", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_train_upgrades_first, disable: AdvancedAi::disable_siege_train_upgrades_first },
    // Live Emperor 10-06/07: in 35 of 120 runs a siege march held short of a
    // third major's closed borders (102 city-holds, the water crossing round
    // them a median 19 steps); 1 of those cities fell. The bridge's passage
    // purchase closed 42 of 47 asks, but only for exploration. See
    // `siege_road::siege_passage_blockers`.
    Gene { tag: "siege-buys-the-passage", field: "siege_buys_the_passage", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_buys_the_passage, disable: AdvancedAi::disable_siege_buys_the_passage },
    // Live Emperor 10-06/07: 448 city-turns of "holds at the muster line" in
    // 46 runs came while the target's military stood at 0.3x ours or under;
    // the holds sat a median 10 tiles out (p75 16) because the target's
    // other cities' strikes barred every nearer stand. See
    // `siege_train::MUSTER_WEAK_TARGET_SHARE`.
    Gene { tag: "weak-target-skips-the-muster", field: "weak_target_skips_the_muster", kind: Kind::OptIn, enable: AdvancedAi::enable_weak_target_skips_the_muster, disable: AdvancedAi::disable_weak_target_skips_the_muster },
    // Live Emperor 10-06: Tüngliyou (game 242) sat at walls 0 and one health
    // from turn 155 to 158 with its reserved Pike and Shot beside it at 29
    // health, one under the 30 a taker must keep. See
    // `air_city_assault::air_assault_capture`.
    Gene { tag: "wounded-taker-finishes-the-breach", field: "wounded_taker_finishes_the_breach", kind: Kind::OptIn, enable: AdvancedAi::enable_wounded_taker_finishes_the_breach, disable: AdvancedAi::disable_wounded_taker_finishes_the_breach },
    // Live Emperor 10-06: G194 declared on Vietnam at 2.7x with Dong Hoi
    // already behind 200 walls and one gun, its budget 18.0 turns against 8.7
    // endurance; walls 300 by t89 and no city fell. Walled-target wars without
    // a breach took nothing in G188, G192 or G194. See
    // `siege_train::declaration_breach_reading`.
    Gene { tag: "declaration-waits-for-the-breach", field: "declaration_waits_for_the_breach", kind: Kind::OptIn, enable: AdvancedAi::enable_declaration_waits_for_the_breach, disable: AdvancedAi::disable_declaration_waits_for_the_breach },
    // Live Emperor G200: Quito's Shrine opened the Confucian counterweight at
    // turn 103 with 565 Faith banked and Buddhism on 8 of our 10 cities; the
    // seat paid 260 for a Great Scientist and kept two Missionaries, and
    // Mongolia won on Religion at 108. See `advanced/counterweight_bank.rs`.
    Gene { tag: "counterweight-spends-the-bank", field: "counterweight_spends_the_bank", kind: Kind::OptIn, enable: AdvancedAi::enable_counterweight_spends_the_bank, disable: AdvancedAi::disable_counterweight_spends_the_bank },
    // Live Emperor G185-G198 (civvis-20261006T024058Z..T053813Z): 5.0
    // citizens a city at t100 against the best rival's 8.3, production per
    // citizen at parity; 49% of city-turns t60-120 at or within one of the
    // housing cap with no Granary, building Campus 13% / Settler 11% / Granary
    // 5%; 61% of cities short of Amenities. See
    // `BasicAi::housing_bound_granary_step`.
    Gene { tag: "housing-bound-city-builds-its-granary", field: "housing_bound_city_builds_its_granary", kind: Kind::OptIn, enable: AdvancedAi::enable_housing_bound_city_builds_its_granary, disable: AdvancedAi::disable_housing_bound_city_builds_its_granary },
    // Live Emperor G185-G198: 20 declarations on majors took 4 cities; the 16
    // made under 0.8 times the target's Production took 1 within 40 turns.
    // At war 54% of production went to the army (32% at peace) and our power
    // fell a median 43% from its peak. See
    // `one_war::declaration_has_production_parity`.
    Gene { tag: "declaration-needs-production-parity", field: "declaration_needs_production_parity", kind: Kind::OptIn, enable: AdvancedAi::enable_declaration_needs_production_parity, disable: AdvancedAi::disable_declaration_needs_production_parity },
    // Live Emperor G185-G198: Gold a turn 0.55x the best rival's at t50,
    // 0.15x at t100 (net 14 against 63), 0.11x at t125, unit upkeep 20 -> 42
    // eating 45-65% of the cities' gross Gold; no Commercial Hub or Market in
    // any of the 13 games at t100, trade route capacity 1-2 until t150. See
    // `BasicAi::commercial_hub_step` and `advanced/commercial_routes.rs`.
    Gene { tag: "commercial-hub-and-traders", field: "commercial_hub_and_traders", kind: Kind::OptIn, enable: AdvancedAi::enable_commercial_hub_and_traders, disable: AdvancedAi::disable_commercial_hub_and_traders },
    // Live Emperor G210-G211 (declaration-needs-production-parity armed):
    // no offensive declaration in either game while our Production read 0.28
    // to 0.79 times the target empire's, and both lost to Culture at turns
    // 181 and 175 as the strongest military. Against the target's cities
    // within 12 tiles of our cities or the objective (its public Production
    // shared out by population) it read 0.83 to 2.1 on Macedon t64-117 and
    // 1.4 to 4.4 on Rome t55-109; from t118 Macedon's capital stood on the
    // front and held it. See `one_war::rival_front_production`.
    Gene { tag: "parity-reads-the-front", field: "parity_reads_the_front", kind: Kind::OptIn, enable: AdvancedAi::enable_parity_reads_the_front, disable: AdvancedAi::disable_parity_reads_the_front },
    // Emperor Religious defeats of October 6: we founded in five of six, and
    // four kept one Shrine city to the end; the defence ended when it flipped
    // (G186 9 turns after founding, G212 11, G215 47). See
    // `advanced/second_faith_source.rs`.
    Gene { tag: "founder-keeps-two-sources", field: "founder_keeps_two_sources", kind: Kind::OptIn, enable: AdvancedAi::enable_founder_keeps_two_sources, disable: AdvancedAi::disable_founder_keeps_two_sources },
    // Live Emperor G215 spent over 700 Faith on seven Missionaries and three
    // Builders from founding to turn 92 and first afforded its Apostle two
    // turns before Bogota fell; G213, the one founder that launched the
    // Inquisition, held 49 turns as the last holdout. See
    // `advanced/inquisition_first.rs`.
    Gene { tag: "founder-funds-the-inquisition", field: "founder_funds_the_inquisition", kind: Kind::OptIn, enable: AdvancedAi::enable_founder_funds_the_inquisition, disable: AdvancedAi::disable_founder_funds_the_inquisition },
    // Live Emperor 2026-10-06 (35 games): a University started a median 15
    // turns after its Campus city held the Library and Education (p75 32;
    // 41 of 218 cities never), 0 / 1 / 3 per game at t100 / t125 / t150,
    // while 28% of that wait went to new districts, ordinary buildings and
    // district projects. See `BasicAi::campus_buildings_first`.
    Gene { tag: "campus-buildings-first", field: "campus_buildings_first", kind: Kind::OptIn, enable: AdvancedAi::enable_campus_buildings_first, disable: AdvancedAi::disable_campus_buildings_first },
    // Live Emperor 2026-10-06 (42 games): the first Industrial Zone a median
    // 40 turns after Apprenticeship (t80 -> t120), a second in 23 games at
    // t180; none in 29 of 41 games at t100, 1 zone / 1 Workshop / 0 Factories
    // at t150 at 0.46x the best rival's Production, while the three most
    // productive cities built soldiers 44% of the turns a zone was placeable.
    // See `BasicAi::industrial_zone_in_the_producers`.
    Gene { tag: "industrial-zone-in-the-producers", field: "industrial_zone_in_the_producers", kind: Kind::OptIn, enable: AdvancedAi::enable_industrial_zone_in_the_producers, disable: AdvancedAi::disable_industrial_zone_in_the_producers },
    // Live Emperor 2026-10-06 (24 Science losses): once the winner's pad was
    // on the board, 42 of 73 spy postings and 27 of 45 Rocketry disruptions
    // went to another rival's pad -- 26 postings to a rival at war with us
    // while the winner led -- and 9 of 24 games ever disrupted the winner.
    // The leading threat's free pad outranks every other posting, and an idle
    // spy in a non-threat foreign city is re-posted to it. Requires and arms
    // `science-threat-denial`. See `advanced/science_threat_denial.rs`.
    Gene { tag: "science-denial-spy-reads-the-leader", field: "science_denial_spy_reads_the_leader", kind: Kind::OptIn, enable: AdvancedAi::enable_science_denial_spy_reads_the_leader, disable: AdvancedAi::disable_science_denial_spy_reads_the_leader },
    // `theater-keeps-its-amphitheater` (2026-10-06): the Great Work veto
    // refused every Amphitheater on the Domination seat, so the strategic
    // scorer never ordered one. Live Emperor (55 games): 141 of 249 completed
    // Theater Squares never got an Amphitheater (a median 73 turns standing),
    // the 108 that did were all `pick_item` orders a median 35 turns late, and
    // our culture ran 0.23-0.25 of the best rival's. The veto passes over an
    // Amphitheater in a city that holds a Theater Square. See
    // `AdvancedAi::theater_keeps_its_amphitheater`.
    Gene { tag: "theater-keeps-its-amphitheater", field: "theater_keeps_its_amphitheater", kind: Kind::OptIn, enable: AdvancedAi::enable_theater_keeps_its_amphitheater, disable: AdvancedAi::disable_theater_keeps_its_amphitheater },
    // Live Emperor 2026-10-06 (47 runs with commercial-hub-and-traders armed):
    // Gold a turn 14 net / 30 gross at t100 against the best rival's 66 net,
    // no Commercial Hub or Market at t100 or t120 (median), the first hub a
    // median 55 turns after the step opens; the strategic governor's scorer
    // made 43% of the build starts in hub-ready cities and never a hub. The
    // hub step also runs in its idle queues. Requires and arms
    // `commercial-hub-and-traders`. See `BasicAi::commercial_hub_step`.
    Gene { tag: "commercial-hub-in-the-strategic-queue", field: "commercial_hub_in_the_strategic_queue", kind: Kind::OptIn, enable: AdvancedAi::enable_commercial_hub_in_the_strategic_queue, disable: AdvancedAi::disable_commercial_hub_in_the_strategic_queue },
    // `urban-planning-fills-the-slot`: Urban Planning is wanted at the tail
    // of every portfolio, so it fills a slot no wanted card holds.
    Gene { tag: "urban-planning-fills-the-slot", field: "urban_planning_fills_the_slot", kind: Kind::OptIn, enable: AdvancedAi::enable_urban_planning_fills_the_slot, disable: AdvancedAi::disable_urban_planning_fills_the_slot },
    // `growth-prices-the-farm`: 122 Emperor runs: our cities hold 5.1 citizens
    // against the best rival's 8.6; 52-60% sit within one of their Housing and
    // grow 1.19 citizens in 20 turns against 1.91 with room; 19-30% have no
    // Food surplus and grow 0.50. Builders laid 6.1 Mines to 4.3 Farms a run by
    // turn 100 because the Farm's Housing was never priced and Food weighs 1.2
    // to Production's 2.8 under Conquest. In a city below 12 citizens an
    // improvement's Housing is worth 6.0 a point while the city is Housing-bound
    // and its Food a further 1.6 while the surplus is at most one. See
    // `advanced/growth_farm.rs`.
    Gene { tag: "growth-prices-the-farm", field: "growth_prices_the_farm", kind: Kind::OptIn, enable: AdvancedAi::enable_growth_prices_the_farm, disable: AdvancedAi::disable_growth_prices_the_farm },
    // `breakers-match-the-walls`: 6,060 hopeless siege decisions of 10-06/07
    // (inf or 20+ turns): 69% sat in Stage with no fit gun though guns were
    // alive in 87% of them, and ~70% of the infinite budgets were the gun
    // tier and count (-d8): three Trebuchets against 300 walls at a city
    // strength of 85 strike ~6 a shot. The campaign target's Siege row asks
    // the guns that breach its walls and take its health within 0.8 of the
    // train's endurance at our best gun's blow, up to six, and holds the
    // shipped count when even six cannot (game 141). See
    // `siege_production::breakers_matched_to_walls`.
    Gene { tag: "breakers-match-the-walls", field: "breakers_match_the_walls", kind: Kind::OptIn, enable: AdvancedAi::enable_breakers_match_the_walls, disable: AdvancedAi::disable_breakers_match_the_walls },
    // `siege-buys-the-gun-resource`: live Emperor game 343 held Angkor
    // Thom's 400 walls at a Trebuchet's 2.3 a shot with Steel and Military
    // Science researched and no Niter or Oil tile owned, while the Zulu
    // offered 82 Niter and Arabia 70; at turn 150 of 101 Emperor runs 92
    // lacked Niter or Oil and 53 had a met rival offering one, and 22% of
    // 1,000 walled infinite siege-turns were resource-blocked (-d8: the
    // tech-best gun hits a median 9.4 a shot against 4.1 for the buildable
    // best). The bridge buys the resource the better gun waits on, sized to
    // the guns its blow needs. See `gun_resource::siege_gun_resource_wants`.
    Gene { tag: "siege-buys-the-gun-resource", field: "siege_buys_the_gun_resource", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_buys_the_gun_resource, disable: AdvancedAi::disable_siege_buys_the_gun_resource },
    // Native-only purchase proposal; strength requires native trials.
    Gene { tag: "science-power-buys-fuel", field: "science_power_buys_fuel", kind: Kind::OptIn, enable: AdvancedAi::enable_science_power_buys_fuel, disable: AdvancedAi::disable_science_power_buys_fuel },
    // Native site proposal only; outcome evidence requires native games.
    Gene { tag: "spaceport-above-the-sea", field: "spaceport_above_the_sea", kind: Kind::OptIn, enable: AdvancedAi::enable_spaceport_above_the_sea, disable: AdvancedAi::disable_spaceport_above_the_sea },
    // The decisive window spent ~1,200 science a game off the Advanced
    // Flight path after the air surge's horizon opened (10-06/07 Emperor),
    // and captures ran 0.20 per 100 turns before the Bomber against 1.24
    // after it. The window yields to the surge when its goal is off that
    // path. See `AdvancedAi::window_yields_to_the_bombers`.
    Gene { tag: "siege-tier-yields-to-the-bombers", field: "siege_tier_yields_to_the_bombers", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_tier_yields_to_the_bombers, disable: AdvancedAi::disable_siege_tier_yields_to_the_bombers },
    // `surge-fields-the-bombers`: the air surge fields its wing. -d8's
    // census of the 89 Emperor games of October 6-7 that reached Advanced
    // Flight: Bombers alive at AF+15 median 1 (none in 44%), at AF+30
    // median 3 (none in 22%), the first one a median 13 turns after AF and
    // never in 27%; major cities taken AF..AF+40 rise 0.07 -> 0.24 -> 0.60
    // with 0, 1-2 and 3+ Bombers alive at AF+30. Live Emperor
    // civvis-20261007T121238Z (game 349): the strategic-queue Commercial Hub
    // (t130) and Industrial Zone (t133) spent the last district slots of
    // Bogota (53 Production) and Maracaibo past the air plan's reservation,
    // the Aerodrome went to Panama (population 1, 3 Production), and its
    // Bombers took 41 turns. See `air_surge::bomber_wing`.
    Gene { tag: "surge-fields-the-bombers", field: "surge_fields_the_bombers", kind: Kind::OptIn, enable: AdvancedAi::enable_surge_fields_the_bombers, disable: AdvancedAi::disable_surge_fields_the_bombers },
    // `prophet-builds-its-site`: 2 of the 17 Religious defeats of the
    // October 6-7 Emperor runs held a Great Prophet with no Holy Site to
    // found on (G348 lost at turn 68 six turns after Revelation earned it),
    // and the host exhausted the Prophet class at a median turn 45 while the
    // race kept paying. The site comes with the Prophet; the race closes with
    // the class. See `prophet_site::prophet_site_due`.
    Gene { tag: "prophet-builds-its-site", field: "prophet_builds_its_site", kind: Kind::OptIn, enable: AdvancedAi::enable_prophet_builds_its_site, disable: AdvancedAi::disable_prophet_builds_its_site },
    // `counterweight-from-the-first-convert`: in the 12 faithless Religious
    // defeats of the October 6-7 Emperor runs our first city followed the
    // winner's faith at a median turn 68 and the majority fell at 85, while
    // the counterweight waited for the majority; a source existed in 6 of
    // the 12 and a median ~400 Faith went unspent. The cap, the reserve and
    // the sanctuary start at the first convert. See
    // `counterweight_first_convert::first_convert_threat`.
    Gene { tag: "counterweight-from-the-first-convert", field: "counterweight_from_the_first_convert", kind: Kind::OptIn, enable: AdvancedAi::enable_counterweight_from_the_first_convert, disable: AdvancedAi::disable_counterweight_from_the_first_convert },
    // G351 (civvis-20261007T123621Z): the dry road round Japan's closed
    // borders ran 40-43 steps against 7-9 through them, and the train
    // shuffled on the shore for twelve turns with nothing naming Japan. A
    // march that long holds and names the blocker instead, which the passage
    // purchase and the road stand-down act on. See
    // `AdvancedAi::long_road_holds`.
    Gene { tag: "long-road-names-the-blocker", field: "long_road_names_the_blocker", kind: Kind::OptIn, enable: AdvancedAi::enable_long_road_names_the_blocker, disable: AdvancedAi::disable_long_road_names_the_blocker },
    // Live Emperor 10-06/07: 15 finished runs held two or more Settlers at
    // turns 80 and 100, and in 8 the still turns were safe-step holds — a
    // Settler cycling threatened sites 7-10 tiles out within four tiles of
    // its own cities (game 355: one walked turns 51-130). Past its walk
    // allowance it takes the best legal site within four tiles whose ground
    // and first step are safe. See `advanced/stalled_settler_site.rs`.
    Gene { tag: "stalled-settler-takes-a-safe-site", field: "stalled_settler_takes_a_safe_site", kind: Kind::OptIn, enable: AdvancedAi::enable_stalled_settler_takes_a_safe_site, disable: AdvancedAi::disable_stalled_settler_takes_a_safe_site },
    // 283 of 634 gun approaches that ended short of the post on 10-07/08
    // read "no route step and no pass-through destination": the train's
    // router treats our units as walls and the crossing looks only beside
    // the gun. The gun steps up behind the column instead. See
    // `AdvancedAi::column_queue_step`.
    Gene { tag: "gun-queues-behind-the-column", field: "gun_queues_behind_the_column", kind: Kind::OptIn, enable: AdvancedAi::enable_gun_queues_behind_the_column, disable: AdvancedAi::disable_gun_queues_behind_the_column },
    // A city within one of its housing whose Granary stands builds its
    // Aqueduct (Rome's Bath) ahead of the economy steps and the military
    // floor, within 25 turns. See `BasicAi::housing_cap_builds_the_aqueduct`.
    Gene { tag: "housing-cap-builds-the-aqueduct", field: "housing_cap_builds_the_aqueduct", kind: Kind::OptIn, enable: AdvancedAi::enable_housing_cap_builds_the_aqueduct, disable: AdvancedAi::disable_housing_cap_builds_the_aqueduct },
    // Builders while the charges in hand and queued cover under 60% of the
    // unimproved worked tiles, one per city, from a city that finishes one
    // within eight standard turns, ahead of the Monument, the Settler step and
    // the military floor; under the controller it also claims one idle queue
    // a turn ahead of the routine idle-queue claims, buys one above the
    // reserve, and allows 15 standard turns while the backlog is twice the
    // charges. See `BasicAi::builders_cover_the_worked_backlog`.
    Gene { tag: "builders-cover-the-worked-backlog", field: "builders_cover_the_worked_backlog", kind: Kind::OptIn, enable: AdvancedAi::enable_builders_cover_the_worked_backlog, disable: AdvancedAi::disable_builders_cover_the_worked_backlog },
    // An improvement's Production on a tile one of our cities works is priced
    // again at 2.11 / 1.43 times the lane's Production weight (the top third's
    // Production per improved tile over the bottom third's at t100), so a Mine
    // under a citizen outbids a Farm on an idle flat; a starving city with
    // Housing to grow into keeps the stock pricing. See
    // `advanced/worked_production.rs`.
    Gene { tag: "builders-improve-the-worked-for-production", field: "builders_improve_the_worked_for_production", kind: Kind::OptIn, enable: AdvancedAi::enable_builders_improve_the_worked_for_production, disable: AdvancedAi::disable_builders_improve_the_worked_for_production },
    // `founder-defends-its-cities`: live Emperor 20261008T100610Z founded
    // Buddhism at 45 and lost to Catholicism at 111 with a held Catholic
    // Missionary counted in its defensive cap and 706 Faith banked once no
    // city of ours followed our faith; 20261008T101304Z saved for an Apostle
    // it never reached from 49 to 83 and lost at 104. Once a rival faith
    // holds a city of ours the founder buys its own faith's defenders now.
    // See `founder_defence::founder_defence_live`.
    Gene { tag: "founder-defends-its-cities", field: "founder_defends_its_cities", kind: Kind::OptIn, enable: AdvancedAi::enable_founder_defends_its_cities, disable: AdvancedAi::disable_founder_defends_its_cities },
    // From turn 75, 56% of the live seat's city-turns ran Displeased, 84% of
    // them one Amenity short, while the median empire held spare luxury copies
    // and its peaceful rivals offered types it lacked; Gold alone never bought
    // one. The bridge now offers a spare copy for a luxury we lack.
    Gene { tag: "luxury-swap-asks", field: "luxury_swap_asks", kind: Kind::OptIn, enable: AdvancedAi::enable_luxury_swap_asks, disable: AdvancedAi::disable_luxury_swap_asks },
    // G388 (civvis-20261008T111334Z): the nearest tile outside Russia's
    // closed borders was five from St. Petersburg, so the 3-5 staging band
    // held two bodies against an 819 bill all game at 2-3 times every rival;
    // 39 of 97 held campaign targets had no stand nearer than four. The
    // band widens until it holds six peacetime stands (at most eight). See
    // `AdvancedAi::campaign_staging_reach`.
    Gene { tag: "staging-reaches-the-border", field: "staging_reaches_the_border", kind: Kind::OptIn, enable: AdvancedAi::enable_staging_reaches_the_border, disable: AdvancedAi::disable_staging_reaches_the_border },
    // A rival with two space projects landed (or a science race at 80%)
    // gets a spy on each of its standing Spaceport cities, and every spy
    // there runs Disrupt Rocketry whenever the host offers it. G398 lost to
    // Japan's four pads while both disruptions hit the same one. See
    // `advanced/science_denial_every_pad.rs`.
    Gene { tag: "science-denial-every-pad", field: "science_denial_every_pad", kind: Kind::OptIn, enable: AdvancedAi::enable_science_denial_every_pad, disable: AdvancedAi::disable_science_denial_every_pad },
    // A Diplomatic Victory leader one session from the win (15 points) is a
    // Domination counter clock and opens a second front at the declaration
    // edge. G402 lost to Nubia's Diplomatic Victory at 207, Nubia at peace on
    // 15 points from turn 181 while the army fought two other rivals. See
    // `advanced/dvp_leader_front.rs`.
    Gene { tag: "dvp-leader-is-the-front", field: "dvp_leader_is_the_front", kind: Kind::OptIn, enable: AdvancedAi::enable_dvp_leader_is_the_front, disable: AdvancedAi::disable_dvp_leader_is_the_front },
    // The bridge leases the Congress ballot a guard on the Diplomatic
    // Victory leader (14-15 points): its A block is read at the largest any
    // rival cast last session, so the bank outvotes or redirects it instead
    // of a B nobody joins. G402 t202 cast 10 B votes; Nubia's A block grew
    // from 3 to 7 and took +4 to 19. See `CivvisCongressRedirect`.
    Gene { tag: "congress-guards-the-leader", field: "congress_guards_the_leader", kind: Kind::OptIn, enable: AdvancedAi::enable_congress_guards_the_leader, disable: AdvancedAi::disable_congress_guards_the_leader },
    // G403 (civvis-20261008T134147Z): three cities at 727 power, the
    // counter aimed at Kongo (880) while the Netherlands stood at 130 with
    // five cities. A counter on a stronger rival yields the target to a
    // neighbour at a third of our power. See
    // `AdvancedAi::counter_out_of_reach`.
    Gene { tag: "counter-out-of-reach-takes-the-weak", field: "counter_out_of_reach_takes_the_weak", kind: Kind::OptIn, enable: AdvancedAi::enable_counter_out_of_reach_takes_the_weak, disable: AdvancedAi::disable_counter_out_of_reach_takes_the_weak },
    // Against a decisive space racer the top-Production cities train Spies
    // up to its pads plus one, ahead of routine builds. G406 held 0-1 Spies
    // of 5 capacity from t175 to its t215 Science loss. See
    // `advanced/science_denial_trains_spies.rs`.
    Gene { tag: "science-denial-trains-spies", field: "science_denial_trains_spies", kind: Kind::OptIn, enable: AdvancedAi::enable_science_denial_trains_spies, disable: AdvancedAi::disable_science_denial_trains_spies },
    // `advanced/culture_denial_heist.rs`.
    Gene { tag: "culture-denial-heist", field: "culture_denial_heist", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_denial_heist, disable: AdvancedAi::disable_culture_denial_heist },
    // `advanced/band_hunt.rs`.
    Gene { tag: "war-kills-the-bands", field: "war_kills_the_bands", kind: Kind::OptIn, enable: AdvancedAi::enable_war_kills_the_bands, disable: AdvancedAi::disable_war_kills_the_bands },
    // Against a decisive space racer the suppression city — the campaign's
    // first objective and the air surge's target — is its nearest standing
    // Spaceport city, whatever lane the counter labels it with. G408's
    // campaign aimed at Faras, whose pad our spy had pillaged at t190, while
    // Nubia launched from the others. See `advanced/science_suppression_pads.rs`.
    Gene { tag: "science-suppression-hits-the-pads", field: "science_suppression_hits_the_pads", kind: Kind::OptIn, enable: AdvancedAi::enable_science_suppression_hits_the_pads, disable: AdvancedAi::disable_science_suppression_hits_the_pads },
    // `defeated-majors-leave-the-board`: live Emperor G415 eliminated
    // Poland at turn 104, and the board kept it alive: Ethiopia's Orthodoxy,
    // at match point (every major but Sumeria), read 50% of a 75 bar for 20
    // turns, and the counterweight bought Orthodox Missionaries to 107;
    // Ethiopia won on Religion at 132. Empty seats beyond the host's living
    // count retire. See `defeated_majors::retire_defeated_majors`.
    Gene { tag: "defeated-majors-leave-the-board", field: "defeated_majors_leave_the_board", kind: Kind::OptIn, enable: AdvancedAi::enable_defeated_majors_leave_the_board, disable: AdvancedAi::disable_defeated_majors_leave_the_board },
    // G415 (civvis-20261008T160451Z): eliminating Poland, one of Ethiopian
    // Orthodoxy's last three holdouts, put Orthodoxy at match point; we lost
    // to it 28 turns later. The last city of a holdout waits while the faith
    // is at its early warning. Wants `defeated-majors-leave-the-board`. See
    // `AdvancedAi::elimination_crowns_a_faith`.
    Gene { tag: "elimination-waits-on-the-clock", field: "elimination_waits_on_the_clock", kind: Kind::OptIn, enable: AdvancedAi::enable_elimination_waits_on_the_clock, disable: AdvancedAi::disable_elimination_waits_on_the_clock },
    // Before the band turn, while cities plus walkers are short of six and
    // no Settler is in production, the unthreatened city that trains one
    // soonest queues a Settler ahead of the Prophet race and the routine
    // builds. 10-08: four or fewer cities at t75 passed the production gate
    // in 0 of 19 live Emperor runs. See `advanced/early_settler_floor.rs`.
    Gene { tag: "early-settler-floor", field: "early_settler_floor", kind: Kind::OptIn, enable: AdvancedAi::enable_early_settler_floor, disable: AdvancedAi::disable_early_settler_floor },
    // At war with a decisive space racer, a bomber pillages a standing pad in
    // range and a nearby land unit walks onto one and pillages it, inside the
    // band hunt's safety envelope. G422 made peace with Sumeria the turn its
    // Mars base landed. See `advanced/launcher_war.rs`.
    Gene { tag: "war-raids-the-pads", field: "war_raids_the_pads", kind: Kind::OptIn, enable: AdvancedAi::enable_war_raids_the_pads, disable: AdvancedAi::disable_war_raids_the_pads },
    // No peace offered to or accepted from a rival past its Mars base and
    // short of the Exoplanet launch while a pad of its stands, unless our
    // cities are falling. See `advanced/launcher_war.rs`.
    Gene { tag: "no-peace-with-a-launcher", field: "no_peace_with_a_launcher", kind: Kind::OptIn, enable: AdvancedAi::enable_no_peace_with_a_launcher, disable: AdvancedAi::disable_no_peace_with_a_launcher },
    // `advanced/band_hunt.rs`.
    Gene { tag: "war-kills-the-bands-2", field: "war_kills_the_bands_2", kind: Kind::OptIn, enable: AdvancedAi::enable_war_kills_the_bands_2, disable: AdvancedAi::disable_war_kills_the_bands_2 },
    // `match-point-interception-ignores-power`: live Emperor G425 held the
    // religious interception on Georgia at 282 against a steady 273 beside
    // France's war (1.2 edge) and lost on Religion at 98. When the faith
    // holds every other major and we are its last holdout, the war that
    // condemns its spreader at home opens at 0.7 times its steady power.
    // See `match_point_last_holdout::last_holdout_interception`.
    Gene { tag: "match-point-interception-ignores-power", field: "match_point_interception_ignores_power", kind: Kind::OptIn, enable: AdvancedAi::enable_match_point_interception_ignores_power, disable: AdvancedAi::disable_match_point_interception_ignores_power },
    // `counterweight-finishes-one-shrine`: live Emperor G425 queued its one
    // Hindu city's Shrine 19 times (turns 86-92) while the siege reservation
    // replaced it with a Trebuchet each turn, started Holy Sites in five
    // cities, and spent 450 Faith on a Great Merchant at match point; Georgia
    // won on Religion at 98. One sanctuary finishes (bought when covered) and
    // the bank waits for it. See `counterweight_shrine::counterweight_shrine_city`.
    Gene { tag: "counterweight-finishes-one-shrine", field: "counterweight_finishes_one_shrine", kind: Kind::OptIn, enable: AdvancedAi::enable_counterweight_finishes_one_shrine, disable: AdvancedAi::disable_counterweight_finishes_one_shrine },
    // G428 (civvis-20261008T182825Z): Yokohama stood wall-less at 1-40
    // health for eleven turns while the takers in reach held to heal at 63
    // and 78 hp; 11 of 26 falling cities over 10-06/07/08 took more than two
    // turns or never fell. A recovering melee unit near a falling city stays
    // in the fight. See `AdvancedAi::falling_city_calls`.
    Gene { tag: "falling-city-outranks-the-heal", field: "falling_city_outranks_the_heal", kind: Kind::OptIn, enable: AdvancedAi::enable_falling_city_outranks_the_heal, disable: AdvancedAi::disable_falling_city_outranks_the_heal },
    // From live turn 30 to 80, while a met major at peace with a city within
    // ten tiles out-guns us, one queue a turn trains a land unit until we
    // stand level. 10-08: the AI declared 23 early wars, all at 1.32 or less
    // of our power, 12 costing a city. See `advanced/near_rival_deterrence.rs`.
    Gene { tag: "near-rival-deterrence", field: "near_rival_deterrence", kind: Kind::OptIn, enable: AdvancedAi::enable_near_rival_deterrence, disable: AdvancedAi::disable_near_rival_deterrence },
    // Against a racer past its Moon and short of the Exoplanet launch, the
    // war opens from 0.8 times its steady power, staged or not, by surprise;
    // its pads are raided by bombers and lone units, not besieged. G432 held
    // the urgent denial on Persia under 1.5x for seven turns after its Mars
    // base. See `advanced/launcher_war.rs`.
    Gene { tag: "launcher-war-ignores-the-edge", field: "launcher_war_ignores_the_edge", kind: Kind::OptIn, enable: AdvancedAi::enable_launcher_war_ignores_the_edge, disable: AdvancedAi::disable_launcher_war_ignores_the_edge },
    // G433 (civvis-20261008T192219Z): four Bombers flew 90 of 100 sorties
    // at one neutralised Nubian Encampment inside the wall sortie's guard
    // radius while every siege target stood at 400 walls. The guard and
    // reliever slots take only tiles a hostile soldier stands on. See
    // `hostile_soldier_at` in `siege_train`.
    Gene { tag: "wall-sortie-skips-the-encampment", field: "wall_sortie_skips_the_encampment", kind: Kind::OptIn, enable: AdvancedAi::enable_wall_sortie_skips_the_encampment, disable: AdvancedAi::disable_wall_sortie_skips_the_encampment },
    // A defensive spreader breaks the faith holding our cities from the
    // smallest town up: every city counts the same toward a Religious
    // Victory's majority. G211317Z spent five Catholic charges on a pop-9
    // Orthodox Maracaibo while three towns of pop 2-3 were the flips that
    // broke the majority. See `advanced/counterweight_small_towns.rs`.
    Gene { tag: "counterweight-flips-the-small-towns", field: "counterweight_flips_the_small_towns", kind: Kind::OptIn, enable: AdvancedAi::enable_counterweight_flips_the_small_towns, disable: AdvancedAi::disable_counterweight_flips_the_small_towns },
    // Live Emperor 10-08: gate passers held 2,796 train-member turns "at the
    // muster line" past turn 150, 69% more than ten tiles from the city where
    // the muster cannot count them; replays traced 36% of those holds to a
    // coast or pocket with a dry road round it. A mustering member walks in
    // by the dry road. See `muster_step` in `siege_train`.
    Gene { tag: "muster-walks-the-road", field: "muster_walks_the_road", kind: Kind::OptIn, enable: AdvancedAi::enable_muster_walks_the_road, disable: AdvancedAi::disable_muster_walks_the_road },
    // The rebuild takes the seat's city memory before the host's capital
    // flags land, so every rival's first planted city was remembered as its
    // capital: find-the-capital never priced a passage or hunted, and the
    // planning board drew fogged cities with the planting's crown. 113 of 258
    // rival capitals were never seen in 87 Emperor runs. The decider re-takes
    // the memory. See `mirror::refresh_city_memory`.
    Gene { tag: "unseen-capital-is-unseen", field: "unseen_capital_is_unseen", kind: Kind::OptIn, enable: AdvancedAi::enable_unseen_capital_is_unseen, disable: AdvancedAi::disable_unseen_capital_is_unseen },
    Gene { tag: "unit-preservation", field: "unit_preservation", kind: Kind::OptIn, enable: AdvancedAi::enable_unit_preservation, disable: AdvancedAi::disable_unit_preservation },
    // `peacetime-classical-republic`: 115 Emperor runs ran Oligarchy on 4,672
    // of 4,780 turns between Political Philosophy (median t41) and Divine
    // Right (t80), at war with a major on 15% of them, while 54% of our
    // cities sat at their housing. The Republic gives +1 Housing and +1
    // Amenity to every city with a district and a second Economic card.
    // See `advanced/peacetime_republic.rs`.
    Gene { tag: "peacetime-classical-republic", field: "peacetime_classical_republic", kind: Kind::OptIn, enable: AdvancedAi::enable_peacetime_classical_republic, disable: AdvancedAi::disable_peacetime_classical_republic },
    // Live Emperor 10-08/09: the air wing read no Bomber goal until the bank
    // held two Bombers' training and fourteen turns of their upkeep (30
    // Aluminum), and asked rivals for that whole block or nothing. A rival
    // at peace offered Aluminum on 361 wait-turns, under the block on 224.
    // The host's fuel shortage costs -1 Strength per unpaid unit, capped at
    // 20, so a small stock flies the wing. See `AIR_WING_SMALL_STOCK_TURNS`.
    Gene { tag: "bombers-fly-on-a-small-stock", field: "bombers_fly_on_a_small_stock", kind: Kind::OptIn, enable: AdvancedAi::enable_bombers_fly_on_a_small_stock, disable: AdvancedAi::disable_bombers_fly_on_a_small_stock },
    // `settler-walks-to-the-better-site`: the routed settle pick returned the
    // best site reachable THIS turn whenever one existed, over far better
    // ranked sites a turn or two out (G034655Z t51: dry 77.9 a tile away
    // over fresh 143.5 two tiles away). 49% of 1,224 of our foundings were
    // fresh water against the rivals' 64%. See `advanced/far_settle_site.rs`.
    Gene { tag: "settler-walks-to-the-better-site", field: "settler_walks_to_the_better_site", kind: Kind::OptIn, enable: AdvancedAi::enable_settler_walks_to_the_better_site, disable: AdvancedAi::disable_settler_walks_to_the_better_site },
    // `early-conquest-stands-down`: 28 live Emperor early-conquest declarations
    // (10-08/09) took 0 cities within 30 turns at every power ratio (3 under
    // 0.7, 13 at 0.7-1.0, 5 at 1.0-1.5, 7 at 1.5-4.6 times the target's
    // military) and 1 by turn 120; peace came a median 15 turns later. The
    // opening still scans, its scouts keep their caution, but it never opens.
    // See `AdvancedAi::conquest_stands_down`.
    Gene { tag: "early-conquest-stands-down", field: "early_conquest_stands_down", kind: Kind::OptIn, enable: AdvancedAi::enable_early_conquest_stands_down, disable: AdvancedAi::disable_early_conquest_stands_down },
    // `granary-claims-the-bound-queue`: 145 Emperor runs held 13,409 of
    // 21,729 housing-bound city-turns (t25-90) without a buildable Granary,
    // in streaks of median 9 / p90 29 turns against 5.3 to build it, while
    // the deterrent, the worked backlog's Builder, recon and catch-up claims
    // took the queue first. See `advanced/granary_claims_the_bound_queue.rs`.
    Gene { tag: "granary-claims-the-bound-queue", field: "granary_claims_the_bound_queue", kind: Kind::OptIn, enable: AdvancedAi::enable_granary_claims_the_bound_queue, disable: AdvancedAi::disable_granary_claims_the_bound_queue },
    // `capital-campus-before-the-plaza`: 145 live Emperor runs (10-08/09) put a
    // Holy Site (83) or a Government Plaza (58) in the capital first and a
    // Campus never; the capital's Campus stood at a median turn 86, its
    // Library at 92, while our Science ran 0.21/0.26/0.39 of the best rival's
    // at turns 50/75/100. The capital's Campus, then its Library, claim the
    // idle capital ahead of the Plaza claim. See `advanced/capital_campus_claim.rs`.
    Gene { tag: "capital-campus-before-the-plaza", field: "capital_campus_before_the_plaza", kind: Kind::OptIn, enable: AdvancedAi::enable_capital_campus_before_the_plaza, disable: AdvancedAi::disable_capital_campus_before_the_plaza },
    // `gold-buys-the-settler`: 144 Emperor runs banked a median 145-170
    // Gold from t30 to t60 while the gate's line is the city count at t60
    // (4 or fewer cities 8% pass, five 22%, six 50%); one Settler was bought
    // with Gold in 144 runs. In the expansion window, at peace, the treasury
    // saves for a Settler and buys it. See `advanced/gold_buys_the_settler.rs`.
    Gene { tag: "gold-buys-the-settler", field: "gold_buys_the_settler", kind: Kind::OptIn, enable: AdvancedAi::enable_gold_buys_the_settler, disable: AdvancedAi::disable_gold_buys_the_settler },
    // `trader-fills-the-idle-route`: 134 Emperor runs opened the first trade
    // route slot at a median turn 25 and ran the first route at turn 69 (a
    // 42-turn lag; 63 empty slot-turns by t100, passers 50 against retirees
    // 68), because every Trader claim reads an idle queue the expansion
    // window never leaves. The safe origin that trains a Trader soonest puts
    // one ahead of the routine claims. See `advanced/trader_fills_the_idle_route.rs`.
    Gene { tag: "trader-fills-the-idle-route", field: "trader_fills_the_idle_route", kind: Kind::OptIn, enable: AdvancedAi::enable_trader_fills_the_idle_route, disable: AdvancedAi::disable_trader_fills_the_idle_route },
    // `civic-awaits-its-inspiration`: 157 Emperor runs adopted their opening
    // civics a few turns before their own triggers landed: Craftsmanship 9%
    // inspired (the third improvement came within 10 turns of adoption in 49
    // of 136), State Workforce 23% (a district within 5 turns in 52 of 115),
    // Games and Recreation 9% (Construction within 10 in 40 of 130), while our
    // Culture ran 0.28 of the median rival's. On a forced beeline a step whose
    // inspiration is still ours to earn goes after the goal's other steps;
    // off one, a pick that would finish before its near trigger lands gives
    // way. See `advanced/civic_inspiration_wait.rs`.
    Gene { tag: "civic-awaits-its-inspiration", field: "civic_awaits_its_inspiration", kind: Kind::OptIn, enable: AdvancedAi::enable_civic_awaits_its_inspiration, disable: AdvancedAi::disable_civic_awaits_its_inspiration },
    // `backlog-builder-takes-the-queue`: per citizen our Production is the
    // rivals' less their +40% Emperor handicap; the tiles are the gap. A
    // quarter to a third of our worked tiles are improved at t40-t60, the
    // unimproved worked tiles run 6 → 14 (t30-t70) against 1-4 charges and the
    // backlog gate wants a Builder on 93% of turns, but its claim reads only an
    // idle queue. The city that trains it soonest puts it ahead of the routine
    // claims. See `advanced/backlog_builder_takes_the_queue.rs`.
    Gene { tag: "backlog-builder-takes-the-queue", field: "backlog_builder_takes_the_queue", kind: Kind::OptIn, enable: AdvancedAi::enable_backlog_builder_takes_the_queue, disable: AdvancedAi::disable_backlog_builder_takes_the_queue },
    // G222142Z (2026-10-09): Bogotá queued its religious-defence Holy Site on
    // 17 straight turns (t50-66) and near-rival-deterrence displaced it with an
    // Archer or Pikeman every frame. An uninvested district is always
    // displaceable, so it never started; Spain's faith won at t103. 31 of the
    // last 60 games show the deterrent displacing a Holy Site, Shrine or Temple.
    // See `deterrence_may_displace` in `advanced/near_rival_deterrence.rs`.
    Gene { tag: "deterrence-spares-the-faith-defence", field: "deterrence_spares_the_faith_defence", kind: Kind::OptIn, enable: AdvancedAi::enable_deterrence_spares_the_faith_defence, disable: AdvancedAi::disable_deterrence_spares_the_faith_defence },
    // 10-08/09 live Emperor: 27 siege targets reached walls 0 and at most 25
    // health under our strikes; 17 fell within two turns, 4 took three to
    // eight, 6 never fell, while healthy melee bodies held 4-9 tiles off
    // (Amboise t149 "waits for a body" with a Knight at 8; Majapahit at 1
    // health t163-169 with a full Pike-and-Shot at 7). A falling city is taken
    // when a body can, else calls the nearest fit bodies one safe step in.
    // See `advanced/falling_city_takers.rs`.
    Gene { tag: "falling-city-calls-the-takers", field: "falling_city_calls_the_takers", kind: Kind::OptIn, enable: AdvancedAi::enable_falling_city_calls_the_takers, disable: AdvancedAi::disable_falling_city_calls_the_takers },
    // 9 Emperor science losses after the t150 gate (10-08/09): the winner had
    // Rocketry 31-60 turns before its Exoplanet launch (median ~35) but the
    // spy network only starts at its Moon landing (8-23 turns out), held 0-3
    // Spies against capacity 2-5 and ran 0-3 Disrupt Rocketry on the winner
    // before launch. See `denial_spy_racers` in `science_denial_every_pad.rs`.
    Gene { tag: "space-denial-spies-from-rocketry", field: "space_denial_spies_from_rocketry", kind: Kind::OptIn, enable: AdvancedAi::enable_space_denial_spies_from_rocketry, disable: AdvancedAi::disable_space_denial_spies_from_rocketry },
    // The live opening's barbarian defense displaced the capital's Settler
    // twice in 73 of 123 Emperor runs (2026-10-10), the second a median six
    // turns after the first once its Slinger left to hunt; those runs saw
    // their second Settler at t24 against t19. The Settler now keeps the
    // queue after one displacement. See `opening_defense_settler_preempts`.
    Gene { tag: "opening-defense-preempts-once", field: "opening_defense_preempts_once", kind: Kind::OptIn, enable: AdvancedAi::enable_opening_defense_preempts_once, disable: AdvancedAi::disable_opening_defense_preempts_once },
    // Version 2 of `first-luxury-first` (2026-10-10, eco9): 77 Emperor runs had
    // 36% of cities Amenity-short at t50 and 47-49% at t100-125 (a short city
    // loses 15% growth and 10% of every yield); at t50, 27 of 51 runs with a short
    // city owned a luxury type they lacked, unimproved and tech-ready (39 of 42),
    // while the Builder paid it the flat +14. v1 also pays +26 to a content empire;
    // v2 prices the first copy only while the host-calibrated deficit is positive.
    Gene { tag: "first-luxury-first-2", field: "first_luxury_first_2", kind: Kind::OptIn, enable: AdvancedAi::enable_first_luxury_first_2, disable: AdvancedAi::disable_first_luxury_first_2 },
    // Founder losses G215527Z/G094619Z: our Inquisitors started 15 theological
    // fights at strength 75 against 100-strength Apostles, took 443 damage for
    // 367, and all nine died with most Remove Heresy charges unspent; each death
    // gives the winner's faith 250 pressure beside our cities. A fight is taken
    // only when the mean exchange kills or trades evenly and survives. See
    // `advanced/theology_fights.rs`.
    Gene { tag: "theology-fights-only-to-win", field: "theology_fights_only_to_win", kind: Kind::OptIn, enable: AdvancedAi::enable_theology_fights_only_to_win, disable: AdvancedAi::disable_theology_fights_only_to_win },
    // Live Emperor founders 10-09/10: the Holy City left our faith in 40 of 83
    // games and in five of the seven Religious defeats, 27-51 turns before the
    // end. The host named the rival as its next faith in 29 of the 40 flips
    // while its clock read hundreds of turns (183646Z: 501 turns at t57,
    // Zoroastrian at t61), so the shipped 20-turn warning never rose; our one
    // Missionary walked away from Guayaquil the turn before. Our nearest spreader
    // spreads there first and, with none near, the Holy City buys one ahead of
    // the Apostle save. See `advanced/holy_city_guard.rs`.
    Gene { tag: "founder-holds-the-holy-city", field: "founder_holds_the_holy_city", kind: Kind::OptIn, enable: AdvancedAi::enable_founder_holds_the_holy_city, disable: AdvancedAi::disable_founder_holds_the_holy_city },
    // Live Emperor founders 10-09/11: our faith held half or more of our cities
    // at t80 in 61 of 85 founders that kept clear of a Religious defeat against
    // 4 of the 10 that lost. Once a rival faith holds one of our cities, the
    // small-town counterweight charges our own towns 24 a citizen while foreign
    // targets keep 12, so a founder's Missionaries walked abroad (005957Z:
    // Plymouth 190 against our unconverted Bogotá 70; lost t118 with 14
    // cities). See `advanced/founder_home.rs`.
    Gene { tag: "founder-converts-its-own-cities", field: "founder_converts_its_own_cities", kind: Kind::OptIn, enable: AdvancedAi::enable_founder_converts_its_own_cities, disable: AdvancedAi::disable_founder_converts_its_own_cities },
    // 10-09/10: rival Apostles attacked our religious units 1,039 times in 109
    // Emperor runs and killed 395, 55% of the fights one or two tiles from our
    // cities; each kill hands the winner 250 pressure across ten tiles
    // (G231456Z: five Buddhist cities to none t96-104, lost t106). A unit of
    // ours never ends a step where a rival that would win the fight reaches
    // it. See `advanced/apostle_evasion.rs`.
    Gene { tag: "spreader-steps-out-of-the-apostle", field: "spreader_steps_out_of_the_apostle", kind: Kind::OptIn, enable: AdvancedAi::enable_spreader_steps_out_of_the_apostle, disable: AdvancedAi::disable_spreader_steps_out_of_the_apostle },
    // 10-09/11 live Emperor: 23 games held a STAGED, ready declaration in
    // turns 100-130 at 2-10 times the target's steady military (median 3.45)
    // because version 2's edge asks twice its 30-turn peak against a rival
    // that out-produces us (median peak 1.64 times, our Production 0.65 of
    // theirs); 17 of 27 such targets were never declared on. Wars declared in
    // that window took a city within 30 turns in 5 of 17 at 2.5 times or more
    // and 0 of 7 under it (G190448Z, the only Emperor domination win, opened
    // on the Aztecs at turn 110 at 2.8 times). Three times the steady power
    // with at least 1.5 times the peak passes the edge.
    Gene { tag: "crushing-steady-passes-the-edge", field: "crushing_steady_passes_the_edge", kind: Kind::OptIn, enable: AdvancedAi::enable_crushing_steady_passes_the_edge, disable: AdvancedAi::disable_crushing_steady_passes_the_edge },
    // Live October 9-11 openings: a Settler took a median 5 turns at
    // Immortal (4 at Emperor) to found 4 tiles from its birth, and the last
    // 39 games logged 419 "Settler waits for its guard" turns before t80
    // (about 10 a game) while settler captures by t60 had become rare (1 of 7
    // Immortal, 4 of 50 Emperor). Cities at t60 set the t50 production ratio
    // against the second rival (0.27 at three or fewer, 0.53 at six or more).
    // Up to live turn 80 the guard holds give way while no hostile unit or
    // barbarian camp is within four tiles of a road that is all in sight.
    // See `advanced/settler_path_clear.rs`.
    Gene { tag: "settler-marches-alone-when-clear", field: "settler_marches_alone_when_clear", kind: Kind::OptIn, enable: AdvancedAi::enable_settler_marches_alone_when_clear, disable: AdvancedAi::disable_settler_marches_alone_when_clear },
    // `aqueduct-claims-the-capped-queue`: at Immortal t100 59% of our cities
    // grew at the host's housing ×0.25/×0.5 and 8% held an Aqueduct, while
    // 22 of 67 capped cities without one had a legal Aqueduct (20 with the
    // Granary built); the pick_item step reads an idle queue the claims take
    // first. See `advanced/aqueduct_claims_the_capped_queue.rs`.
    Gene { tag: "aqueduct-claims-the-capped-queue", field: "aqueduct_claims_the_capped_queue", kind: Kind::OptIn, enable: AdvancedAi::enable_aqueduct_claims_the_capped_queue, disable: AdvancedAi::disable_aqueduct_claims_the_capped_queue },
    // `engineering-for-capped-fresh-water`: in 11 of 25 Immortal runs two or
    // more capped fresh-water cities with their Granary waited on Engineering
    // while it was a median 1.6 turns of research away; in six it landed
    // 36-74 turns later behind the conquest beeline (551 capped city-turns).
    // See `advanced/engineering_for_capped_fresh_water.rs`.
    Gene { tag: "engineering-for-capped-fresh-water", field: "engineering_for_capped_fresh_water", kind: Kind::OptIn, enable: AdvancedAi::enable_engineering_for_capped_fresh_water, disable: AdvancedAi::disable_engineering_for_capped_fresh_water },
    // 10-11 live Emperor/Immortal census, 53 runs: in 51 a city held a paused
    // district foundation the host quoted at one or two turns while it built
    // something else (274 stretches, 1,912 city-turns, 83% at full health,
    // 702 of them on military units). Immortal G054318Z's capital Campus sat
    // at 46 of 56 from turn 53 to 82 behind a zero-damage war handoff. At full
    // city and wall health with no attack in reach, such a foundation goes
    // back to the head of its queue and the defence handoff keeps it there.
    Gene { tag: "paused-district-finishes", field: "paused_district_finishes", kind: Kind::OptIn, enable: AdvancedAi::enable_paused_district_finishes, disable: AdvancedAi::disable_paused_district_finishes },
    // 10-11 live census, 38 Immortal and 120 Emperor GC runs: Apprenticeship
    // at a median t82 (Immortal), the first Industrial Zone founded 22 turns
    // later (Emperor 27): 0 zones at t100, 1 at t125. Between the technology
    // and the first zone, producer cities with a legal zone built soldiers
    // 39%, ordinary buildings 21%, other districts 19%; the producer step
    // asks only idle queues the claims take first. The producer step's zone
    // or Workshop now claims its city's queue over a deferrable head. See
    // `advanced/industrial_zone_claims_the_producer_queue.rs`.
    Gene { tag: "industrial-zone-claims-the-producer-queue", field: "industrial_zone_claims_the_producer_queue", kind: Kind::OptIn, enable: AdvancedAi::enable_industrial_zone_claims_the_producer_queue, disable: AdvancedAi::disable_industrial_zone_claims_the_producer_queue },
    // `sea-locked-front-moves-on`: live Emperor G004440Z kept the Netherlands
    // as its front from turn 146 to 192 and stood ten Dutch sieges down for
    // want of a land road while the Maya and Egypt, at war with us at 3-5x
    // our power over theirs, stood on our side of the water. See
    // `advanced/sea_locked_front.rs`.
    Gene { tag: "sea-locked-front-moves-on", field: "sea_locked_front_moves_on", kind: Kind::OptIn, enable: AdvancedAi::enable_sea_locked_front_moves_on, disable: AdvancedAi::disable_sea_locked_front_moves_on },
    // 10-11 live census, 54 Immortal and 118 Emperor GC runs: the rivals'
    // walls reach 400 at a median t111 (Immortal) while our Metal Casting
    // lands at t131 and 21 of 54 runs never research it; at t125 our best gun
    // is a Trebuchet in 27 of 49 runs. 444 research picks t60-150 walked the
    // Advanced Flight beeline against 28 for a siege technology, and Advanced
    // Flight came by t150 in 17 of 41 runs. The next fed siege design's
    // technology now takes the slot ahead of the beeline when it costs a few
    // turns. See `advanced/siege_tier_before_the_beeline.rs`.
    Gene { tag: "siege-tier-before-the-beeline", field: "siege_tier_before_the_beeline", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_tier_before_the_beeline, disable: AdvancedAi::disable_siege_tier_before_the_beeline },
    // 10-11 live census, 63 Immortal and 105 Emperor GC runs: Campuses come
    // (Immortal 2 at t100, 4 at t125) but their buildings lag (1.5 Libraries,
    // 0 Universities at t100); the top third by Science per citizen held 4.5
    // Libraries and 3 Universities at t125 to the bottom third's 1 and 0. A
    // median game spent 45 city-turns with a Campus and no Library and 47 with
    // a University buildable but not in production; campus-buildings-first
    // asks only idle queues the claims take first. The next Campus building
    // now claims its city's queue over a deferrable head. See
    // `advanced/campus_building_claims_the_queue.rs`.
    Gene { tag: "campus-building-claims-the-queue", field: "campus_building_claims_the_queue", kind: Kind::OptIn, enable: AdvancedAi::enable_campus_building_claims_the_queue, disable: AdvancedAi::disable_campus_building_claims_the_queue },
    // 10-13, 5 Immortal runs + 33 surviving 10-10/11 copies: our worked land
    // yields 2.04 Food a tile at turn 60 (1.80 at 100) against the two a
    // citizen eats, so a city's surplus stays its centre's +3-4 and growth is
    // linear; Food a citizen 2.74 against the rivals' 3.06. Farms are 14-25% of
    // our improvements and 45-56% of the rivals'; the day's Builders laid 93
    // Mines (worth 15.5) and 63 Lumber Mills (13.9) to 40 Farms (6.2), and
    // improvements gave our cities 0.29 Housing at turn 60 while 45-50% grow at
    // x0.5/x0.25 from their cap. Version 1 priced nothing in a city with room.
    // Version 2 prices a growing city's Food as the citizens it grows, under
    // the multipliers a Mine's Production gets, and ramps the Housing price in
    // from three citizens of room. See `advanced/growth_farm.rs`.
    Gene { tag: "growth-prices-the-farm-2", field: "growth_prices_the_farm_2", kind: Kind::OptIn, enable: AdvancedAi::enable_growth_prices_the_farm_2, disable: AdvancedAi::disable_growth_prices_the_farm_2 },
    // 2026-10-12 capital-staging tally, five live gate passers with logs:
    // when a major's capital was the siege objective after t150, the top hold
    // in two of five was water ("the bombard holds on land short of the
    // water ... no dry road opens within 128 steps": 133 lines in the Emperor
    // win civvis-20261010T190448Z, 342 in civvis-20261011T004440Z), and 51%
    // of at-war capital samples had no land unit of ours within six tiles. A
    // water-locked objective's guns and escorts now gather at a coastal city,
    // embark together over a lane no visible enemy warship watches, and land
    // together beside the target; a gun never lands alone. See
    // `advanced/amphibious_siege_train.rs`.
    Gene { tag: "amphibious-siege-train", field: "amphibious_siege_train", kind: Kind::OptIn, enable: AdvancedAi::enable_amphibious_siege_train, disable: AdvancedAi::disable_amphibious_siege_train },
    // 10-13, 17 Immortal runs: after t100 the rivals' Production a citizen
    // climbs from ~2.8 to 4.5-6.8 by t125-150 while ours stays 2.0-2.5. At
    // t150 our 11 games held 25 Workshops, 9 Factories and 1 Coal Power Plant
    // with Industrialization known in 9 (median t118): 679 city-turns with a
    // Workshop and no Factory (53 building one) and 119 with a Factory and no
    // power while Coal income was positive in 74% of samples. A Factory pays
    // +3 to every city within six tiles of its zone, +3 more powered. The zone
    // city whose Factory newly reaches the most cities (then the Factory city
    // whose plant powers the most Factories, with Coal) claims its queue with
    // the Industrial Zone claim's rules. See
    // `advanced/industrial_zone_claims_the_factory.rs`.
    Gene { tag: "industrial-zone-claims-the-factory", field: "industrial_zone_claims_the_factory", kind: Kind::OptIn, enable: AdvancedAi::enable_industrial_zone_claims_the_factory, disable: AdvancedAi::disable_industrial_zone_claims_the_factory },
    // 10-13 live Immortal runs: 65 of 90 distinct "holds on land short of
    // the water" rows had a dry road for a gun of that kind. The Stage and
    // Invest marches read `route_step_dry`, which takes its first edge as a
    // stop and returns nothing for a unit an enemy zone of control has
    // locked, so a gun behind a friend on the one land exit, or beside an
    // enemy, read as water-locked: it fortified, the road stand-down counted
    // it, and `amphibious-siege-train` shipped it (civvis-20261013T082508Z
    // held Tlacopan, on our continent with a 13-tile road, as water-locked).
    // Such a march now waits on its dry road and counts as marching. See
    // `AdvancedAi::dry_road_blocked_holds`.
    Gene { tag: "dry-road-outlasts-a-blocked-step", field: "dry_road_outlasts_a_blocked_step", kind: Kind::OptIn, enable: AdvancedAi::enable_dry_road_outlasts_a_blocked_step, disable: AdvancedAi::disable_dry_road_outlasts_a_blocked_step },
    // First live crossing, civvis-20261013T083300Z: the train for Susa took
    // 22 turns from forming to landing (a 12-water-tile lane) though the best
    // mixed road from Cali crossed ONE water tile; members on the mixed
    // router hopped between land and sea (each switch ends the turn), a gun
    // was combined into an Army at sea, and an escort was re-tasked to a
    // builder guard and then upgraded (a new id, dropped), while the
    // cohesion hold waited on it. Madrid in the Emperor win (190448Z) has the
    // same shape: sea lanes of 27-42 tiles, a land road crossing one water
    // tile. Version two fords a strait of at most two water tiles (march to
    // the shore, cross, land), locks members against combining, upgrading
    // and re-tasking, sails on a water-only router, drops a member that does
    // not close for two turns from the cohesion wait, and lands on any free
    // tile within two of the landing once the train is within three. A ford
    // is held only for a warship beside it or within a turn's reach (a sea
    // lane keeps the three-tile watch), gathers only the units joined over
    // land to its near shore (live 204616Z forded from an islet with the
    // column already across, held eleven turns), and journals the gathering
    // each turn. A sea lane sails only from a port off the objective's
    // landmass and drafts only the units joined to that port by land: a unit
    // with a dry road marches. See `advanced/amphibious_siege_train.rs`.
    Gene { tag: "amphibious-siege-train-2", field: "amphibious_siege_train_2", kind: Kind::OptIn, enable: AdvancedAi::enable_amphibious_siege_train_2, disable: AdvancedAi::disable_amphibious_siege_train_2 },
    // Version two of `luxury-swap-asks`. 21 live Immortal games on 455f438ca:
    // our cities Displeased or worse 32/39/53/63% at turns 75/100/125/150,
    // luxuries flat at 2.3-2.5 Amenities a city while the need climbs, and
    // peaceful rivals offering 3.4-3.9 luxury types we lack in nearly every
    // game. Version one closed 36 of 119 asks (22 games) and every close
    // added a type, but a rival whose land holds the spare we put up closed
    // 2 of 32 against 34 of 87 otherwise, and 25 of those 32 had a partner
    // and spare that fit; the two-short gate also held 28 luxury slots with
    // a spare and an offer. Version two asks from one Amenity short and only
    // of a partner whose mirrored board holds none of a spare, offering that
    // spare. See `append_luxury_swap_order` in `civvis_orders`.
    Gene { tag: "luxury-swap-asks-2", field: "luxury_swap_asks_2", kind: Kind::OptIn, enable: AdvancedAi::enable_luxury_swap_asks_2, disable: AdvancedAi::disable_luxury_swap_asks_2 },
    // The road-blocker front of `blocker-becomes-the-target` needed a siege
    // stood down for want of the road, and a train held short of a third
    // party's closed borders mostly holds instead: over 138 live Immortal
    // runs of 10-11/13 the closed-borders hold struck 19 games (27 blockers),
    // 58 of 59 open-borders asks during the holds were refused, and the gene
    // never fired. civvis-20261013T083300Z held its Susa train
    // short of Mongolia's borders from turn 175 at about five times
    // Mongolia's power until Persia won on Culture at 193. This gene's
    // trigger is three turns of holds against a blocker at half our power or
    // under; a city-state needs a suzerain as weak. See
    // `AdvancedAi::closed_border_front`.
    Gene { tag: "closed-border-blocker-declares", field: "closed_border_blocker_declares", kind: Kind::OptIn, enable: AdvancedAi::enable_closed_border_blocker_declares, disable: AdvancedAi::disable_closed_border_blocker_declares },
    // `purchases-keep-the-upkeep-reserve`: the main purchase pass, the
    // counterweight Shrine's Gold branch and the city-state levy keep one and
    // a half turns of the army's bill, the floor `upkeep-reserve` gives the
    // upgrade passes. See `AdvancedAi::purchase_upkeep_floor`.
    Gene { tag: "purchases-keep-the-upkeep-reserve", field: "purchases_keep_the_upkeep_reserve", kind: Kind::OptIn, enable: AdvancedAi::enable_purchases_keep_the_upkeep_reserve, disable: AdvancedAi::disable_purchases_keep_the_upkeep_reserve },
    // Live Immortal 10-13: 21 objectives stood unwalled at full health
    // during a muster, a shooter in range on 2 and none taken; 30 of the 70
    // muster holds read a finite budget whose endurance was charged a strike
    // the city cannot make. Jenne (civvis-20261013T184508Z) met its bill at
    // turn 110 and held at 6.2 turns against 3.5 endurance. See
    // `conversion_siege_entry_budget`.
    Gene { tag: "unwalled-city-spares-the-train", field: "unwalled_city_spares_the_train", kind: Kind::OptIn, enable: AdvancedAi::enable_unwalled_city_spares_the_train, disable: AdvancedAi::disable_unwalled_city_spares_the_train },
    // A sealed ring stops the city's heal, but the entry budget priced a
    // train holding off the ring at the open ring's 20 a turn: live Immortal
    // Jenne (civvis-20261013T184508Z) held turns 111-117 with seven to nine
    // units at 23.7-65.0 turns and its ring 0/6. See `train_seals_the_ring`.
    Gene { tag: "siege-budget-projects-the-seal", field: "siege_budget_projects_the_seal", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_budget_projects_the_seal, disable: AdvancedAi::disable_siege_budget_projects_the_seal },
    // `elimination-yields-to-a-launch`: the Diplomatic Victory elimination
    // front yields to an at-war rival past its Mars launch or a short culture
    // clock, without first holding the contender's capital. See
    // `capital_moves_on::elimination_yields_to_a_launch`.
    Gene { tag: "elimination-yields-to-a-launch", field: "elimination_yields_to_a_launch", kind: Kind::OptIn, enable: AdvancedAi::enable_elimination_yields_to_a_launch, disable: AdvancedAi::disable_elimination_yields_to_a_launch },
    // Live Immortal 220550Z (civvis-20261013T220550Z), production twice the
    // second rival's, waited on oil for its Artillery from turn 126 while its
    // one owned oil, offshore at (42, 20), stood unimproved: from Professional
    // Sports at turn 148 the board routed each Builder sent to it across the
    // mountain at (42, 19), the host refused all 13 moves, and the job was
    // retired as forgotten three times. No Builder of ours stood on a
    // mountain in 984 Builder-turns after the unlock over two games.
    Gene { tag: "builders-route-around-mountains", field: "builders_route_around_mountains", kind: Kind::OptIn, enable: AdvancedAi::enable_builders_route_around_mountains, disable: AdvancedAi::disable_builders_route_around_mountains },
    // Over the 15 strong Immortal games of 10-12/13 the decisive siege opened
    // 7-44 turns after its target had Urban Defenses (400 walls) in 8 of 13,
    // our guns then reading 2-12 a shot, while 9 games still held a rival
    // under 400 walls at turn 150, where they read 14-36. See
    // `advanced/war_target_walls.rs`.
    Gene { tag: "war-target-prices-the-walls", field: "war_target_prices_the_walls", kind: Kind::OptIn, enable: AdvancedAi::enable_war_target_prices_the_walls, disable: AdvancedAi::disable_war_target_prices_the_walls },
    // A Resident Embassy reveals the host's capital: over 30 Immortal games of
    // 10-13/14, 12 capitals appeared the turn one landed, while 38 of 90 were
    // never seen. The stock cadence asked an Unfriendly favourite (880 of
    // 1,038 asks refused by the bridge), never the plan's target, and stalled
    // once its favourite held an Embassy. Asked whenever Neutral, 7 never-seen
    // capitals would have been revealed and 16 a median 7 turns sooner. See
    // `advanced/embassy_capital.rs`.
    Gene { tag: "embassy-finds-the-capital", field: "embassy_finds_the_capital", kind: Kind::OptIn, enable: AdvancedAi::enable_embassy_finds_the_capital, disable: AdvancedAi::disable_embassy_finds_the_capital },
    // `aluminum-buys-the-tile`: while the empire wants Aluminum and draws
    // none, buy an unowned Aluminum tile a city can buy, above the reserve.
    // 10-13/14: 34 of 67 Immortal runs past Radio owned no Aluminum; 6 of
    // them had an unowned deposit within 3 tiles of a city. See
    // `gun_resource::aluminum_tile_purchase`.
    Gene { tag: "aluminum-buys-the-tile", field: "aluminum_buys_the_tile", kind: Kind::OptIn, enable: AdvancedAi::enable_aluminum_buys_the_tile, disable: AdvancedAi::disable_aluminum_buys_the_tile },
    // `aluminum-ask-tops-up-gold`: the air wing's Aluminum ask carries a Gold
    // ceiling for the host's counter. 10-13/14: 7 of 91 answered Aluminum
    // asks closed, every one at ceiling 0, against 38% for luxury swaps. See
    // `aluminum_ask_ceiling` in `civvis_orders`.
    Gene { tag: "aluminum-ask-tops-up-gold", field: "aluminum_ask_tops_up_gold", kind: Kind::OptIn, enable: AdvancedAi::enable_aluminum_ask_tops_up_gold, disable: AdvancedAi::disable_aluminum_ask_tops_up_gold },
    // Live Immortal 050758Z lost to Gaul's Science Victory: our two Spies
    // ran Foment Unrest in London (the war plan's capital) after Gaul's
    // Rocketry, both were captured, and the host kept their slots while the
    // board dropped them, so no Spy could be trained for 19 turns and the
    // first Disrupt Rocketry came at turn 176. While a space racer exists, a
    // Spy outside every racer's cities starts no capture-risk operation, an
    // idle one is posted to the leading racer before any pad is seen, and in
    // a racer's city it runs Disrupt Rocketry or a safe operation. The
    // leader follows the race (a racer one project behind with 1.25x the
    // Science counts level; Emperor 100910Z's Greece; level racers go by
    // Production, 192420Z-cont1's France), and a Spy at a racer that no
    // longer leads moves on unless offered the disruption. See
    // `advanced/racer_keeps_the_spies.rs`.
    Gene { tag: "racer-keeps-the-spies", field: "racer_keeps_the_spies", kind: Kind::OptIn, enable: AdvancedAi::enable_racer_keeps_the_spies, disable: AdvancedAi::disable_racer_keeps_the_spies },
    // `capital-walls-before-the-surprise`: a met major at peace with twice
    // our power and a soldier within eight tiles of the original capital in
    // the last ten turns puts Masonry next and the capital on its Walls; two
    // soldiers within six buy a defender above the upkeep reserve. 10-13/14:
    // 28 of 183 Immortal runs lost the capital before turn 100, walls up in 4;
    // the trigger fired before 27 of them, walls in time for 20, and in 75 of
    // the 149 that held. See `advanced/capital_walls_before_the_surprise.rs`.
    Gene { tag: "capital-walls-before-the-surprise", field: "capital_walls_before_the_surprise", kind: Kind::OptIn, enable: AdvancedAi::enable_capital_walls_before_the_surprise, disable: AdvancedAi::disable_capital_walls_before_the_surprise },
    // Traced replays at 851192f2e (Tula civvis-20261014T080351Z turns
    // 136-141, Bhavapura, Sodo, Cincinnati): of 36 gun-turns that read "no
    // route step and no pass-through destination", 17 had spent part of their
    // moves and lacked the next tile's cost, and 8 held full moves while the
    // router's first step went round terrain or our column at an equal or
    // greater hex distance, which gun-queues-behind-the-column refused. On the
    // no-route call the queue step follows the road when the route to the post
    // falls, may land two tiles from a city that cannot strike, and the
    // short-of-moves case is journaled as such. See
    // `AdvancedAi::column_queue_step`.
    Gene { tag: "gun-queue-follows-the-road", field: "gun_queue_follows_the_road", kind: Kind::OptIn, enable: AdvancedAi::enable_gun_queue_follows_the_road, disable: AdvancedAi::disable_gun_queue_follows_the_road },
    // Live Emperor civvis-20261014T130619Z: Scone stood behind fallen walls
    // at 20-60 health turns 180-190 and never fell. The opening board applied
    // the bombers' volley and the siege's helicopter "joined the assault ...
    // captured true" behind it; the executor deferred every order after the
    // volley, so nothing was sent, but the board capture had already written
    // the siege to Hold, released its taker and freed its members, and the
    // re-planned frames found a 6-unit force under its bill. 12 of 40
    // "Captured X" decisions since 10-12 never landed. A capture made on the
    // frame's own earlier damage (the host reported the city healthier)
    // commits no siege state and its keep/raze line waits for the host; a
    // committed capture the host never executed over a falling city resumes
    // its siege, stage and taker. See `advanced/phantom_capture.rs`.
    Gene { tag: "phantom-capture-keeps-the-siege", field: "phantom_capture_keeps_the_siege", kind: Kind::OptIn, enable: AdvancedAi::enable_phantom_capture_keeps_the_siege, disable: AdvancedAi::disable_phantom_capture_keeps_the_siege },
    // No peace offered to, or accepted from, a faith's founder while we are its
    // last holdout and a city of ours follows or is converting to it, unless a
    // city of ours is falling. See `advanced/holdout_faith_war.rs`.
    Gene { tag: "holdout-keeps-the-faith-war", field: "holdout_keeps_the_faith_war", kind: Kind::OptIn, enable: AdvancedAi::enable_holdout_keeps_the_faith_war, disable: AdvancedAi::disable_holdout_keeps_the_faith_war },
    // A rival that has launched its Exoplanet Expedition and holds the city
    // whose capture completes Domination: the second front at once, that city
    // the objective at peace, and a declaration no major-war, treasury or
    // staging hold delays. See `advanced/launched_racer.rs`.
    Gene { tag: "launched-racer-yields-the-capital", field: "launched_racer_yields_the_capital", kind: Kind::OptIn, enable: AdvancedAi::enable_launched_racer_yields_the_capital, disable: AdvancedAi::disable_launched_racer_yields_the_capital },
    // Emperor native 230322Z still held ten Heavy Chariots at turn 89,
    // missing the ten Iron quoted for a Knight upgrade. Peaceful rivals
    // offered 25 Iron; no Iron buy was submitted. Ask for one useful
    // land upgrade's material, preserving its exact Gold bill. An offer
    // is not acceptance or execution. See `army_upgrade_materials`.
    Gene { tag: "army-upgrade-materials", field: "army_upgrade_materials", kind: Kind::OptIn, enable: AdvancedAi::enable_army_upgrade_materials, disable: AdvancedAi::disable_army_upgrade_materials },
    // An urgent Culture or Science racer our Conquest counter cannot reach,
    // behind one civilization's closed borders: that blocker, when weak by
    // closed-border-blocker-declares' reading, is the front every turn with
    // no held siege march, aimed at its city on the road. See
    // `advanced/silent_counter.rs`.
    Gene { tag: "racer-blocker-declares", field: "racer_blocker_declares", kind: Kind::OptIn, enable: AdvancedAi::enable_racer_blocker_declares, disable: AdvancedAi::disable_racer_blocker_declares },
    // A faithless seat loses the Prophet race to the 2-city floor: Astrology
    // waits for the second city and lands at t24-34, after the third Prophet
    // went at t31-44. The lone capital researches it once the opening techs
    // are in; the Holy Site still waits for the second city. See
    // `advanced/astrology_before_the_second_city.rs`.
    Gene { tag: "astrology-before-the-second-city", field: "astrology_before_the_second_city", kind: Kind::OptIn, enable: AdvancedAi::enable_astrology_before_the_second_city, disable: AdvancedAi::disable_astrology_before_the_second_city },
    // The race's other cheap lever: Divine Spark (+1 Prophet point a turn
    // on every Holy Site) ranks behind Religious Settlements and ahead of
    // Fertility Rites while the seat runs the race. See
    // `advanced/astrology_before_the_second_city.rs`.
    Gene { tag: "prophet-race-takes-divine-spark", field: "prophet_race_takes_divine_spark", kind: Kind::OptIn, enable: AdvancedAi::enable_prophet_race_takes_divine_spark, disable: AdvancedAi::disable_prophet_race_takes_divine_spark },
    // A city of ours losing health with a hostile soldier beside it ranks its
    // Defend row ahead of every Defend row of a city that is not under fire,
    // urgent, with a one-turn deadline floor. See
    // `advanced/objective_board.rs`.
    Gene { tag: "city-under-fire-ranks-first", field: "city_under_fire_ranks_first", kind: Kind::OptIn, enable: AdvancedAi::enable_city_under_fire_ranks_first, disable: AdvancedAi::disable_city_under_fire_ranks_first },
    // A defensive war (no siege, no staging) on a founding rival whose
    // spreaders stand within six tiles of our cities while our majority does
    // not follow its faith and a city of ours already leans to it, at 0.7
    // times its steady power, rout- and solvency-guarded; no peace while a
    // city of ours is converting, peace after five clear turns. See
    // `advanced/faith_war_before_the_flip.rs`.
    Gene { tag: "faith-war-before-the-flip", field: "faith_war_before_the_flip", kind: Kind::OptIn, enable: AdvancedAi::enable_faith_war_before_the_flip, disable: AdvancedAi::disable_faith_war_before_the_flip },
    // The base deck reads policy income paid to the player (Merchant
    // Confederation's Gold per Envoy, Raj's yields per tributary), and
    // Merchant Confederation joins the portfolio ahead of the plan's own
    // diplomatic cards while our Envoys pay ten Gold a turn. See
    // `merchant_confederation_pays` in `advanced.rs`.
    Gene { tag: "merchant-confederation-earns-its-slot", field: "merchant_confederation_earns_its_slot", kind: Kind::OptIn, enable: AdvancedAi::enable_merchant_confederation_earns_its_slot, disable: AdvancedAi::disable_merchant_confederation_earns_its_slot },
    // A siege held on a walled city turns to an open (unwalled or breached)
    // city of the same owner a healthy field-army melee can reach within
    // eight tiles and ten land steps, under Recovery or Expansion too and
    // past a prior with three quarters of its walls; skipped when the open
    // city's defence exceeds our best field melee by more than 15; held
    // until walled, captured or eight turns without progress. See
    // `advanced/open_city_front.rs`.
    Gene { tag: "open-city-draws-the-front", field: "open_city_draws_the_front", kind: Kind::OptIn, enable: AdvancedAi::enable_open_city_draws_the_front, disable: AdvancedAi::disable_open_city_draws_the_front },
    // faith-war-before-the-flip, version 2: held while our own founded faith
    // holds our majority (two cities of ours leaning to the rival's faith, or
    // our faith one city from losing its majority, open it); otherwise
    // version 1. See `advanced/faith_war_before_the_flip.rs`.
    Gene { tag: "faith-war-before-the-flip-2", field: "faith_war_before_the_flip_2", kind: Kind::OptIn, enable: AdvancedAi::enable_faith_war_before_the_flip_2, disable: AdvancedAi::disable_faith_war_before_the_flip_2 },
    // Version two of `holdout-keeps-the-faith-war`: the last holdout also
    // keeps the war at match point (the founder's race at 75% or more),
    // whatever its own cities' conversion, unless a city of ours is falling
    // or our capital is under siege. See `advanced/holdout_faith_war.rs`.
    Gene { tag: "holdout-keeps-the-faith-war-2", field: "holdout_keeps_the_faith_war_2", kind: Kind::OptIn, enable: AdvancedAi::enable_holdout_keeps_the_faith_war_2, disable: AdvancedAi::disable_holdout_keeps_the_faith_war_2 },
    // Medina Quarter (+2 Housing in every city with three specialty
    // districts) joins the policy portfolio, ahead of the plan's ordinary
    // cards, while two or more of our cities are housing-limited with three
    // specialty districts, and displaces the weakest Economic card the plan
    // wants least (never a production, Builder or Settler card). See
    // `advanced/medina_quarter.rs`.
    Gene { tag: "medina-quarter-houses-the-districts", field: "medina_quarter_houses_the_districts", kind: Kind::OptIn, enable: AdvancedAi::enable_medina_quarter_houses_the_districts, disable: AdvancedAi::disable_medina_quarter_houses_the_districts },
    // `solvent-or-hold`: while income is not positive, no Domination upgrade
    // whose added upkeep takes income below zero (upkeep-reserve floor), and
    // no amenity or upkeep card traded for another kind. 10-14 083713Z: unit
    // bill 30 -> 70 on 24 -> 30 units t128-145 as the modernizer read only the
    // treasury; Liberalism traded away while broke. See `advanced/solvency.rs`.
    Gene { tag: "solvent-or-hold", field: "solvent_or_hold", kind: Kind::OptIn, enable: AdvancedAi::enable_solvent_or_hold, disable: AdvancedAi::disable_solvent_or_hold },
    // `bankruptcy-exits-the-drain`: while the treasury holds less than one
    // turn of a negative income, gold cards first, two extra surplus sales,
    // then the cheapest units disbanded before the host takes the costliest.
    // 10-14: the bankruptcy amenity drain (20-120) turned every city Unhappy
    // in 083713Z and 100910Z. See `advanced/solvency.rs`.
    Gene { tag: "bankruptcy-exits-the-drain", field: "bankruptcy_exits_the_drain", kind: Kind::OptIn, enable: AdvancedAi::enable_bankruptcy_exits_the_drain, disable: AdvancedAi::disable_bankruptcy_exits_the_drain },
    // After Urbanization, the most housing-capped city with no Aqueduct left
    // to claim puts its best-housing Neighborhood first, one in flight per
    // five cities. See `advanced/neighborhood_houses_the_capped_city.rs`.
    Gene { tag: "neighborhood-houses-the-capped-city", field: "neighborhood_houses_the_capped_city", kind: Kind::OptIn, enable: AdvancedAi::enable_neighborhood_houses_the_capped_city, disable: AdvancedAi::disable_neighborhood_houses_the_capped_city },
    // Version one of merchant-confederation-earns-its-slot, and while the
    // card pays it takes a diplomatic seat from a card the portfolio ranks
    // after it (Gunboat Diplomacy seated under Communism kept version one
    // out). See `merchant_confederation_pays` in `advanced.rs`.
    Gene { tag: "merchant-confederation-earns-its-slot-2", field: "merchant_confederation_earns_its_slot_2", kind: Kind::OptIn, enable: AdvancedAi::enable_merchant_confederation_earns_its_slot_2, disable: AdvancedAi::disable_merchant_confederation_earns_its_slot_2 },
    // Early fortification for an exposed non-capital city watched by a
    // stronger peaceful major. Separate from the original-capital policy.
    Gene { tag: "frontier-walls-before-the-surprise", field: "frontier_walls_before_the_surprise", kind: Kind::OptIn, enable: AdvancedAi::enable_frontier_walls_before_the_surprise, disable: AdvancedAi::disable_frontier_walls_before_the_surprise },
    // Affordable suzerainty opens a road already blocking an active siege.
    Gene { tag: "envoys-open-the-siege-road", field: "envoys_open_the_siege_road", kind: Kind::OptIn, enable: AdvancedAi::enable_envoys_open_the_siege_road, disable: AdvancedAi::disable_envoys_open_the_siege_road },
    // Append before all tail markers to preserve every published genome index.
    Gene { tag: "siege-promotions-open-the-walls", field: "siege_promotions_open_the_walls", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_promotions_open_the_walls, disable: AdvancedAi::disable_siege_promotions_open_the_walls },
    // `siege-budget-counts-the-ram`: the damage budget priced a melee wall
    // swing at 0.15 only once a Ram already stood beside the city, and at 0
    // before, while the host lets a Ram-supported swing strike the walls
    // whole and a Tower carry it into the city. Live Emperor Lyon
    // (civvis-20261018T011334Z) held Stage turns 79-84 with a Ram, 12 of 14
    // units staged against Ancient Walls, at "70.2 turns / 25.0 endurance".
    Gene { tag: "siege-budget-counts-the-ram", field: "siege_budget_counts_the_ram", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_budget_counts_the_ram, disable: AdvancedAi::disable_siege_budget_counts_the_ram },
    // `campus-claims-the-free-slot`: 69% of our Emperor cities at t50 held a
    // free district slot and no Campus while the routine floor built Archers
    // and Walls in them; Science per citizen ran 0.8 against the rivals' 1.8,
    // and games with 2+ Campuses at t60 reached r150 0.62 against 0.30 with
    // none. See `advanced/campus_claims_the_free_slot.rs`.
    Gene { tag: "campus-claims-the-free-slot", field: "campus_claims_the_free_slot", kind: Kind::OptIn, enable: AdvancedAi::enable_campus_claims_the_free_slot, disable: AdvancedAi::disable_campus_claims_the_free_slot },
    // Version 2 of campus-claims-the-free-slot: from two citizens and in every
    // eligible city a turn. Version one's live claims began around turn 80; 23
    // of its t45-65 free-slot samples were held by the three-citizen floor.
    Gene { tag: "campus-claims-the-free-slot-2", field: "campus_claims_the_free_slot_2", kind: Kind::OptIn, enable: AdvancedAi::enable_campus_claims_the_free_slot_2, disable: AdvancedAi::disable_campus_claims_the_free_slot_2 },
    // `breaker-bought-for-the-siege`: 1,009 live Emperor siege-turns in 52 of
    // 62 games held a walled city with no breaker coming; Lyon
    // (civvis-20261018T011334Z) waited from turn 44 to 79 behind Ancient
    // Walls for Rams queued in 1-3 Production cities while the treasury held
    // about 150 Gold. See `advanced/siege_train/breaker_purchase.rs`.
    Gene { tag: "breaker-bought-for-the-siege", field: "breaker_bought_for_the_siege", kind: Kind::OptIn, enable: AdvancedAi::enable_breaker_bought_for_the_siege, disable: AdvancedAi::disable_breaker_bought_for_the_siege },
    // `gold-buys-the-idle-trader`: the first route slot stood empty at t30 in
    // 45 of 51 live Emperor games and at t60 in 24, while the bank held
    // 121-150 Gold and a Trader sold for about 95. See
    // `advanced/trader_fills_the_idle_route/purchase.rs`.
    Gene { tag: "gold-buys-the-idle-trader", field: "gold_buys_the_idle_trader", kind: Kind::OptIn, enable: AdvancedAi::enable_gold_buys_the_idle_trader, disable: AdvancedAi::disable_gold_buys_the_idle_trader },
    // `threatened-city-buys-its-defender`: live Emperor Cali
    // (civvis-20261018T045526Z) sold an Archer for 120 at turns 38-40 with
    // 151-172 Gold banked while it was the plan's threatened city, bought
    // nothing, and fell at 43 once a unit in it closed the menu. 37 of 164
    // Emperor runs lost a city by turn 100. See
    // `advanced/threatened_city_purchase.rs`.
    Gene { tag: "threatened-city-buys-its-defender", field: "threatened_city_buys_its_defender", kind: Kind::OptIn, enable: AdvancedAi::enable_threatened_city_buys_its_defender, disable: AdvancedAi::disable_threatened_city_buys_its_defender },
    // `threatened-city-buys-its-defender-2`: v1 bought 121 Warriors and 67
    // Heavy Chariots in 119 live runs; v2 buys a defender of the city's era
    // or keeps the Gold. See `advanced/threatened_city_purchase.rs`.
    Gene { tag: "threatened-city-buys-its-defender-2", field: "threatened_city_buys_its_defender_2", kind: Kind::OptIn, enable: AdvancedAi::enable_threatened_city_buys_its_defender_2, disable: AdvancedAi::disable_threatened_city_buys_its_defender_2 },
    // `air-wing-grows-with-the-aluminum`: live Emperor 052256Z banked 25
    // Aluminum (the cap) on +4 to +8 a turn from turn 150 with a four-Bomber
    // wing, and that wing took Sydney's 400 walls in six turns; the wing's
    // ceiling, not the metal, held it at four. See `AIR_WING_GROWN_BOMBERS`.
    Gene { tag: "air-wing-grows-with-the-aluminum", field: "air_wing_grows_with_the_aluminum", kind: Kind::OptIn, enable: AdvancedAi::enable_air_wing_grows_with_the_aluminum, disable: AdvancedAi::disable_air_wing_grows_with_the_aluminum },
    // `denial-target-leads-the-fronts`: live Emperor 071140Z was at war with
    // Byzantium from turn 140 at 1.4-2.9 times its power while the counter
    // named it; the campaign stayed on the Aztecs until 165 and Byzantium won
    // on Culture at 176. See `advanced/denial_target_front.rs`.
    Gene { tag: "denial-target-leads-the-fronts", field: "denial_target_leads_the_fronts", kind: Kind::OptIn, enable: AdvancedAi::enable_denial_target_leads_the_fronts, disable: AdvancedAi::disable_denial_target_leads_the_fronts },
    // `friendship-ends-at-the-race`: live Emperor 075143Z renewed its
    // friendship with Canada every 21 turns to 114, and at 150 the Conquest
    // counter to Canada's 54% Culture race was barred by it. See
    // `protective_friendship::FRIENDSHIP_RACE_CEILING`.
    Gene { tag: "friendship-ends-at-the-race", field: "friendship_ends_at_the_race", kind: Kind::OptIn, enable: AdvancedAi::enable_friendship_ends_at_the_race, disable: AdvancedAi::disable_friendship_ends_at_the_race },
    // `friendship-only-with-the-stronger`: 85% of the declared-friend
    // rival-frames in the first four live games under `befriend-the-strongest`
    // were with a rival weaker than us. See `protective_friendship.rs`.
    Gene { tag: "friendship-only-with-the-stronger", field: "friendship_only_with_the_stronger", kind: Kind::OptIn, enable: AdvancedAi::enable_friendship_only_with_the_stronger, disable: AdvancedAi::disable_friendship_only_with_the_stronger },
    // `foothold-faces-the-capital`: 56% of our war turns against a rival
    // capital's owner after turn 120 had no city of ours within Bomber range
    // of it; the campaign aimed at that range's town 154 of 408 turns. See
    // `advanced/foothold_faces_the_capital.rs`.
    Gene { tag: "foothold-faces-the-capital", field: "foothold_faces_the_capital", kind: Kind::OptIn, enable: AdvancedAi::enable_foothold_faces_the_capital, disable: AdvancedAi::disable_foothold_faces_the_capital },
    // `delegations-reach-every-rival`: 19 of 97 rivals met by turn 80 in
    // the live Emperor pin era held our Delegation or Embassy; the mission
    // step asked only the friendliest rival and sent nothing once it held
    // ours. See `advanced/delegations_reach_every_rival.rs`.
    Gene { tag: "delegations-reach-every-rival", field: "delegations_reach_every_rival", kind: Kind::OptIn, enable: AdvancedAi::enable_delegations_reach_every_rival, disable: AdvancedAi::disable_delegations_reach_every_rival },
    // `faith-war-is-no-front`: 51 of 106 live pin-era wars were faith wars;
    // the campaign aimed at their rival on 810 of 1,023 turns and took 1.0
    // cities per 100, against 6.4 for our conquest wars. See
    // `advanced/faith_war_is_no_front.rs`.
    Gene { tag: "faith-war-is-no-front", field: "faith_war_is_no_front", kind: Kind::OptIn, enable: AdvancedAi::enable_faith_war_is_no_front, disable: AdvancedAi::disable_faith_war_is_no_front },
    // `faith-war-is-no-front-2`: 115456Z's interception on the Khmer, no
    // Khmer city ever located, held the campaign from 78 to the Culture loss
    // at 144 beside a three-city India at a fifteenth of our power.
    Gene { tag: "faith-war-is-no-front-2", field: "faith_war_is_no_front_2", kind: Kind::OptIn, enable: AdvancedAi::enable_faith_war_is_no_front_2, disable: AdvancedAi::disable_faith_war_is_no_front_2 },
    // `friendship-spares-the-target`: 46 of 153 live friendship offers on
    // pins g-m went to the campaign's own target; 125943Z befriended China at
    // 7 power while aiming at it. See `protective_friendship.rs`.
    Gene { tag: "friendship-spares-the-target", field: "friendship_spares_the_target", kind: Kind::OptIn, enable: AdvancedAi::enable_friendship_spares_the_target, disable: AdvancedAi::disable_friendship_spares_the_target },
    // `stage-reads-the-muster-breakers`: 140 Stage turns over 57 live
    // pin-era sieges held "nothing to open the walls" with the muster closed
    // and a healthy gun 6-8 tiles out, past the 5-tile staging read. See
    // `advanced/siege_train/stage_reads_the_muster.rs`.
    Gene { tag: "stage-reads-the-muster-breakers", field: "stage_reads_the_muster_breakers", kind: Kind::OptIn, enable: AdvancedAi::enable_stage_reads_the_muster_breakers, disable: AdvancedAi::disable_stage_reads_the_muster_breakers },
    // `unwalled-ring-steps-in`: in 12 of 20 live walls-down sieges the city
    // never fell below 150; melee stood 2-3 tiles out on 56 unit-turns
    // against 30 on the ring, and the open ring healed the city 20 a turn.
    // See `advanced/siege_train/unwalled_ring.rs`.
    Gene { tag: "unwalled-ring-steps-in", field: "unwalled_ring_steps_in", kind: Kind::OptIn, enable: AdvancedAi::enable_unwalled_ring_steps_in, disable: AdvancedAi::disable_unwalled_ring_steps_in },
    // `friendship-spares-the-prey`: at turn 100 in 11 of the 20 live games
    // with a rival under 0.4 times our power, that rival was our declared
    // friend. See `protective_friendship::FRIENDSHIP_PREY_RATIO`.
    Gene { tag: "friendship-spares-the-prey", field: "friendship_spares_the_prey", kind: Kind::OptIn, enable: AdvancedAi::enable_friendship_spares_the_prey, disable: AdvancedAi::disable_friendship_spares_the_prey },
    // `campus-unlock-before-the-luxury`: Writing at t34.5 behind Astrology,
    // Sailing and Irrigation; first Campus t50; our Science 8 against the best
    // rival's 25 at t40. See `advanced/domination_research.rs`.
    Gene { tag: "campus-unlock-before-the-luxury", field: "campus_unlock_before_the_luxury", kind: Kind::OptIn, enable: AdvancedAi::enable_campus_unlock_before_the_luxury, disable: AdvancedAi::disable_campus_unlock_before_the_luxury },
    // `prey-is-declared-on`: live Emperor held wars on rivals at a fifth to
    // a tenth of our power for 15-30 turns on short home Defend rows and an
    // unstaged ring. See `advanced/prey_declaration.rs`.
    Gene { tag: "prey-is-declared-on", field: "prey_is_declared_on", kind: Kind::OptIn, enable: AdvancedAi::enable_prey_is_declared_on, disable: AdvancedAi::disable_prey_is_declared_on },
    // `city-state-war-is-no-front`: 29% of live Emperor campaign turns
    // (t60-200, 120 games) aimed at a city-state, the war shutting every
    // at-peace branch of the target choice. See
    // `advanced/city_state_war_is_no_front.rs`.
    Gene { tag: "city-state-war-is-no-front", field: "city_state_war_is_no_front", kind: Kind::OptIn, enable: AdvancedAi::enable_city_state_war_is_no_front, disable: AdvancedAi::disable_city_state_war_is_no_front },
    // `staging-gun-trusts-its-escort-2`: live Emperor 10-25 (043224Z) held
    // six or seven healthy catapults six to thirteen tiles from Nuri for
    // 36 turns; 72% of those gun-turns had at most one soldier beside the
    // step, 67% had two or more within two tiles. See
    // `siege_train::STAGING_COLUMN_BODIES`.
    Gene { tag: "staging-gun-trusts-its-escort-2", field: "staging_gun_trusts_its_escort_2", kind: Kind::OptIn, enable: AdvancedAi::enable_staging_gun_trusts_its_escort_2, disable: AdvancedAi::disable_staging_gun_trusts_its_escort_2 },
    // `prey-war-is-kept`: live Emperor 10-25, 5 of 29 games made peace
    // with a rival at a seventh to a third of our power (China 444/63 with
    // Xi'an at 40 HP). See `advanced/prey_war_is_kept.rs`.
    Gene { tag: "prey-war-is-kept", field: "prey_war_is_kept", kind: Kind::OptIn, enable: AdvancedAi::enable_prey_war_is_kept, disable: AdvancedAi::disable_prey_war_is_kept },
    // `defenders-hold-the-walls`: live Emperor 10-25 (070148Z) lost its
    // capital to two or three Trebuchets while nine of ours stood within
    // three tiles, doomed or rotated out by the danger at their stands. See
    // `advanced/defenders_hold_the_walls.rs`.
    Gene { tag: "defenders-hold-the-walls", field: "defenders_hold_the_walls", kind: Kind::OptIn, enable: AdvancedAi::enable_defenders_hold_the_walls, disable: AdvancedAi::disable_defenders_hold_the_walls },
    // `war-faith-buys-the-army`: live Emperor 10-25, faith income 22-38 a
    // turn at t100-175 and the host selling Knights for 220 Faith, yet 1,010
    // Missionaries against ~90 combat units bought. See
    // `advanced/war_faith.rs`.
    Gene { tag: "war-faith-buys-the-army", field: "war_faith_buys_the_army", kind: Kind::OptIn, enable: AdvancedAi::enable_war_faith_buys_the_army, disable: AdvancedAi::disable_war_faith_buys_the_army },
    // Version two retains the at-war launch release and stages a physical
    // Culture air interception; only two fresh selected safe sorties open it.
    Gene { tag: "elimination-yields-to-a-launch-2", field: "elimination_yields_to_a_launch_2", kind: Kind::OptIn, enable: AdvancedAi::enable_elimination_yields_to_a_launch_2, disable: AdvancedAi::disable_elimination_yields_to_a_launch_2 },
    // `faith-war-needs-the-edge`: live 10-25, a first faith war on a founder
    // at 0.7 times our power or more preceded 11 collapses in 45 games, none
    // in 9 under it. See `faith_war_before_the_flip::FAITH_WAR_EDGE`.
    Gene { tag: "faith-war-needs-the-edge", field: "faith_war_needs_the_edge", kind: Kind::OptIn, enable: AdvancedAi::enable_faith_war_needs_the_edge, disable: AdvancedAi::disable_faith_war_needs_the_edge },

    // Append the new tag after existing positional rows, before tail markers.
    Gene { tag: "wing-capital-spotting", field: "wing_capital_spotting", kind: Kind::OptIn, enable: AdvancedAi::enable_wing_capital_spotting, disable: AdvancedAi::disable_wing_capital_spotting },
    // `the-giant-gets-the-peace-offer`: live Immortal 10-25, 5 of 17 games
    // collapsed to one city against a rival at 2.5-20 times our power that the
    // peace gate never offered peace. See `advanced/giant_peace.rs`.
    Gene { tag: "the-giant-gets-the-peace-offer", field: "the_giant_gets_the_peace_offer", kind: Kind::OptIn, enable: AdvancedAi::enable_the_giant_gets_the_peace_offer, disable: AdvancedAi::disable_the_giant_gets_the_peace_offer },
    // `the-last-two-capitals-come-first`: retained live games to 10-25, 12
    // reached two or fewer capitals to take (one won); 139 campaign turns
    // aimed elsewhere at a rival holding one, against 41 at the capital. See
    // `advanced/last_two_capitals.rs`.
    Gene { tag: "the-last-two-capitals-come-first", field: "the_last_two_capitals_come_first", kind: Kind::OptIn, enable: AdvancedAi::enable_the_last_two_capitals_come_first, disable: AdvancedAi::disable_the_last_two_capitals_come_first },
    Gene { tag: "capital-watch-arms-the-slinger", field: "capital_watch_arms_the_slinger", kind: Kind::OptIn, enable: AdvancedAi::enable_capital_watch_arms_the_slinger, disable: AdvancedAi::disable_capital_watch_arms_the_slinger },
    // `launcher-war-skips-the-reserve`: retained live games October 22-25,
    // the treasury reserve held the war on a racer past its Moon on 34 turns
    // in 11 games; 231506Z declared on Macedon six turns late and lost on
    // Science. See `advanced/launcher_war.rs`.
    Gene { tag: "launcher-war-skips-the-reserve", field: "launcher_war_skips_the_reserve", kind: Kind::OptIn, enable: AdvancedAi::enable_launcher_war_skips_the_reserve, disable: AdvancedAi::disable_launcher_war_skips_the_reserve },
    // `nuclear-goal-needs-a-launcher`: the live bridge builds warheads but
    // carries no WMD strike; 26 of 123 retained live games spent about 20,200
    // Production on nuclear projects. Arm it on the live seat only. See
    // `advanced/nuclear_launcher.rs`.
    Gene { tag: "nuclear-goal-needs-a-launcher", field: "nuclear_goal_needs_a_launcher", kind: Kind::OptIn, enable: AdvancedAi::enable_nuclear_goal_needs_a_launcher, disable: AdvancedAi::disable_nuclear_goal_needs_a_launcher },
    Gene { tag: "forward-airfield-project", field: "forward_airfield_project", kind: Kind::OptIn, enable: AdvancedAi::enable_forward_airfield_project, disable: AdvancedAi::disable_forward_airfield_project },
    // `aluminum-tile-spends-the-war-chest`: live Immortal 070741Z held a
    // 135-Gold Aluminum tile against a 1,669 reserve from Advanced Flight
    // (t124) to t169 and never flew a Bomber. The tile now keeps only the
    // upkeep floor. See `AdvancedAi::aluminum_tile_reserve`.
    Gene { tag: "aluminum-tile-spends-the-war-chest", field: "aluminum_tile_spends_the_war_chest", kind: Kind::OptIn, enable: AdvancedAi::enable_aluminum_tile_spends_the_war_chest, disable: AdvancedAi::disable_aluminum_tile_spends_the_war_chest },
    // `friendship-spares-the-converter`: retained live Immortal games to
    // 10-27, 4 of 14 Religious losses held the faith war on the founder
    // converting us as "not a legal target": `befriend-the-strongest` had
    // befriended it at turns 42-54, before its faith reached us. See
    // `advanced/protective_friendship.rs`.
    Gene { tag: "friendship-spares-the-converter", field: "friendship_spares_the_converter", kind: Kind::OptIn, enable: AdvancedAi::enable_friendship_spares_the_converter, disable: AdvancedAi::disable_friendship_spares_the_converter },
    // `siege-tier-yields-to-the-bombers-2`: over 261 Immortal control dirs
    // the window yielded in 26 games, at a median 7 techs from the Bomber
    // (12 in 031756Z t82, where it gave up Gunpowder; Metal Casting came at
    // t118, after rival walls reached 400). The yield now waits until the
    // Bomber is near. See `AdvancedAi::window_yields_to_the_bombers`.
    Gene { tag: "siege-tier-yields-to-the-bombers-2", field: "siege_tier_yields_to_the_bombers_2", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_tier_yields_to_the_bombers_2, disable: AdvancedAi::disable_siege_tier_yields_to_the_bombers_2 },
    // `siege-shortfall-claims-the-projects`: retained live Immortal games to
    // 10-27, capital sieges sat in Stage on 89% of 1,248 turns at a median
    // 0.09 of their bill while Theater and Campus projects took 4.8% of
    // wartime Production. See `advanced/siege_shortfall_projects.rs`.
    Gene { tag: "siege-shortfall-claims-the-projects", field: "siege_shortfall_claims_the_projects", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_shortfall_claims_the_projects, disable: AdvancedAi::disable_siege_shortfall_claims_the_projects },
    // `disrupt-before-the-sources`: retained live Immortal games to 10-27,
    // with Disrupt Rocketry offered, a green Spy ran Gain Sources 71 times
    // against 91 disruptions; 061046Z held a Spy in Beijing 168-196 with it
    // offered and never ran it. See `advanced/disrupt_before_the_sources.rs`.
    Gene { tag: "disrupt-before-the-sources", field: "disrupt_before_the_sources", kind: Kind::OptIn, enable: AdvancedAi::enable_disrupt_before_the_sources, disable: AdvancedAi::disable_disrupt_before_the_sources },
    // `siege-moves-under-the-wing`: post-reboot live Immortal games to 10-28
    // that reached turn 160 with Bombers spent 385 of 668 siege-turns on an
    // objective beyond the wing's reach, 120 of them with another city of
    // the same rival within it (233902Z held Pewen Mapu's unbreachable walls
    // t150-193 beside Ina Pire Mapu). See `advanced/siege_under_the_wing.rs`.
    Gene { tag: "siege-moves-under-the-wing", field: "siege_moves_under_the_wing", kind: Kind::OptIn, enable: AdvancedAi::enable_siege_moves_under_the_wing, disable: AdvancedAi::disable_siege_moves_under_the_wing },
    // `unchosen-war-takes-the-first-peace`: live Immortal 10-26/28, a major's
    // declaration on us by turn 60 cut our Production share from 0.38 to 0.25
    // in ten turns (77% retired by turn 95, 37% with no war); white peace was
    // taken 31/44 at war ages 8-11, yet 35 of 428 war turns at ages 10-30
    // carried an offer. See `advanced/unchosen_war_peace.rs`.
    Gene { tag: "unchosen-war-takes-the-first-peace", field: "unchosen_war_takes_the_first_peace", kind: Kind::OptIn, enable: AdvancedAi::enable_unchosen_war_takes_the_first_peace, disable: AdvancedAi::disable_unchosen_war_takes_the_first_peace },
    // `prey-waits-for-the-march`: live Immortal 10-27/28, the prey waiver
    // opened wars with the field army's median 12-25 tiles from the
    // objective; those took no city in 20 wars. See
    // `advanced/prey_declaration.rs`.
    Gene { tag: "prey-waits-for-the-march", field: "prey_waits_for_the_march", kind: Kind::OptIn, enable: AdvancedAi::enable_prey_waits_for_the_march, disable: AdvancedAi::disable_prey_waits_for_the_march },
    // `prey-waits-for-the-march-2`: version one with a median bar of 6 and a
    // siege gun within 6 of the objective; live war orders on majors took a
    // city within 20 turns 4/43 at a median ≤6 against 2/46 at 7-10, and 1/66
    // with no gun fielded. See `advanced/prey_declaration.rs`.
    Gene { tag: "prey-waits-for-the-march-2", field: "prey_waits_for_the_march_2", kind: Kind::OptIn, enable: AdvancedAi::enable_prey_waits_for_the_march_2, disable: AdvancedAi::disable_prey_waits_for_the_march_2 },
    // `upkeep-waits-for-the-income`: live Immortal 10-27/10-29, 11 of the 30
    // games past turn 160 went bankrupt (the host's 10-amenity charge put
    // every city at -40% and disbanded the costliest units); income went +25
    // to -37 in nine turns of 162814Z as queued modern units came due. A
    // Domination seat prices out an upkeep item when income, less every other
    // queue head's upkeep, less its own, goes below zero and the bank cannot
    // carry that deficit 15 turns; a queued one under half paid gives the
    // queue back. A threatened city's land defender never waits, nor does a
    // Recovery plan's, and nothing waits before standard turn 240 (live t120):
    // v1 set aside 18 Spearmen/Archers at t45-50 of 052705Z's early war. See
    // `advanced/upkeep_waits_for_the_income.rs`.
    Gene { tag: "upkeep-waits-for-the-income", field: "upkeep_waits_for_the_income", kind: Kind::OptIn, enable: AdvancedAi::enable_upkeep_waits_for_the_income, disable: AdvancedAi::disable_upkeep_waits_for_the_income },
    // `food-focus-grows-the-small-city` (native seat only): live Immortal
    // 10-28/29, our small cities with housing room grew at a median +2 Food
    // from t10 to t80 (60-69% at +2 or less); rival capitals reached 10
    // citizens at t60 against our 6. The native growth recovery favoured Food
    // only at zero surplus (4-9% of those cities; +0.2 -> +1.7 Food for 7.5 ->
    // 6.3 Production where it did). This widens its request to a city of up
    // to five growing at two or less, never to a city training a Settler (v1
    // put the capital's settler pump on Food: 4 cities at t60 against 5). See
    // `advanced/food_focus_grows_the_small_city.rs`.
    Gene { tag: "food-focus-grows-the-small-city", field: "food_focus_grows_the_small_city", kind: Kind::OptIn, enable: AdvancedAi::enable_food_focus_grows_the_small_city, disable: AdvancedAi::disable_food_focus_grows_the_small_city },
    // `capital-monument-after-the-second-city`: live Immortal 10-28/29, our
    // culture ran 3.9 / 6.6 / 10.7 against the rivals' 16 / 35 / 54 at t30 /
    // t45 / t60 and Political Philosophy came at t43; the capital had no
    // Monument by t85 in more than half the games (monument-first waits for
    // three cities behind every earlier claim). Fast expanders whose capital
    // built one within 8 turns of the third city reached Political Philosophy
    // at t34 against t42. From the second city on, an unthreatened capital at
    // peace with the majors claims its Monument once. See
    // `advanced/capital_monument.rs`.
    Gene { tag: "capital-monument-after-the-second-city", field: "capital_monument_after_the_second_city", kind: Kind::OptIn, enable: AdvancedAi::enable_capital_monument_after_the_second_city, disable: AdvancedAi::disable_capital_monument_after_the_second_city },
    // `culture-seat-theater-first`: live Prince Pericles 10-30, Drama and
    // Poetry at t62-63 but the first Acropolis only at t110-121 while the
    // ungated Campus claims took every first slot (10 Campuses, 3 Acropoleis
    // and 0 Great Works at t138); one Culture seat lost to France at t228. A
    // Culture seat's unthreatened cities claim their first Theater Square once
    // it is unlocked, and the free-slot Campus claim yields them. See
    // `advanced/culture_theater_first.rs`.
    Gene { tag: "culture-seat-theater-first", field: "culture_seat_theater_first", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_seat_theater_first, disable: AdvancedAi::disable_culture_seat_theater_first },
    // The Statue of Liberty is four of the twenty Diplomatic Victory Points;
    // live King civvis-20261030T074500Z lost to Culture at t207 standing on
    // 18, and the first live Diplomatic win (081846Z t208) needed one point
    // between sessions. Under lane delegation nothing prices those wonders:
    // a Diplomatic seat now keeps one in production in its strongest city.
    // See `advanced/diplo_wonder_claim.rs`.
    Gene { tag: "diplo-seat-wonder-claim", field: "diplo_seat_wonder_claim", kind: Kind::OptIn, enable: AdvancedAi::enable_diplo_seat_wonder_claim, disable: AdvancedAi::disable_diplo_seat_wonder_claim },
    // Every live King rival-Technology loss of 2026-10-30 had us leading the
    // field in science: civvis-20261030T053333Z (Culture seat, 475 a turn
    // against Mapuche's 428, lost t236), 060008Z (Culture, 456 against the
    // Aztecs' 441, t209) and 070824Z-cont1 (Diplomatic, 452 against India's
    // 303, t231) -- and `science-victory-drive` never opens on a seat
    // assigned another lane. With this on it opens there once a rival has
    // landed a space project and we lead, and races Science beside the lane.
    Gene { tag: "science-drive-answers-the-launch", field: "science_drive_answers_the_launch", kind: Kind::OptIn, enable: AdvancedAi::enable_science_drive_answers_the_launch, disable: AdvancedAi::disable_science_drive_answers_the_launch },
    // The defensive Inquisition (save for the Apostle, launch, Inquisitors
    // first) was gated to Domination seats when it was written for that lane
    // (#3656). On the Pericles ladder no seat is Domination: live Emperor
    // civvis-20261030T103149Z (Diplomatic) held 8 of 9 cities for Buddhism at
    // t90, bought eleven Missionaries and a Guru at +17-29 Faith, never an
    // Apostle, and lost to Judaism on Religion at t127. Diplomatic seats now
    // prepare it too (paired: Diplomatic 3 -> 4 wins of 20; Culture measured
    // 9 -> 7 and left out). See `advanced/defensive_apostle.rs`.
    Gene { tag: "inquisition-defends-the-diplomat", field: "inquisition_defends_the_diplomat", kind: Kind::OptIn, enable: AdvancedAi::enable_inquisition_defends_the_diplomat, disable: AdvancedAi::disable_inquisition_defends_the_diplomat },
    // `culture-seat-monuments`: the first live Emperor Culture seat
    // (civvis-20261030T090715Z) held one Monument in six cities at t60 and
    // made 12 Culture a turn against Egypt's 56. A Culture seat's
    // unthreatened cities claim their Monument once the second city stands,
    // ahead of a deferrable head, while no major is at war with us. See
    // `advanced/culture_monuments.rs`.
    Gene { tag: "culture-seat-monuments", field: "culture_seat_monuments", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_seat_monuments, disable: AdvancedAi::disable_culture_seat_monuments },
    // Seasteads and Global Warming Mitigation are a Diplomatic Victory Point
    // each, and near the bar Congress stops paying: live Emperor
    // civvis-20261030T111154Z stood on 18 of 20 from t180 to its Culture loss
    // at t213, every rival voting B on it at t200; Seasteads never landed once
    // the plan read Recovery. From 16 points the seat researches and adopts
    // both first. See `advanced/diplo_match_point_research.rs`.
    Gene { tag: "diplo-match-point-beelines-the-points", field: "diplo_match_point_beelines", kind: Kind::OptIn, enable: AdvancedAi::enable_diplo_match_point_beelines_the_points, disable: AdvancedAi::disable_diplo_match_point_beelines_the_points },
    // `culture-keeps-every-border-open`: tourism pressure is banked with the
    // multiplier in force when it is generated, and a rival's Open Borders
    // grant is +25% against it. The Culture objective bought one grant every
    // sixth turn and held 0-2 of three rivals at most turn-25 marks of a
    // native Immortal culture census. Once our tourism reaches 15 a turn, a
    // Culture seat buys every allowed grant each turn, the bar holder first,
    // never into the solvency reserve. See `advanced/culture_open_borders.rs`.
    Gene { tag: "culture-keeps-every-border-open", field: "culture_keeps_every_border_open", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_keeps_every_border_open, disable: AdvancedAi::disable_culture_keeps_every_border_open },
    // The defensive Inquisition waits to spread our faith first while it
    // holds under half our cities -- right for an unconverted empire, wrong
    // for one a rival faith is taking: live Emperor civvis-20261030T120109Z
    // (Diplomatic) founded Buddhism, held one Temple city of four against
    // Catholicism's two from t64 to t80, never launched, lost its Holy City
    // by t88 and the game to Religion at t114 with 1,169 Faith banked. With
    // this on, a rival-held city of ours ends the wait. See
    // `advanced/defensive_apostle.rs`.
    Gene { tag: "inquisition-answers-a-rival-majority", field: "inquisition_answers_a_rival_majority", kind: Kind::OptIn, enable: AdvancedAi::enable_inquisition_answers_a_rival_majority, disable: AdvancedAi::disable_inquisition_answers_a_rival_majority },
    // `diplo-seat-statue-harbor`: the Statue of Liberty (+4 Diplomatic
    // Victory Points) needs a Harbor beside its coast tile; in live Emperor
    // civvis-20261030T101932Z it never once reached our buildable list (our
    // only Harbor, in a 15-19 Production city, from t160), and 111154Z sat at
    // 18 points for thirty turns. A Diplomacy seat's strongest coastal city
    // claims its first Harbor while the Statue is open. See
    // `advanced/diplo_statue_harbor.rs`.
    Gene { tag: "diplo-seat-statue-harbor", field: "diplo_seat_statue_harbor", kind: Kind::OptIn, enable: AdvancedAi::enable_diplo_seat_statue_harbor, disable: AdvancedAi::disable_diplo_seat_statue_harbor },
    // `hidden-border-yields-to-our-pressure`: live Immortal
    // civvis-20261030T123145Z held a Settler out from t50 past t80, at peace,
    // after sixteen "rival border whose city may be hidden" refusals, and
    // retired at t88 on four cities. The unresolved-border veto yields where
    // our own cities press the site (population times closeness, 20 or more).
    // See `advanced/hidden_border_reach.rs`.
    Gene { tag: "hidden-border-yields-to-our-pressure", field: "hidden_border_yields_to_our_pressure", kind: Kind::OptIn, enable: AdvancedAi::enable_hidden_border_yields_to_our_pressure, disable: AdvancedAi::disable_hidden_border_yields_to_our_pressure },
    // The founder's Inquisition reserve holds only while the Apostle is five
    // turns of Faith away; live Immortal civvis-20261030T171157Z (Diplomatic,
    // 16 DVP to the rivals' 3-6) earned +11-13 a turn, sat 124-184 short of
    // the Apostle each review, bought five Missionaries t60-94 while its Holy
    // City held Catholicism with Temple, Shrine and Holy Site, and lost to
    // Religion at t168. A Diplomatic founder whose Holy City still follows its
    // faith now saves over fifteen turns. See `advanced/founder_defence.rs`.
    Gene { tag: "diplomat-saves-for-the-apostle", field: "diplomat_saves_for_the_apostle", kind: Kind::OptIn, enable: AdvancedAi::enable_diplomat_saves_for_the_apostle, disable: AdvancedAi::disable_diplomat_saves_for_the_apostle },
    // `culture-routes-reach-every-rival`: an international route of ours is
    // +25% on the tourism pressure banked against its owner, and a native
    // Immortal culture census found routes to about half the rivals at turns
    // 100-125 of the tourism ramp. While a Culture seat's tourism is at least
    // 15, a Trader in one of our cities that can reach a rival without our
    // route goes there, the bar holder first. See `advanced/culture_routes.rs`.
    Gene { tag: "culture-routes-reach-every-rival", field: "culture_routes_reach_every_rival", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_routes_reach_every_rival, disable: AdvancedAi::disable_culture_routes_reach_every_rival },
    // `trade-quotes-pay-the-lump`: `quoted_payment` pays a quote's fraction
    // as 0.1 Gold a turn, checked against `empire_gold_per_turn` (4 Gold a
    // city less upkeep, floor zero). A native Immortal culture census read that
    // proxy as zero from turn 100 in every game while real income was 30-200,
    // and the seat's luxury, strategic and Great Work quotes fell from 1-5 to
    // none. This seat's quotes pay a rounded-up lump the payer can cover. See
    // `advanced/trade_quotes_lump.rs`.
    Gene { tag: "trade-quotes-pay-the-lump", field: "trade_quotes_pay_the_lump", kind: Kind::OptIn, enable: AdvancedAi::enable_trade_quotes_pay_the_lump, disable: AdvancedAi::disable_trade_quotes_pay_the_lump },
    // Live Immortal 10-30 civvis-20261030T171157Z (diplomatic): 16 DVP at t160
    // against 3-6, lost to Islam's Religious Victory at 168. Our Catholicism
    // held none of our cities from 100, Islam 8 of 10 from 145, 300-780 Faith
    // banked with no religious unit: the counterweight family answers only
    // the Domination lane and only a seat that never founded. On the
    // Diplomacy lane it answers too, and a founder with no city of its faith
    // defends as faithless. See `advanced/counterweight_diplomat.rs`.
    Gene { tag: "counterweight-defends-the-diplomat", field: "counterweight_defends_the_diplomat", kind: Kind::OptIn, enable: AdvancedAi::enable_counterweight_defends_the_diplomat, disable: AdvancedAi::disable_counterweight_defends_the_diplomat },
    // A Diplomatic seat with no counterweight source has no religious defence
    // but a war: native diplomatic religious losses 52011/17/18 had every city
    // on the threat by turns 86-95 with 297-352 Faith banked, and live 171157Z
    // lost at 168 on 16 DVP. `faith-war-before-the-flip` (spreaders 0.26 a
    // turn at war against 1.47 at peace) opens on the Diplomacy lane too. See
    // `faith_war_lane` in `advanced/counterweight_diplomat.rs`.
    Gene { tag: "faith-war-defends-the-diplomat", field: "faith_war_defends_the_diplomat", kind: Kind::OptIn, enable: AdvancedAi::enable_faith_war_defends_the_diplomat, disable: AdvancedAi::disable_faith_war_defends_the_diplomat },
    // 13 live religious losses 2026-10-30: a counterfaith city of ours stood in
    // 7, one with a Holy Site in 1, so no counterweight Missionary could be
    // bought (171157Z: Buddhist Argos and Rhodes t70-168, no Holy Site, 337-718
    // Faith banked, 16 DVP at t160). A faithless seat a rival faith presses
    // claims a Holy Site in its biggest safe-counterfaith city. See
    // `counterweight_builds_its_source` in `advanced/counterweight_diplomat.rs`.
    Gene { tag: "counterweight-builds-its-source", field: "counterweight_builds_its_source", kind: Kind::OptIn, enable: AdvancedAi::enable_counterweight_builds_its_source, disable: AdvancedAi::disable_counterweight_builds_its_source },
    // Live Immortal culture seats 2026-10-30: 38-134 "recovery plan" lines a
    // game, and Recovery's Faith reserve holds whenever any non-culture unit is
    // on a menu. 132518Z: a Band (550) or Naturalist (350) for sale with twice
    // its price banked on 22 turns, 4,384 Faith at t210, none bought. A named
    // Culture seat in Recovery spends once the bank holds twice the cheapest.
    // See `advanced/culture_recovery_bank.rs`.
    Gene { tag: "culture-recovery-spends-the-bank", field: "culture_recovery_spends_the_bank", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_recovery_spends_the_bank, disable: AdvancedAi::disable_culture_recovery_spends_the_bank },
    // 13 live Science-Victory losses 2026-10-30: the first Disrupt Rocketry
    // came 30 turns after the racer's first project (153459Z, Culture), 24
    // (162440Z) and 13 (084235Z), each with a Spy waiting in a leader city
    // with no pad, its Spaceport unseen. Once the leader has landed a project,
    // a Spy where Disrupt Rocketry is not offered moves on to the leader's
    // next city until it finds the pad. Needs `racer-keeps-the-spies`. See
    // `advanced/racer_keeps_the_spies.rs`.
    Gene { tag: "racer-spies-search-for-the-pad", field: "racer_spies_search_for_the_pad", kind: Kind::OptIn, enable: AdvancedAi::enable_racer_spies_search_for_the_pad, disable: AdvancedAi::disable_racer_spies_search_for_the_pad },
    // Live Lv 7 Immortal 2026-10-30: nine Culture/Diplomatic seats lost to a
    // Science Victory with no war on the racer between its Moon and its
    // launch, five of them at 0.8x its power or better for most of that window
    // (224544Z 35/36 turns). `counter-in-lane` answers a Science threat in
    // lane off Domination, and the launcher war opens only from a Conquest
    // plan. Off Domination, the racer `launcher_war_opens` names becomes the
    // Conquest counter. Needs `launcher-war-ignores-the-edge`. See
    // `advanced/launcher_war_every_lane.rs`.
    Gene { tag: "launcher-war-serves-every-lane", field: "launcher_war_serves_every_lane", kind: Kind::OptIn, enable: AdvancedAi::enable_launcher_war_serves_every_lane, disable: AdvancedAi::disable_launcher_war_serves_every_lane },
    // Ten live Lv 7 Culture seats 2026-10-30 held no alliance at t80, t120 or
    // t160: the live binary and the agent passed alliances only for the
    // Diplomatic lane, and early wars were the culture seats' worst losses.
    // A Culture seat allies its nearest safe rival, never the science racer
    // or the rival that sets our culture bar. See
    // `advanced/culture_seat_allies.rs`.
    Gene { tag: "culture-seat-allies", field: "culture_seat_allies", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_seat_allies, disable: AdvancedAi::disable_culture_seat_allies },
    // Live Immortal seats 2026-10-30 (54 games): the first Builder came at a
    // median turn 26 (scout, Settler, slinger, Settler first), 5% of owned land
    // stood improved at turn 40 against the rivals' 26%, and their population
    // ran 1.6x ours from turn 20. Once the capital's first Settler is out and
    // the empire has never held a Builder, the capital trains one before its
    // next Settler. See `BasicAi::opening_builder_after_the_first_settler`.
    Gene { tag: "opening-builder-after-the-first-settler", field: "opening_builder_after_the_first_settler", kind: Kind::OptIn, enable: AdvancedAi::enable_opening_builder_after_the_first_settler, disable: AdvancedAi::disable_opening_builder_after_the_first_settler },
    // Live Lv 7/8 2026-10-30/31: 7 of 8 seats declared on by t40 lost a
    // city by t41, five of them with walls part-built. The walls' live 2.0x
    // reading stood down when we armed (001453Z: bought warriors lifted us
    // to 1.7x and Athens built a Monument first) or the rival dipped
    // (173341Z: 1.6x). A 2x major seen within ten tiles of the capital or a
    // frontier city keeps that city's walls, and Masonry, armed for the
    // ten-turn window. Needs `capital-walls-before-the-surprise` and/or
    // `frontier-walls-before-the-surprise`. See
    // `advanced/surprise_watch_latch.rs`.
    Gene { tag: "surprise-watch-holds-its-ratio", field: "surprise_watch_holds_its_ratio", kind: Kind::OptIn, enable: AdvancedAi::enable_surprise_watch_holds_its_ratio, disable: AdvancedAi::disable_surprise_watch_holds_its_ratio },
    // Live Immortal 10-30, 21 seats: a Settler lived a median 8 turns (51% at
    // 8+, tails to 58) before founding, and 571 of ~630 "Settler HELD" lines
    // were the safe-step guard against barbarian raiders, and the stall-expiry
    // fallback then refused on the same tile risk. With barbarians the only
    // visible threat and a city that would outlast them (live barbarians do
    // take cities), the held Settler founds in place.
    // See `advanced/settler_raiders.rs`.
    Gene { tag: "settler-founds-under-raiders", field: "settler_founds_under_raiders", kind: Kind::OptIn, enable: AdvancedAi::enable_settler_founds_under_raiders, disable: AdvancedAi::disable_settler_founds_under_raiders },
    // While a living major is unmet or unlocated, or a city-state is unmet,
    // the queued sea scout keeps its queue against the governor's rescoring,
    // ships route toward foreign landfall, and the faster hull is preferred.
    // See `advanced/contact_fleet.rs`.
    Gene { tag: "contact-fleet", field: "contact_fleet", kind: Kind::OptIn, enable: AdvancedAi::enable_contact_fleet, disable: AdvancedAi::disable_contact_fleet },
    // `immortal-skips-the-prophet-race`: live Immortal Culture seats lost
    // the Prophet race by t58-60 with 36-93 points, the capital (6-9
    // Production) having spent t34-t55 on the race's Holy Site and Shrine
    // (civvis-20261030T220042Z, 134907Z), and 16 of 27 retired under the
    // production rule. At Immortal and Deity a seat aiming at neither Religion
    // nor Diplomacy stays out of the race unless a Prophet is pending. See
    // `advanced/immortal_prophet_race.rs`.
    Gene { tag: "immortal-skips-the-prophet-race", field: "immortal_skips_the_prophet_race", kind: Kind::OptIn, enable: AdvancedAi::enable_immortal_skips_the_prophet_race, disable: AdvancedAi::disable_immortal_skips_the_prophet_race },
    // Operator 10-31 rolls Religion-target seats into the Lv 7 lane. After
    // founding (median t44-54 live), a Religion seat's plan reads Expansion
    // until ~t125, and the spreading posture, the 80-Faith reserve and
    // religious production all key on the plan, so the corps idles while
    // rivals finish at t145-176 (native, 6 seats, 0 religious wins). A
    // Religion-target founder keeps all three in any plan. See
    // `advanced/religion_lane_spreads.rs`.
    Gene { tag: "religion-lane-spreads-from-founding", field: "religion_lane_spreads_from_founding", kind: Kind::OptIn, enable: AdvancedAi::enable_religion_lane_spreads_from_founding, disable: AdvancedAi::disable_religion_lane_spreads_from_founding },
    // Live Immortal 054450Z (Domination, 10-31) held its war on Australia at
    // 6-12x its power on 49 turns from t101: `war_policy_declaration` read
    // our own faith war on Macedon as "another major war", although
    // `faith-war-is-no-front` already keeps that war out of
    // `one_war_holds_declaration`. Melbourne walled up by t123. The board
    // reads the same exemption. Needs `faith-war-is-no-front` (or -2). See
    // `war_policy_declaration` in `advanced/war_policy.rs`.
    Gene { tag: "board-ignores-the-faith-war", field: "board_ignores_the_faith_war", kind: Kind::OptIn, enable: AdvancedAi::enable_board_ignores_the_faith_war, disable: AdvancedAi::disable_board_ignores_the_faith_war },
    // Live Immortal 6p Continents 10-31: `naval-escort-patience` counts its
    // wait per water tile, so a Settler crossing alone held two turns at every
    // tile (042324Z: t52-79 afloat, 110 holds on 48 turns; 024232Z 22 turns,
    // 011801Z 19). A voyage that has crossed alone steps on while the sea
    // stays quiet. See `advanced/naval_crossing.rs`.
    Gene { tag: "naval-crossing-keeps-going", field: "naval_crossing_keeps_going", kind: Kind::OptIn, enable: AdvancedAi::enable_naval_crossing_keeps_going, disable: AdvancedAi::disable_naval_crossing_keeps_going },
    // Live Immortal seats 2026-10-30 (30 seats, t<=120): 63% of a Builder's
    // consecutive jobs sat near a different city, a median 6 turns and 5 hexes
    // apart against 2 and 2 inside one city, at 7.6 Builder-turns per
    // improvement. Every destination was scored `value - 0.7 x wdist`, and
    // 0.7 a hex is nothing against jobs worth 5-100. While a Builder has a
    // charge to spare it now scores value per Builder-turn; its last charge
    // keeps the untreated price. See `advanced/builder_travel_turns.rs`.
    Gene { tag: "builder-prices-travel-in-turns", field: "builder_prices_travel_in_turns", kind: Kind::OptIn, enable: AdvancedAi::enable_builder_prices_travel_in_turns, disable: AdvancedAi::disable_builder_prices_travel_in_turns },
    // A Religion-target seat that lost the Prophet race keeps a Religion
    // plan, with no religion, for the rest of the game: the 4th religion
    // closed the race at a median t47.5 live (6p Immortal), and our seat
    // founded in 5 of 17. With every slot claimed and none ours, it takes
    // Science (else Culture, else Domination). See
    // `advanced/religion_lane_hands_over.rs`.
    Gene { tag: "religion-lane-hands-over", field: "religion_lane_hands_over", kind: Kind::OptIn, enable: AdvancedAi::enable_religion_lane_hands_over, disable: AdvancedAi::disable_religion_lane_hands_over },
    // The t80 production gate retires 16 of 20 6p Immortal seats at a median
    // share of 0.23. The first Trader (~t21) goes foreign or to a city-state
    // for ~4 Gold in kept and retired seats alike: `commercial-hub-and-traders`
    // pays 1.5 per Gold, so a domestic route's Production never wins. Within
    // ~100 Online turns, route Production outbids that premium. See
    // `advanced/early_route_production.rs`.
    Gene { tag: "early-route-feeds-production", field: "early_route_feeds_production", kind: Kind::OptIn, enable: AdvancedAi::enable_early_route_feeds_production, disable: AdvancedAi::disable_early_route_feeds_production },
    // A Religion seat without a religion got the Religion strategy before the
    // Expansion branch read its city count: 4 of 5 6p Immortal Religion seats
    // ran Religion at t20-40 (every other lane ran Expansion), held a median 3
    // cities at t60 against 4-5, and 4 of 5 were retired at the t80 gate. The
    // prophet race keys on the target, not the strategy. See
    // `advanced/religion_race_expands.rs`.
    Gene { tag: "religion-race-keeps-expanding", field: "religion_race_keeps_expanding", kind: Kind::OptIn, enable: AdvancedAi::enable_religion_race_keeps_expanding, disable: AdvancedAi::disable_religion_race_keeps_expanding },
    // On 6p Continents a Domination plan aimed overseas never declares: the
    // army is kept on land at peace and the amphibious train forms only at
    // war. Live 041027Z aimed at overseas Russia t78-85 and retired with no
    // city; 22 of 45 rival slots in the long 6p games sat across water. Rivals
    // reachable by land rank first in the frontier and capital picks and the
    // hand-over bar. See `advanced/domination_land_first.rs`.
    Gene { tag: "domination-targets-land-first", field: "domination_targets_land_first", kind: Kind::OptIn, enable: AdvancedAi::enable_domination_targets_land_first, disable: AdvancedAi::disable_domination_targets_land_first },
    // On a Religion seat, `spreader-steps-out-of-the-apostle` pins the corps
    // in a pocket while an out-trading Apostle camps on every approach: live
    // Immortal 063431Z logged 821 holds on 43 turns (one Missionary t118-177)
    // and spread 5 times all game. After three held turns a spreader yields
    // only to a lethal blow for six turns. See `advanced/stalled_spreader.rs`.
    Gene { tag: "stalled-spreader-braves-the-march", field: "stalled_spreader_braves_the_march", kind: Kind::OptIn, enable: AdvancedAi::enable_stalled_spreader_braves_the_march, disable: AdvancedAi::disable_stalled_spreader_braves_the_march },
    // Live Lv 7 2026-10-30: two frontier Corinths fell at t27 (200156Z) and
    // t28 (201608Z) with no walls while the journal read "Anvil at Corinth:
    // … slinger in the city". The Anvil gives the city tile to a Shooter
    // and puts melee on the ring, but an unwalled city's defence is its
    // garrison's melee strength: 20 with a Warrior inside, 10 with a
    // Slinger or nobody (Civ VI's own city defence read both ways). In
    // 201608Z the Warrior that stood inside at t26 (defence 18.6) was posted
    // to the ring at t27 and the city fell the next turn. With no standing
    // walls, the Anvil's strongest melee soldier within a tile holds the
    // city and makes no blow. See `advanced/anvil_garrisons_its_melee.rs`.
    Gene { tag: "anvil-garrisons-its-melee", field: "anvil_garrisons_its_melee", kind: Kind::OptIn, enable: AdvancedAi::enable_anvil_garrisons_its_melee, disable: AdvancedAi::disable_anvil_garrisons_its_melee },
    // The defence pass queues walls in a threatened city and the general pass
    // switches it straight back: "switches to amphitheater, displacing walls"
    // 50 times on the live journals, and 8 of the 10 cities lost unwalled at
    // t45-100 on 6p Immortal seats had their walls displaced first. While the
    // city is damaged or a visible enemy soldier stands within 4 tiles, a
    // defensive commitment holds against a civilian build. See
    // `advanced/defence_holds.rs`.
    Gene { tag: "defence-holds-under-fire", field: "defence_holds_under_fire", kind: Kind::OptIn, enable: AdvancedAi::enable_defence_holds_under_fire, disable: AdvancedAi::disable_defence_holds_under_fire },
    // Live Immortal 6p Continents 10-30/31: `rapid-city-expansion-2` is asked
    // before `land_grab`, so every live seat planned the ordinary cadence
    // floored at ten (1,223 of 1,894 readings past t110) and held 10 cities
    // at t150-180 against the leader's 11-13. Under the gene the target is
    // the larger of the two. See `advanced/land_grab_outlasts.rs`.
    Gene { tag: "land-grab-outlasts-the-opening", field: "land_grab_outlasts_the_opening", kind: Kind::OptIn, enable: AdvancedAi::enable_land_grab_outlasts_the_opening, disable: AdvancedAi::disable_land_grab_outlasts_the_opening },
    // The operator's non-Diplomatic Lv 7 lane (2026-10-31) seats Science
    // first, and the live alliance gate passed alliances only for the
    // Diplomatic lane (and Culture under `culture-seat-allies`): every
    // Research Alliance `research-alliance-first` proposed on a Science seat
    // was dropped. A Science seat allies its nearest safe rival, never the
    // leading science rival or a space racer. See
    // `advanced/culture_seat_allies.rs`.
    Gene { tag: "science-seat-allies", field: "science_seat_allies", kind: Kind::OptIn, enable: AdvancedAi::enable_science_seat_allies, disable: AdvancedAi::disable_science_seat_allies },
    // `capital-walls-at-any-ratio`: 8 of 18 located Immortal city losses
    // were the capital, and the attacker's power ratio barely told it apart
    // from neighbours that never declared (medians 2.69 against 3.0); live
    // civvis-20261030T201608Z lost an unwalled Athens to a 1.41x Egypt. At
    // Immortal and Deity the capital's walls arm on any watched major soldier
    // at our door. See `advanced/capital_walls_at_any_ratio.rs`.
    Gene { tag: "capital-walls-at-any-ratio", field: "capital_walls_at_any_ratio", kind: Kind::OptIn, enable: AdvancedAi::enable_capital_walls_at_any_ratio, disable: AdvancedAi::disable_capital_walls_at_any_ratio },
    // The operator's non-Diplomatic Lv 7 lane (2026-10-31) rolls Religion
    // seats, and -3b's audit found every founder defence gated to Domination
    // (and Diplomacy): the defensive Inquisition, the Holy City guard, the
    // founder's spreaders kept home, the faithless homeland pass. A Religious
    // Victory needs our faith to hold our own cities too. Opens them for a
    // seat aiming at Religion. See `defensive_apostle.rs`.
    Gene { tag: "religion-seat-defends-its-faith", field: "religion_seat_defends_its_faith", kind: Kind::OptIn, enable: AdvancedAi::enable_religion_seat_defends_its_faith, disable: AdvancedAi::disable_religion_seat_defends_its_faith },
    // `religion-seat-founds-first`: the live 6p Immortal race is decided by
    // t30-37, and a Religion seat's Holy Site waits for its third city
    // (`expansion-before-prophet`): t29 and t36 in two lost races, none in a
    // third. A Religion-target seat's first idle queue after Astrology starts
    // it. See `advanced/religion_seat_founds_first.rs`.
    Gene { tag: "religion-seat-founds-first", field: "religion_seat_founds_first", kind: Kind::OptIn, enable: AdvancedAi::enable_religion_seat_founds_first, disable: AdvancedAi::disable_religion_seat_founds_first },
    // Live Immortal 6-major seats 2026-10-31 denounced every rival with a
    // seen pad ("their space race is a science threat"): 111516Z all four at
    // t142-150 and again every 21 turns, 104757Z 41 times, 094146Z 49. Every
    // rival stood DENOUNCED by t160, so no seat could make a friend or an
    // ally. Only the leading racer's denunciation serves the formal launcher
    // war. Denounce only the most pressing science threat. See
    // `advanced/science_threat_denial.rs`.
    Gene { tag: "science-denounce-names-the-leader", field: "science_denounce_names_the_leader", kind: Kind::OptIn, enable: AdvancedAi::enable_science_denounce_names_the_leader, disable: AdvancedAi::disable_science_denounce_names_the_leader },
    // Live Immortal 2026-10-30/31, seats alive past t120: 32-42% of cities
    // grew at half or a quarter for housing and 22-28% were short of
    // Amenities at t80-t140, with our citizens per city at 0.68-0.77 of the
    // production leader's. The policy counterfactual reads yields only, so a
    // housing or amenity card read as nearly nothing: Insulae slotted in 1 of
    // 99 t80 seats holding it, Retainers in 18 of 89. The deck prices each
    // city's growth surplus. See `BasicAi::deck_prices_growth`.
    Gene { tag: "deck-prices-growth", field: "deck_prices_growth", kind: Kind::OptIn, enable: AdvancedAi::enable_deck_prices_growth, disable: AdvancedAi::disable_deck_prices_growth },
    // 24 live Immortal 6-major seats (2026-10-31, non-Diplomatic lanes): 34
    // declared friendships, 22 lapsed unrenewed, and 9 lapsed friends later
    // declared war on us (t109-t200). Off Domination, a lapsing friendship is
    // renewed at once (the host reads Friendly for about a turn after the
    // lapse) and the Domination-era stronger/prey filters do not apply. See
    // `advanced/protective_friendship.rs`.
    Gene { tag: "friendship-keeps-the-peace", field: "friendship_keeps_the_peace", kind: Kind::OptIn, enable: AdvancedAi::enable_friendship_keeps_the_peace, disable: AdvancedAi::disable_friendship_keeps_the_peace },
    // Live Immortal 2026-10-31, deck-prices-growth seats with Retainers
    // slotted: 1,014 Amenity-short city-turns, 110 (11%) holding a soldier;
    // at t140 106 of 118 short cities stood at -1. At peace 1.4-1.8 units a
    // city, 72-79% within three tiles of one. An idle soldier garrisons each
    // short city while Retainers is slotted. See `ai/retainers_garrison.rs`.
    Gene { tag: "retainers-garrison-the-short-cities", field: "retainers_garrison_the_short_cities", kind: Kind::OptIn, enable: AdvancedAi::enable_retainers_garrison_the_short_cities, disable: AdvancedAi::disable_retainers_garrison_the_short_cities },
    // `pillaged-districts-repair-first`: 26 of 63 lane seats had a pillaged
    // district (77 spells, a median 10 turns, 19 never repaired by t150). The
    // repair is priced 1,500 but the claim genes take the queue first; live
    // civvis-20261101T024926Z lost the Prophet race on a Holy Site pillaged
    // from t30 to t66. The repair now claims its city after every other claim.
    // See `advanced/pillaged_repairs_first.rs`.
    Gene { tag: "pillaged-districts-repair-first", field: "pillaged_districts_repair_first", kind: Kind::OptIn, enable: AdvancedAi::enable_pillaged_districts_repair_first, disable: AdvancedAi::disable_pillaged_districts_repair_first },
    // Live Emperor civvis-20261101T043921Z launched its Exoplanet first (214)
    // and lost at 224: at turn 180 two racers had their Moon landed, the
    // launcher war's tie went to the lower seat (Georgia, 60 techs), and
    // Hungary (64 techs, 387 Science against 267, at half our power) won on
    // laser stations. A tie now goes to the racer knowing more techs. Needs
    // `launcher-war-serves-every-lane`. See `advanced/launcher_war_every_lane.rs`.
    Gene { tag: "launcher-war-fights-the-faster-racer", field: "launcher_war_fights_the_faster_racer", kind: Kind::OptIn, enable: AdvancedAi::enable_launcher_war_fights_the_faster_racer, disable: AdvancedAi::disable_launcher_war_fights_the_faster_racer },
    // Live Emperor Religion seat civvis-20261031T034930Z (2026-11-01, -3b):
    // the Apostle bought at t68 held every Faith purchase for the Inquisitor,
    // silently, while Catholic spreaders worked the Holy City, which flipped
    // at t80-90 with 254-769 Faith banked; nothing of ours could be bought
    // after (2,670 Faith unspent at the t218 loss). While the Apostle
    // travels, a threatened source buys its cover Missionary when the Faith
    // left covers the first Inquisitor. See `advanced/defensive_apostle.rs`.
    Gene { tag: "apostle-transit-keeps-the-cover", field: "apostle_transit_keeps_the_cover", kind: Kind::OptIn, enable: AdvancedAi::enable_apostle_transit_keeps_the_cover, disable: AdvancedAi::disable_apostle_transit_keeps_the_cover },
    // `culture-keeps-every-border-open-2`: version one, buying passage only
    // from the bar holder (most domestic tourists) — its visitors count twice.
    // A King screen read version one at −1.7 pp share with wins unchanged. See
    // `advanced/culture_open_borders.rs`.
    Gene { tag: "culture-keeps-every-border-open-2", field: "culture_keeps_every_border_open_2", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_keeps_every_border_open_2, disable: AdvancedAi::disable_culture_keeps_every_border_open_2 },
    // `fog-yields-to-a-stranded-settler`: live civvis-20261101T042616Z held
    // three cities t40-t127 with a Settler stranded t44-t177, 49 sites refused
    // as "beyond the empire's Loyalty reach on ground the seat has not
    // explored"; the hidden-border yield sits below that clause and never
    // fired. Once a Settler has walked fifteen turns the fog clause yields.
    // See `advanced/fog_yields_stranded.rs`.
    Gene { tag: "fog-yields-to-a-stranded-settler", field: "fog_yields_to_a_stranded_settler", kind: Kind::OptIn, enable: AdvancedAi::enable_fog_yields_to_a_stranded_settler, disable: AdvancedAi::disable_fog_yields_to_a_stranded_settler },
    // Live Emperor 2026-10-31/11-01: one game in three that began a Spaceport
    // left it for other builds. Once a claim borrows the queue, the placed
    // foundation reads as a second pad (-10,000) and the first-pad rung has
    // lapsed (250), so the strategic controller never resumes it. 043921Z: placed t161, finished t193 (8 turns on it),
    // Satellite 36 turns behind the leader. See `unfinished_launch_pad_site`.
    Gene { tag: "launch-pad-keeps-its-rung", field: "launch_pad_keeps_its_rung", kind: Kind::OptIn, enable: AdvancedAi::enable_launch_pad_keeps_its_rung, disable: AdvancedAi::disable_launch_pad_keeps_its_rung },
    // Live King civvis-20261101T075446Z (Religion) led the space race to Mars
    // (Satellite 208, Moon 215, against the Ottomans' 215 and 224) on 320
    // science against 394, so `science-drive-answers-the-launch`, which opens
    // on an outright science lead, never drove: research stayed on the war
    // plan, Smart Materials came at 227, our Exoplanet launched at 240 against
    // theirs at 236, and the Ottomans won at 245. The answer now also opens
    // and holds while our landed projects are level with the leading racer's.
    // Needs `science-victory-drive` and `science-drive-answers-the-launch`.
    // See `advanced/science_victory_drive.rs`.
    Gene { tag: "science-drive-answers-from-the-pad", field: "science_drive_answers_from_the_pad", kind: Kind::OptIn, enable: AdvancedAi::enable_science_drive_answers_from_the_pad, disable: AdvancedAi::disable_science_drive_answers_from_the_pad },
    // `culture-digs-one-museum`: the two Museums tie and the base AI breaks
    // toward Art, so a Culture seat never owns an Artifact slot (live King
    // culture seat 091422Z: 66 Art Museum orders, no Archaeologist, lost t237
    // 82 visitors short). One Archaeological Museum opens the dig line. See
    // `advanced/culture_dig_museum.rs`.
    Gene { tag: "culture-digs-one-museum", field: "culture_digs_one_museum", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_digs_one_museum, disable: AdvancedAi::disable_culture_digs_one_museum },
    // Live King civvis-20261101T095815Z (with v1 armed) landed its Moon at
    // 202, one project behind Gran Colombia's Mars at 203, so the level-pad
    // reading never held. Research ran the war plan until an outright
    // science lead opened the answer at 218. Smart Materials came at 221 and
    // Offworld Mission at 231. Our Exoplanet launched at 223 against theirs
    // at 221 with no laser station possible before 231, and Gran Colombia
    // won at 233. The answer now also opens within one project of every
    // rival. Replaces `science-drive-answers-from-the-pad` (either reads the
    // pads; -2 adds the slack). Needs `science-victory-drive` and
    // `science-drive-answers-the-launch`. See `advanced/science_victory_drive.rs`.
    Gene { tag: "science-drive-answers-from-the-pad-2", field: "science_drive_answers_from_the_pad_2", kind: Kind::OptIn, enable: AdvancedAi::enable_science_drive_answers_from_the_pad_2, disable: AdvancedAi::disable_science_drive_answers_from_the_pad_2 },
    // Live King 2026-11-01: the Spy trainer and other claims take the pad
    // city's queue, since the launch city is the top producer and a district
    // at the head counts as routine work. 085353Z: Mbwila placed the pad at
    // t175, trained a Spy at t180, then a reactor conversion, an air-surge
    // unit and Research Grants; the pad finished at t206 and the Satellite
    // landed at 215 against Khmer's 177. 081602Z trained Spies in Rome from
    // t193 and never landed a Satellite. While no pad stands, the first pad
    // goes back to the head of its city after every claim, short of a threat
    // to that city, and the Spy trainer skips it.
    // See `advanced/launch_pad_holds_its_queue.rs`.
    Gene { tag: "launch-pad-holds-its-queue", field: "launch_pad_holds_its_queue", kind: Kind::OptIn, enable: AdvancedAi::enable_launch_pad_holds_its_queue, disable: AdvancedAi::disable_launch_pad_holds_its_queue },
    // `launch-commits-the-endgame`: live civvis-20261101T075446Z (assigned
    // Religion) tied the tree 77-77 and led every launch, then lost the
    // Exoplanet leg by four turns: the science endgame admits a launched seat
    // only while it has no assigned lane, so its schedule never ran. Our own
    // Earth Satellite now commits any lane but Domination. See
    // `advanced/launch_commits_endgame.rs`.
    Gene { tag: "launch-commits-the-endgame", field: "launch_commits_the_endgame", kind: Kind::OptIn, enable: AdvancedAi::enable_launch_commits_the_endgame, disable: AdvancedAi::disable_launch_commits_the_endgame },
    // `culture-seat-theater-first-2`: version one balanced against the
    // Campuses: a city claims its first Theater only while the empire's
    // Theaters (standing or queued) trail its Campuses, or one. Live King
    // culture seats held 2-4 Campuses to 4-5 Theaters at t100 and lost mostly
    // to rival Science at t222-244. See `advanced/culture_theater_first.rs`.
    Gene { tag: "culture-seat-theater-first-2", field: "culture_seat_theater_first_2", kind: Kind::OptIn, enable: AdvancedAi::enable_culture_seat_theater_first_2, disable: AdvancedAi::disable_culture_seat_theater_first_2 },
    // Live King 2026-11-01: every game ended in a Science victory, and the
    // Domination seat 073004Z held the whole tree with no pad (all three
    // exclusions) while Korea won at t257. Within three techs of the field,
    // once a rival has landed, the seat answers with its own race beside its
    // war. See `advanced/domination_joins_the_race.rs`.
    Gene { tag: "domination-joins-the-race", field: "domination_joins_the_race", kind: Kind::OptIn, enable: AdvancedAi::enable_domination_joins_the_race, disable: AdvancedAi::disable_domination_joins_the_race },
    // Live King 2026-11-01: every Culture seat froze on a turn a rival
    // refused our alliance ask, and most refusals were the same rival asked
    // again on the ten-turn retry (081602Z six times, 102116Z four). A
    // partner that did not ally is not re-asked for thirty turns. See
    // `advanced/alliance_remembers_the_refusal.rs`.
    Gene { tag: "alliance-remembers-the-refusal", field: "alliance_remembers_the_refusal", kind: Kind::OptIn, enable: AdvancedAi::enable_alliance_remembers_the_refusal, disable: AdvancedAi::disable_alliance_remembers_the_refusal },
    // Live King 2026-11-01: 7 of 25 seats assigned Culture, Religion or
    // Domination led the field outright before any rival landed a space
    // project, by 9 to 86 turns, and `science-drive-answers-the-launch`
    // waited for that launch every time. 141505Z and 151815Z (Domination) led
    // from 143 and 110, opened the drive at 190 and 184, landed their first
    // project at 211 and 208, and lost to rival Culture at 216 and 214.
    // 075446Z led from 184 with no rival launch until 215 and lost the
    // Exoplanet race at 245 by four turns. From Online turn 140 an outright
    // lead (1.1x the best rival's Science, techs level or ahead) opens the
    // drive beside the assigned lane. Needs `science-victory-drive` and
    // `science-drive-answers-the-launch`. See `advanced/science_victory_drive.rs`.
    Gene { tag: "science-drive-leads-beside-the-lane", field: "science_drive_leads_beside_the_lane", kind: Kind::OptIn, enable: AdvancedAi::enable_science_drive_leads_beside_the_lane, disable: AdvancedAi::disable_science_drive_leads_beside_the_lane },
    // Native King Domination seats lost to rival Culture behind a declared
    // friendship: 30700000 accepted France's offer at t128 and t149, 30700004
    // offered Gaul at t105 and t126; every counter read "barred: we are
    // declared friends". A racer's offer is refused, and culture alone counts
    // as racing. See `advanced/protective_friendship.rs`.
    Gene { tag: "friendship-refuses-the-racer", field: "friendship_refuses_the_racer", kind: Kind::OptIn, enable: AdvancedAi::enable_friendship_refuses_the_racer, disable: AdvancedAi::disable_friendship_refuses_the_racer },
    // Live Emperor/King 11-01: 144 of 262 near-rival deterrents (55%)
    // targeted a declared friend, and a declared friend declared war within
    // ten turns on 1.0 per 100 rival-turns (vs 8.0 unfriendly, 10.3 friendly).
    // Under the gene a declared friend is not a deterrence neighbour. See
    // `advanced/deterrence_trusts_a_friend.rs`.
    Gene { tag: "deterrence-trusts-a-friend", field: "deterrence_trusts_a_friend", kind: Kind::OptIn, enable: AdvancedAi::enable_deterrence_trusts_a_friend, disable: AdvancedAi::disable_deterrence_trusts_a_friend },
    // Live King 11-01/02 (28 games): Writing landed at a median t37 on
    // Domination seats (which hold the Campus-unlock goal) but t45 on
    // Religion, t50 on adaptive and t69 on Culture seats; the first Campus
    // finished at a median t64 and its turn correlates -0.59 with Science at
    // t100. Under the gene every lane takes Writing once it holds two
    // cities, in the Domination goal's slot. See
    // `advanced/domination_research.rs`.
    Gene { tag: "campus-unlock-every-lane", field: "campus_unlock_every_lane", kind: Kind::OptIn, enable: AdvancedAi::enable_campus_unlock_every_lane, disable: AdvancedAi::disable_campus_unlock_every_lane },
    // Live King 11-01/02 (30 games): the first Builder came at a median
    // t33.5, one improvement by t40, no chop before t40 and no improved
    // luxury at t40, while a Builder sold for 100 Gold against a median bank
    // of 86-106 from t15 to t30; the early Gold bought Traders, Warriors,
    // Monuments and Archers, and 9 Builders in 30 games. Under the gene a
    // builderless opening with work for a Builder buys one above the upkeep
    // floor, ahead of the idle-route Trader. See
    // `advanced/gold_buys_the_opening_builder.rs`.
    Gene { tag: "gold-buys-the-opening-builder", field: "gold_buys_the_opening_builder", kind: Kind::OptIn, enable: AdvancedAi::enable_gold_buys_the_opening_builder, disable: AdvancedAi::disable_gold_buys_the_opening_builder },
    // Live King 11-01/02, 23 games with a first pad: under a Science plan
    // every city prices the first pad at the 3,000-point rung, so the first
    // idle city takes it: 091117Z placed it in Gori ("about 200 turns at
    // 4.5 a turn") beside Telavi at 54 Production; 150036Z in Panama ("about
    // 225 turns"). Over 23 games the first pad stood in a city under 80% of
    // the best placing producer in 9 (Production share 0.09-0.75) and took
    // 24-38 turns to build against 11-17 for the rest; the idle-Great-Person
    // path places it in "the fastest idle city" (105550Z: Chicago at 18 against
    // 78, 36 turns). Under the gene the first pad goes only to a city within
    // 80% of the best placing producer. See `ai/first_pad_in_the_forge.rs`.
    Gene { tag: "first-pad-in-the-forge", field: "first_pad_in_the_forge", kind: Kind::OptIn, enable: AdvancedAi::enable_first_pad_in_the_forge, disable: AdvancedAi::disable_first_pad_in_the_forge },
    // Live King 11-01/02, 22 games with a standing pad: `launch-pad-holds-
    // its-queue` holds the pad until it stands and `launch-commits-the-
    // endgame` commits only once the Earth Satellite lands; in between the
    // Satellite took a median 7 turns but 14-30 in four games, and 13 of 22
    // pad cities switched off it twice or more (131016Z: reactor conversion,
    // Builder, Jet Bomber, Broadcast Center, Helicopter; Satellite ~t217;
    // lost Science at t223 while leading the field's Science at t200). Under
    // the gene the best pad city keeps the Satellite at its head until it
    // lands. See `advanced/satellite_holds_the_pad.rs`.
    Gene { tag: "satellite-holds-the-pad", field: "satellite_holds_the_pad", kind: Kind::OptIn, enable: AdvancedAi::enable_satellite_holds_the_pad, disable: AdvancedAi::disable_satellite_holds_the_pad },
    // Native Emperor 20261102T161612Z owned Rocketry at t171, diverted to
    // Ballistics and wartime upgrades, then owned Satellites at t196.
    // Keep the first launch through Recovery and optional modernization.
    Gene { tag: "first-launch-keeps-research", field: "first_launch_keeps_research", kind: Kind::OptIn, enable: AdvancedAi::enable_first_launch_keeps_research, disable: AdvancedAi::disable_first_launch_keeps_research },
    // Live King 11-01/02: Domination seats won 0 of 13 (8 lost to Science,
    // 5 to Culture, tech gap −5 at t150) while Religion seats, which
    // `religion-lane-hands-over` retargets to Science near t47, won 6 of 20,
    // all by Science, at a gap of −6. 8 of 9 traced Domination seats held no
    // rival capital at t150. Under the gene a Domination seat that holds no
    // rival capital at standard turn 180 (live t120) retargets to Science.
    // See `advanced/stalled_conquest_takes_science.rs`.
    Gene { tag: "stalled-conquest-takes-science", field: "stalled_conquest_takes_science", kind: Kind::OptIn, enable: AdvancedAi::enable_stalled_conquest_takes_science, disable: AdvancedAi::disable_stalled_conquest_takes_science },
    // Operator 11-02, live Lv 6 civvis-20261102T163456Z (Inca): the air-surge
    // beeline reached Flight t127 / Advanced Flight t138 while Iron Working
    // waited to t116 and Machinery to t139, so the seat bought 12 Warriors
    // (t81-114) and 12 Archers (t121-138) in the Renaissance and Industrial
    // eras and still fielded both in the Information era. Under the gene the
    // research slot takes, ahead of the air surge and every lane beeline, the
    // technology our land army waits on to upgrade once the world has left
    // its era, then any technology two eras behind the world. See
    // `advanced/old_techs_before_the_beeline.rs`.
    Gene { tag: "old-techs-before-the-beeline", field: "old_techs_before_the_beeline", kind: Kind::OptIn, enable: AdvancedAi::enable_old_techs_before_the_beeline, disable: AdvancedAi::disable_old_techs_before_the_beeline },
    // `saved-work-is-seen`: live, the host keeps a switched item's progress
    // (382 of 383 resumed Buildings in 38 Emperor/Immortal games on
    // 2026-11-02 restarted from it), but the menu export carried `pr` for
    // districts only, so the mirror's bank never held a paused unit, building
    // or project: the resume path fired about once a game while a median 17
    // paused units, buildings and projects a game were never finished, their
    // saved work 4.9-7.9% of all city production. Under the gene the host's
    // saved work on paused units, buildings and projects enters
    // `City::production_progress` before production, as the native engine
    // already keeps it. Inert on a native board (no host menu). See
    // `advanced/saved_work_is_seen.rs`.
    Gene { tag: "saved-work-is-seen", field: "saved_work_is_seen", kind: Kind::OptIn, enable: AdvancedAi::enable_saved_work_is_seen, disable: AdvancedAi::disable_saved_work_is_seen },
    // `gold-buys-the-backlog-builder`: live (38 Emperor/Immortal games,
    // 2026-11-02) 64% / 48% of the worked land tiles stood unimproved at t60 /
    // t80, 4.7-6.5 of them improvable now per game, against 1.0-2.3 Builders
    // afield; in 17 of 38 games at t40 and 13 at t60 the Builders afield or
    // training fell short of `builder_backlog_item`'s own quota because the
    // Campus, Granary, Walls and Settler claims took the queue. Under the gene
    // the treasury buys that missing Builder above the purchase upkeep floor,
    // at peace, after the opening Builder and the idle route's Trader, in the
    // city owning the most unimproved worked tiles (the weakest producer on a
    // tie) whose cards do not already speed a Builder. See
    // `advanced/gold_buys_the_backlog_builder.rs`.
    Gene { tag: "gold-buys-the-backlog-builder", field: "gold_buys_the_backlog_builder", kind: Kind::OptIn, enable: AdvancedAi::enable_gold_buys_the_backlog_builder, disable: AdvancedAi::disable_gold_buys_the_backlog_builder },
    // Operator 2026-11-02: production is best spent on what a card boosts
    // (units +50%, Settlers +50%, ships +100%). The deck review prices a
    // production card by what it adds to the queue heads, but a full deck is
    // reviewed only every eighth turn. Live, 69 games 11-01/02: Feudal
    // Contract boosted no head on 84% of its slotted turns, Agoge 72%; an
    // unlocked unslotted card would have boosted the head on 8,676
    // city-turns, ~1,290 Production a game (Limes, International Waters,
    // Grande Armee most). Under the gene the review also runs on the turn
    // the set of queue cards worth slotting changes. See `ai/deck_queue.rs`.
    Gene { tag: "deck-follows-the-queue", field: "deck_follows_the_queue", kind: Kind::OptIn, enable: AdvancedAi::enable_deck_follows_the_queue, disable: AdvancedAi::disable_deck_follows_the_queue },
    // `city-state-harvest`: live Immortal 11-02 (17 games) captured no city;
    // the gap to the median rival at t100 was population (56 against 36),
    // while the median seat at t80 had two city-state cities within eight
    // tiles at population 5-12 and a fifth of our military. The softest one
    // with no suzerain but us and at most one of our envoys becomes the
    // plan's Conquest target for a bounded window. See
    // `advanced/city_state_harvest.rs`.
    Gene { tag: "city-state-harvest", field: "city_state_harvest", kind: Kind::OptIn, enable: AdvancedAi::enable_city_state_harvest, disable: AdvancedAi::disable_city_state_harvest },
    // Live Immortal 6p Continents 11-02/03: the seat never reached its city
    // target, so Expansion (a beaker 1.2 against Science's 4.2) lasted to the
    // halfway clock, 55% of the logged strategy turns. Every decided game was
    // lost to a rival's science victory at t188-215. Under the gene an
    // assigned Science lane specializes at a third of the clock, as Culture
    // already does. See `advanced/science_specializes_earlier.rs`.
    Gene { tag: "science-specializes-earlier", field: "science_specializes_earlier", kind: Kind::OptIn, enable: AdvancedAi::enable_science_specializes_earlier, disable: AdvancedAi::disable_science_specializes_earlier },
    // `near-done-work-finishes`: live (39 Immortal games with
    // `saved-work-is-seen`, 2026-11-03), 1,204 items were paused with saved
    // work; 47% of that work sat in items within two turns of finishing when
    // they were paused (177 within one turn), because the claims and
    // governors displace the head every turn and the resume path only sees
    // an empty queue. Under the gene a head displaced this turn that
    // finishes within two turns goes back to the head after every ordinary
    // writer, unless the city is threatened, attacked or recovering, or the
    // displacing item is a soldier, Settler, defence building, Holy Site,
    // Shrine, Spaceport, Wonder or project. See
    // `advanced/near_done_work_finishes.rs`.
    Gene { tag: "near-done-work-finishes", field: "near_done_work_finishes", kind: Kind::OptIn, enable: AdvancedAi::enable_near_done_work_finishes, disable: AdvancedAi::disable_near_done_work_finishes },
    // Live, both Māori seats (11-01 King, 11-03 Immortal): the Settler started
    // embarked on ocean, knew no land, and stood until the defeat "no cities
    // remain" at turn 6; the mirror's fog priors give a land unit at sea no
    // route. Under the gene it sails toward the edge of the known sea. See
    // `advanced/maori_founds_from_the_sea.rs`.
    Gene { tag: "founding-voyage", field: "founding_voyage", kind: Kind::OptIn, enable: AdvancedAi::enable_founding_voyage, disable: AdvancedAi::disable_founding_voyage },
    Gene { tag: "anvil-follows-the-defense", field: "anvil_follows_the_defense", kind: Kind::OptIn, enable: AdvancedAi::enable_anvil_follows_the_defense, disable: AdvancedAi::disable_anvil_follows_the_defense },
    // 57 live Immortal games (11-03/04) lost 765 military units; 383 were
    // healthy units, no strike that turn, that moved and died, 580 of all 765
    // to ONE blow, and 351 of the healthy ones had their killer in sight
    // within two tiles when our turn ended: an Archer or Spearman stepping
    // beside a Line Infantry or a Machine Gun. Version one refused such a
    // step for siege guns only. Version two refuses it for every land
    // military unit the battle planner did not place, and a hostile killed
    // later in the frame no longer vetoes. See
    // `advanced/guns_stay_out_of_reach.rs`.
    Gene { tag: "guns-stay-out-of-reach-2", field: "guns_stay_out_of_reach_2", kind: Kind::OptIn, enable: AdvancedAi::enable_guns_stay_out_of_reach_2, disable: AdvancedAi::disable_guns_stay_out_of_reach_2 },
    // Live Immortal Standard 012627Z: the Siege of Chucuito sat in Stage
    // from turn 222 to 309 while the army went 16 to 5, 44 of 55 losses
    // healthy land units removed by one blow of an AT Crew, a Cuirassier or a
    // Giant Death Robot; the board read "743 against their 579" (power is a
    // linear sum) and every peace offer was refused. Under the gene a Siege
    // row whose city's visible field units have sat 25+ strength over the
    // defence of half our land army for four turns running leaves the board
    // for ten turns, keyed by the city's tile, unless the city is falling
    // (126 live episodes: 26 would stand down, 2 of 13 captures among them,
    // 167 of our units lost near those cities afterwards). See
    // `advanced/outclassed_siege.rs`.
    Gene { tag: "outclassed-siege-stands-down", field: "outclassed_siege_stands_down", kind: Kind::OptIn, enable: AdvancedAi::enable_outclassed_siege_stands_down, disable: AdvancedAi::disable_outclassed_siege_stands_down },
    // Version two (the one-blow veto on every land unit) read unfavourable
    // on a paired Immortal domination screen (12 seeds: score -47, z -1.9;
    // cities lost +0.6), most plausibly because it also held back the units
    // marching to defend or relieve our own cities. Version three is version
    // two with every member of a Defend or Relieve task force left free to
    // close on the attackers. See `advanced/guns_stay_out_of_reach.rs`.
    Gene { tag: "guns-stay-out-of-reach-3", field: "guns_stay_out_of_reach_3", kind: Kind::OptIn, enable: AdvancedAi::enable_guns_stay_out_of_reach_3, disable: AdvancedAi::disable_guns_stay_out_of_reach_3 },
    // 60 live Immortal runs: the finishing volley made 766 kills and refused
    // 272 lines on the lowest roll, while 694 enemy units were left alive at
    // 30 health or less. A ranged blow draws no return damage, so under the
    // gene a line whose every attacker is ranged commits on its centre roll;
    // melee lines keep the floor. See `advanced/ranged_finish.rs`.
    Gene { tag: "ranged-finish-on-the-mean", field: "ranged_finish_on_the_mean", kind: Kind::OptIn, enable: AdvancedAi::enable_ranged_finish_on_the_mean, disable: AdvancedAi::disable_ranged_finish_on_the_mean },
    Gene { tag: "first-capital-before-the-camp", field: "first_capital_before_the_camp", kind: Kind::OptIn, enable: AdvancedAi::enable_first_capital_before_the_camp, disable: AdvancedAi::disable_first_capital_before_the_camp },
    // Gran Colombia receives a Comandante General every era: +5 Combat
    // Strength and +1 Movement to land units within 2 tiles, in every era.
    // The live bridge retired each one the turn it arrived (live GC games
    // 11-03/04: every Comandante activated on its first turn), trading the
    // aura for a one-shot civic, Trader or promotion. Under the gene the
    // bridge keeps one General per front with our largest land cluster
    // nearest the enemy and retires only the surplus. Live bridge only. See
    // `advanced/generals_lead_the_army.rs`.
    Gene { tag: "generals-lead-the-army", field: "generals_lead_the_army", kind: Kind::OptIn, enable: AdvancedAi::enable_generals_lead_the_army, disable: AdvancedAi::disable_generals_lead_the_army },
    // Live Immortal Standard 054226Z founded Bogota on turn 1 on a SNOW tile
    // between a lake and the polar sea (3-5 Production for 70 turns; the
    // median capital makes 11 at turn 50); 015124Z founded on lakeside
    // tundra with grassland two hexes south (pop 2, 4 Production at t100).
    // The site score forecasts four citizens, floors the center's yields and
    // pays fresh water +12 against -20 for dry land, so frozen ground cost
    // nothing. Under the gene, while the empire has no city, frozen tiles in
    // a site's footprint cost 4 points each, and a Settler about to found on
    // snow or tundra steps toward warmer ground and looks first, for one
    // turn fewer than the speed's opening walk budget. Russia and Canada are
    // exempt. See `advanced/frost_capital.rs`.
    Gene { tag: "capital-leaves-the-frost", field: "capital_leaves_the_frost", kind: Kind::OptIn, enable: AdvancedAi::enable_capital_leaves_the_frost, disable: AdvancedAi::disable_capital_leaves_the_frost },
    // Live Lv 7 Standard, Gran Colombia 2026-11-04T015124Z, eliminated at turn
    // 18: Vietnam at 4.6x our power stood within 8 tiles from turn 15, the
    // answer was Masonry, the only Warrior explored ten tiles away and the
    // capital held no soldier. Under the gene a stronger major's soldier near
    // a city with no soldier drafts the nearest idle one home. See
    // `ai/garrison_before_the_surprise.rs`.
    Gene { tag: "garrison-before-the-surprise", field: "garrison_before_the_surprise", kind: Kind::OptIn, enable: AdvancedAi::enable_garrison_before_the_surprise, disable: AdvancedAi::disable_garrison_before_the_surprise },
    // Live Lv 7 Immortal Standard (11-03/04): Gold sat at 100-190 through
    // t20-t45 because Standard prices put a Warrior at 160 and a Builder near
    // 200, while a border tile costs 50-75; the purchase phase wants
    // reserve + 200 + cost before any plot, so no game bought a tile before
    // t80. 17 of 26 capitals at t30 worked a tile of at most one Production
    // beside a buyable Hill or Forest of two or more. Under the gene, the
    // opening buys that tile above the upkeep floor once a turn, at peace.
    // See `advanced/gold_buys_the_production_tile.rs`.
    Gene { tag: "gold-buys-the-production-tile", field: "gold_buys_the_production_tile", kind: Kind::OptIn, enable: AdvancedAi::enable_gold_buys_the_production_tile, disable: AdvancedAi::disable_gold_buys_the_production_tile },
    // Refine an existing emergency land defender; see `advanced/spears_answer_the_horse.rs`.
    Gene { tag: "spears-answer-the-horse", field: "spears_answer_the_horse", kind: Kind::OptIn, enable: AdvancedAi::enable_spears_answer_the_horse, disable: AdvancedAi::disable_spears_answer_the_horse },
    // ---- append: a-b ------------------------------------------------
    // ---- append: c-d ------------------------------------------------
    // ---- append: e-f ------------------------------------------------
    // ---- append: g-k ------------------------------------------------
    // ---- append: l-o ------------------------------------------------
    // ---- append: p-r ------------------------------------------------
    // ---- append: s-s ------------------------------------------------
    // ---- append: t-z ------------------------------------------------
];

// ═══ GENERATED BY tools/genes.py — THE VERDICTS. Do not edit below: `python3 tools/genes.py write` ═══
//
// Source: docs/gene_ledger.json (the same tool writes both); `genes.py check` holds them
// together; this reporting-only publication retains `DEPLOYMENT_GENOME`.
// Each tag's available latest-three `BATCH_COLUMNS`, weighted by completed
// total player seats, decide it with hysteresis against the previous published
// selection: off turns on strictly above +3 wins/10k, on turns off strictly
// below -3; one higher-average version ships per family.

/// The policy that supplies every `default_on` below.
pub(super) const DEPLOYMENT_POLICY: &str = "operator-retained-selection";

/// The screenable genes selected with hysteresis from their completed-total-
/// seat-weighted average over available latest-three batch readings: a gene
/// that was off turned on strictly above +3 wins per 10,000 total seats, a gene
/// that was on stayed on unless strictly below -3 (`rules.hysteresis_held` in
/// the ledger names the kept ones); every other screenable gene is off. One
/// higher-average version ships per family.
#[rustfmt::skip]
pub(super) const DEPLOYMENT_GENOME: &[&str] = &[
    "age-closer",
    "air-surge-2",
    "air-surge-strikes-through-urgency",
    "air-volley-needs-a-road",
    "aluminum-ask-tops-up-gold",
    "amenity-district-path",
    "amenity-project-preemption-2",
    "amphibious-siege-train-2",
    "anvil",
    "army-upgrade-materials",
    "barbarian-bargain",
    "barbarian-scouts-are-scouts",
    "battle-planner",
    "beeline-orders-by-value",
    "befriend-the-strongest",
    "blind-objective-strength",
    "boost-first-research",
    "boosted-bargain-first-2",
    "border-parity",
    "bounded-recovery",
    "breach-assault-closes-in",
    "breaker-keeps-its-queue",
    "breaker-reads-the-march",
    "breaker-research-first",
    "breaker-supply-scales",
    "breaker-to-the-fastest",
    "breakers-stay-with-the-siege",
    "builder-barbarian-safety",
    "builder-before-the-army-2",
    "builder-supply-floor",
    "builder-workforce-recovery-2",
    "builders-cover-the-worked-backlog",
    "builders-improve-the-worked-for-production",
    "builders-work-through-raiders",
    "buildings-before-projects",
    "buy-what-cards-cannot-boost",
    "camp-tile-buyout",
    "campaign-pillage",
    "campus-adjacency-threshold-2",
    "campus-before-harbor-2",
    "campus-building-claims-the-queue",
    "campus-through-expansion",
    "canal-city",
    "capital-campaign-router",
    "capital-campus-before-the-plaza",
    "capital-defense-holds",
    "capital-prey-opens-a-front",
    "capital-settler-after-completion",
    "capital-walls-before-the-surprise",
    "capture-go-or-stand-down",
    "capture-hold-chain",
    "capture-waits-on-the-march",
    "chain-payback-window-2",
    "chase-every-boost",
    "chokepoint-claim",
    "chokepoint-garrison",
    "city-campaign",
    "city-target-meets-the-map",
    "close-as-a-body",
    "closed-border-blocker-declares",
    "coalition-before-war-3",
    "coastal-city-sites",
    "colonization-earns-its-slot-2",
    "commercial-hub-and-traders",
    "commitment-patience",
    "congress-counter-leader",
    "connect-the-luxury-2",
    "counter-out-of-reach-takes-the-weak",
    "counter-war-needs-the-emperor-edge",
    "counterweight-flips-the-small-towns",
    "crushing-steady-passes-the-edge",
    "culture-cold-war-window",
    "culture-counter-declares",
    "culture-defense-theater",
    "culture-finish-at-the-observed-bar",
    "culture-floor",
    "culture-lane-forecast",
    "culture-tourism-payback",
    "deals-for-our-gain",
    "declaration-needs-the-edge",
    "declaration-waits-for-the-breaker",
    "defend-where-you-stand",
    "defensible-sites",
    "denial-nearest-finish",
    "detour-keeps-the-site-worth",
    "diplomatic-contender-eliminated",
    "diplomatic-lane-forecast-2",
    "district-coverage-2",
    "district-planning-3",
    "domination-city-count",
    "domination-lane-hands-over",
    "domination-siege-research",
    "doomed-blow-veto",
    "early-archers",
    "early-conquest-opening",
    "early-conquest-stands-down",
    "early-contact-window",
    "early-project-restraint-2",
    "early-settler-floor",
    "elective-war-in-reach",
    "elective-war-yields-to-a-lane",
    "encampment-seals-the-pass",
    "engine-faith-price",
    "enter-the-prophet-race-2",
    "envoy-building-dividends",
    "escort-cap-holds",
    "escort-unstick",
    "eureka-chasing-builder-2",
    "expansion-best-idle-city",
    "expansion-schedule",
    "falling-city-calls-the-takers",
    "falling-city-outranks-the-heal",
    "first-builder-reserve-2",
    "first-district-first",
    "first-granary-reserve",
    "first-luxury-first-2",
    "formations-heed-refusals",
    "founder-converts-its-own-cities",
    "founder-defends-its-cities",
    "founder-holds-the-holy-city",
    "founder-keeps-two-sources",
    "founder-temple",
    "front-needs-a-declarable-rival",
    "gold-income-floor",
    "golden-dedication-serves-the-conquest",
    "government-capacity-fallback",
    "government-ladder-2",
    "granary-claims-the-bound-queue",
    "great-person-housing",
    "growth-to-settle",
    "gun-queue-follows-the-road",
    "gun-queues-behind-the-column",
    "guns-enter-together",
    "guns-post-for-a-near-breach",
    "guru-heals-the-corps-2",
    "holdout-keeps-the-faith-war",
    "hostile-memory-3",
    "housing-bound-city-builds-its-granary",
    "housing-cap-builds-the-aqueduct",
    "improvement-upgrades-count",
    "industrial-chain-debt",
    "industrial-zone-claims-the-producer-queue",
    "industrial-zone-in-the-producers",
    "industry-before-the-army-2",
    "industry-in-the-district-list",
    "island-exploration",
    "lane-culture-spending",
    "lane-delegates-production-2",
    "lane-great-people",
    "lane-space-race",
    "lane-votes-its-favor",
    "launcher-war-ignores-the-edge",
    "liang-follows-builders",
    "maintenance-aware-deck",
    "melee-storms-an-open-city",
    "missionary-last-charge-explores",
    "native-emergency-purchase-2",
    "naval-recon",
    "never-an-empty-queue-2",
    "no-free-passage",
    "objective-board",
    "one-war-at-a-time",
    "opening-warrior-recon-2",
    "opening-yields-to-walls",
    "order-retry",
    "parity-reads-the-front",
    "pass-picket",
    "paused-district-finishes",
    "peace-asks-a-city",
    "peace-when-the-war-does-not-pay",
    "peacetime-deterrence",
    "phantom-capture-keeps-the-siege",
    "pingala-follows-research",
    "policy-deck-hysteresis",
    "power-the-laboratory-2",
    "price-the-suzerainty",
    "promote-when-wounded",
    "purchases-keep-the-upkeep-reserve",
    "quest-camp-errand",
    "quest-production",
    "quest-trade-route",
    "racer-keeps-the-spies",
    "raid-pillage-prizes",
    "ranged-before-melee",
    "ranged-hp-reserve",
    "rapid-city-expansion-2",
    "recorded-tactical-step",
    "reinforce-before-stall",
    "relief-targets-the-siege",
    "religion-sues-peace",
    "religious-defence-scales",
    "religious-units-heal-first",
    "religious-veto-defence",
    "research-alliance-first",
    "research-building-catchup-3",
    "research-tier-premium",
    "reyna-follows-revenue",
    "route-block-is-a-wait",
    "runaway-expander-counter",
    "sanctuary-yields-a-held-queue",
    "science-denial-every-pad",
    "science-denial-spy-reads-the-leader",
    "science-denial-trains-spies",
    "science-denounce-waits-for-the-race",
    "science-expansion-phase",
    "science-leader-is-the-target",
    "science-opening-band",
    "science-suppression-hits-the-pads",
    "science-threat-denial",
    "science-victory-drive",
    "scout-first-opening",
    "screen-the-shooters",
    "second-front-keeps-its-war",
    "second-front-kept-when-winning",
    "settle-sooner",
    "settler-backlog-brake",
    "settler-before-the-navy",
    "settler-detour-stays-near",
    "settler-factory-coordination",
    "settler-guard-holds",
    "settler-never-idles",
    "settler-target-hysteresis",
    "settler-walk-deadline",
    "settler-walks-to-the-better-site",
    "shared-danger",
    "siege-budget-projects-the-seal",
    "siege-force-keeps-its-members",
    "siege-holds-a-breach",
    "siege-is-progress-3",
    "siege-keeps-a-shooter",
    "siege-members-use-their-moves",
    "siege-positive-damage-budget",
    "siege-rally-holds",
    "siege-target-needs-a-road",
    "siege-train-scales-with-walls",
    "skip-the-prophet-race-2",
    "slot-kind-tiebreak",
    "solvency-first-trade-slot",
    "space-denial-spies-from-rocketry",
    "spaceport-surplus-veto",
    "stage-march-keeps-to-land",
    "staging-gun-reads-the-shared-danger",
    "staging-gun-trusts-its-escort",
    "staging-reaches-the-border",
    "stall-waits-for-the-breach",
    "stalled-peace-spares-the-counter",
    "stranded-settler-discount",
    "strategic-deposit-prey",
    "strategic-wonders",
    "strike-opening",
    "strike-reach",
    "surprise-war-mobilization",
    "swap-rotation-2",
    "tier-gap-reads-the-fielded-line",
    "tower-assault",
    "trade-building-before-bankruptcy-2",
    "trade-production-to-launch",
    "trade-route-network",
    "trader-fills-the-idle-route",
    "treasury-at-work-2-2",
    "unchosen-war-keeps-the-lane",
    "unit-cost-efficiency",
    "unit-objective-memory",
    "unwalled-city-spares-the-train",
    "unwalled-city-takes-the-swarm",
    "unwalled-target-declares-into-the-strike",
    "upkeep-reserve",
    "war-bill-prices-the-tier-gap",
    "war-economy",
    "war-kills-the-bands-2",
    "war-needs-a-treasury",
    "war-policy-via-board",
    "war-raids-the-pads",
    "war-target-prices-the-walls",
    "whole-turn-backtrack-guard",
    "wide-map-capacity",
    "wonder-adjacent-sites-2",
    "wonder-ring-recon-2",
    "wounded-taker-finishes-the-breach",
];

/// No manual on overrides: every deployed gene meets the published
/// completed-total-seat-weighted latest-three criterion — above +3 to turn
/// on, not below -3 to stay on.
#[rustfmt::skip]
pub(super) const OPERATOR_DEFAULT_ON: &[&str] = &[
];

/// No manual off overrides: every gene outside `DEPLOYMENT_GENOME` is off
/// because it did not meet the explicit selection criterion.
#[rustfmt::skip]
pub(super) const OPERATOR_DEFAULT_OFF: &[&str] = &[
];

/// Every screenable gene a reporting batch priced, with its three batch
/// columns newest first — wins ± per 10,000 total seats in the ranking's
/// *Last*, *Prior* and *Third Batch* columns. They remain evidence while
/// this reporting-only publication retains the selected defaults.
#[rustfmt::skip]
pub(super) const BATCH_COLUMNS: &[(&str, [Option<i32>; 3])] = &[
    ("age-closer", [Some(13), Some(3), Some(10)]),
    ("age-closer-2", [Some(-14), Some(-1), Some(-2)]),
    ("age-closer-spends-the-reserve", [Some(-5), None, None]),
    ("air-fire-counts-on-the-city", [Some(1), None, None]),
    ("air-surge", [Some(-11), Some(12), Some(2)]),
    ("air-surge-2", [Some(20), Some(6), Some(4)]),
    ("air-surge-strikes-through-urgency", [Some(6), None, None]),
    ("air-volley-needs-a-road", [Some(14), None, None]),
    ("aluminum-ask-tops-up-gold", [Some(24), None, None]),
    ("aluminum-buys-the-tile", [Some(-4), None, None]),
    ("amani-follows-suzerainty", [Some(-15), Some(-22), Some(20)]),
    ("amenity-district-path", [Some(18), Some(13), Some(17)]),
    ("amenity-project-preemption", [Some(-5), Some(-11), Some(6)]),
    ("amenity-project-preemption-2", [Some(22), Some(19), Some(-1)]),
    ("amphibious-siege-train", [Some(-4), None, None]),
    ("amphibious-siege-train-2", [Some(11), None, None]),
    ("anvil", [Some(1), Some(12), Some(15)]),
    ("apostle-promotion-by-role", [Some(8), Some(4), Some(-25)]),
    ("aqueduct-claims-the-capped-queue", [Some(-4), None, None]),
    ("army-target-weighs-enemy", [Some(13), Some(-8), Some(-10)]),
    ("army-upgrade-materials", [Some(6), None, None]),
    ("backlog-builder-takes-the-queue", [Some(-13), None, None]),
    ("barbarian-bargain", [Some(16), Some(5), Some(10)]),
    ("barbarian-ranged-answer", [Some(5), Some(-10), Some(-3)]),
    ("barbarian-scouts-are-scouts", [Some(7), Some(-7), Some(19)]),
    ("barbarian-settler-capture", [Some(-18), Some(2), Some(-21)]),
    ("battle-planner", [Some(13), Some(-2), Some(9)]),
    ("battle-planner-2", [Some(-5), Some(3), Some(-4)]),
    ("battle-planner-3", [Some(-2), Some(16), Some(4)]),
    ("beeline-orders-by-value", [Some(0), Some(8), Some(17)]),
    ("befriend-the-strongest", [Some(47), Some(45), Some(27)]),
    ("bleeding-capital-loyalty", [Some(-15), None, None]),
    ("blind-objective-strength", [Some(16), Some(6), Some(-3)]),
    ("blind-objective-units", [Some(-4), Some(2), Some(10)]),
    ("blocker-becomes-the-target", [Some(-13), None, None]),
    ("bombers-fly-on-a-small-stock", [Some(2), None, None]),
    ("bombers-open-the-siege-walls", [Some(-16), None, None]),
    ("boost-first-research", [Some(1), Some(-10), Some(3)]),
    ("boost-first-research-2", [Some(-6), Some(-11), Some(12)]),
    ("boost-planner", [Some(-18), Some(12), Some(-5)]),
    ("boost-planner-builds", [Some(-21), Some(-25), Some(8)]),
    ("boost-unlock-research", [Some(-9), Some(-7), Some(0)]),
    ("boost-wait-research-2", [Some(-1), Some(4), Some(-2)]),
    ("boosted-bargain-first", [Some(-17), Some(6), Some(-10)]),
    ("boosted-bargain-first-2", [Some(5), Some(0), Some(5)]),
    ("boosted-bargain-first-3", [Some(-1), Some(3), Some(6)]),
    ("border-parity", [Some(18), Some(0), Some(7)]),
    ("border-parity-2", [Some(8), Some(-5), Some(-18)]),
    ("border-parity-3", [Some(-5), Some(1), Some(-4)]),
    ("bounded-recovery", [Some(1), Some(7), Some(12)]),
    ("breach-assault", [Some(-8), None, None]),
    ("breach-assault-closes-in", [Some(8), None, None]),
    ("breach-counts-nearby-guns", [Some(-2), None, None]),
    ("breach-reads-the-air", [Some(-9), None, None]),
    ("breach-support-reads-the-wall-tier", [Some(-18), None, None]),
    ("breaker-before-the-war", [Some(-5), None, None]),
    ("breaker-keeps-its-queue", [Some(16), None, None]),
    ("breaker-reads-the-march", [Some(4), None, None]),
    ("breaker-research-first", [Some(9), None, None]),
    ("breaker-supply-scales", [Some(19), None, None]),
    ("breaker-supply-scales-2", [Some(-13), None, None]),
    ("breaker-to-the-fastest", [Some(11), None, None]),
    ("breakers-match-the-walls", [Some(-1), None, None]),
    ("breakers-stay-with-the-siege", [Some(8), None, None]),
    ("build-what-cards-boost", [Some(-13), Some(-9), Some(14)]),
    ("builder-barbarian-safety", [Some(-16), Some(2), Some(5)]),
    ("builder-before-the-army", [Some(-1), None, None]),
    ("builder-before-the-army-2", [Some(9), None, None]),
    ("builder-before-the-army-3", [Some(2), None, None]),
    ("builder-charge-window", [Some(-6), Some(-22), Some(-5)]),
    ("builder-supply-floor", [Some(-4), Some(24), Some(18)]),
    ("builder-tries-the-next-tile", [Some(-13), Some(13), Some(8)]),
    ("builder-workforce-recovery", [Some(6), Some(2), Some(-19)]),
    ("builder-workforce-recovery-2", [Some(4), Some(-8), Some(17)]),
    ("builder-workforce-recovery-3", [Some(-4), Some(-4), Some(2)]),
    ("builders-before-the-lent-floor", [Some(-1), None, None]),
    ("builders-cover-the-worked-backlog", [Some(18), None, None]),
    ("builders-improve-the-worked-for-production", [Some(6), None, None]),
    ("builders-route-around-mountains", [Some(-3), None, None]),
    ("builders-work-through-raiders", [Some(62), Some(57), Some(54)]),
    ("buildings-before-projects", [Some(-1), Some(12), Some(-12)]),
    ("buy-what-cards-cannot-boost", [Some(5), Some(24), Some(16)]),
    ("camp-party", [Some(3), Some(-16), Some(3)]),
    ("camp-tile-buyout", [Some(-8), Some(28), Some(14)]),
    ("campaign-pillage", [Some(19), Some(1), Some(-5)]),
    ("campaign-weighs-the-tourism-leader", [Some(-10), None, None]),
    ("campus-adjacency-threshold", [Some(-14), Some(1), Some(11)]),
    ("campus-adjacency-threshold-2", [Some(24), Some(-4), Some(7)]),
    ("campus-before-halfway", [Some(1), Some(-4), Some(7)]),
    ("campus-before-harbor", [Some(-4), None, None]),
    ("campus-before-harbor-2", [Some(6), None, None]),
    ("campus-before-the-army", [Some(-14), None, None]),
    ("campus-before-the-army-2", [Some(-3), None, None]),
    ("campus-before-the-army-3", [Some(-15), None, None]),
    ("campus-building-claims-the-queue", [Some(11), None, None]),
    ("campus-buildings-first", [Some(-2), None, None]),
    ("campus-through-expansion", [Some(-4), Some(-1), Some(5)]),
    ("canal-city", [Some(2), Some(12), Some(-4)]),
    ("capital-campaign-router", [Some(12), Some(7), Some(-9)]),
    ("capital-campus-before-the-plaza", [Some(18), None, None]),
    ("capital-defense-holds", [Some(15), None, None]),
    ("capital-prey-opens-a-front", [Some(6), None, None]),
    ("capital-prey-opens-a-front-2", [Some(-1), None, None]),
    ("capital-prey-scales-the-walls", [Some(-9), None, None]),
    ("capital-settler-after-completion", [Some(5), Some(-2), Some(-4)]),
    ("capital-taken-moves-on", [Some(-1), None, None]),
    ("capital-walls-before-the-surprise", [Some(4), None, None]),
    ("capture-go-or-stand-down", [Some(7), Some(0), Some(14)]),
    ("capture-go-or-stand-down-2", [Some(-1), Some(0), Some(-19)]),
    ("capture-hold-chain", [Some(-13), Some(16), Some(8)]),
    ("capture-holds-the-ring", [Some(-10), None, None]),
    ("capture-waits-on-the-march", [Some(4), None, None]),
    ("chain-payback-window", [Some(1), Some(-7), Some(-1)]),
    ("chain-payback-window-2", [Some(9), Some(2), Some(1)]),
    ("chase-every-boost", [Some(-17), Some(8), Some(10)]),
    ("chase-every-boost-2", [Some(-6), Some(-17), Some(-13)]),
    ("cheapest-wonder-first", [Some(-16), Some(2), Some(7)]),
    ("chokepoint-claim", [Some(11), Some(-3), Some(12)]),
    ("chokepoint-garrison", [Some(-8), Some(-10), Some(16)]),
    ("chokepoint-siting", [Some(-8), Some(3), Some(-21)]),
    ("chop-for-expansion", [Some(-12), Some(-40), Some(-10)]),
    ("city-campaign", [Some(26), Some(-2), Some(-8)]),
    ("city-campaign-2", [Some(-25), Some(6), Some(-10)]),
    ("city-target-meets-the-map", [Some(-10), Some(0), Some(3)]),
    ("civic-awaits-its-inspiration", [Some(-11), None, None]),
    ("civilian-out-of-reach", [Some(-72), Some(-6), Some(-36)]),
    ("close-as-a-body", [Some(4), Some(-6), Some(25)]),
    ("closed-border-blocker-declares", [Some(7), None, None]),
    ("coalition-before-war", [Some(3), Some(-15), Some(2)]),
    ("coalition-before-war-2", [Some(11), Some(-18), Some(12)]),
    ("coalition-before-war-3", [Some(-9), Some(21), Some(4)]),
    ("coastal-city-sites", [Some(13), Some(11), Some(17)]),
    ("coastal-city-sites-2", [Some(-24), Some(-4), Some(17)]),
    ("colonization-earns-its-slot", [Some(2), None, None]),
    ("colonization-earns-its-slot-2", [Some(7), None, None]),
    ("come-ashore", [Some(-13), Some(-13), Some(2)]),
    ("commercial-hub-and-traders", [Some(12), None, None]),
    ("commercial-hub-in-the-strategic-queue", [Some(2), None, None]),
    ("commitment-owner-acts", [Some(-1), Some(-16), Some(-4)]),
    ("commitment-patience", [Some(-9), Some(18), Some(10)]),
    ("competition-victory-points", [Some(-12), Some(1), Some(-4)]),
    ("congress-counter-leader", [Some(-13), Some(0), Some(8)]),
    ("congress-guards-the-leader", [Some(-4), None, None]),
    ("connect-the-luxury", [Some(10), Some(5), Some(-8)]),
    ("connect-the-luxury-2", [Some(25), Some(4), Some(-1)]),
    ("conquest-opening-needs-the-production", [Some(-5), None, None]),
    ("conquest-opening-stays-near", [Some(1), None, None]),
    ("conquest-takes-the-soft-city", [Some(-11), Some(-6), Some(-17)]),
    ("contender-at-peace-is-the-target", [Some(-9), None, None]),
    ("contested-land-first", [Some(-24), Some(12), Some(-4)]),
    ("conversion-majority-alarm", [Some(1), Some(-4), Some(1)]),
    ("conversion-majority-alarm-2", [Some(-4), Some(1), Some(-13)]),
    ("coordinated-finish", [Some(1), Some(-11), Some(-10)]),
    ("counter-culture-by-conquest", [Some(-3), Some(-10), Some(9)]),
    ("counter-out-of-reach-takes-the-weak", [Some(14), None, None]),
    ("counter-war-needs-parity", [Some(-9), None, None]),
    ("counter-war-needs-the-emperor-edge", [Some(4), None, None]),
    ("counterfaith-leaves-two-holdouts", [Some(-6), None, None]),
    ("counterweight-faith-is-no-threat", [Some(-23), None, None]),
    ("counterweight-finishes-one-shrine", [Some(-16), None, None]),
    ("counterweight-flips-the-small-towns", [Some(5), None, None]),
    ("counterweight-from-the-first-convert", [Some(-9), None, None]),
    ("counterweight-spends-the-bank", [Some(-3), None, None]),
    ("crushing-steady-passes-the-edge", [Some(6), None, None]),
    ("culture-building-catchup", [Some(-14), Some(3), Some(-4)]),
    ("culture-building-catchup-2", [Some(-15), Some(-3), Some(-5)]),
    ("culture-building-catchup-3", [Some(4), Some(3), Some(-10)]),
    ("culture-building-debt", [Some(10), Some(-24), Some(16)]),
    ("culture-cold-war-window", [Some(-4), Some(3), Some(-9)]),
    ("culture-counter-declares", [Some(18), None, None]),
    ("culture-defense-theater", [Some(9), None, None]),
    ("culture-defense-theater-2", [Some(-4), None, None]),
    ("culture-denial-heist", [Some(1), None, None]),
    ("culture-faith-reservation", [Some(-5), Some(-11), Some(7)]),
    ("culture-finish-at-the-observed-bar", [Some(5), None, None]),
    ("culture-floor", [Some(-10), Some(26), Some(0)]),
    ("culture-lane-forecast", [Some(11), Some(14), Some(10)]),
    ("culture-lane-forecast-2", [Some(-2), Some(14), Some(3)]),
    ("culture-reads-the-engine-clock", [Some(0), None, None]),
    ("culture-threat-early", [Some(7), Some(-4), Some(5)]),
    ("culture-tourism-payback", [Some(5), Some(5), Some(11)]),
    ("deals-at-the-ceiling", [Some(-2), Some(-13), Some(-17)]),
    ("deals-for-our-gain", [Some(4), Some(-7), Some(13)]),
    ("decisive-window", [Some(-5), None, None]),
    ("declaration-needs-production-parity", [Some(-3), None, None]),
    ("declaration-needs-the-edge", [Some(3), None, None]),
    ("declaration-needs-the-edge-2", [Some(3), None, None]),
    ("declaration-waits-for-the-breach", [Some(-2), None, None]),
    ("declaration-waits-for-the-breaker", [Some(13), None, None]),
    ("defeated-majors-leave-the-board", [Some(2), None, None]),
    ("defend-where-you-stand", [Some(-22), Some(20), Some(5)]),
    ("defensible-sites", [Some(17), Some(19), Some(8)]),
    ("denial-keeps-its-rival", [Some(-16), None, None]),
    ("denial-nearest-finish", [Some(6), None, None]),
    ("denial-needs-a-road", [Some(-5), None, None]),
    ("denial-outranks-expansion", [Some(-20), Some(-18), Some(-28)]),
    ("deterrence-spares-the-faith-defence", [Some(-5), None, None]),
    ("detour-keeps-the-site-worth", [Some(1), Some(25), Some(0)]),
    ("dialogue-never-declares-war", [Some(-16), None, None]),
    ("diplomatic-contender-eliminated", [Some(14), None, None]),
    ("diplomatic-contender-kept", [Some(-16), None, None]),
    ("diplomatic-contender-kept-2", [Some(-12), None, None]),
    ("diplomatic-lane-forecast", [Some(7), Some(4), Some(-11)]),
    ("diplomatic-lane-forecast-2", [Some(2), Some(-8), Some(21)]),
    ("district-buildings-first", [Some(-1), None, None]),
    ("district-buildings-first-2", [Some(-14), None, None]),
    ("district-coverage", [Some(-5), Some(7), Some(6)]),
    ("district-coverage-2", [Some(14), Some(-8), Some(-13)]),
    ("district-planning", [Some(-4), Some(-13), Some(-22)]),
    ("district-planning-3", [Some(-1), Some(18), Some(15)]),
    ("domination-capital-focus", [Some(-16), Some(6), Some(2)]),
    ("domination-city-count", [Some(-5), Some(15), Some(1)]),
    ("domination-finish-holds-the-front", [Some(-1), None, None]),
    ("domination-ignores-city-states", [Some(-11), Some(7), Some(-3)]),
    ("domination-lane-hands-over", [Some(18), Some(3), Some(-6)]),
    ("domination-siege-research", [Some(3), Some(24), Some(-15)]),
    ("domination-siege-research-2", [Some(-14), None, None]),
    ("domination-specializes-earlier", [Some(-12), Some(5), Some(-7)]),
    ("domination-strikes-when-staged", [Some(-4), None, None]),
    ("doomed-blow-veto", [Some(5), Some(16), Some(4)]),
    ("doomed-blow-veto-2", [Some(11), Some(-13), Some(18)]),
    ("dry-road-outlasts-a-blocked-step", [Some(-25), None, None]),
    ("dvp-leader-is-the-front", [Some(-19), None, None]),
    ("early-archers", [Some(14), Some(29), Some(20)]),
    ("early-conquest-opening", [Some(12), Some(19), Some(7)]),
    ("early-conquest-stands-down", [Some(17), None, None]),
    ("early-contact-window", [Some(9), Some(5), Some(-12)]),
    ("early-contact-window-2", [Some(-27), Some(9), Some(14)]),
    ("early-project-restraint", [Some(-11), Some(2), Some(-1)]),
    ("early-project-restraint-2", [Some(25), Some(-16), Some(-7)]),
    ("early-settler-floor", [Some(8), None, None]),
    ("elective-war-in-reach", [Some(1), Some(-4), Some(0)]),
    ("elective-war-yields-to-a-lane", [Some(13), Some(3), Some(-3)]),
    ("elimination-waits-on-the-clock", [Some(3), None, None]),
    ("elimination-yields-to-a-launch", [Some(2), None, None]),
    ("embassy-finds-the-capital", [Some(-8), None, None]),
    ("encampment-seals-the-pass", [Some(7), Some(0), Some(5)]),
    ("enemy-of-my-enemy", [Some(-16), Some(-9), Some(-1)]),
    ("engine-faith-price", [Some(7), Some(-4), Some(8)]),
    ("engineering-for-capped-fresh-water", [Some(-32), None, None]),
    ("enhancer-for-the-corps", [Some(-11), Some(11), Some(-11)]),
    ("enter-the-prophet-race-2", [Some(40), Some(9), Some(5)]),
    ("envoy-building-dividends", [Some(0), Some(8), Some(25)]),
    ("escort-cap-holds", [Some(12), Some(18), Some(1)]),
    ("escort-unstick", [Some(16), Some(-6), Some(9)]),
    ("eureka-chasing-builder", [Some(-1), Some(-7), Some(-2)]),
    ("eureka-chasing-builder-2", [Some(5), Some(-3), Some(-2)]),
    ("eureka-chasing-production", [Some(-9), Some(-5), Some(2)]),
    ("exchange-is-the-engines", [Some(15), Some(-16), Some(10)]),
    ("exhaustion-loyalty-guard", [Some(-29), Some(-8), Some(18)]),
    ("expansion-best-idle-city", [Some(1), Some(8), Some(11)]),
    ("expansion-best-idle-city-2", [Some(2), Some(-16), Some(6)]),
    ("expansion-hall-district", [Some(5), Some(-16), Some(2)]),
    ("expansion-pays-back", [Some(16), Some(-21), Some(8)]),
    ("expansion-scales-with-difficulty", [Some(2), Some(-6), Some(-19)]),
    ("expansion-schedule", [Some(12), Some(17), Some(2)]),
    ("faith-counter-needs-the-edge", [Some(-11), None, None]),
    ("faith-counter-waits-for-match-point", [Some(1), None, None]),
    ("falling-city-calls-the-takers", [Some(17), None, None]),
    ("falling-city-outranks-the-heal", [Some(11), None, None]),
    ("favor-bought-before-congress", [Some(-2), None, None]),
    ("favor-spares-the-surprise-war", [Some(1), None, None]),
    ("find-the-capital", [Some(-5), None, None]),
    ("fire-plan", [Some(-16), Some(5), Some(-5)]),
    ("first-builder-reserve", [Some(-3), Some(-5), Some(6)]),
    ("first-builder-reserve-2", [Some(-2), Some(3), Some(10)]),
    ("first-district-first", [Some(15), Some(7), Some(3)]),
    ("first-granary-reserve", [Some(0), Some(19), Some(19)]),
    ("first-granary-reserve-2", [Some(7), Some(-9), Some(0)]),
    ("first-granary-reserve-3", [Some(-11), None, None]),
    ("first-luxury-first", [Some(9), Some(5), Some(4)]),
    ("first-luxury-first-2", [Some(22), None, None]),
    ("first-research-building-reserve", [Some(-5), Some(-3), Some(13)]),
    ("flipped-capital-finishes", [Some(-9), None, None]),
    ("formations-heed-refusals", [Some(10), None, None]),
    ("found-against-a-rival-faith", [Some(0), None, None]),
    ("founder-converts-its-own-cities", [Some(7), None, None]),
    ("founder-defends-its-cities", [Some(5), None, None]),
    ("founder-funds-the-inquisition", [Some(-3), None, None]),
    ("founder-holds-the-holy-city", [Some(19), None, None]),
    ("founder-keeps-two-sources", [Some(6), None, None]),
    ("founder-spreads-only-its-faith", [Some(-17), None, None]),
    ("founder-temple", [Some(8), Some(16), Some(17)]),
    ("front-finishes-its-capital", [Some(-24), None, None]),
    ("front-finishes-its-siege", [Some(0), None, None]),
    ("front-needs-a-declarable-rival", [Some(13), None, None]),
    ("front-weighted-floor", [Some(-4), None, None]),
    ("front-weighted-floor-2", [Some(-15), None, None]),
    ("frontier-massing-alarm", [Some(0), Some(0), Some(4)]),
    ("garrison-under-fire", [Some(-25), Some(-2), Some(-6)]),
    ("gold-buys-the-settler", [Some(-17), None, None]),
    ("gold-income-floor", [Some(-11), Some(10), Some(3)]),
    ("golden-dedication-serves-the-conquest", [Some(15), None, None]),
    ("government-capacity-fallback", [Some(10), Some(7), Some(-1)]),
    ("government-ladder", [Some(-16), Some(29), Some(5)]),
    ("government-ladder-2", [Some(27), Some(-4), Some(0)]),
    ("government-ladder-3", [Some(-6), Some(-5), Some(7)]),
    ("granary-before-the-army", [Some(-9), None, None]),
    ("granary-before-the-army-2", [Some(2), None, None]),
    ("granary-claims-the-bound-queue", [Some(4), None, None]),
    ("great-person-housing", [Some(1), Some(11), Some(13)]),
    ("great-work-completion-value", [Some(-4), Some(6), Some(-13)]),
    ("growth-prices-the-farm", [Some(-15), None, None]),
    ("growth-prices-the-farm-2", [Some(-11), None, None]),
    ("growth-to-settle", [Some(-9), Some(12), Some(-3)]),
    ("gun-queue-follows-the-road", [Some(10), None, None]),
    ("gun-queues-behind-the-column", [Some(4), None, None]),
    ("guns-enter-together", [Some(11), None, None]),
    ("guns-grind-the-walls", [Some(0), None, None]),
    ("guns-post-for-a-near-breach", [Some(5), None, None]),
    ("guns-stay-out-of-reach", [Some(-1), None, None]),
    ("guru-heals-the-corps-2", [Some(-6), Some(-13), Some(25)]),
    ("holdout-keeps-the-faith-war", [Some(10), None, None]),
    ("holy-lane-parity", [Some(-27), Some(-14), Some(10)]),
    ("holy-site-where-the-threat-is", [Some(-11), Some(13), Some(-11)]),
    ("holy-site-where-the-threat-is-2", [Some(-11), Some(2), Some(1)]),
    ("hostile-memory", [Some(-13), Some(12), Some(2)]),
    ("hostile-memory-2", [Some(-4), Some(-3), Some(-5)]),
    ("hostile-memory-3", [Some(13), Some(-1), Some(8)]),
    ("housing-bound-city-builds-its-granary", [Some(18), None, None]),
    ("housing-cap-builds-the-aqueduct", [Some(7), None, None]),
    ("housing-research", [Some(-14), Some(-5), Some(2)]),
    ("housing-research-2", [Some(-11), Some(3), Some(6)]),
    ("idle-faith-patronage", [Some(-3), Some(7), Some(-12)]),
    ("improvement-upgrades-count", [Some(18), None, None]),
    ("industrial-chain-debt", [Some(21), Some(-3), Some(-25)]),
    ("industrial-hub", [Some(-7), None, None]),
    ("industrial-zone-claims-the-factory", [Some(-3), None, None]),
    ("industrial-zone-claims-the-producer-queue", [Some(9), None, None]),
    ("industrial-zone-in-the-producers", [Some(17), None, None]),
    ("industry-before-the-army", [Some(0), None, None]),
    ("industry-before-the-army-2", [Some(7), None, None]),
    ("industry-before-the-army-3", [Some(-3), None, None]),
    ("industry-in-the-district-list", [Some(21), None, None]),
    ("invest-keeps-its-cavalry", [Some(-18), None, None]),
    ("island-exploration", [Some(-9), Some(-2), Some(9)]),
    ("lane-culture-spending", [Some(7), Some(-10), Some(-1)]),
    ("lane-delegates-production", [Some(-62), Some(12), Some(28)]),
    ("lane-delegates-production-2", [Some(189), Some(96), Some(97)]),
    ("lane-great-people", [Some(3), Some(13), Some(-8)]),
    ("lane-policy-deck", [Some(-12), Some(-6), Some(9)]),
    ("lane-release-when-hopeless", [Some(3), Some(2), Some(-20)]),
    ("lane-space-race", [Some(22), Some(2), Some(-3)]),
    ("lane-votes-its-favor", [Some(1), Some(11), Some(13)]),
    ("last-capital-war-kept", [Some(-3), None, None]),
    ("launched-racer-yields-the-capital", [Some(-14), None, None]),
    ("launcher-war-ignores-the-edge", [Some(5), None, None]),
    ("liang-follows-builders", [Some(-1), Some(4), Some(10)]),
    ("liberation-funds-the-congress", [Some(-12), None, None]),
    ("long-road-names-the-blocker", [Some(-2), None, None]),
    ("loyalty-rate-alarm", [Some(-11), Some(-2), Some(-4)]),
    ("luxury-buy-asks", [Some(-1), None, None]),
    ("luxury-swap-asks", [Some(1), None, None]),
    ("luxury-swap-asks-2", [Some(-5), None, None]),
    ("magnus-follows-settlers", [Some(-7), Some(6), Some(-1)]),
    ("maintenance-aware-deck", [Some(12), Some(19), Some(5)]),
    ("march-uses-its-moves", [Some(-4), None, None]),
    ("match-point-interception-ignores-power", [Some(-17), None, None]),
    ("melee-storms-an-open-city", [Some(4), None, None]),
    ("missionary-evades-raiders", [Some(6), Some(-10), Some(14)]),
    ("missionary-last-charge-explores", [Some(12), Some(2), Some(5)]),
    ("missionary-last-charge-explores-2", [Some(-1), Some(3), Some(13)]),
    ("modernize-before-spending", [Some(14), Some(-9), Some(-9)]),
    ("moksha-defends-the-faithless", [Some(-11), Some(-8), Some(-5)]),
    ("monument-first", [Some(-16), None, None]),
    ("muster-walks-the-road", [Some(-3), None, None]),
    ("native-emergency-purchase", [Some(-14), Some(-21), Some(21)]),
    ("native-emergency-purchase-2", [Some(5), Some(14), Some(-9)]),
    ("naval-recon", [Some(-1), Some(11), Some(1)]),
    ("naval-recon-2", [Some(4), Some(7), Some(-4)]),
    ("naval-recon-3", [Some(-15), Some(-2), Some(-6)]),
    ("naval-threat-triage", [Some(4), Some(15), Some(-16)]),
    ("near-rival-deterrence", [Some(-10), None, None]),
    ("never-an-empty-queue", [Some(3), Some(1), Some(-5)]),
    ("never-an-empty-queue-2", [Some(7), Some(12), Some(5)]),
    ("never-an-empty-queue-3", [Some(-13), Some(-2), Some(20)]),
    ("no-free-passage", [Some(5), Some(-6), Some(29)]),
    ("no-peace-with-a-launcher", [Some(1), None, None]),
    ("objective-board", [Some(16), Some(5), Some(-13)]),
    ("one-launch-pad", [Some(-19), Some(-11), Some(3)]),
    ("one-sanctuary", [Some(-29), None, None]),
    ("one-shot-recovery", [Some(-6), Some(-5), Some(-24)]),
    ("one-war-at-a-time", [Some(-13), Some(-3), Some(13)]),
    ("one-war-swaps-a-stalled-front", [Some(-7), None, None]),
    ("opening-defense-preempts-once", [Some(-6), None, None]),
    ("opening-force-keeps-its-members", [Some(-6), None, None]),
    ("opening-warrior-recon-2", [Some(-14), Some(13), Some(-6)]),
    ("opening-yields-to-walls", [Some(12), None, None]),
    ("opportunistic-war", [Some(-17), Some(-1), Some(-1)]),
    ("opportunistic-war-2", [Some(-20), Some(7), Some(2)]),
    ("order-retry", [Some(-13), Some(17), Some(12)]),
    ("overseas-settlement", [Some(-10), Some(-1), Some(7)]),
    ("overwhelming-power-declares", [Some(-14), None, None]),
    ("own-column-is-not-a-refusal", [Some(2), None, None]),
    ("pantheon-board", [Some(-19), Some(-1), Some(-2)]),
    ("parity-reads-the-front", [Some(6), None, None]),
    ("pass-picket", [Some(23), Some(0), Some(17)]),
    ("pass-picket-2", [Some(-12), Some(-1), Some(-11)]),
    ("paused-district-finishes", [Some(9), None, None]),
    ("peace-asks-a-city", [Some(13), None, None]),
    ("peace-waits-for-the-foothold", [Some(-2), None, None]),
    ("peace-waits-for-unseen-prey", [Some(2), None, None]),
    ("peace-when-the-war-does-not-pay", [Some(2), Some(24), Some(-9)]),
    ("peacetime-classical-republic", [Some(-5), None, None]),
    ("peacetime-deterrence", [Some(14), Some(-2), Some(2)]),
    ("phantom-capture-keeps-the-siege", [Some(10), None, None]),
    ("pingala-follows-research", [Some(5), Some(10), Some(4)]),
    ("plaza-in-the-district-list", [Some(-20), None, None]),
    ("policy-deck-hysteresis", [Some(13), None, None]),
    ("policy-deck-hysteresis-2", [Some(-1), None, None]),
    ("power-the-laboratory", [Some(0), Some(2), Some(-8)]),
    ("power-the-laboratory-2", [Some(23), Some(-3), Some(21)]),
    ("prey-reads-a-steady-power", [Some(-6), None, None]),
    ("price-the-suzerainty", [Some(-9), Some(17), Some(4)]),
    ("promote-when-wounded", [Some(4), Some(-3), Some(11)]),
    ("prophet-builds-its-site", [Some(-2), None, None]),
    ("prophet-race-earns-its-points", [Some(-5), None, None]),
    ("prophet-race-takes-a-district-slot", [Some(-14), None, None]),
    ("prophet-race-takes-a-district-slot-2", [Some(1), None, None]),
    ("purchases-keep-the-upkeep-reserve", [Some(23), None, None]),
    ("quest-boost", [Some(-8), Some(6), Some(-14)]),
    ("quest-camp-errand", [Some(3), Some(-5), Some(15)]),
    ("quest-production", [Some(19), Some(8), Some(-17)]),
    ("quest-trade-route", [Some(5), Some(36), Some(15)]),
    ("racer-keeps-the-spies", [Some(7), None, None]),
    ("raid-pillage-prizes", [Some(29), Some(-14), Some(17)]),
    ("raids-cut-tourism", [Some(0), None, None]),
    ("ranged-before-melee", [Some(9), None, None]),
    ("ranged-hp-reserve", [Some(11), Some(12), Some(1)]),
    ("rapid-city-expansion-2", [Some(60), Some(18), Some(39)]),
    ("raze-a-doomed-capture", [Some(-17), None, None]),
    ("recon-replacement", [Some(-15), Some(-38), Some(-56)]),
    ("recorded-tactical-step", [Some(9), Some(-6), Some(11)]),
    ("recovery-keeps-a-winning-war", [Some(-13), None, None]),
    ("recovery-needs-the-deficit", [Some(-18), None, None]),
    ("recovery-peace-waits", [Some(-4), None, None]),
    ("recovery-reads-the-war", [Some(9), Some(-10), Some(-7)]),
    ("recovery-reads-the-war-2", [Some(2), Some(-6), Some(5)]),
    ("reinforce-before-stall", [Some(10), Some(6), Some(8)]),
    ("relief-column-marches", [Some(7), Some(-9), Some(-6)]),
    ("relief-targets-the-siege", [Some(6), Some(-6), Some(20)]),
    ("religion-race-is-closed", [Some(5), Some(-4), Some(-5)]),
    ("religion-sues-peace", [Some(18), Some(-9), Some(-13)]),
    ("religious-defence-scales", [Some(-13), Some(14), Some(22)]),
    ("religious-match-point-defence", [Some(-30), None, None]),
    ("religious-threat-spares-the-front", [Some(-3), None, None]),
    ("religious-units-heal-first", [Some(14), Some(-5), Some(13)]),
    ("religious-veto-defence", [Some(12), Some(-4), Some(9)]),
    ("research-alliance-first", [Some(14), Some(8), Some(-23)]),
    ("research-building-catchup", [Some(-22), Some(-4), Some(-27)]),
    ("research-building-catchup-2", [Some(-5), Some(-3), Some(-4)]),
    ("research-building-catchup-3", [Some(3), Some(10), Some(17)]),
    ("research-tier-premium", [Some(-11), Some(11), Some(10)]),
    ("reyna-follows-revenue", [Some(18), Some(9), Some(-14)]),
    ("ring-fires-on-the-city", [Some(-10), None, None]),
    ("rival-suzerainty-alarm", [Some(-3), Some(-15), Some(-8)]),
    ("rout-spares-a-stronger-army", [Some(-11), None, None]),
    ("rout-spares-the-counter", [Some(-13), None, None]),
    ("route-block-is-a-wait", [Some(14), Some(-5), Some(18)]),
    ("runaway-expander-counter", [Some(11), None, None]),
    ("safest-stand", [Some(-20), Some(-21), Some(-4)]),
    ("sanctuary-yields-a-held-queue", [Some(12), None, None]),
    ("science-building-first", [Some(-11), Some(5), Some(-5)]),
    ("science-chain-alarm", [Some(24), Some(-11), Some(-16)]),
    ("science-denial-every-pad", [Some(4), None, None]),
    ("science-denial-spy-reads-the-leader", [Some(9), None, None]),
    ("science-denial-trains-spies", [Some(20), None, None]),
    ("science-denial-war", [Some(24), Some(-16), Some(-7)]),
    ("science-denounce-waits-for-the-race", [Some(23), None, None]),
    ("science-expansion-phase", [Some(-8), Some(13), Some(20)]),
    ("science-ladder-reads-the-clock", [Some(0), None, None]),
    ("science-leader-is-the-target", [Some(15), None, None]),
    ("science-multiplier-payoff", [Some(7), Some(-8), Some(4)]),
    ("science-opening-band", [Some(8), Some(12), Some(7)]),
    ("science-suppression-hits-the-pads", [Some(24), None, None]),
    ("science-threat-denial", [Some(19), Some(2), Some(3)]),
    ("science-victory-drive", [Some(-1), Some(34), Some(27)]),
    ("science-victory-drive-2", [Some(-1), Some(-36), Some(-18)]),
    ("scout-first-opening", [Some(-10), Some(23), Some(-5)]),
    ("screen-the-shooters", [Some(-6), Some(5), Some(-4)]),
    ("sea-locked-front-moves-on", [Some(-9), None, None]),
    ("second-front-keeps-its-war", [Some(3), None, None]),
    ("second-front-kept-when-winning", [Some(21), None, None]),
    ("second-front-kept-when-winning-2", [Some(-7), None, None]),
    ("second-front-waits-for-its-war", [Some(1), None, None]),
    ("settle-sooner", [Some(7), Some(30), Some(23)]),
    ("settlement-gap-target", [Some(-10), Some(-9), Some(-1)]),
    ("settler-backlog-brake", [Some(7), Some(4), Some(8)]),
    ("settler-backlog-brake-2", [Some(-19), Some(-14), Some(-8)]),
    ("settler-before-the-navy", [Some(5), None, None]),
    ("settler-detour-stays-near", [Some(16), Some(0), Some(29)]),
    ("settler-factory-coordination", [Some(-8), Some(16), Some(6)]),
    ("settler-guard-holds", [Some(15), Some(18), Some(-14)]),
    ("settler-guard-holds-2", [Some(-13), Some(-9), Some(-21)]),
    ("settler-marches-alone-when-clear", [Some(-3), None, None]),
    ("settler-never-idles", [Some(25), Some(10), Some(6)]),
    ("settler-site-gate", [Some(-17), Some(-4), Some(8)]),
    ("settler-target-floor", [Some(-1), Some(-9), Some(-10)]),
    ("settler-target-hysteresis", [Some(-6), Some(9), Some(18)]),
    ("settler-target-hysteresis-2", [Some(-6), Some(0), Some(-13)]),
    ("settler-threat-detour", [Some(-2), Some(-10), Some(12)]),
    ("settler-walk-deadline", [Some(6), Some(10), Some(-13)]),
    ("settler-walks-to-the-better-site", [Some(5), None, None]),
    ("shared-danger", [Some(6), None, None]),
    ("siege-budget-counts-what-fires", [Some(-24), None, None]),
    ("siege-budget-projects-the-seal", [Some(8), None, None]),
    ("siege-buys-the-gun-resource", [Some(-5), None, None]),
    ("siege-buys-the-passage", [Some(-10), None, None]),
    ("siege-commitment", [Some(-12), Some(3), Some(17)]),
    ("siege-counts-posted-shooters", [Some(-8), None, None]),
    ("siege-force-keeps-its-members", [Some(4), None, None]),
    ("siege-holds-a-breach", [Some(12), None, None]),
    ("siege-is-progress-2", [Some(11), Some(-6), Some(-2)]),
    ("siege-is-progress-3", [Some(12), Some(0), Some(19)]),
    ("siege-keeps-a-shooter", [Some(18), None, None]),
    ("siege-members-use-their-moves", [Some(9), None, None]),
    ("siege-needs-a-breaker", [Some(-2), None, None]),
    ("siege-positive-damage-budget", [Some(9), Some(36), Some(18)]),
    ("siege-preempts-the-queue", [Some(-6), Some(-3), Some(-23)]),
    ("siege-rally-holds", [Some(7), None, None]),
    ("siege-ranged-floor", [Some(-8), None, None]),
    ("siege-target-needs-a-road", [Some(4), None, None]),
    ("siege-tier-before-the-beeline", [Some(-3), None, None]),
    ("siege-tier-yields-to-the-bombers", [Some(-17), None, None]),
    ("siege-train", [Some(-3), Some(11), Some(-3)]),
    ("siege-train-scales-with-walls", [Some(13), None, None]),
    ("siege-train-upgrades-first", [Some(-7), None, None]),
    ("skip-the-prophet-race-2", [Some(-9), Some(25), Some(2)]),
    ("slot-kind-tiebreak", [Some(-21), Some(11), Some(17)]),
    ("solvency-first-trade-slot", [Some(4), Some(38), Some(14)]),
    ("space-denial-spies-from-rocketry", [Some(4), None, None]),
    ("spaceport-surplus-veto", [Some(13), Some(-17), Some(-2)]),
    ("spreader-steps-out-of-the-apostle", [Some(-4), None, None]),
    ("stage-march-keeps-to-land", [Some(5), None, None]),
    ("stage-musters-out-of-reach", [Some(-5), None, None]),
    ("staging-column-passes-through", [Some(3), None, None]),
    ("staging-gun-reads-the-shared-danger", [Some(15), None, None]),
    ("staging-gun-remembers-hostiles", [Some(-9), None, None]),
    ("staging-gun-trusts-its-escort", [Some(18), None, None]),
    ("staging-reaches-the-border", [Some(11), None, None]),
    ("stale-swap-reads-the-march", [Some(0), None, None]),
    ("stall-rebases-on-new-walls", [Some(-7), None, None]),
    ("stall-waits-for-the-breach", [Some(12), None, None]),
    ("stalled-peace-spares-the-counter", [Some(5), None, None]),
    ("stalled-settler-takes-a-safe-site", [Some(-4), None, None]),
    ("standing-still-is-a-risk", [Some(0), Some(-8), Some(-14)]),
    ("stranded-settler-discount", [Some(19), Some(23), Some(-5)]),
    ("stranded-settler-leaves-the-corridor", [Some(-13), None, None]),
    ("strategic-deposit-prey", [Some(9), None, None]),
    ("strategic-wonders", [Some(25), Some(-9), Some(6)]),
    ("strike-opening", [Some(12), Some(13), Some(22)]),
    ("strike-reach", [Some(17), Some(-1), Some(3)]),
    ("surge-fields-the-bombers", [Some(-9), None, None]),
    ("surprise-war-mobilization", [Some(4), Some(8), Some(13)]),
    ("swap-rotation", [Some(-15), Some(-7), Some(1)]),
    ("swap-rotation-2", [Some(16), Some(-24), Some(6)]),
    ("theater-keeps-its-amphitheater", [Some(2), None, None]),
    ("theology-fights-only-to-win", [Some(-7), None, None]),
    ("threatened-city-reserve", [Some(2), Some(7), Some(-9)]),
    ("threatened-city-reserve-2", [Some(-19), Some(7), Some(17)]),
    ("tier-gap-priced-once", [Some(-7), None, None]),
    ("tier-gap-reads-the-fielded-line", [Some(5), None, None]),
    ("tourism-land-reservation", [Some(-10), Some(2), Some(-3)]),
    ("tower-assault", [Some(14), None, None]),
    ("trade-building-before-bankruptcy", [Some(10), Some(-8), Some(-9)]),
    ("trade-building-before-bankruptcy-2", [Some(13), Some(9), Some(13)]),
    ("trade-growth-to-district", [Some(7), Some(-4), Some(-3)]),
    ("trade-production-to-launch", [Some(5), Some(8), Some(2)]),
    ("trade-route-network", [Some(-2), Some(10), Some(14)]),
    ("trader-fills-the-idle-route", [Some(14), None, None]),
    ("treasury-at-work-2", [Some(7), Some(-15), Some(10)]),
    ("treasury-at-work-2-2", [Some(12), Some(24), Some(9)]),
    ("unchosen-war-keeps-the-lane", [Some(2), Some(-6), Some(14)]),
    ("unique-unit-preference", [Some(0), None, None]),
    ("unit-cost-efficiency", [Some(-16), Some(12), Some(-5)]),
    ("unit-objective-memory", [Some(-1), Some(12), Some(9)]),
    ("unit-preservation", [Some(-16), None, None]),
    ("unseen-capital-is-unseen", [Some(1), None, None]),
    ("unwalled-city-spares-the-train", [Some(13), None, None]),
    ("unwalled-city-takes-the-swarm", [Some(30), None, None]),
    ("unwalled-target-declares-into-the-strike", [Some(8), None, None]),
    ("upgrade-the-garrison", [Some(1), Some(-1), Some(-4)]),
    ("upgrade-window-campaign", [Some(-3), Some(-4), Some(-9)]),
    ("upkeep-reserve", [Some(25), None, None]),
    ("urban-planning-fills-the-slot", [Some(3), None, None]),
    ("urgent-denial-needs-the-edge", [Some(-30), None, None]),
    ("veterans-withdraw-early", [Some(0), Some(-8), Some(-15)]),
    ("victory-deadline-budget", [Some(5), Some(5), Some(-11)]),
    ("victory-portfolio", [Some(-25), Some(19), Some(-32)]),
    ("wall-sortie-skips-the-encampment", [Some(1), None, None]),
    ("walls-after-districts", [Some(-12), Some(-7), Some(9)]),
    ("war-bill-prices-the-tier-gap", [Some(6), None, None]),
    ("war-economy", [Some(1), Some(-5), Some(28)]),
    ("war-kills-the-bands", [Some(-7), None, None]),
    ("war-kills-the-bands-2", [Some(4), None, None]),
    ("war-needs-a-treasury", [Some(3), Some(-8), Some(9)]),
    ("war-policy-via-board", [Some(28), Some(-11), Some(3)]),
    ("war-raids-the-pads", [Some(5), None, None]),
    ("war-reinforcement", [Some(-19), Some(-17), Some(7)]),
    ("war-target-prices-the-walls", [Some(17), None, None]),
    ("weak-target-skips-the-muster", [Some(-17), None, None]),
    ("whole-turn-backtrack-guard", [Some(11), Some(-9), Some(12)]),
    ("wide-map-capacity", [Some(21), Some(44), Some(21)]),
    ("wonder-adjacent-sites-2", [Some(-3), Some(19), Some(-2)]),
    ("wonder-ring-recon", [Some(-1), Some(-4), Some(8)]),
    ("wonder-ring-recon-2", [Some(4), Some(11), Some(9)]),
    ("wonder-score-tally", [Some(3), Some(-15), Some(-10)]),
    ("wounded-out-of-reach", [Some(-8), Some(-11), Some(-13)]),
    ("wounded-out-of-reach-2", [Some(-9), Some(-6), Some(-20)]),
    ("wounded-taker-finishes-the-breach", [Some(15), None, None]),
];

#[rustfmt::skip]
pub(super) const VERDICTS: &[GeneVerdict] = &[
    GeneVerdict { tag: "air-surge", verdict: Verdict::Helps, default_on: false, wins_last_10k: Some(44), wins_prior_10k: Some(108), win_diff_pp: Some(1.868162), posterior_pp: Some(100.730365), posterior_se_pp: Some(12.512909), family_wise: true, screen: Some(Measure { pairs: 19080, win_delta_pp: 1.748, win_z: 4.063, share_delta_pp: 0.523, share_z: 5.915, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "amenity-district-path", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(9), wins_prior_10k: Some(17), win_diff_pp: Some(0.220736), posterior_pp: Some(11.500915), posterior_se_pp: Some(8.515459), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.343, win_z: 0.778, share_delta_pp: 0.086, share_z: 0.944, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "amenity-project-preemption", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(26), wins_prior_10k: Some(-34), win_diff_pp: Some(-0.037946), posterior_pp: Some(-0.579866), posterior_se_pp: Some(12.814024), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.515, win_z: 1.347, share_delta_pp: 0.062, share_z: 0.787, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "apostle-promotion-by-role", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(12), wins_prior_10k: Some(16), win_diff_pp: Some(0.133468), posterior_pp: Some(6.102099), posterior_se_pp: Some(10.821961), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.488, win_z: 1.11, share_delta_pp: 0.009, share_z: 0.1, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "army-target-weighs-enemy", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(-1), wins_prior_10k: Some(18), win_diff_pp: Some(0.098436), posterior_pp: Some(4.708189), posterior_se_pp: Some(10.494744), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: -0.026, win_z: -0.058, share_delta_pp: -0.071, share_z: -0.77, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "barbarian-bargain", verdict: Verdict::Helps, default_on: true, wins_last_10k: Some(22), wins_prior_10k: Some(10), win_diff_pp: Some(0.322761), posterior_pp: Some(16.41034), posterior_se_pp: Some(10.942339), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.879, win_z: 2.013, share_delta_pp: 0.131, share_z: 1.474, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "barbarian-ranged-answer", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(-2), wins_prior_10k: Some(17), win_diff_pp: Some(0.194468), posterior_pp: Some(10.931114), posterior_se_pp: Some(10.506421), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: -0.095, win_z: -0.216, share_delta_pp: -0.008, share_z: -0.093, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "barbarian-scouts-are-scouts", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(1), wins_prior_10k: Some(12), win_diff_pp: Some(0.542033), posterior_pp: Some(29.535753), posterior_se_pp: Some(11.143814), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.037, win_z: 0.085, share_delta_pp: 0.131, share_z: 1.443, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "blind-objective-strength", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(-23), wins_prior_10k: Some(0), win_diff_pp: Some(0.185599), posterior_pp: Some(10.786338), posterior_se_pp: Some(10.431471), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: -0.458, win_z: -1.197, share_delta_pp: 0.042, share_z: 0.546, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "blind-objective-units", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(2), wins_prior_10k: Some(0), win_diff_pp: Some(0.009017), posterior_pp: Some(0.293538), posterior_se_pp: Some(8.178949), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.031, win_z: 0.083, share_delta_pp: -0.095, share_z: -1.209, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "bounded-recovery", verdict: Verdict::Helps, default_on: true, wins_last_10k: Some(23), wins_prior_10k: Some(29), win_diff_pp: Some(0.602307), posterior_pp: Some(31.029126), posterior_se_pp: Some(8.476105), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.904, win_z: 2.094, share_delta_pp: 0.296, share_z: 3.353, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "builder-barbarian-safety", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(13), wins_prior_10k: Some(-10), win_diff_pp: Some(0.077422), posterior_pp: Some(3.322829), posterior_se_pp: Some(10.068339), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.255, win_z: 0.67, share_delta_pp: 0.023, share_z: 0.295, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "buildings-before-projects", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(13), wins_prior_10k: Some(61), win_diff_pp: Some(0.567693), posterior_pp: Some(28.304902), posterior_se_pp: Some(11.64753), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.534, win_z: 1.214, share_delta_pp: 0.059, share_z: 0.654, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "camp-party", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(28), wins_prior_10k: Some(-15), win_diff_pp: Some(0.398999), posterior_pp: Some(22.420326), posterior_se_pp: Some(12.741517), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.566, win_z: 1.481, share_delta_pp: 0.059, share_z: 0.746, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "campus-adjacency-threshold", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(21), wins_prior_10k: Some(-18), win_diff_pp: Some(-0.007025), posterior_pp: Some(0.159571), posterior_se_pp: Some(19.440709), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.425, win_z: 1.115, share_delta_pp: 0.016, share_z: 0.208, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "come-ashore", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(-3), wins_prior_10k: Some(5), win_diff_pp: Some(0.124668), posterior_pp: Some(7.026062), posterior_se_pp: Some(8.597676), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: -0.102, win_z: -0.232, share_delta_pp: -0.035, share_z: -0.381, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "competition-victory-points", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(35), wins_prior_10k: Some(0), win_diff_pp: Some(0.309119), posterior_pp: Some(15.760591), posterior_se_pp: Some(17.698531), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.702, win_z: 1.841, share_delta_pp: 0.037, share_z: 0.463, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "coordinated-finish", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(0), wins_prior_10k: None, win_diff_pp: Some(-0.008735), posterior_pp: Some(-0.436761), posterior_se_pp: Some(19.047677), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: -0.009, win_z: -0.023, share_delta_pp: 0.074, share_z: 0.943, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "culture-building-debt", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(15), wins_prior_10k: Some(24), win_diff_pp: Some(0.486116), posterior_pp: Some(25.813208), posterior_se_pp: Some(12.82409), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.58, win_z: 1.328, share_delta_pp: 0.087, share_z: 0.957, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "district-coverage", verdict: Verdict::Helps, default_on: false, wins_last_10k: Some(14), wins_prior_10k: Some(-22), win_diff_pp: Some(0.008266), posterior_pp: Some(0.19452), posterior_se_pp: Some(10.3006), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.28, win_z: 0.736, share_delta_pp: 0.166, share_z: 2.158, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "district-planning", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(12), wins_prior_10k: None, win_diff_pp: Some(0.244584), posterior_pp: Some(12.229214), posterior_se_pp: Some(18.957561), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.245, win_z: 0.645, share_delta_pp: 0.145, share_z: 1.843, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "early-contact-window", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(17), wins_prior_10k: Some(2), win_diff_pp: Some(0.169393), posterior_pp: Some(7.701146), posterior_se_pp: Some(12.097581), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.337, win_z: 0.877, share_delta_pp: 0.091, share_z: 1.164, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "engine-faith-price", verdict: Verdict::Helps, default_on: true, wins_last_10k: Some(63), wins_prior_10k: None, win_diff_pp: Some(1.259609), posterior_pp: Some(62.980433), posterior_se_pp: Some(19.232589), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 1.26, win_z: 3.275, share_delta_pp: 0.089, share_z: 1.125, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "enhancer-for-the-corps", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(-5), wins_prior_10k: Some(8), win_diff_pp: Some(0.043714), posterior_pp: Some(2.646744), posterior_se_pp: Some(12.161783), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: -0.091, win_z: -0.239, share_delta_pp: 0.096, share_z: 1.239, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "escort-unstick", verdict: Verdict::Helps, default_on: true, wins_last_10k: Some(38), wins_prior_10k: Some(36), win_diff_pp: Some(0.665374), posterior_pp: Some(32.078711), posterior_se_pp: Some(12.520561), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.767, win_z: 2.017, share_delta_pp: 0.197, share_z: 2.463, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "founder-temple", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(11), wins_prior_10k: Some(7), win_diff_pp: Some(0.317732), posterior_pp: Some(19.361508), posterior_se_pp: Some(9.58433), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.455, win_z: 1.028, share_delta_pp: -0.108, share_z: -1.196, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "garrison-under-fire", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(31), wins_prior_10k: Some(-27), win_diff_pp: Some(0.234065), posterior_pp: Some(15.397499), posterior_se_pp: Some(16.420664), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.617, win_z: 1.615, share_delta_pp: 0.118, share_z: 1.499, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "great-person-housing", verdict: Verdict::Helps, default_on: true, wins_last_10k: Some(38), wins_prior_10k: Some(94), win_diff_pp: Some(1.583612), posterior_pp: Some(84.173107), posterior_se_pp: Some(10.509873), family_wise: true, screen: Some(Measure { pairs: 19080, win_delta_pp: 1.499, win_z: 3.464, share_delta_pp: 0.375, share_z: 4.121, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "holy-lane-parity", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(5), wins_prior_10k: Some(19), win_diff_pp: Some(0.623541), posterior_pp: Some(32.349037), posterior_se_pp: Some(19.66726), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.185, win_z: 0.421, share_delta_pp: -0.184, share_z: -1.997, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "holy-site-where-the-threat-is", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(19), wins_prior_10k: Some(-19), win_diff_pp: Some(-0.031224), posterior_pp: Some(-1.100691), posterior_se_pp: Some(19.032158), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.391, win_z: 1.034, share_delta_pp: -0.088, share_z: -1.141, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "housing-research", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(-5), wins_prior_10k: Some(-17), win_diff_pp: Some(-0.009393), posterior_pp: Some(0.465459), posterior_se_pp: Some(11.264612), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: -0.107, win_z: -0.282, share_delta_pp: -0.004, share_z: -0.048, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "idle-faith-patronage", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(-1), wins_prior_10k: Some(39), win_diff_pp: Some(0.505304), posterior_pp: Some(25.778142), posterior_se_pp: Some(7.31643), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: -0.056, win_z: -0.127, share_delta_pp: 0.148, share_z: 1.622, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "lane-culture-spending", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(9), wins_prior_10k: Some(8), win_diff_pp: Some(0.172513), posterior_pp: Some(8.564803), posterior_se_pp: Some(12.159394), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.187, win_z: 0.486, share_delta_pp: -0.01, share_z: -0.13, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "lane-great-people", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(33), wins_prior_10k: Some(-3), win_diff_pp: Some(0.262286), posterior_pp: Some(13.24308), posterior_se_pp: Some(17.90329), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.66, win_z: 1.717, share_delta_pp: 0.1, share_z: 1.261, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "lane-policy-deck", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(29), wins_prior_10k: Some(0), win_diff_pp: Some(0.264627), posterior_pp: Some(12.799771), posterior_se_pp: Some(14.670107), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.592, win_z: 1.554, share_delta_pp: 0.083, share_z: 1.067, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "lane-space-race", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(-12), wins_prior_10k: Some(11), win_diff_pp: Some(0.010148), posterior_pp: Some(1.30902), posterior_se_pp: Some(12.141457), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: -0.239, win_z: -0.632, share_delta_pp: -0.104, share_z: -1.317, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "loyalty-rate-alarm", verdict: Verdict::Helps, default_on: false, wins_last_10k: Some(5), wins_prior_10k: Some(38), win_diff_pp: Some(0.752269), posterior_pp: Some(39.929305), posterior_se_pp: Some(9.323774), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.207, win_z: 0.473, share_delta_pp: 0.188, share_z: 2.083, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "maintenance-aware-deck", verdict: Verdict::Helps, default_on: true, wins_last_10k: Some(61), wins_prior_10k: None, win_diff_pp: Some(1.229909), posterior_pp: Some(61.49546), posterior_se_pp: Some(19.045342), family_wise: true, screen: Some(Measure { pairs: 19080, win_delta_pp: 1.23, win_z: 3.229, share_delta_pp: 0.341, share_z: 4.381, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "naval-recon", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(17), wins_prior_10k: Some(-20), win_diff_pp: Some(-0.045836), posterior_pp: Some(-3.061334), posterior_se_pp: Some(8.280916), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.353, win_z: 0.917, share_delta_pp: 0.066, share_z: 0.83, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "one-launch-pad", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(19), wins_prior_10k: Some(-11), win_diff_pp: Some(0.235943), posterior_pp: Some(11.406528), posterior_se_pp: Some(8.259198), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.374, win_z: 0.97, share_delta_pp: 0.031, share_z: 0.395, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "one-shot-recovery", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(8), wins_prior_10k: Some(-8), win_diff_pp: Some(-0.022638), posterior_pp: Some(-1.894908), posterior_se_pp: Some(12.019236), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.159, win_z: 0.418, share_delta_pp: 0.053, share_z: 0.671, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "opportunistic-war", verdict: Verdict::Helps, default_on: false, wins_last_10k: Some(39), wins_prior_10k: Some(49), win_diff_pp: Some(0.904992), posterior_pp: Some(48.055552), posterior_se_pp: Some(14.27792), family_wise: true, screen: Some(Measure { pairs: 19080, win_delta_pp: 1.531, win_z: 3.564, share_delta_pp: 0.482, share_z: 5.452, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "pantheon-board", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(5), wins_prior_10k: None, win_diff_pp: Some(0.106576), posterior_pp: Some(5.328802), posterior_se_pp: Some(19.058715), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.107, win_z: 0.28, share_delta_pp: 0.013, share_z: 0.169, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "peacetime-deterrence", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(16), wins_prior_10k: Some(21), win_diff_pp: Some(0.349649), posterior_pp: Some(18.012148), posterior_se_pp: Some(8.565639), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.617, win_z: 1.413, share_delta_pp: 0.039, share_z: 0.427, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "power-the-laboratory", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(14), wins_prior_10k: Some(-8), win_diff_pp: Some(0.035908), posterior_pp: Some(0.603865), posterior_se_pp: Some(11.964935), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.29, win_z: 0.762, share_delta_pp: 0.054, share_z: 0.695, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "price-the-suzerainty", verdict: Verdict::Helps, default_on: true, wins_last_10k: Some(55), wins_prior_10k: None, win_diff_pp: Some(1.11297), posterior_pp: Some(55.648484), posterior_se_pp: Some(19.144988), family_wise: true, screen: Some(Measure { pairs: 19080, win_delta_pp: 1.113, win_z: 2.907, share_delta_pp: 0.337, share_z: 4.293, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "promote-when-wounded", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(7), wins_prior_10k: None, win_diff_pp: Some(0.143269), posterior_pp: Some(7.163433), posterior_se_pp: Some(19.219865), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.143, win_z: 0.373, share_delta_pp: 0.025, share_z: 0.317, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "raid-pillage-prizes", verdict: Verdict::Helps, default_on: true, wins_last_10k: Some(43), wins_prior_10k: Some(53), win_diff_pp: Some(1.016339), posterior_pp: Some(53.890257), posterior_se_pp: Some(14.608934), family_wise: true, screen: Some(Measure { pairs: 19080, win_delta_pp: 1.698, win_z: 3.94, share_delta_pp: 0.407, share_z: 4.569, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "recon-replacement", verdict: Verdict::Helps, default_on: false, wins_last_10k: Some(36), wins_prior_10k: Some(30), win_diff_pp: Some(0.956553), posterior_pp: Some(50.640837), posterior_se_pp: Some(10.654421), family_wise: true, screen: Some(Measure { pairs: 19080, win_delta_pp: 1.454, win_z: 3.362, share_delta_pp: 0.418, share_z: 4.632, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "recorded-tactical-step", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(11), wins_prior_10k: Some(18), win_diff_pp: Some(0.321794), posterior_pp: Some(16.717609), posterior_se_pp: Some(8.50066), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.444, win_z: 1.021, share_delta_pp: 0.084, share_z: 0.936, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "relief-targets-the-siege", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(18), wins_prior_10k: Some(6), win_diff_pp: Some(0.191188), posterior_pp: Some(9.598962), posterior_se_pp: Some(8.511735), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.71, win_z: 1.628, share_delta_pp: 0.013, share_z: 0.138, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "religion-sues-peace", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(5), wins_prior_10k: Some(-18), win_diff_pp: Some(0.120977), posterior_pp: Some(6.548389), posterior_se_pp: Some(8.778382), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.091, win_z: 0.238, share_delta_pp: -0.006, share_z: -0.074, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "religious-defence-scales", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(12), wins_prior_10k: Some(-8), win_diff_pp: Some(0.01249), posterior_pp: Some(-0.269738), posterior_se_pp: Some(12.17978), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.238, win_z: 0.619, share_delta_pp: -0.063, share_z: -0.802, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "religious-units-heal-first", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(5), wins_prior_10k: Some(12), win_diff_pp: Some(0.177982), posterior_pp: Some(9.256103), posterior_se_pp: Some(11.985282), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.105, win_z: 0.274, share_delta_pp: 0.009, share_z: 0.109, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "research-tier-premium", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(29), wins_prior_10k: Some(-6), win_diff_pp: Some(0.191249), posterior_pp: Some(9.651653), posterior_se_pp: Some(17.243946), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.575, win_z: 1.503, share_delta_pp: 0.079, share_z: 1.01, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "science-multiplier-payoff", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(23), wins_prior_10k: Some(-8), win_diff_pp: Some(0.120995), posterior_pp: Some(5.644704), posterior_se_pp: Some(15.161652), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.459, win_z: 1.206, share_delta_pp: 0.076, share_z: 0.964, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "settle-sooner", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(19), wins_prior_10k: Some(28), win_diff_pp: Some(0.654906), posterior_pp: Some(34.563276), posterior_se_pp: Some(10.399355), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.764, win_z: 1.748, share_delta_pp: 0.123, share_z: 1.352, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "settlement-gap-target", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(14), wins_prior_10k: None, win_diff_pp: Some(0.286513), posterior_pp: Some(14.32565), posterior_se_pp: Some(18.969806), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.287, win_z: 0.755, share_delta_pp: 0.055, share_z: 0.707, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "settler-guard-holds", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(25), wins_prior_10k: Some(-8), win_diff_pp: Some(0.080401), posterior_pp: Some(3.289281), posterior_se_pp: Some(8.232809), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.489, win_z: 1.285, share_delta_pp: 0.061, share_z: 0.783, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "settler-target-hysteresis", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(17), wins_prior_10k: Some(-18), win_diff_pp: Some(0.011271), posterior_pp: Some(0.142789), posterior_se_pp: Some(8.235122), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.335, win_z: 0.873, share_delta_pp: 0.12, share_z: 1.532, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "settler-threat-detour", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(1), wins_prior_10k: Some(18), win_diff_pp: Some(0.450991), posterior_pp: Some(24.316588), posterior_se_pp: Some(13.516949), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.021, win_z: 0.047, share_delta_pp: 0.044, share_z: 0.493, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "siege-commitment", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(9), wins_prior_10k: Some(6), win_diff_pp: Some(-0.039073), posterior_pp: Some(-2.000626), posterior_se_pp: Some(8.322987), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.185, win_z: 0.485, share_delta_pp: -0.036, share_z: -0.457, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "slot-kind-tiebreak", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(25), wins_prior_10k: Some(-1), win_diff_pp: Some(0.203632), posterior_pp: Some(9.448489), posterior_se_pp: Some(8.258141), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.507, win_z: 1.329, share_delta_pp: 0.12, share_z: 1.526, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "stranded-settler-discount", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(33), wins_prior_10k: Some(-8), win_diff_pp: Some(0.234064), posterior_pp: Some(11.031107), posterior_se_pp: Some(8.29178), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.659, win_z: 1.743, share_delta_pp: 0.007, share_z: 0.085, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "strategic-wonders", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(0), wins_prior_10k: Some(11), win_diff_pp: Some(0.172073), posterior_pp: Some(8.794727), posterior_se_pp: Some(8.277293), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: -0.007, win_z: -0.018, share_delta_pp: -0.044, share_z: -0.559, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "strike-opening", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(1), wins_prior_10k: Some(4), win_diff_pp: Some(0.229561), posterior_pp: Some(12.164275), posterior_se_pp: Some(8.437152), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.051, win_z: 0.116, share_delta_pp: 0.107, share_z: 1.162, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "unit-cost-efficiency", verdict: Verdict::Helps, default_on: true, wins_last_10k: Some(17), wins_prior_10k: None, win_diff_pp: Some(0.347661), posterior_pp: Some(17.383064), posterior_se_pp: Some(19.225877), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.348, win_z: 0.904, share_delta_pp: 0.177, share_z: 2.235, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "unit-objective-memory", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(10), wins_prior_10k: None, win_diff_pp: Some(0.197428), posterior_pp: Some(9.871423), posterior_se_pp: Some(19.11049), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.197, win_z: 0.517, share_delta_pp: 0.138, share_z: 1.788, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "war-economy", verdict: Verdict::Helps, default_on: true, wins_last_10k: Some(46), wins_prior_10k: Some(118), win_diff_pp: Some(0.527307), posterior_pp: Some(13.370014), posterior_se_pp: Some(51.998198), family_wise: true, screen: Some(Measure { pairs: 19080, win_delta_pp: 1.872, win_z: 4.325, share_delta_pp: 1.141, share_z: 12.467, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "war-reinforcement", verdict: Verdict::Unresolved, default_on: false, wins_last_10k: Some(0), wins_prior_10k: Some(34), win_diff_pp: Some(0.326817), posterior_pp: Some(16.756373), posterior_se_pp: Some(10.360862), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: 0.005, win_z: 0.011, share_delta_pp: -0.048, share_z: -0.536, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "whole-turn-backtrack-guard", verdict: Verdict::Unresolved, default_on: true, wins_last_10k: Some(-14), wins_prior_10k: Some(6), win_diff_pp: Some(0.20946), posterior_pp: Some(11.765564), posterior_se_pp: Some(9.909905), family_wise: false, screen: Some(Measure { pairs: 19080, win_delta_pp: -0.563, win_z: -1.269, share_delta_pp: -0.124, share_z: -1.37, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
    GeneVerdict { tag: "wide-map-capacity", verdict: Verdict::Helps, default_on: true, wins_last_10k: Some(55), wins_prior_10k: Some(91), win_diff_pp: Some(1.198264), posterior_pp: Some(60.530019), posterior_se_pp: Some(16.598622), family_wise: true, screen: Some(Measure { pairs: 19080, win_delta_pp: 2.223, win_z: 5.21, share_delta_pp: 0.577, share_z: 6.468, source: "2026-08-24-standard-continuous-38160-total-seats.json" }) },
];
// ═══ END GENERATED ═══
