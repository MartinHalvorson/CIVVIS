from pathlib import Path
import argparse,copy,hashlib,json,shutil,subprocess,sys
repo=Path.home()/'civvis-main-managed';sys.path.insert(0,str(repo/'tools'))
import civ6_captured_read_replay as replay
from civ6_decision_trace import exact_fact
from civ6_ladder import decider_genome
from native_city_route_replay import control_payload,request_identity_errors
ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);args=ap.parse_args();root=args.root.resolve();report=json.loads((root/'captured-prefix/results.json').read_text());gene=report['intent']['tag'];binary=root/'candidate-ci-orders';sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(binary.read_bytes())==report['candidate_sha256']
allrecords=[json.loads(l) for l in (root/'native-decisions.jsonl').open()];length=len(report['treatments'][0]['requests']);assert report['treatments'][0]['failed_request']==report['treatments'][1]['failed_request'];records=allrecords[:length];context=json.loads((root/'observed-context.json').read_text());mapping={r['source']:Path(r['sealed_directory']) for r in json.loads((root/'sealed-captures.json').read_text())};expected_on=[json.loads(l) for l in (root/'captured-prefix/on-0/replies.jsonl').open()];assert len(expected_on)==length
out=root/'successful-prefix-pairs';out.mkdir(exist_ok=False);common=out/'capture-current';assert not common.exists();runs={}
for arm,on in [('off',False),('on',True)]:
 for repeat in range(2):
  d=out/f'{arm}-{repeat}';d.mkdir();a=list(context['processes'][0]['argv']);a[0]=str(binary);a[a.index('--mirror')+1]=str(d);a[a.index('--capture-inputs')+1]=str(common)
  if on:a+=['--with',gene]
  received=[];delivered=[];capture_dirs=set();feeder=None
  with (d/'stderr.log').open('w') as stderr,(d/'replies.jsonl').open('w') as replies:
   p=subprocess.Popen(a,cwd=context['processes'][0]['cwd'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,text=True,bufsize=1)
   try:
    for i,record in enumerate(records):
     source=dict(record['input_capture'],directory=str(mapping[record['input_capture']['directory']]));expected=replay.expanded_reads(source);path=d/'events.jsonl'
     if path.exists():path.unlink()
     feeder=replay.deliver_reads(path,expected,60,'hybrid');key=(record['decision']['turn'],record['decision']['frame']);p.stdin.write(str(key[0])+'\n');p.stdin.flush();reply=replay.request_reply(p,60);feeder.finish();feeder=None
     assert not request_identity_errors(reply,*key);actual=replay.expanded_reads(reply['input_capture']);assert actual==expected
     assert exact_fact(control_payload(expected_on[i] if on else record),control_payload(reply));replies.write(json.dumps(reply,sort_keys=True)+'\n');replies.flush();received.append(reply);capture_dirs.add(reply['input_capture']['directory']);delivered.append({'request':key,'reads':[{'sha256':sha(b),'bytes':len(b)} for b in expected]})
    p.stdin.close();code=p.wait(timeout=10);assert code==0
   finally:
    if feeder is not None:feeder.close()
    if p.poll() is None:p.terminate();p.wait(timeout=5)
    if p.stdout:p.stdout.close()
  g=decider_genome(d/'stderr.log');assert g
  # The argument is genuinely identical for both arms. Relocate the closed
  # capture for archival storage; retain every raw path and this scope map.
  capture_map={old:str((d/'recaptured')/Path(old).relative_to(common)) for old in capture_dirs};shutil.move(str(common),str(d/'recaptured'));assert not common.exists()
  receipt={'arm':arm,'argv':a,'cwd':context['processes'][0]['cwd'],'exit':code,'genome':g,'delivered':delivered,'capture_directory_map':capture_map,'payload':received[-1],'scope':'Successful persistent same-prefix query. Every actual captured read byte/count/order and every full reply matched the corresponding captured OFF/ON control. Capture storage moved only after successful EOF exit.'};(d/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');runs[(arm,repeat)]=receipt;print(json.dumps({'arm':arm,'repeat':repeat,'requests':length,'exit':code}),flush=True)
for repeat in range(2):
 off,on=runs[('off',repeat)],runs[('on',repeat)];assert off['delivered']==on['delivered'] and off['payload']['orders']!=on['payload']['orders'];last=records[-1];capture=dict(last['input_capture'],directory=str(mapping[last['input_capture']['directory']]));blobs=replay.expanded_reads(capture);unique=[]
 for blob in blobs:
  if sha(blob) not in [r['sha256'] for r in unique]:unique.append({'complete':True,'sha256':sha(blob),'bytes':len(blob),'arms':[{k:off[k] for k in ['arm','argv','exit','genome','payload']},{k:on[k] for k in ['arm','argv','exit','genome','payload']}]})
 pair={'complete':True,'scope':'Persistent paired captured-input queries, not independent fresh-board queries. Both consumed the identical qualified prefix. Reads list the captured byte versions in the final request; their order/count and complete preceding history are bound by raw receipts and captures. No continued divergent world or strength inference.','prefix_requests':length,'through_request':off['delivered'][-1]['request'],'reads':unique};(out/f'pair-{repeat}.json').write_text(json.dumps(pair,indent=2)+'\n')
print(json.dumps({'passed':True,'first_order_difference':report['treatments'][0]['failed_request'],'prefix_requests':length,'successful_pair_repeats':2}),flush=True)
