from pathlib import Path
import copy,hashlib,json,subprocess,sys
root=Path(sys.argv[1]).resolve();repo=Path.home()/'civvis-main-managed';sys.path.insert(0,str(repo/'tools'))
from civ6_decision_trace import captured_input,exact_fact
from civ6_ladder import decider_genome
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text());lines=lambda p:[json.loads(l) for l in p.open()];control=lambda r:{k:r[k] for k in ['orders','decision'] if k in r}
report=read(root/'captured-prefix/results.json');intent=report['intent'];extra=read(root/'intent.json');assert all(extra[k]==v for k,v in intent.items());regressions=extra.get('regression_files_sha256',{});gene=intent['tag'];source=lines(root/'native-decisions.jsonl');assert len(source)==425
seals=read(root/'sealed-captures.json');oldroot=Path(seals[0]['sealed_directory']).parent
mapping={s['source']:root/Path(s['sealed_directory']).name for s in seals}
def relocated(p):
 p=Path(p)
 return root/p.relative_to(oldroot) if p.is_relative_to(oldroot) else p
for s in seals:
 d=mapping[s['source']];assert sha((d/'bytes.bin').read_bytes())==s['archive_sha256'] and sha((d/'snapshots.jsonl').read_bytes())==s['index_sha256']
for name,digest in (intent['production_files_sha256']|regressions).items():
 raw=subprocess.check_output(['git','show',intent['source_commit']+':'+name],cwd=repo);assert sha(raw)==digest
 (root/'source-files'/name).parent.mkdir(parents=True,exist_ok=True);(root/'source-files'/name).write_bytes(raw)
context=read(root/'observed-context.json')
for r in source:
 unsigned={k:v for k,v in r.items() if k!='sha256'};assert sha(json.dumps(unsigned,sort_keys=True,separators=(',',':'),allow_nan=False).encode())==r['sha256'];assert r['binary']==context['processes'][0]['argv'][0] and r['binary_on_disk_sha256']==context['binary_sha256']
def expanded(capture,scoped=None):
 c=copy.deepcopy(capture);assert c['complete'] and c['reads'];p=c['directory'];c['directory']=str(mapping[p] if p in mapping else relocated((scoped or {}).get(p,p)));result=[]
 for r in c['reads']:result.extend([captured_input(c,r['snapshot_id'])]*r['count'])
 return result
expected=[expanded(r['input_capture']) for r in source];prefixes={};genomes={}
for arm in ['off','on']:
 for n in range(2):
  d=root/f'captured-prefix/{arm}-{n}';replies=lines(d/'replies.jsonl');genomes[(arm,n)]=decider_genome(d/'stderr.log');prefixes[(arm,n)]=replies
  assert len(replies)==(425 if arm=='off' else len(report['treatments'][n]['requests']))
  for i,r in enumerate(replies):
   native=source[i];assert r['turn']==native['decision']['turn'] and r['decision']['frame']==native['decision']['frame'];assert expanded(r['input_capture'])==expected[i]
   if arm=='off':assert exact_fact(control(r),control(native))
first=[]
for n in range(2):
 replies=prefixes[('on',n)];changed=[i for i,r in enumerate(replies) if r['orders']!=source[i]['orders']];assert changed==[len(replies)-1];first.append(changed[0]);assert exact_fact([control(r) for r in replies],[control(r) for r in prefixes[('on',0)]])
assert first[0]==first[1];last=first[0];length=last+1
for arm in ['off','on']:
 for n in range(2):
  d=root/f'successful-prefix-pairs/{arm}-{n}';receipt=read(d/'receipt.json');assert receipt['exit']==0;replies=lines(d/'replies.jsonl');assert len(replies)==length;assert exact_fact([control(r) for r in replies],[control(r) for r in prefixes[(arm,0)][:length]])
  assert receipt['genome']==decider_genome(d/'stderr.log')==genomes[(arm,n)]
  assert receipt['cwd']==context['processes'][0]['cwd'];assert receipt['payload']==replies[-1]
  for i,r in enumerate(replies):assert expanded(r['input_capture'],receipt['capture_directory_map'])==expected[i]
for n in range(2):
 off=read(root/f'successful-prefix-pairs/off-{n}/receipt.json');on=read(root/f'successful-prefix-pairs/on-{n}/receipt.json');a=list(off['argv']);b=list(on['argv']);a[a.index('--mirror')+1]=b[b.index('--mirror')+1]='<same-input>';i=b.index(gene);assert b[i-1]=='--with';del b[i-1:i+1];assert a==b
 x,y=copy.deepcopy(off['genome']),copy.deepcopy(on['genome'])
 for field in ['treatments','forced']:
  left,right=x.pop(field),y.pop(field);assert len(left)==len(set(left)) and len(right)==len(set(right));assert gene not in left and set(right)==set(left)|{gene}
 assert x==y
 pair=read(root/f'successful-prefix-pairs/pair-{n}.json');assert pair['complete'];assert pair['through_request']==[source[last]['decision']['turn'],source[last]['decision']['frame']]
 wanted={sha(b):len(b) for b in expected[last]};assert {r['sha256']:r['bytes'] for r in pair['reads']}==wanted
 for readrow in pair['reads']:
  assert readrow['complete'];arms={a['arm']:a for a in readrow['arms']}
  for arm,receipt in [('off',off),('on',on)]:
   for key in ['argv','exit','genome','payload']:assert arms[arm][key]==receipt[key]
first_intent=next(i for i,r in enumerate(prefixes[('on',0)]) if not exact_fact(r['decision'],source[i]['decision']))
native=source[last]['orders'];changed=prefixes[('on',0)][-1]['orders']
def production(orders):
 rows=[o for o in orders if o['kind']=='produce'];assert len({o['subject'] for o in rows})==len(rows)
 return {o['subject']:o['verb'] for o in rows}
before,after=production(native),production(changed)
replacements=[{'city':cid,'off':value,'on':after[cid]} for cid,value in before.items() if cid in after and after[cid]!=value]
assert any(r['off']=='UNIT_HEAVY_CHARIOT' and r['on']=='UNIT_SPEARMAN' for r in replacements),replacements
assert before!=after
assert replacements==[{'city':65536,'off':'UNIT_HEAVY_CHARIOT','on':'UNIT_SPEARMAN'}]
other=lambda orders:[o for o in orders if not (o['kind']=='produce' and o['subject']==65536)]
assert other(native)==other(changed)
binary=root/'candidate-ci-orders'
if binary.exists():assert sha(binary.read_bytes())==report['candidate_sha256']
proof={'protocol_verified':True,'regression_source_verified':bool(regressions),'intended_defender_order_verified':True,'source_commit':intent['source_commit'],'candidate_sha256':report['candidate_sha256'],'native_off_controls':{'repetitions':2,'requests_each':425,'through':[172,1]},'first_internal_decision_difference':[source[first_intent]['decision']['turn'],source[first_intent]['decision']['frame']],'first_final_order_difference':[source[last]['decision']['turn'],source[last]['decision']['frame']],'on_prefix_requests_each':length,'successful_paired_query_repetitions':2,'actual_read_sequences_reconstructed':True,'per_city_production_replacements':replacements,'other_order_sequence_unchanged':True,'removed_orders':[o for o in native if o not in changed],'added_orders':[o for o in changed if o not in native],'scope':'Intended captured-history per-city defender proposal change only. No native execution/completion, continued divergent world, saved city or strength claim.'}
(root/'independent-verification.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
