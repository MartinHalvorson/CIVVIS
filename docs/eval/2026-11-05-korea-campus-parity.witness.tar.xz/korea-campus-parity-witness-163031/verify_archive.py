from pathlib import Path
import json,hashlib,sys,copy,datetime
r=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'helpers'))
from civ6_decision_trace import captured_input,validate_input_capture
from civ6_ladder import decider_genome
def expanded_reads(capture):
 validate_input_capture(capture)
 assert capture['complete'] and capture['reads']
 return [captured_input(capture,e['snapshot_id']) for e in capture['reads'] for _ in range(e['count'])]
manifest=json.loads((r/'manifest.json').read_text())
for name,digest in manifest['files'].items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==digest,name
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();p=read(r/'protocol.json');data=(r/'events.jsonl').read_bytes();assert sha(data)==p['input_sha256'];assert read(r/'source-native-build.json')['provenance']['sha256']==p['binary_sha256'];record=read(r/'original-record.json');unsigned={k:v for k,v in record.items() if k!='sha256'};assert sha(json.dumps(unsigned,sort_keys=True,separators=(',',':'),allow_nan=False).encode())==record['sha256']==p['source_record_sha256'];capture=copy.deepcopy(record['input_capture']);capture['directory']=str(r/'original-sealed-inputs/source-capture-0');original_reads=expanded_reads(capture);assert original_reads and all(x==data for x in original_reads)
states=[json.loads(l) for l in data.splitlines() if json.loads(l).get('kind')=='state'];e=states[-1];assert e['turn']==61;city=next(c for c in e['cities'] if c['id']==131073);quote=next(q for q in city['buildable'] if q['t']=='DISTRICT_SEOWON');legal={(s['x'],s['y']) for s in quote['s']};assert legal;assert (r/'02-off/stdout.json').read_bytes()==b'';assert 'cannot be both --with and --without' in (r/'02-off/stderr.log').read_text();assert read(r/'failure.json')['error']=="AssertionError(('02-off', 2))";amend=read(r/'cli-correction-amendment.json');assert amend['remaining_execution_order']==['02-off-cli-corrected','03-on','04-off'];roles=['01-on']+amend['remaining_execution_order'];g0=read(r/'source-genome.json');references={};rows=[]
for role in roles:
 out=r/role;payload=read(out/'stdout.json');g=decider_genome(out/'stderr.log');argv=read(out/'command.json')['argv'];assert Path(argv[0]).name=='probe-binary';assert (payload['decision']['turn'],payload['decision']['frame'])==(61,0);assert payload['decision']['victory_portfolio']['assigned_target']=='science';recapture=copy.deepcopy(payload['input_capture']);recapture['directory']=str(out/'capture');reads=expanded_reads(recapture);assert reads and all(x==data for x in reads);arm=role.split('-')[1];expected=copy.deepcopy(g0)
 if arm=='off':
  for field in ['treatments','forced']:expected[field].remove(p['flag'])
 assert expected==g;target=[o for o in payload['orders'] if o.get('kind')=='produce' and o.get('subject')==131073];assert len(target)==1
 if arm=='on':assert target[0]['verb']=='UNIT_WARRIOR'
 else:assert target[0]['verb']=='DISTRICT_SEOWON' and (target[0]['x'],target[0]['y']) in legal
 stable={k:payload[k] for k in ['orders','decision']}
 if arm in references:assert stable==references[arm]
 else:references[arm]=stable
 rows.append({'role':role,'actual_reads_verified':len(reads),'target_order':target[0],'genome_sha256':sha(json.dumps(g,sort_keys=True).encode()),'stdout_sha256':sha((out/'stdout.json').read_bytes()),'stderr_sha256':sha((out/'stderr.log').read_bytes())})
report={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'amended_four_successful_roles_verified':True,'original_failed_off_cli_retained':True,'original_fixed_reads_verified':len(original_reads),'actual_proposal_reads_verified':sum(x['actual_reads_verified'] for x in rows),'native_quoted_seowon':quote,'roles':rows,'scope':'Same frozen native bytes, exact observed source/executable, one named bit omitted from forced/treatments only, native-legal Seowon vs Warrior, repeated full replies and all actual reads verified. Original four-role attempt failed before OFF decision; corrected execution is separately amended. No original private-state parity, native execution, timing saved or strength claim.'};(r/'portable-verification-result.json').write_text(json.dumps(report,indent=2)+'\n');print({k:report[k] for k in ['amended_four_successful_roles_verified','original_failed_off_cli_retained','original_fixed_reads_verified','actual_proposal_reads_verified','native_quoted_seowon']})
