"""Disposable captured-board comparisons; no live host commands or flags."""
from pathlib import Path
import argparse,datetime,hashlib,json,subprocess,sys,shutil
repo=Path('/Users/martbot-mbp-m5-max-128/civvis-anvil-follows-the-defense-e936');sys.path.insert(0,str(repo/'tools'))
from civ6_decision_trace import captured_input
from civ6_ladder import decider_genome
from civ6_captured_read_replay import exact_fact,control_payload
sha=lambda raw:hashlib.sha256(raw).hexdigest()
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--candidate',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);args=ap.parse_args();out=args.out.resolve();out.mkdir(exist_ok=False)
root=Path(__file__).parent;candidate=args.candidate.resolve();tag='anvil-follows-the-defense';runs=Path.home()/'civvis-civ6-runs/control'
selected=[('civvis-20261103T034543Z',39),('civvis-20261103T034543Z',40),('civvis-20261103T040708Z',26),('civvis-20261103T025902Z',29)]
report={'intent':{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_sha256':sha(candidate.read_bytes()),'selected':selected,'scope':'Fresh-board proposals; no persistent replay qualification, execution or strength claim. Actual captured input and profile, before/OFF and repeated OFF/ON full-payload controls.'},'cases':[]}
for name,turn in selected:
 run=runs/name;genome=decider_genome(run/'why.log');profile=sorted(genome['forced']);assert tag not in genome['treatments'];summary=json.loads((run/'summary.json').read_text());seat=summary['seat'];target=summary['victory_target'];context=json.loads((root/'contexts'/name/'observed-context.json').read_text());actual_argv=context['processes'][0]['argv'];assert actual_argv[actual_argv.index('--victory')+1]==target and actual_argv[actual_argv.index('--civ')+1]==seat['civ']
 record=next(json.loads(line) for line in (run/'decisions.jsonl').open() if (json.loads(line)['decision']['turn'],json.loads(line)['decision']['frame'])==(turn,0));cap=record['input_capture'];assert cap['complete'];before=Path(record['binary']);assert sha(before.read_bytes())==record['binary_on_disk_sha256']=='4f269c7368c7aea82b589d09fef2b448b98b161d2ee166d055cf2c1bde50702a'
 frozen=root/'frozen-before-orders'
 if not frozen.exists():shutil.copy2(before,frozen)
 assert sha(frozen.read_bytes())==record['binary_on_disk_sha256'];before=frozen
 selected_read=None
 for read in cap['reads']:
  raw=captured_input(cap,read['snapshot_id']);states=[json.loads(line) for line in raw.splitlines() if json.loads(line).get('kind')=='state']
  if states and (states[-1]['turn'],states[-1].get('frame',0))==(turn,0):selected_read=(raw,read['snapshot_id']);break
 assert selected_read
 raw,snapshot=selected_read;directory=out/f'{name}-{turn}';directory.mkdir();(directory/'captured-events.jsonl').write_bytes(raw);(directory/'source-record.json').write_text(json.dumps(record,indent=2)+'\n')
 case={'run':name,'turn':turn,'source_decision_sha256':record['sha256'],'source_binary_sha256':record['binary_on_disk_sha256'],'snapshot':snapshot,'complete':False,'reads':[{'complete':True,'sha256':sha(raw),'bytes':len(raw),'arms':[]}],'controls':[]};report['cases'].append(case);arms={}
 for label in ['before-off','candidate-off','candidate-on','candidate-on-repeat','candidate-off-repeat']:
  binary=before if label=='before-off' else candidate;on=label in ['candidate-on','candidate-on-repeat'];d=directory/label;d.mkdir();(d/'events.jsonl').write_bytes(raw)
  argv=[str(binary),'--mirror',str(d),'--turn',str(turn),'--victory',target,'--civ',seat['civ'],'--fresh-board','--explain']
  for flag in sorted(profile+([tag] if on else [])):argv+=['--with',flag]
  p=subprocess.run(argv,cwd=repo,capture_output=True,timeout=60);(d/'stdout').write_bytes(p.stdout);(d/'stderr').write_bytes(p.stderr);realized=decider_genome(d/'stderr');a={'label':label,'argv':argv,'exit':p.returncode,'genome':realized};case['controls'].append(a);(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
  assert p.returncode==0 and realized and sorted(realized['treatments'])==sorted(genome['treatments']+([tag] if on else [])) and sorted(realized['forced'])==sorted(profile+([tag] if on else []))
  a['payload']=json.loads(p.stdout);arms[label]=a;(d/'events.jsonl').unlink()
 for left,right in [('before-off','candidate-off'),('candidate-off','candidate-off-repeat'),('candidate-on','candidate-on-repeat')]:assert exact_fact(control_payload(arms[left]['payload']),control_payload(arms[right]['payload'])),(name,turn,left,right,'full payload differs')
 for arm,label in [('off','candidate-off'),('on','candidate-on')]:case['reads'][0]['arms'].append({'arm':arm,**{k:v for k,v in arms[label].items() if k!='label'}})
 old=arms['candidate-off']['payload']['orders'];new=arms['candidate-on']['payload']['orders'];case['changed']=old!=new;case['removed_orders']=[o for o in old if o not in new];case['added_orders']=[o for o in new if o not in old];case['complete']=True
 (directory/'result.json').write_text(json.dumps(case,indent=2)+'\n');(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'run':name,'turn':turn,'changed':case['changed'],'removed':len(case['removed_orders']),'added':len(case['added_orders'])}),flush=True)
assert any(c['changed'] for c in report['cases']),'No demonstrated proposal activation; withhold the candidate.'
