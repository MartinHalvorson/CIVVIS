"""Seal completed development evidence; refuse an unfinished Rust validation."""
from pathlib import Path
import datetime
import hashlib
import io
import json
import re
import shutil
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/martbot-mbp-m5-max-128/civvis-anvil-follows-the-defense-e936')
sha = lambda data: hashlib.sha256(data).hexdigest()
tests = json.loads((root / 'full-rust-02-tests.json').read_text())
assert tests['exit'] == 0
candidate = json.loads((root / 'candidate-02-binary.json').read_text())
assert tests['head'] == candidate['source_commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == candidate['source_commit']
assert all(sha((repo / path).read_bytes()) == digest for path, digest in candidate['source_sha256'].items())
assert sha((root / 'frozen-candidate-02-ci-orders').read_bytes()) == candidate['binary_sha256']
log = (root / 'full-rust-02-tests.log').read_text()
summaries = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
assert summaries and all(int(failed) == 0 for _, failed, _ in summaries)
focused = re.findall(r'^test ai::advanced::anvil_assignment::tests::\S+ \.\.\. ok$', log, re.M)
assert len(focused) == 9
subprocess.run(['python3', str(root / 'verify.py')], check=True, stdout=subprocess.DEVNULL)

out = root / 'evidence-02'
out.mkdir(exist_ok=False)
def copy_file(source, relative):
    target = out / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)

directories = ['helpers', 'contexts', 'census-inputs', 'queries-01', 'queries-02',
               'native-qualified-01', 'native-qualified-khmer-01', 'native-qualified-korea-01',
               'prefix-comparisons-01', 'prefix-comparisons-02']
for name in directories:
    for path in (root / name).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:
            copy_file(path, Path(name) / path.relative_to(root / name))

names = [
    'verify.py', 'verify-executed-01.py', 'package.py', 'query.py', 'query-executed-01.py',
    'compare-prefix.py', 'compare-prefix-02.py', 'validate-candidate.py', 'validate-candidate-02.py',
    'candidate-binary.json', 'candidate-02-binary.json', 'original-test-binary.json',
    'original-scaffold-commit.json', 'original-scaffold.patch', 'scaffold.patch',
    'anvil-census-frozen.py', 'anvil-census-frozen.json', 'census-inputs-manifest.json',
    'design.md',
    'selected-contexts.json', 'old-binary-flag.json', 'old-binary-flag.stderr',
    'old-binary-flag.stdout', 'scope-refinement-trace-correction.json',
    'validation-stopped-for-scope-refinement.json', 'verification-reader-normalization.json',
    'independent-verification.json', 'independent-verification-01.log',
    'independent-verification-02.log', 'independent-verification-03.log',
    'original-tests.log', 'append-tests.log', 'append-tests-corrected.log',
    'manifest-tests.log', 'fmt-check-01.log', 'fmt-check-02.log', 'fmt-check-03.log', 'fmt-check-04.log',
    'candidate-build.log', 'candidate-build.json', 'candidate-02-build.log', 'candidate-02-build.json',
    'full-rust-tests.log', 'full-rust-02-tests.log', 'full-rust-02-tests.json',
    'validate-candidate.log', 'validate-candidate-02.log', 'query-01.log', 'query-02.log',
    'compare-prefix-01.log', 'compare-prefix-02.log', 'prefix-intent.json', 'prefix-intent-02.json',
    'native-qualified-01.log', 'native-qualified-khmer-01.log', 'native-qualified-korea-01.log'
]
for name in names:
    assert (root / name).is_file(), name
    copy_file(root / name, name)

source_runs = []
for run in ('civvis-20261103T034543Z', 'civvis-20261103T040708Z', 'civvis-20261103T025902Z'):
    for name in ('events.jsonl', 'summary.json', 'why.log', 'runtime_updates.jsonl', 'decisions.jsonl'):
        source = Path.home() / 'civvis-civ6-runs/control' / run / name
        raw = source.read_bytes()
        copy_file(source, Path('native-source') / run / name)
        source_runs.append({'run': run, 'file': name, 'bytes': len(raw), 'sha256': sha(raw)})
(out / 'native-source-manifest.json').write_text(json.dumps(source_runs, indent=2) + '\n')

for revision, commit in [('original', '84e65fce78ef25a2eeee451d560053c82f521160'),
                         ('prototype-01', '5c5a6bbad24356c1072c2b512599d1491b20244b'),
                         ('candidate-02', candidate['source_commit'])]:
    patch = subprocess.check_output(['git', 'diff', '067304336a3383ac068ee275a74ed572f989f953', commit,
                                     '--', 'src/ai/advanced.rs', 'src/ai/advanced/anvil_assignment.rs',
                                     'src/ai/advanced/anvil_assignment/tests.rs', 'src/ai/advanced/genes.rs',
                                     'src/ai/advanced/treatment_flags.rs', 'src/ai/advanced/siege_train.rs'], cwd=repo)
    target = out / 'source' / (revision + '.patch')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(patch)
    for path in candidate['source_sha256']:
        raw = subprocess.check_output(['git', 'show', f'{commit}:{path}'], cwd=repo)
        target = out / 'source' / revision / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)

verification = json.loads((root / 'independent-verification.json').read_text())
queries = json.loads((root / 'queries-02/results.json').read_text())
prefix = json.loads((root / 'prefix-comparisons-02/results.json').read_text())
assert len(queries['cases']) == 4 and all(case['complete'] for case in queries['cases'])
assert sum(case['changed'] for case in queries['cases']) == 2
assert all(row['summary']['valid_prefix_comparison'] for row in prefix['results'])
report = {
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'decision': 'Retain the narrowed default-OFF candidate for review; no native strength or promotion claim.',
    'gene': 'anvil-follows-the-defense',
    'scope': 'Development inputs reused for scope refinement. Captured proposals and read-conformance controls, not held-out confirmation, host execution, saved-city outcomes or victory-rate evidence.',
    'source_commit': candidate['source_commit'], 'candidate_binary_sha256': candidate['binary_sha256'],
    'native_binary_sha256': '4f269c7368c7aea82b589d09fef2b448b98b161d2ee166d055cf2c1bde50702a',
    'census': verification['census_reproduced'],
    'original_native_qualified_requests': sum(row['requests'] for row in verification['qualifications']),
    'candidate_off_full_payload_controls': [row['summary']['requests'] for row in prefix['results'] if row['summary']['variant'].startswith('off-')],
    'candidate_on_first_order_change_controls': [{key: row['summary'][key] for key in
                                               ('variant', 'requests', 'stopped_request', 'valid_prefix_comparison')}
                                              for row in prefix['results'] if row['summary']['variant'].startswith('on-')],
    'fresh_board_queries': 20,
    'fresh_board_cases': [{key: case[key] for key in ('run', 'turn', 'changed', 'removed_orders', 'added_orders')} for case in queries['cases']],
    'local_rust': {'command': tests['command'], 'passed': sum(int(n) for n, _, _ in summaries),
                   'failed': 0, 'ignored': sum(int(n) for _, _, n in summaries), 'focused_routing_tests': 9},
    'append_tests': 14, 'manifest_tests': 21,
    'retained_development_checks': [
        'Original-routing scaffold: three compatibility tests passed; five initial routing tests failed.',
        'Initial append checks had three failures; placement was corrected and all fourteen passed.',
        'Initial module declaration order failed formatting; corrected source passes.',
        'First prototype ON changed at6/0 by forming an Anvil without the original warning. Its full Rust suite was intentionally stopped incomplete. Narrowed revision preserves original eligibility.',
        'The first scope explanation blamed non-Defend fallback; actual trace already had Defend. The corrected explanation and both traces remain retained.',
        'First independent verifier compared normalized profiles to raw metadata; the documented eight-field reader normalization corrected that comparison without changing input, payload or read gates.'
    ],
    'binary_artifacts': 'Exact native and candidate executables plus original regression-test executable retained outside the worktree; archive binds hashes and includes source, captured inputs, outputs and independent reconstruction.',
    'no_native_treatment_armed': True, 'no_strength_ledger_update': True,
    'verification': verification
}
(out / 'adjudication.json').write_text(json.dumps(report, indent=2) + '\n')
subprocess.run(['python3', str(out / 'verify.py')], check=True, stdout=subprocess.DEVNULL)
files = {path.relative_to(out).as_posix(): path.read_bytes() for path in out.rglob('*')
         if path.is_file() and '__pycache__' not in path.parts}
manifest = {'members': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(files.items())}}
files['SHA256SUMS.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive = repo / 'docs/eval/2026-11-03-anvil-assignment.raw.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as tar:
    for name, raw in sorted(files.items()):
        item = tarfile.TarInfo(name)
        item.size = len(raw)
        item.mtime = 0
        item.mode = 0o644
        tar.addfile(item, io.BytesIO(raw))
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(files)
    for name, raw in files.items():
        assert tar.extractfile(name).read() == raw
report['archive'] = {'path': str(archive.relative_to(repo)), 'bytes': archive.stat().st_size,
                     'sha256': sha(archive.read_bytes()), 'members': len(files), 'manifest': 'SHA256SUMS.json'}
(repo / 'docs/eval/2026-11-03-anvil-assignment.json').write_text(json.dumps(report, indent=2) + '\n')
fire = {'kind': 'captured_native_action_pairs_v1', 'tag': report['gene'],
        'scope': report['scope'], 'archive': {key: report['archive'][key] for key in ('path', 'sha256')},
        'members': [f"queries-02/{case['run']}-{case['turn']}/result.json" for case in queries['cases']]}
(repo / 'docs/gene_screens/fires/anvil-follows-the-defense.json').write_text(json.dumps(fire, indent=2) + '\n')
print(json.dumps({'archive': report['archive'], 'rust': report['local_rust']}), flush=True)
