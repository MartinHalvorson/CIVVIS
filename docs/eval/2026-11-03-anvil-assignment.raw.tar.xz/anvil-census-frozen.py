from pathlib import Path
import json,re,hashlib,datetime
root=Path(__file__).parent/'census-inputs';cases=[];eligible=0;matched=0
for p in sorted(root.glob('civvis-*/summary.json')):
 if p.parent.name<'civvis-20261030T000000Z':continue
 try:s=json.loads(p.read_text())
 except (ValueError,OSError):continue
 why=p.parent/'why.log'
 if s.get('difficulty') not in ('DIFFICULTY_IMMORTAL','DIFFICULTY_DEITY') or not why.exists():continue
 eligible+=1;active=None;unique=set()
 for number,line in enumerate(why.open(),1):
  t=re.match(r'\[why\] t(\d+) ',line)
  if not t:continue
  turn=int(t[1])
  if 'Military/Strategy Board:' in line:
   active=None
   if ', 1 force(s),' not in line:continue
   assigned=re.findall(r'Defend ([^(·]+?) \(value [^·]*?force #(\d+)',line)
   if len(assigned)==1:active=(turn,assigned[0][0].strip(),assigned[0][1],number,line.rstrip())
  if 'Military/Decision Anvil at ' in line and active and active[0]==turn:
   city=line.split('Anvil at ',1)[1].split(':',1)[0];key=(turn,active[1],city)
   if key in unique:continue
   unique.add(key);matched+=1
   if city!=active[1]:cases.append({'run':p.parent.name,'turn':turn,'assigned_city':active[1],'anvil_city':city,'force':active[2],'board_line':active[3],'anvil_line':number,'board':active[4],'anvil':line.rstrip(),'why_sha256':hashlib.sha256(why.read_bytes()).hexdigest()})
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only journal census; require a board with exactly one force explicitly assigned Defend and the subsequent same-turn Anvil before the next board. Deduplicate run/turn/city pair. A naming mismatch is proposal routing evidence, not host execution or causal loss. Files may be ongoing prefixes.','eligible_logs':eligible,'unique_single_force_anvil_observations':matched,'mismatch_observations':len(cases),'mismatch_games':len({c['run'] for c in cases}),'cases':cases}
(Path(__file__).parent/'anvil-census-frozen.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k not in ('cases','scope')});print([{'run':c['run'],'turn':c['turn'],'assigned':c['assigned_city'],'anvil':c['anvil_city']} for c in cases][-8:])
