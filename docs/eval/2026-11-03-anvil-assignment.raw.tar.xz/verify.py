"""Recheck retained inputs, replies, profiles and read traces without execution."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "helpers"))
import civ6_captured_read_replay as replay


def rows(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def genome(path):
    for line in path.read_text().splitlines():
        try:
            value = json.loads(line)
        except ValueError:
            continue
        if isinstance(value, dict) and "treatments" in value:
            return {key: value.get(key) for key in ("strategy", "source", "lane", "civ", "strength_bound", "treatments", "ledger_withheld", "forced")}
    raise AssertionError(f"No realized genome in {path}")


def source(q):
    proof = json.loads((q / "qualification.json").read_text())
    raw = (q / "native-decisions.jsonl").read_bytes()
    assert replay.sha(raw) == proof["native_decisions_sha256"]
    mapping = {}
    for capture in proof["sealed_captures"]:
        directory = q / Path(capture["sealed_directory"]).name
        assert replay.sha((directory / "bytes.bin").read_bytes()) == capture["archive_sha256"]
        assert replay.sha((directory / "snapshots.jsonl").read_bytes()) == capture["index_sha256"]
        mapping[capture["source"]] = directory
    return proof, rows(q / "native-decisions.jsonl"), mapping


def control(records, mapping, directory, metrics, orders_only=False):
    by_key = {replay.frame_key(row): row for row in records}
    replies = rows(directory / "replies.jsonl")
    assert len(replies) == len(metrics)
    matched = []
    for metric, reply in zip(metrics, replies):
        key = tuple(metric["request"])
        record = by_key[key]
        capture = record["input_capture"]
        expected = replay.expanded_reads(dict(capture, directory=str(mapping[capture["directory"]])))
        actual = replay.expanded_reads(dict(reply["input_capture"], directory=str(directory / "recaptured")))
        assert expected == actual
        assert [replay.sha(x) for x in expected] == metric["expected_read_sha256"]
        assert [replay.sha(x) for x in actual] == metric["actual_read_sha256"]
        assert not replay.request_identity_errors(reply, *key)
        before = record["orders"] if orders_only else replay.control_payload(record)
        after = reply["orders"] if orders_only else replay.control_payload(reply)
        matched.append(replay.exact_fact(before, after))
    return matched, replies


report = {"scope": "Read-only independent evidence checks; no game execution or strength estimate.",
          "qualifications": [], "prefixes": [], "fresh_boards": []}
for name in ("native-qualified-01", "native-qualified-khmer-01", "native-qualified-korea-01"):
    q = root / name
    proof, records, mapping = source(q)
    assert proof["passed"] and len(proof["controls"]) == 2
    for number, result in enumerate(proof["controls"]):
        matches, _ = control(records, mapping, q / f"control-{number}", result["requests"])
        assert result["passed"] and all(matches) and len(matches) == len(records)
        report["qualifications"].append({"case": name, "control": number, "requests": len(matches)})

q = root / "native-qualified-01"
_, records, mapping = source(q)
baseline = genome(q / "control-0/stderr.log")
tag = "anvil-follows-the-defense"
for revision, expected_change in (("01", [6, 0]), ("02", [39, 0])):
    directory = root / f"prefix-comparisons-{revision}"
    proof = json.loads((directory / "results.json").read_text())
    on_replies = []
    assert len(proof["results"]) == 4
    for result in proof["results"]:
        summary = result["summary"]
        label = summary["variant"]
        on = label.startswith("on-")
        realized = genome(directory / label / "stderr.log")
        for field in ("treatments", "forced"):
            assert sorted(realized[field]) == sorted(baseline[field] + ([tag] if on else []))
        matches, replies = control(records, mapping, directory / label,
                                   result["driver_result"]["requests"], orders_only=on)
        assert summary["valid_prefix_comparison"]
        if on:
            assert all(matches[:-1]) and matches[-1] is False
            assert summary["stopped_request"] == expected_change
            assert result["driver_result"]["failed_request"] == expected_change
            on_replies.append(replies)
        else:
            assert all(matches) and len(matches) == len(records)
        report["prefixes"].append({"revision": revision, "arm": label,
                                   "requests": len(matches), "matching": sum(matches),
                                   "first_change": expected_change if on else None})
    assert all(replay.exact_fact(replay.control_payload(a), replay.control_payload(b))
               for a, b in zip(*on_replies))

for revision in ("01", "02"):
    directory = root / f"queries-{revision}"
    report_file = json.loads((directory / "results.json").read_text())
    assert len(report_file["cases"]) == 4
    for case in report_file["cases"]:
        d = directory / f"{case['run']}-{case['turn']}"
        captured = (d / "captured-events.jsonl").read_bytes()
        assert case["complete"] and replay.sha(captured) == case["reads"][0]["sha256"]
        assert len(captured) == case["reads"][0]["bytes"]
        controls = {row["label"]: row for row in case["controls"]}
        assert len(controls) == 5
        for label, arm in controls.items():
            assert arm["exit"] == 0
            assert replay.exact_fact(arm["payload"], json.loads((d / label / "stdout").read_text()))
            assert replay.exact_fact(arm["genome"], genome(d / label / "stderr"))
        for left, right in (("before-off", "candidate-off"),
                            ("candidate-off", "candidate-off-repeat"),
                            ("candidate-on", "candidate-on-repeat")):
            assert replay.exact_fact(replay.control_payload(controls[left]["payload"]),
                                     replay.control_payload(controls[right]["payload"]))
        for arm_label in ("candidate-off", "candidate-on"):
            on = arm_label.endswith("-on")
            observed = controls[arm_label]["genome"]
            original = controls["before-off"]["genome"]
            for field in ("treatments", "forced"):
                assert sorted(observed[field]) == sorted(original[field] + ([tag] if on else []))
        changed = controls["candidate-off"]["payload"]["orders"] != controls["candidate-on"]["payload"]["orders"]
        assert changed == case["changed"]
        report["fresh_boards"].append({"revision": revision, "run": case["run"],
                                      "turn": case["turn"], "changed": changed})

manifest = json.loads((root / "census-inputs-manifest.json").read_text())
for member in manifest["members"]:
    raw = (root / member["member"]).read_bytes()
    assert len(raw) == member["bytes"] and replay.sha(raw) == member["sha256"]
report["census_members_verified"] = len(manifest["members"])
with tempfile.TemporaryDirectory(prefix="anvil-census-check-") as temporary:
    temporary = Path(temporary)
    shutil.copy2(root / "anvil-census-frozen.py", temporary / "anvil-census-frozen.py")
    (temporary / "census-inputs").symlink_to(root / "census-inputs", target_is_directory=True)
    subprocess.run([sys.executable, str(temporary / "anvil-census-frozen.py")],
                   check=True, capture_output=True)
    before = json.loads((root / "anvil-census-frozen.json").read_text())
    after = json.loads((temporary / "anvil-census-frozen.json").read_text())
    before.pop("utc")
    after.pop("utc")
    assert before == after
    report["census_reproduced"] = {key: before[key] for key in
                                   ("eligible_logs", "unique_single_force_anvil_observations",
                                    "mismatch_observations", "mismatch_games")}
(root / "independent-verification.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"qualified_requests": sum(row["requests"] for row in report["qualifications"]),
                  "prefix_controls": len(report["prefixes"]),
                  "fresh_board_cases": len(report["fresh_boards"]),
                  "census_members": report["census_members_verified"]}))
