from pathlib import Path
import subprocess,os,json,hashlib,shutil,datetime
root=Path(__file__).parent;repo=Path('/Users/martbot-mbp-m5-max-128/civvis-anvil-follows-the-defense-e936');env=os.environ.copy();env['CARGO_TARGET_DIR']=str(root/'target');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
paths=['src/ai/advanced.rs','src/ai/advanced/anvil_assignment.rs','src/ai/advanced/anvil_assignment/tests.rs','src/ai/advanced/genes.rs','src/ai/advanced/treatment_flags.rs','src/ai/advanced/siege_train.rs'];hashes={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
for stage,args in [('candidate-build',['cargo','build','--profile','ci','--locked','--bin','civvis_orders']),('full-rust-tests',['cargo','test','--profile','ci','--locked'])]:
 print(json.dumps({'stage':stage,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head}),flush=True)
 with (root/(stage+'.log')).open('wb') as log:p=subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt={'stage':stage,'exit':p.returncode,'completed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'command':args};(root/(stage+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
 assert hashes=={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
 if stage=='candidate-build':
  source=root/'target/ci/civvis_orders';dest=root/'frozen-candidate-ci-orders';assert not dest.exists();shutil.copy2(source,dest);receipt={'source_commit':head,'binary_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'source_sha256':hashes,'scope':'Locally built CI-profile candidate; not an observed native process or deployment.'};(root/'candidate-binary.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'frozen_candidate':receipt['binary_sha256']}),flush=True)
