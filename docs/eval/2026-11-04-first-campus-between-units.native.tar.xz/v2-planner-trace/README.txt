Rejected first-campus-between-the-units prototype.
Native executable source: efaced090 (production bytes are in source-files/).
The executable itself is not included; its recorded SHA-256 is in captured-prefix/results.json.
Raw same-prefix controls and successful queries verify the input/action comparison, not the intended Campus effect. No Campus order was added at the first difference; existing city-production orders were only reordered.
verify.py requires a CIVVIS checkout available as ~/civvis-main-managed for parsing helpers and the archived source commit. It reconstructs all recorded read sequences, outputs and paired-query equality. The protocol check is not an intended-effect or strength check.
Capture directories in successful-prefix-pairs were moved after successful EOF exit; each receipt records the per-query absolute-to-archived path map.
