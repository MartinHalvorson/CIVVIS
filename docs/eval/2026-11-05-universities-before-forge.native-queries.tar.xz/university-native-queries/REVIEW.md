# Reviewing this captured-input evidence

This archive contains raw commands, replies, genomes, captured-read archives,
the original canonical record and sealed original input, plus the executed
probe and independent checker. It does not contain a game outcome or imply
original private-planner parity, construction, saved turns or strength.

The candidate source is e6380fe51a31c413e28074e0a7f5da58069ceb95. Its exact
hosted build is GitHub Actions run42122126276. Keep the downloaded native
artifact (receipt, both executables and logs); hosted artifacts have finite
retention. The repository archive intentionally excludes executables and the
source checkout. The build receipt binds all tracked source inputs and both
binary hashes.

To recheck from an extracted directory, use a clean checkout of that source
and the retained artifact. Substitute actual paths in this command:

```sh
python3.12 university-native-queries/independent-checker.py \
  --root university-native-queries \
  --base university-native-queries/original-capture-seal \
  --source /path/to/clean-source-checkout \
  --artifact /path/to/retained-native-artifact \
  --binary /path/to/retained-native-artifact/civvis_orders
```

The checker reads evidence and checks source/binary hashes; it does not execute
the decider or launch a game. Raw commands retain their original absolute
paths, which are checked against the recorded protocol. Capture relocation
receipts let readback use the extracted directories without rewriting replies.
