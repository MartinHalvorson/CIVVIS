"""Independent read-only verification of retained cold proposals, no queries."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import subprocess
import sys

B = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, default=B / 'universities-before-forge-captured-input-42122126276')
parser.add_argument('--base', type=Path, default=B / 'indonesia-university-industry-proposals-codex-korea-20261105T212617Z')
parser.add_argument('--artifact', type=Path, default=B / 'universities-before-forge-hosted-42122126276')
parser.add_argument('--source', type=Path)
parser.add_argument('--binary', type=Path)
args = parser.parse_args()
ROOT, BASE, ARTIFACT = args.root.resolve(), args.base.resolve(), args.artifact.resolve()
SOURCE = args.source.resolve() if args.source else ROOT / 'clean-source'
BINARY = args.binary.resolve() if args.binary else ROOT / 'probe-binary'
read = lambda p: json.loads(p.read_text())
digest = lambda data: hashlib.sha256(data).hexdigest()
protocol = read(ROOT / 'protocol.json')
recorded_root = Path(protocol['root'])
sys.path.insert(0, str(SOURCE / 'tools'))
from civ6_captured_read_replay import expanded_reads
from civ6_ladder import decider_genome
from native_build_artifact import verify

receipt = verify(SOURCE, ARTIFACT, protocol['source_sha'],
                 toolchain='1.97.1')
assert receipt == read(ROOT / 'verified-hosted-receipt.json')
assert digest(BINARY.read_bytes()) == receipt['binaries']['civvis_orders'] == protocol['binary_sha256']
data = (ROOT / 'events.jsonl').read_bytes()
assert digest(data) == protocol['input_sha256']
record = read(ROOT / 'original-record.json')
encoded = json.dumps({k: v for k, v in record.items() if k != 'sha256'},
                     sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
assert digest(encoded) == record['sha256'] == protocol['original_record_sha256']
seal = read(BASE / 'sealed-original-capture.json')
sealed = BASE / 'sealed-original-capture'
assert seal['original_directory'] == record['input_capture']['directory']
assert digest((sealed / 'bytes.bin').read_bytes()) == seal['archive_sha256']
assert digest((sealed / 'snapshots.jsonl').read_bytes()) == seal['index_sha256']
original_reads = expanded_reads({**record['input_capture'], 'directory': str(sealed)})
assert len(original_reads) == 18 and all(x == data for x in original_reads)
events = [json.loads(line) for line in data.splitlines()]
seat = next(e for e in events if e.get('kind') == 'seat')
assert (seat['civ'], seat['difficulty'], seat['speed']) == (
    'CIVILIZATION_INDONESIA', 'DIFFICULTY_DEITY', 'GAMESPEED_ONLINE')
state = [e for e in events if e.get('kind') == 'state'][-1]
city = next(c for c in state['cities'] if c['id'] == protocol['city'])
assert city == read(ROOT / 'source-native-city.json')
assert 'BUILDING_LIBRARY' in city['buildings'] and 'BUILDING_UNIVERSITY' not in city['buildings']
replies, genomes, commands, payloads, rows = {}, {}, {}, {}, []
for role in protocol['order']:
    out = ROOT / role
    arm = role.split('-')[1]
    payload = read(out / 'stdout.json')
    payloads[role] = payload
    assert [payload['decision']['turn'], payload['decision']['frame']] == protocol['request']
    assert payload['decision']['victory_portfolio']['assigned_target'] == 'science'
    relocation = read(out / 'capture-relocation.json')
    assert relocation['original_directory'] == payload['input_capture']['directory']
    assert relocation['retained_directory'] == str(recorded_root / role / 'capture')
    reads = expanded_reads({**payload['input_capture'], 'directory': str(out / 'capture')})
    assert len(reads) > 0 and all(x == data for x in reads)
    genome = decider_genome(out / 'stderr.log')
    for gene in ['industrial-zone-claims-the-producer-queue', 'industrial-zone-claims-the-factory']:
        assert gene in genome['treatments']
    full = {k: payload[k] for k in ['decision', 'orders']}
    if arm in replies:
        assert full == replies[arm] and genome == genomes[arm]
    replies[arm], genomes[arm] = full, genome
    orders = [o for o in payload['orders'] if o.get('kind') == 'produce' and o.get('subject') == city['id']]
    assert len(orders) == 1
    verb = 'BUILDING_UNIVERSITY' if arm == 'on' else 'DISTRICT_INDUSTRIAL_ZONE'
    assert orders[0]['verb'] == verb
    quote = next(q for q in city['buildable'] if q['t'] == verb)
    assert quote['p'] > 0
    if arm == 'off':
        assert {'x': orders[0]['x'], 'y': orders[0]['y']} in quote['s']
    cmd = read(out / 'command.json')
    assert cmd['cwd'] == str(recorded_root / 'clean-source')
    argv = list(cmd['argv'])
    assert argv[0] == str(recorded_root / 'probe-binary')
    assert argv[argv.index('--capture-inputs') + 1] == str(recorded_root / 'active-capture')
    argv[argv.index('--mirror') + 1] = '<captured-input>'
    if arm == 'on':
        indices = [i for i in range(len(argv)-1) if argv[i:i+2] == ['--with', protocol['tag']]]
        assert len(indices) == 1
        del argv[indices[0]:indices[0]+2]
    if commands:
        assert argv == next(iter(commands.values()))
    commands[role] = argv
    rows.append({'role': role, 'actual_reads': len(reads), 'orders': orders,
                 'native_quote': quote,
                 'stdout_sha256': digest((out / 'stdout.json').read_bytes()),
                 'stderr_sha256': digest((out / 'stderr.log').read_bytes())})
off, on = [json.loads(json.dumps(genomes[a])) for a in ['off', 'on']]
for field in ['treatments', 'forced']:
    assert protocol['tag'] not in off[field] and protocol['tag'] in on[field]
    on[field].remove(protocol['tag'])
assert off == on
pairs = read(ROOT / 'action-pairs.json')
assert pairs['complete'] is True and len(pairs['reads']) == 2
for pair, roles in zip(pairs['reads'], [('01-off', '02-on'), ('04-off', '03-on')]):
    assert pair['complete'] is True and pair['sha256'] == digest(data) and pair['bytes'] == len(data)
    for entry, role in zip(pair['arms'], roles):
        assert entry == {'arm': role.split('-')[1], 'exit': 0,
                         'genome': decider_genome(ROOT / role / 'stderr.log'),
                         'argv': read(ROOT / role / 'command.json')['argv'],
                         'payload': payloads[role]}
result = {'verified_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'verified': True, 'source_sha': protocol['source_sha'],
    'binary_sha256': protocol['binary_sha256'], 'original_actual_reads': 18,
    'proposal_actual_reads': sum(r['actual_reads'] for r in rows),
    'only_named_genome_bit_differs': True, 'normalized_argv_equal': True,
    'complete_decision_and_orders_repeat': True, 'rows': rows,
    'scope': protocol['scope']}
(ROOT / 'independent-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['verified', 'source_sha', 'original_actual_reads',
    'proposal_actual_reads', 'only_named_genome_bit_differs', 'normalized_argv_equal']}))
