"""Cold captured-input qualification; never opens or commands a native game."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import subprocess
import sys

B = Path(__file__).resolve().parent
REPO = Path.home() / 'civvis-universities-before-the-forge-2eb9'
BASE = B / 'indonesia-university-industry-proposals-codex-korea-20261105T212617Z'
SHA = 'e6380fe51a31c413e28074e0a7f5da58069ceb95'
TAG = 'universities-before-the-forge'
ARTIFACT = B / 'universities-before-forge-hosted-42122126276'
ROOT = B / 'universities-before-forge-captured-input-42122126276'
TESTS = {'lib': ['universities_before_the_forge::tests',
    'industrial_zone_claims_the_producer_queue::tests',
    'industrial_zone_claims_the_factory::tests',
    'campus_building_claims_the_queue::tests', 'near_done_work_finishes::tests']}
read = lambda p: json.loads(p.read_text())
digest = lambda data: hashlib.sha256(data).hexdigest()

def write(p, data):
    p.write_text(json.dumps(data, indent=2) + '\n')

def main():
    assert not ROOT.exists(), 'No automatic retry or overwrite of an existing probe'
    ROOT.mkdir()
    protocol = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'root': str(ROOT),
        'source_sha': SHA, 'hosted_run': 42122126276, 'tag': TAG,
        'order': ['01-off', '02-on', '03-on', '04-off'],
        'request': [70, 0], 'city': 131073,
        'selection': 'Previously selected Indonesia Ternate70/0 queue opportunity; not a representative strength sample.',
        'scope': 'Cold same-input proposals only. No original private-planner parity, native execution, construction, saved turns or strength claim. No game harness, game orders or lane settings.'}
    write(ROOT / 'protocol.json', protocol)
    shutil.copy2(__file__, ROOT / 'executed-probe.py')
    try:
        source = ROOT / 'clean-source'
        subprocess.run(['git', 'clone', '--quiet', '--shared', '--no-checkout', str(REPO), str(source)], check=True)
        subprocess.run(['git', 'checkout', '--quiet', '--detach', SHA], cwd=source, check=True)
        sys.path.insert(0, str(source / 'tools'))
        from native_build_artifact import verify
        from civ6_captured_read_replay import expanded_reads
        from civ6_ladder import decider_genome
        receipt = verify(source, ARTIFACT, SHA, json.dumps(TESTS), '1.97.1')
        write(ROOT / 'verified-hosted-receipt.json', receipt)
        data = (BASE / 'events.jsonl').read_bytes()
        original = read(BASE / 'original-record.json')
        assert digest(data) == read(BASE / 'protocol.json')['input_sha256']
        seal = read(BASE / 'sealed-original-capture.json')
        captured = expanded_reads({**original['input_capture'], 'directory': seal['sealed_directory']})
        assert len(captured) == 18 and all(x == data for x in captured)
        write(ROOT / 'original-record.json', original)
        shutil.copy2(BASE / 'events.jsonl', ROOT / 'events.jsonl')
        context = read(BASE / 'observed-native-context.json')
        write(ROOT / 'observed-original-context.json', context)
        city = read(BASE / 'source-native-city.json')
        write(ROOT / 'source-native-city.json', city)
        binary = ROOT / 'probe-binary'
        shutil.copy2(ARTIFACT / 'civvis_orders', binary)
        binary.chmod(binary.stat().st_mode | 0o100)
        assert digest(binary.read_bytes()) == receipt['binaries']['civvis_orders']
        protocol.update(input_sha256=digest(data), binary_sha256=digest(binary.read_bytes()),
                        original_record_sha256=original['sha256'])
        write(ROOT / 'protocol.json', protocol)
        replies, genomes, arms, reads = {}, {}, {}, {}
        for role in protocol['order']:
            arm = role.split('-')[1]
            out = ROOT / role
            out.mkdir()
            (out / 'events.jsonl').write_bytes(data)
            argv = list(context['process']['argv'])
            argv[0] = str(binary)
            argv[argv.index('--mirror') + 1] = str(out)
            # Reuse one new capture pathname, then retain each completed
            # directory under its arm. The raw reply remains untouched;
            # relocation is separately recorded for independent readback.
            active_capture = ROOT / 'active-capture'
            assert not active_capture.exists()
            argv[argv.index('--capture-inputs') + 1] = str(active_capture)
            if arm == 'on':
                argv.extend(['--with', TAG])
            write(out / 'command.json', {'argv': argv, 'cwd': str(source)})
            job = subprocess.run(argv, cwd=source, input='70\n', capture_output=True,
                                 text=True, timeout=180)
            (out / 'stdout.json').write_text(job.stdout)
            (out / 'stderr.log').write_text(job.stderr)
            assert job.returncode == 0, (role, job.returncode)
            payload = json.loads(job.stdout)
            assert [payload['decision']['turn'], payload['decision']['frame']] == [70, 0]
            actual = expanded_reads(payload['input_capture'])
            assert actual and all(x == data for x in actual)
            shutil.move(str(active_capture), str(out / 'capture'))
            write(out / 'capture-relocation.json', {
                'original_directory': payload['input_capture']['directory'],
                'retained_directory': str(out / 'capture')})
            genome = decider_genome(out / 'stderr.log')
            assert 'industrial-zone-claims-the-producer-queue' in genome['treatments']
            assert 'industrial-zone-claims-the-factory' in genome['treatments']
            stable = {k: payload[k] for k in ['decision', 'orders']}
            if arm in replies:
                assert stable == replies[arm] and genome == genomes[arm]
            else:
                replies[arm], genomes[arm] = stable, genome
            orders = [o for o in payload['orders'] if o.get('kind') == 'produce' and o.get('subject') == 131073]
            assert len(orders) == 1
            expected = 'BUILDING_UNIVERSITY' if arm == 'on' else 'DISTRICT_INDUSTRIAL_ZONE'
            assert orders[0]['verb'] == expected, (role, orders)
            quote = next(q for q in city['buildable'] if q['t'] == expected)
            assert quote['p'] > 0
            if arm == 'off':
                assert {'x': orders[0]['x'], 'y': orders[0]['y']} in quote['s']
            arms[role] = {'arm': arm, 'exit': job.returncode, 'genome': genome,
                          'argv': argv, 'payload': payload}
            reads[role] = len(actual)
            print(json.dumps({'role': role, 'actual_reads': len(actual), 'orders': orders}), flush=True)
        off, on = [json.loads(json.dumps(genomes[a])) for a in ['off', 'on']]
        for field in ['treatments', 'forced']:
            assert TAG not in off[field] and TAG in on[field]
            on[field].remove(TAG)
        assert off == on, 'Unexpected raw genome difference'
        pairs = []
        for before, after in [('01-off', '02-on'), ('04-off', '03-on')]:
            pairs.append({'complete': True, 'sha256': digest(data), 'bytes': len(data),
                          'arms': [arms[before], arms[after]]})
        write(ROOT / 'action-pairs.json', {'complete': True, 'reads': pairs})
        write(ROOT / 'result.json', {'complete': True, 'original_actual_reads': 18,
            'proposal_actual_reads': sum(reads.values()), 'reads': reads,
            'full_replies_repeat': True, 'only_named_gene_differs': True,
            'scope': protocol['scope']})
    except BaseException as error:
        write(ROOT / 'failure.json', {'error': repr(error), 'no_retry': True,
                                     'no_game_actions': True})
        raise

if __name__ == '__main__':
    main()
