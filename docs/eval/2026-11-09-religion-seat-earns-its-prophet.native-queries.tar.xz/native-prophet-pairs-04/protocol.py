#!/usr/bin/env python3
"""Same-input proposal activation only; no historical replay or strength claim."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

REPO = Path('/Users/martbot-mbp-m5-max-128/civvis-religion-seat-earns-its-prophet-6a1f')
BASE = Path.home() / '.local/share/civvis-religion'
RUN = Path.home() / 'civvis-civ6-runs/control/civvis-20261109T031713Z'
BINARY = REPO / 'target/native-fast/release/civvis_orders'
TAG = 'religion-seat-earns-its-prophet'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_decision_trace import captured_input, validate_input_capture


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    out = BASE / 'native-prophet-pairs-04'
    assert sha(BINARY.read_bytes()) not in {'e6b9df35a5a63d3c821a8e56055173400b064a906d4a9f702c2bb9d92fab4b4b', '1431fc665e1eb73a914c85f56cbc102d917debca9f584ac49b08db295751b575'}, 'candidate is still the pre-protection executable; rebuild corrected source first'
    out.mkdir(exist_ok=False)
    # Freeze the native run's requested on-tags, then vary only this new tag.
    native_genome = json.loads((RUN / 'why.log').open().readline())
    assert native_genome['kind'] == 'genome' and TAG not in native_genome['forced']
    current = (BASE / 'prophet-pair-force-on-frozen.txt').read_text().strip()
    assert current and not any(c.isspace() for c in current)
    flags = [tag for tag in current.split(',') if tag != TAG]
    assert 'religion-seat-races-the-prophet' in flags
    policies = [arg for tag in flags for arg in ('--with', tag)]
    source_commit = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip()
    assert subprocess.run(['git', '-C', str(REPO), 'diff', '--quiet', 'HEAD']).returncode == 0
    selections = [(17, 0), (22, 0), (27, 0), (28, 0)]
    records = {(r['decision']['turn'], r['decision']['frame']): r
               for r in map(json.loads, (RUN / 'decisions.jsonl').open())}
    changed = []
    for turn, frame in selections:
        native = records[(turn, frame)]
        capture = native['input_capture']
        validate_input_capture(capture)
        assert capture['complete'] is True
        # A frozen snapshot, rather than an attempted reconstruction of the
        # persistent controller's state, defines this isolated proposal query.
        sid = capture['reads'][0]['snapshot_id']
        data = captured_input(capture, sid)
        case = out / ('t%d-f%d' % (turn, frame))
        case.mkdir()
        (case / 'input.jsonl').write_bytes(data)
        result = {'complete': False, 'scope': __doc__, 'source_run': RUN.name,
                  'native_receipt_sha256': native['sha256'],
                  'source_snapshot_id': sid, 'source_turn': turn, 'source_frame': frame,
                  'candidate_binary_sha256': sha(BINARY.read_bytes()), 'source_commit': source_commit, 'reads': []}
        read = {'complete': False, 'sha256': sha(data), 'bytes': len(data), 'arms': []}
        for arm in ['off', 'on']:
            directory = case / arm
            directory.mkdir()
            (directory / 'events.jsonl').write_bytes(data)
            argv = [str(BINARY), '--mirror', str(directory), '--turn', str(turn),
                    '--victory', 'religious', '--resumed', '--capture-inputs', 'capture'] + policies
            if arm == 'on':
                argv += ['--with', TAG]
            done = subprocess.run(argv, cwd=directory, capture_output=True, text=True, timeout=120)
            (directory / 'stdout.json').write_text(done.stdout)
            (directory / 'stderr.log').write_text(done.stderr)
            genome = next((r for r in (json.loads(l) for l in done.stderr.splitlines()
                                      if l.startswith('{')) if r.get('kind') == 'genome'), None)
            assert done.returncode == 0, done.stderr[-2000:]
            payload = json.loads(done.stdout)
            assert genome and isinstance(payload.get('orders'), list)
            recapture = payload.get('input_capture')
            assert recapture and recapture['complete'] is True
            for readback in recapture['reads']:
                assert sha(captured_input(recapture, readback['snapshot_id'])) == sha(data)
            read['arms'].append({'arm': arm, 'argv': argv, 'exit': done.returncode,
                                 'genome': genome, 'payload': payload})
        off, on = read['arms']
        for field in ['treatments', 'forced']:
            assert TAG not in off['genome'][field] and TAG in on['genome'][field]
            assert set(off['genome'][field]) == set(on['genome'][field]) - {TAG}
        read['complete'] = True
        result['reads'] = [read]
        result['complete'] = True
        result['orders_changed'] = off['payload']['orders'] != on['payload']['orders']
        (case / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
        changed.append({'turn': turn, 'frame': frame, 'orders_changed': result['orders_changed'],
                        'off_orders': len(off['payload']['orders']), 'on_orders': len(on['payload']['orders'])})
        print(json.dumps(changed[-1]), flush=True)
    (out / 'summary.json').write_text(json.dumps({'scope': __doc__, 'cases': changed}, indent=2) + '\n')

if __name__ == '__main__':
    main()
