import pathlib,json,hashlib,subprocess,shutil,sys,gzip
w=pathlib.Path('/Users/martbot-mbp-m5-max-128/civvis-production-choice-memo-4d0f');t=pathlib.Path('/tmp/civvis-production-choice-memo-4d0f');base='2026-10-26-production-choice-memo'
initial=json.loads((t/'comparison-02-audit.json').read_text());confirmation=json.loads((t/'confirmation-01-audit.json').read_text());assert initial['verified_raw_replies']==756 and confirmation['verified_raw_replies']==924
for i in [i for i,c in enumerate(initial['cases']) if not c.get('unavailable')]:
 a=gzip.decompress((t/'comparison-02'/f'case-{i:04d}.semantic.json.gz').read_bytes());b=gzip.decompress((t/'confirmation-01'/f'case-{i:04d}.semantic.json.gz').read_bytes());assert a==b
history=t/'historical-sources';history.mkdir(exist_ok=True)
for label,revision,filename,registration in [('comparison01.py','2e1cd463b',base+'.compare.py',t/'comparison-01/registration.json'),('native01.py','2e1cd463b',base+'.native.py',t/'native-01/registration.json')]:
 raw=subprocess.check_output(['git','show',revision+':docs/eval/'+filename],cwd=w);expected=json.loads(registration.read_text())['source_sha256'];assert hashlib.sha256(raw).hexdigest()==expected;(history/label).write_bytes(raw)
assert hashlib.sha256((t/'comparison02-executed-source.py').read_bytes()).hexdigest()==json.loads((t/'comparison-02/registration.json').read_text())['source_sha256']
assert hashlib.sha256((w/'docs/eval'/f'{base}.compare.py').read_bytes()).hexdigest()==json.loads((t/'confirmation-01/registration.json').read_text())['source_sha256']
for name in ['native-01','native-02-profile502']:
 d=json.loads((t/name/'summary.json').read_text());assert d['registered_cases']==d['complete_cases']==8 and not d['incomplete']
shutil.copyfile(t/'comparison-02-audit.json',w/'docs/eval'/f'{base}.initial-audit.json');shutil.copyfile(t/'confirmation-01-audit.json',w/'docs/eval'/f'{base}.confirmation-audit.json')
report='''# Rejected production-choice query memo

The candidate guard is **removed**. All 833 production compiled inputs exactly match the unmodified baseline again. Correctness checks pass, but the small apparent CPU improvement does not resolve cleanly against same-binary variation. No application, default, ledger or live-runtime change is shipped.

The candidate added one `Game::query_memo` scope around immutable `BasicAi::pick_item`. It preserved early returns, menu order and production priorities. The earlier fixed-board profile identified repeated city-yield derivation here; this experiment tests that hypothesis rather than assuming the sampled fraction becomes a gain.

## Exact builds, inputs and correctness

The actual baseline library/probe were built from `c871172d49375da2e635f2a4c001712a690ebc21`; they are not relabeled as the later documentation-only task parent. All 833 frozen compiled inputs matched that parent before the candidate edit. The candidate application source is `609e60698`; it changes only the guard and its two comment lines. Matching Cargo fingerprints cover compiler, features, declared features, target, profile, path, rustflags and config. Both probes use identical source and matching optimized ci/default-feature/opt-level/debug-assertion/codegen settings.

Retain all 48 prior model assignments: 42 available snapshot files and six unavailable cases, with no replacement. Explicitly map the qualified 501-treatment Native list onto those historical simulation boards. This is a fixed synthetic model workload, not stock model defaults or a reconstruction of the original simulation trajectory.

All **1,680 successful model process replies** reconstruct byte-exactly from the canonical semantic bytes and each actual prefix/suffix; timing metadata and actual binary identities are independently verified. All 42 complete worlds, actions, strategic plans and reasoning payloads match within and between both measured runs. Each process also requires identical fresh-planner repetitions internally.

The candidate’s full locked, single-thread Rust suite passes **6,374 tests, zero fail, 56 existing ignores**. Eight fixed exact-prefix Native boards pass baseline/candidate/baseline-repeat controls under both actually observed 501- and 502-treatment profiles: **16 profile/board cases, eight distinct prefixes, 48 adapter queries**. Every complete raw response, full played genome and reasoning sequence matches within each profile. The 502 profile adds `aluminum-tile-spends-the-war-chest`; it is not silently substituted into the registered 501 model timing workload. All Native queries use disposable production `--serve --fresh-board` mirrors and issue no host orders. They are fresh-controller response checks, not historical controller replay or Native speed measurements.

## Initial benchmark

Qualification runs both builds on every available case before timing. Three baseline/baseline control rounds and five baseline/candidate rounds each use five fresh planner calls per case/process, alternating arm order by case/round. Reconstruction, clone, controller setup and serialization stay outside the C process CPU clock. Per-call wall readings and system load are retained.

| Round | Same-binary control change | Candidate change |
| ---: | ---: | ---: |
| 1 | +1.934% | −2.429% |
| 2 | −2.016% | −4.682% |
| 3 | −3.741% | −3.393% |
| 4 | — | −2.954% |
| 5 | — | −4.757% |
| Median | **−2.016%** | **−3.393%** |

The small reduction overlaps the observed control variation. Preserve it as unresolved rather than promoting a selected case or the five negative signs into a resolved speed improvement.

## Published interleaved confirmation

A separate plan was published before additional timing, retaining the same binaries, 42 available cases, six unavailable assignments, 501 treatment list and five fresh calls. In each of five rounds, every case receives a baseline/baseline pair and a baseline/candidate pair. Block and arm orders alternate by case/round parity, bringing control observations close to their comparisons. All cases qualify again first.

The secondary adjustment was declared in advance: `(candidate/baseline) / (control-right/control-left) − 1`. It supplements the raw measurements and does not replace them.

| Round | Same-binary control change | Candidate change | Secondary control-adjusted change |
| ---: | ---: | ---: | ---: |
'''
for a,b,c in zip(confirmation['rounds']['control']['readings'],confirmation['rounds']['comparison']['readings'],confirmation['control_adjusted_rounds']):report+=f"| {a['round']+1} | {a['change_pct']:+.3f}% | {b['change_pct']:+.3f}% | {c['change_pct']:+.3f}% |\n"
report+='''| Median | **−2.056%** | **−3.855%** | **−2.839%** |

The adjusted rounds range from −7.024% to +4.949%, including a reversal. Together with the raw controls, this leaves a small overall effect unresolved. The candidate is rejected and its three added lines are removed exactly; all 833 baseline compiled inputs are restored. No Native, whole-game or strength gain is inferred. Complete per-case readings remain in both independently verified audit JSON files.

## Retained harness failures

The first semantic splitter assumed the payload was the last JSON field. A genuine failing control and an actual retained reply expose the trailing `turn` field. The corrected UTF-8/JSON boundary parser preserves every literal numeric/escape byte. Three semantic controls pass, including Unicode, trailing fields, signed zero, exponent spelling and malformed input rejection; a real 3,834,078-byte reply reconstructs exactly.

The first model qualification then fails because `copyfile` preserved baseline probe bytes but omitted its execute permission. Every failure is retained; no timing round executes. Restoring mode 0644 to the original 0755 leaves SHA-256 `09d9616bfe8c1cfb4bb051be4149db29d054e38d5d64d6bb38cbd6d1e3f26dd8` unchanged. The runner now checks executable permissions before creating an output run. The fresh successful retry and later confirmation use the same fixed inputs and binary bytes. Candidate replies from the unanchored failed qualification are retained without treating them as an equivalence or timing result.

Historical executed helper versions are hash-bound to each registration, including the failed run, the successful initial run and both Native profiles. Complete error stdout/stderr and timeout streams are retained. No failed case or result is replaced.

## Evidence and limits

The evidence packet contains both complete successful runs, the failed qualification, both Native-profile controls, exact historical/current source, both probes and matched adapters, compiler/build/fingerprint/input receipts, candidate source/patch, parser controls, full Rust log, all per-run identities and independent reply reconstructions. Original full model snapshots and Native prefixes are already published in the prior airfield-memo input archives; their exact hashes and paths remain in the selections.

All archive members are read back against sealed bytes/hashes and independent read timestamps. Binary hashes, complete semantics and production restoration are verified separately from timing. The measurement belongs to this fixed workload; it does not estimate a Native or full-game effect. Retain this negative result so the same unproven guard is not rediscovered as a measured optimization.
'''
(w/'docs/eval'/f'{base}.md').write_text(report)
files={f'source/{p.name}':str(p) for p in (w/'docs/eval').glob(base+'*') if p.suffix!='.xz'}
for name in ['comparison-01','comparison-02','confirmation-01','native-01','native-02-profile502','historical-sources','comparison-01.log','comparison-02.log','confirmation-01.log','native-01.log','native-02-profile502.log','comparison-02-audit.log','confirmation-01-audit.log','comparison-02-audit.json','confirmation-01-audit.json','baseline-reuse-qualification.json','baseline-adapter-build-01.jsonl','baseline-adapter-build-01.log','candidate-build-01.jsonl','candidate-build-01.log','candidate-probe-build-01.json','candidate-probe-build-01.log','matched-library-fingerprints-01.json','compiled-inputs-candidate-before.json','compiled-inputs-after-main-integration.json','full-tests-01.log','comparison-parser-initial.py','comparison-controls-red-01.log','comparison-controls-green-01.log','actual-reply-split-control-01.json','baseline-probe-permission-correction-01.json','comparison02-executed-source.py','production-restored-01.json','candidate-ai-source.rs','probe-baseline','probe-candidate','adapter-baseline','adapter-candidate']:
 files['evidence/'+name]=str(t/name)
files['source/prepare-final-evidence.py']=str(pathlib.Path(__file__));files['source/pack-evidence.py']='/tmp/civvis-forward-airfield-project-8c23/pack-evidence.py'
(t/'final-evidence-01.spec.json').write_text(json.dumps({'scope':'Rejected output-preserving production memo. All1680successfullosslessmodelreplies/42worlds, failedinitialqualification, bothNative501/502controls, initial andinterleavedtimings withallcases/controls, exactbuild/source/input/binbindings, actualhistoricalhelpers, full6374tests, restored833productioninputs. No performance/Native/strengthpromotion. Independentmemberreadtimes/hashchecks, notatomic snapshot. Priorcompleteinputarchives referencedbyexactidentities.','files':files},indent=2)+'\n')
subprocess.run([sys.executable,'/tmp/civvis-forward-airfield-project-8c23/pack-evidence.py','--spec',str(t/'final-evidence-01.spec.json'),'--out',str(t/'final-evidence-01.tar.xz')],check=True)
