"""Paired decider queries on live production frames of Deity Science-seat
games of 2026-11-19.

`denial-spies-fill-every-slot-3` is the only bit that varies. Each case is a
live run's own events.jsonl cut right after the turn's first state row (the
frame the live decider answered), replayed at that turn. Cases are turns
100-175 where the seat held Spy capacity and the host still offered a Spy in
at least one city (a free slot: the host menu counts Spies held, in training,
in transit and held by captors), at most ten a game, spread over the game.
Both arms run one frozen `civvis_orders --resumed` built from the branch
head, with that run's own requested genome (why.log line 1 `forced`, each as
`--with`, which carries `denial-spies-fill-every-slot-2`; `civ` is null in
all of them, so no `--civ`); the on arm adds `--with
denial-spies-fill-every-slot-3`, which turns version two off.

Read per arm: the production orders and the Spy claim's journal lines
(`science-denial-trains-spies:`). Per case: whether any order changed, the
Spy orders added, and the heads the added Spies displaced.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import re
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
JOBS = int(sys.argv[4]) if len(sys.argv) > 4 else 2
GENE = 'denial-spies-fill-every-slot-3'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

GAMES = [
    ('civvis-20261119T173500Z', None),
    ('civvis-20261119T183913Z', None),
    ('civvis-20261119T190616Z', None),
    ('civvis-20261119T194013Z', None),
    ('civvis-20261119T200436Z', None),
    ('civvis-20261119T201715Z', None),
    ('civvis-20261119T205955Z', None),
    ('civvis-20261119T212106Z', None),
]
PER_GAME = 10


def windows(run):
    """Turns 100-175 with Spy capacity and a Spy on some city's host menu."""
    turns = []
    with open(RUNS / run / 'events.jsonl', 'rb') as f:
        seen = set()
        for line in f:
            if b'"kind": "state"' not in line:
                continue
            t = re.search(rb'"turn": (\d+), "unit_', line)
            if not t or int(t.group(1)) in seen:
                continue
            turn = int(t.group(1))
            seen.add(turn)
            if turn < 100:
                continue
            if turn > 175:
                break
            e = json.loads(line)
            if not (e.get('spy_capacity') or 0) > 0:
                continue
            if any(any(b.get('t') == 'UNIT_SPY' for b in c.get('buildable') or [])
                   for c in e['cities']):
                turns.append(turn)
    if len(turns) > PER_GAME:
        step = len(turns) / PER_GAME
        turns = [turns[int(i * step)] for i in range(PER_GAME)]
    return turns


def cut(run, turn):
    """Rows through the turn's first state row, and that row."""
    rows, last = [], None
    with open(RUNS / run / 'events.jsonl', errors='replace') as f:
        for line in f:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > turn:
                break
            rows.append(line)
            if e.get('kind') == 'state' and e.get('turn') == turn:
                last = e
                break
    return ''.join(rows).encode(), last


def production(row, names):
    return sorted(f"{names.get(o.get('subject'), o.get('subject'))}:{o.get('verb')}"
                  for o in row.get('payload', {}).get('orders', []) if o.get('kind') == 'produce')


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data, last = cut(case['run'], case['turn'])
        if last is None:
            raise ValueError('no open-window state row in the turn')
        names = {c['id']: c['name'] for c in last['cities']}
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'],
                                 'cut': "after the turn's first state row"},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                  'board': {'producing': {c['name']: c.get('producing') for c in last['cities']},
                            'spy_menu': sorted(c['name'] for c in last['cities']
                                               if any(b.get('t') == 'UNIT_SPY' for b in c.get('buildable') or [])),
                            'spies': sum(u.get('kind') == 'UNIT_SPY' for u in last.get('units') or []),
                            'spy_capacity': last.get('spy_capacity'),
                            'cities': len(last['cities']), 'gold': last.get('gold')},
                  'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', 'science']
            if header.get('civ'):
                cmd += ['--civ', header['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if 'science-denial-trains-spies:' in line]
            row['production'] = production(row, names)
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['production_changed'] = off['production'] != on['production']
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    cases = [{'run': r, 'civ': c, 'turn': t} for r, c in GAMES for t in windows(r)]
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': cases,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    with ThreadPoolExecutor(JOBS) as pool:
        results = list(pool.map(lambda ic: one(*ic), enumerate(cases)))
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': 0, 'changed_production_reads': 0, 'on_gene_lines': 0, 'off_gene_lines': 0,
             'on_passes': 0}
    for r in results:
        c = r['case']
        if r.get('error'):
            print(c['run'], c['turn'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            off, on = v['arms']
            total['changed_order_reads'] += bool(v['orders_changed'])
            total['changed_production_reads'] += bool(v['production_changed'])
            total['on_gene_lines'] += len(on['journal_gene'])
            total['off_gene_lines'] += len(off['journal_gene'])
            print(f"{c['run'][-16:]} t{c['turn']:<3} {'CHANGED' if v['orders_changed'] else 'same   '} "
                  f"gene lines {len(on['journal_gene'])}")
            for line in on['journal_gene']:
                print('      ', line[:220])
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
