"""Paired decider queries on the two captured live cold-start boards.

`capital-leaves-the-frost` is the only bit that varies. Each case is a
committed fixture under `data/fixtures/capital_frost/`: the live run's turn-1
seat/state/tiles events from before its `found` line, byte for byte. Both arms
run one frozen ci-profile `civvis_orders` built from the branch (base revision
4cde232, the revision both live games played) with that run's own requested
genome (`summary.json` `forced`, each as `--with`). The off arm must reproduce
the live founding; the on arm is the gene's proposal on the same input.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'capital-leaves-the-frost'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CASES = [
    {'run': 'civvis-20261104T054226Z', 'turn': 1, 'live_founding': [26, 6],
     'fixture': 'data/fixtures/capital_frost/snow_start_20261104T054226Z.jsonl'},
    {'run': 'civvis-20261104T015124Z', 'turn': 1, 'live_founding': [60, 37],
     'fixture': 'data/fixtures/capital_frost/tundra_start_20261104T015124Z.jsonl'},
]


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        summary = json.loads((Path.home() / 'civvis-civ6-runs/control' / case['run']
                              / 'summary.json').read_text())
        forced = list(summary['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data = (REPO / case['fixture']).read_bytes()
        record = {'descriptor': {'fixture': case['fixture'], 'turn': case['turn']},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', 'domination',
                   '--turn', str(case['turn'])]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=300)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]')]
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
        off, on = record['arms']
        # Control: the off arm reproduces the live founding (the `found` event).
        founded = [[o['x'], o['y']] for o in off.get('payload', {}).get('orders', [])
                   if o['verb'] == 'FOUND_CITY']
        record['off_reproduces_live_founding'] = founded == [case['live_founding']]
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['planned_actions_changed'] = (off.get('payload', {}).get('decision', {}).get('native_actions')
                                             != on.get('payload', {}).get('decision', {}).get('native_actions'))
        record['journal_changed'] = off['journal'] != on['journal']
        record['complete'] = (record['off_reproduces_live_founding']
                              and all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms']))
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        for v in r['reads']:
            for a in v['arms']:
                orders = a.get('payload', {}).get('orders', [])
                print(r['case']['run'], a['arm'], 'exit', a['exit'],
                      [(o['verb'], o['x'], o['y']) for o in orders if o['kind'] == 'unit'])
        if r.get('error'):
            print(r['case']['run'], 'ERROR', r['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
