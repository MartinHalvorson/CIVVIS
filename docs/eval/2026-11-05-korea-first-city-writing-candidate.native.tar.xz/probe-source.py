"""One fixed-input candidate comparison; never sends orders to the game."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys
BASE=Path(__file__).parent;REPO=Path.home()/'civvis-korea-first-city-writing-d4ad';sys.path.insert(0,str(REPO/'tools'))
from civ6_captured_read_replay import expanded_reads
from civ6_ladder import decider_genome
from civ6_decision_trace import exact_fact
from native_build_artifact import verify
p=argparse.ArgumentParser();p.add_argument('--artifact',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=a.output.resolve();root.mkdir()
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();tag='science-writing-before-the-luxury'
try:
 protocol=read(BASE/'korea-first-city-writing-candidate-protocol.json');tests={'lib':['ai::advanced::science_writing_before_the_luxury::tests']};receipt=verify(REPO,a.artifact,protocol['candidate_source'],json.dumps(tests),'1.97.1');assert receipt['tests']==[{'target':'lib','filter':tests['lib'][0],'passed':11}]
 source=BASE/'korea-first-city-writing-native-090547-t16';data=(source/'input.events.jsonl').read_bytes();assert sha(data)==protocol['input_sha256'];context=read(source/'observed-context.json');genome=context['actual_genome'];assert all(tag in genome[k] for k in ['forced','treatments'])
 (root/'events.jsonl').write_bytes(data);shutil.copy2(BASE/'korea-first-city-writing-candidate-protocol.json',root/'protocol.json');shutil.copy2(source/'finding.json',root/'source.json');shutil.copy2(a.artifact/'receipt.json',root/'build-receipt.json')
 binary=a.artifact/'civvis_orders';assert sha(binary.read_bytes())==receipt['binaries']['civvis_orders'];binary.chmod(binary.stat().st_mode|0o100);shutil.copy2(binary,root/'probe-binary');digest=sha((root/'probe-binary').read_bytes());assert digest==receipt['binaries']['civvis_orders']
 common=root/'current-capture';references={};pairs=[];effects=[]
 for repeat in [1,2]:
  pairroot=root/f'repeat-{repeat}';pairroot.mkdir();arms=[]
  for label in ['off','on']:
   directory=pairroot/label;directory.mkdir();(directory/'events.jsonl').write_bytes(data);assert not common.exists()
   cmd=[str(root/'probe-binary'),'--mirror',str(directory),'--turn','16','--victory','science','--civ','CIVILIZATION_KOREA','--explain','--serve','--fresh-board','--capture-inputs',str(common)]
   for gene in genome['forced']:
    if gene!=tag:cmd+=['--with',gene]
   if label=='on':cmd+=['--with',tag]
   (directory/'launch-command.json').write_text(json.dumps({'argv':cmd,'cwd':str(REPO)},indent=2)+'\n')
   proc=subprocess.run(cmd,cwd=REPO,input='16\n',text=True,capture_output=True,timeout=180);(directory/'stdout.json').write_text(proc.stdout);(directory/'stderr.log').write_text(proc.stderr);assert proc.returncode==0,(label,proc.returncode,proc.stderr[-1000:])
   payload=json.loads(proc.stdout);assert payload['turn']==16 and (payload['decision']['turn'],payload['decision']['frame'])==(16,0) and payload['decision']['victory_portfolio']['assigned_target']=='science';reads=expanded_reads(payload['input_capture']);assert reads and all(b==data for b in reads);actual=decider_genome(directory/'stderr.log');assert actual
   stable={k:payload[k] for k in ['orders','decision']}
   if repeat==1:references[label]=stable
   else:assert exact_fact(references[label],stable),f'{label} repeated full reply differs'
   research=[o['verb'] for o in payload['orders'] if o['kind']=='research'];moved=directory/'input-capture';shutil.move(str(common),str(moved))
   arms.append({'arm':label,'exit':0,'argv':cmd,'cwd':str(REPO),'genome':actual,'payload':payload,'actual_read_count':len(reads),'capture_relocated_to':str(moved),'research':research,'binary_sha256':digest});print(json.dumps({'repeat':repeat,'arm':label,'actual_reads':len(reads),'research':research}),flush=True)
  off,on=arms
  for field in ['forced','treatments']:
   assert set(on['genome'][field])-set(off['genome'][field])=={tag} and not set(off['genome'][field])-set(on['genome'][field])
  assert exact_fact({k:v for k,v in off['genome'].items() if k not in ['forced','treatments']},{k:v for k,v in on['genome'].items() if k not in ['forced','treatments']})
  effect={'repeat':repeat,'off_research':off['research'],'on_research':on['research'],'contrast_observed':off['research']!=['TECH_WRITING'] and on['research']==['TECH_WRITING'],'historical_sailing_control_matches':off['research']==['TECH_SAILING']};effects.append(effect)
  record={'execution_complete':True,'source_commit':protocol['candidate_source'],'binary_sha256':digest,'input_sha256':sha(data),'arms':arms,'effect':effect,'scope':'Same candidate bytes and captured native public input, only existing Writing flag differs. Fresh private planner proposals, not original private-state replay or native execution.'};path=pairroot/'pair.json';path.write_text(json.dumps(record,indent=2)+'\n');pairs.append(str(path))
 assert sha((root/'probe-binary').read_bytes())==digest
 (root/'result.json').write_text(json.dumps({'execution_complete':True,'contrast_observed_in_both_repetitions':all(x['contrast_observed'] for x in effects),'source_commit':protocol['candidate_source'],'binary_sha256':digest,'effects':effects,'pairs':pairs,'scope':'All four scheduled roles retained. No source/input change, later input selection, native execution, timing, survival or win-rate claim.'},indent=2)+'\n')
except BaseException as error:
 (root/'failure.json').write_text(json.dumps({'execution_complete':False,'error':repr(error),'scope':'Failed attempt retained; no activation/strength claim, remaining scheduled roles not silently treated as executed.'},indent=2)+'\n');raise
