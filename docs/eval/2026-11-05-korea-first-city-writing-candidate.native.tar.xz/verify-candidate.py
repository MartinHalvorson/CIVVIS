"""Portable independent validation of the completed Writing comparison."""
from pathlib import Path
import argparse,copy,hashlib,json,sys
p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();root=a.root.resolve();sys.path.insert(0,str(root/'verification-tools'))
from civ6_decision_trace import validate_input_capture,captured_input,exact_fact
load=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
result=load(root/'result.json');assert result['execution_complete'] is True
protocol=load(root/'protocol.json');receipt=load(root/'build-receipt.json');source=protocol['candidate_source'];assert result['source_commit']==receipt['source']['sha']==source
assert receipt['status']=='complete' and receipt['architecture']=='arm64'
selected=[t for t in receipt['tests'] if t['target']=='lib' and t['filter']=='ai::advanced::science_writing_before_the_luxury::tests'];assert len(selected)==1 and selected[0]['passed']==11
binary=receipt['binaries']['civvis_orders'];assert result['binary_sha256']==binary
if (root/'probe-binary').exists():assert sha((root/'probe-binary').read_bytes())==binary
frozen=(root/'events.jsonl').read_bytes();assert sha(frozen)==protocol['input_sha256'];tag=protocol['existing_tag'];references={};rows=[];effects=[]
for repeat in [1,2]:
 pair=load(root/f'repeat-{repeat}/pair.json');assert pair['execution_complete'] is True and pair['source_commit']==source and pair['binary_sha256']==binary and pair['input_sha256']==sha(frozen)
 assert [x['arm'] for x in pair['arms']]==['off','on'];genomes={};research={}
 for arm in pair['arms']:
  name=arm['arm'];directory=root/f'repeat-{repeat}'/name;payload=load(directory/'stdout.json');assert exact_fact(payload,arm['payload']) and arm['exit']==0
  assert payload['turn']==16 and (payload['decision']['turn'],payload['decision']['frame'])==(16,0) and payload['decision']['victory_portfolio']['assigned_target']=='science'
  capture=copy.deepcopy(payload['input_capture']);original=Path(arm['argv'][arm['argv'].index('--capture-inputs')+1]);suffix=Path(capture['directory']).relative_to(original);capture['directory']=str(directory/'input-capture'/suffix);validate_input_capture(capture);assert capture['complete'] is True
  actual=[]
  for read in capture['reads']:actual.extend([captured_input(capture,read['snapshot_id'])]*read['count'])
  assert actual and len(actual)==arm['actual_read_count'] and all(data==frozen for data in actual)
  raw_genome=None
  for line in (directory/'stderr.log').read_text().splitlines():
   try:g=json.loads(line)
   except ValueError:continue
   if g.get('kind')=='genome':raw_genome=g;break
  assert raw_genome is not None and all(exact_fact(raw_genome.get(k),v) for k,v in arm['genome'].items())
  assert all((tag in raw_genome[k])==(name=='on') for k in ['forced','treatments']);genomes[name]=raw_genome
  stable={k:payload[k] for k in ['orders','decision']}
  if repeat==1:references[name]=stable
  else:assert exact_fact(stable,references[name]),'Repeated full reply differs'
  research[name]=[o['verb'] for o in payload['orders'] if o['kind']=='research'];assert research[name]==arm['research']
  rows.append({'repeat':repeat,'arm':name,'actual_reads':len(actual),'input_sha256':sha(frozen),'research':research[name]})
 for field in ['forced','treatments']:
  assert set(genomes['on'][field])-set(genomes['off'][field])=={tag} and not set(genomes['off'][field])-set(genomes['on'][field])
 assert exact_fact({k:v for k,v in genomes['off'].items() if k not in ['forced','treatments']},{k:v for k,v in genomes['on'].items() if k not in ['forced','treatments']})
 effects.append({'repeat':repeat,'contrast_observed':research['off']!=['TECH_WRITING'] and research['on']==['TECH_WRITING'],'historical_sailing_matches':research['off']==['TECH_SAILING']})
report={'verified':True,'contrast_observed_in_both_repetitions':all(e['contrast_observed'] for e in effects),'candidate_source':source,'binary_sha256':binary,'focused_mac_tests_passed':11,'rows':rows,'effects':effects,'scope':'Same tested candidate and fixed native public bytes; only existing Writing flag differs. Fresh private-planner proposals. This does not establish original private-state parity, native execution, timing, survival or victory strength.'}
assert report['contrast_observed_in_both_repetitions']==result['contrast_observed_in_both_repetitions']
(root/'independent-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
