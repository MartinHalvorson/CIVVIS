"""Paired decider queries on live frames of five T8 benchmark games of
2026-11-26 (Deity 6p, Online, Religion seats) in which a land force kept
mustering for a siege ("will muster for Siege ...") while the plan read
"recovery | at war and losing ground at home" and our own cities were under
attack.

`recovery-holds-the-muster` is the only bit that varies. Each case is a live
run's own events.jsonl cut after turn N+1 (every row through the first rows
of the next turn), replayed at turn N. Both arms run one frozen
`civvis_orders --resumed` built from the branch, with that run's own
requested genome (why.log line 1 `forced`, each as `--with`); the on arm adds
`--with recovery-holds-the-muster`.

Cases: turns at which the live game logged a siege muster under Recovery.

Read per arm: the unit orders, the "will muster for Siege" task-force lines
and the gene's own journal lines. This records proposal activation on
captured live input only. It does not execute in Civ VI and makes no
strength claim.
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = 'recovery-holds-the-muster'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

GAMES = [
    ('civvis-t8-20261126T122815Z', 'religious', 'CIVILIZATION_ARABIA', [45, 48, 76]),
    ('civvis-t8-20261126T154251Z', 'religious', 'CIVILIZATION_ETHIOPIA', [94, 110, 122]),
    ('civvis-t8-20261126T121510Z', 'religious', 'CIVILIZATION_ETHIOPIA', [88, 100, 125]),
    ('civvis-t8-20261126T153826Z', 'religious', 'CIVILIZATION_MALI', [54, 58]),
    ('civvis-t8-20261126T090737Z', 'religious', 'CIVILIZATION_ARABIA', [77, 82]),
]
CASES = [{'run': r, 'victory': v, 'civ': c, 'turn': t} for r, v, c, turns in GAMES for t in turns]


def cut(run, turn):
    """Rows through turn+1 (the replay recipe), and the turn's last state row."""
    rows, last = [], None
    with open(RUNS / run / 'events.jsonl', errors='replace') as f:
        for line in f:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > turn + 1:
                break
            rows.append(line)
            if e.get('kind') == 'state' and e.get('turn') == turn:
                last = e
    return ''.join(rows).encode(), last


def production(row, names):
    """Unit orders by kind (the muster's units move elsewhere when held)."""
    out = {}
    for o in row.get('payload', {}).get('orders', []):
        if o.get('kind') in ('move', 'attack', 'fortify', 'unit'):
            out.setdefault(str(o.get('subject')), []).append(
                f"{o.get('verb')}:{o.get('x')},{o.get('y')}")
    return out


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data, last = cut(case['run'], case['turn'])
        names = {c['id']: c['name'] for c in (last or {}).get('cities', [])}
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'cut': 'after turn+1'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                  'board': {'cities': len((last or {}).get('cities', []))},
                  'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', case['victory'], '--civ', case['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=600)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if GENE + ':' in line]
            row['muster_lines'] = [line for line in journal if 'will muster for Siege' in line]
            row['strategy_lines'] = [line for line in journal if 'Grand strategy:' in line]
            row['production'] = production(row, names)
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['production_changed'] = {
            city: {'off': off['production'].get(city), 'on': on['production'].get(city)}
            for city in sorted(set(off['production']) | set(on['production']))
            if off['production'].get(city) != on['production'].get(city)}
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
             'on_gene_lines': 0, 'off_gene_lines': 0, 'on_muster_lines': 0, 'off_muster_lines': 0}
    for r in results:
        c = r['case']
        if r.get('error'):
            print(c['run'], c['turn'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            off, on = v['arms']
            for arm, name in ((off, 'off'), (on, 'on')):
                total[f'{name}_gene_lines'] += len(arm.get('journal_gene', []))
                total[f'{name}_muster_lines'] += len(arm.get('muster_lines', []))
            print(f"{c['run'][-16:]} t{c['turn']:<3} {'CHANGED' if v.get('orders_changed') else 'same   '} "
                  f"muster off {len(off.get('muster_lines', []))} on {len(on.get('muster_lines', []))} "
                  f"gene lines {len(on.get('journal_gene', []))} units changed {len(v.get('production_changed', {}))}")
            for line in on.get('strategy_lines', [])[:1] + on.get('journal_gene', [])[:2]:
                print('      ', line[:230])
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
