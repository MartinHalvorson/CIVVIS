"""Paired decider queries for `spies-steal-the-lead` on captured live boards.

Each case is a live Deity Korea Science game (Online) at a turn where a Spy
of ours stood in a rival's city with UNITOPERATION_SPY_STEAL_TECH_BOOST on the
host's menu and the live seat ordered SPY_LISTENING_POST or SPY_GAIN_SOURCES
(orders.sqlite). The board is the run's events.jsonl cut at the first state
frame of that turn (frame 0), the run's other files linked beside it. Both
arms run one frozen ci-profile `civvis_orders` built from the branch with the
run's own requested genome (`summary.json` `forced`, each as `--with`, less
tags the binary does not know); the on arm adds `--with spies-steal-the-lead`.
The off arm must reproduce the live order for that Spy; the on arm records
the gene's proposal on the same input.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
REVISION = sys.argv[4]  # the commit the binary was built from
GENE = 'spies-steal-the-lead'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CASES = [
    {'run': 'civvis-20261105T034948Z', 'turn': 124, 'spy_civ6': 5242917, 'live': 'SPY_LISTENING_POST'},
    {'run': 'civvis-20261105T034948Z', 'turn': 138, 'spy_civ6': 5898257, 'live': 'SPY_LISTENING_POST'},
    {'run': 'civvis-20261105T020911Z', 'turn': 124, 'spy_civ6': 3866639, 'live': 'SPY_LISTENING_POST'},
    {'run': 'civvis-20261104T213449Z', 'turn': 132, 'spy_civ6': 5505060, 'live': 'SPY_LISTENING_POST'},
    {'run': 'civvis-20261105T031845Z', 'turn': 119, 'spy_civ6': 3670035, 'live': 'SPY_LISTENING_POST'},
    {'run': 'civvis-20261105T031845Z', 'turn': 125, 'spy_civ6': 4194323, 'live': 'SPY_GAIN_SOURCES'},
    {'run': 'civvis-20261105T033244Z', 'turn': 142, 'spy_civ6': 4849713, 'live': 'SPY_LISTENING_POST'},
    {'run': 'civvis-20261105T040135Z', 'turn': 145, 'spy_civ6': 3997718, 'live': 'SPY_LISTENING_POST'},
    # Training cases: Spy capacity unfilled, no Spy queued, no rival project landed.
    {'run': 'civvis-20261104T213449Z', 'turn': 103, 'kind': 'train'},
    {'run': 'civvis-20261105T002152Z', 'turn': 101, 'kind': 'train'},
    {'run': 'civvis-20261105T031845Z', 'turn': 105, 'kind': 'train'},
]


def known_tags():
    """Gene tags in the binary's own GENES table (genes.rs at REVISION)."""
    import re
    text = subprocess.run(['git', '-C', str(REPO), 'show', f'{REVISION}:src/ai/advanced/genes.rs'],
                          capture_output=True, text=True, check=True).stdout
    return set(re.findall(r'Gene \{ tag: "([^"]+)"', text))


def cut(src, dst, turn):
    with open(src, 'rb') as f, open(dst, 'wb') as g:
        for line in f:
            g.write(line)
            if line.startswith(b'{"available_policies"'):
                try:
                    if json.loads(line).get('turn') == turn:
                        break
                except Exception:
                    pass


def spy_orders(payload):
    return [o for o in payload.get('orders', []) if str(o.get('verb', '')).startswith('SPY_')]


def one(index, case, known):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        run = RUNS / case['run']
        summary = json.loads((run / 'summary.json').read_text())
        forced = list(summary['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        dropped = [t for t in forced if known and t not in known]
        forced = [t for t in forced if not known or t in known]
        record = {'descriptor': {'run': case['run'], 'turn': case['turn']},
                  'dropped_unknown_tags': dropped, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            for f in run.iterdir():
                if f.name == 'events.jsonl' or f.suffix == '.png' or not f.is_file():
                    continue
                os.symlink(f, mirror / f.name)
            cut(run / 'events.jsonl', mirror / 'events.jsonl', case['turn'])
            data = (mirror / 'events.jsonl').read_bytes()
            record['bytes'] = len(data)
            record['sha256'] = hashlib.sha256(data).hexdigest()
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', 'science',
                   '--turn', str(case['turn'])]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=1800)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]') and ('Spy' in line or 'spy' in line)]
            record['arms'].append(row)
            for f in mirror.iterdir():
                f.unlink()
            mirror.rmdir()
        off, on = record['arms']
        record['off_spy_orders'] = spy_orders(off.get('payload', {}))
        record['on_spy_orders'] = spy_orders(on.get('payload', {}))
        def trains(payload):
            return [o for o in payload.get('orders', []) if 'UNIT_SPY' in str(o.get('verb', ''))]
        record['off_spy_training'] = trains(off.get('payload', {}))
        record['on_spy_training'] = trains(on.get('payload', {}))
        if case.get('kind') == 'train':
            record['on_trains_a_spy'] = bool(record['on_spy_training']) and not record['off_spy_training']
        else:
            record['off_reproduces_live_order'] = any(o.get('verb') == case['live'] for o in record['off_spy_orders'])
            record['on_steals'] = any(o.get('verb') == 'SPY_STEAL_TECH_BOOST' for o in record['on_spy_orders'])
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    known = known_tags()
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(), 'binary_revision': REVISION,
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(lambda pair: one(pair[0], pair[1], known), enumerate(CASES)))
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'off_reproduces_live': sum(v.get('off_reproduces_live_order', False) for r in results for v in r['reads']),
               'on_steals': sum(v.get('on_steals', False) for r in results for v in r['reads']),
               'train_cases': sum(1 for c in CASES if c.get('kind') == 'train'),
               'on_trains_a_spy': sum(v.get('on_trains_a_spy', False) for r in results for v in r['reads']),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        for v in r['reads']:
            print(r['case']['run'], r['case']['turn'], 'live', r['case'].get('live', 'train'),
                  'train off/on', len(v.get('off_spy_training', [])), len(v.get('on_spy_training', [])),
                  'off', [(o['verb'], o.get('x'), o.get('y')) for o in v.get('off_spy_orders', [])],
                  'on', [(o['verb'], o.get('x'), o.get('y')) for o in v.get('on_spy_orders', [])])
        if r.get('error'):
            print(r['case']['run'], 'ERROR', r['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
