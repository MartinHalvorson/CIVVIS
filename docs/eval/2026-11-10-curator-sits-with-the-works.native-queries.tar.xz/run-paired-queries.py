"""Paired decider queries on captured live Deity Kristina boards.

usage: run-paired-queries.py REPO BINARY OUT GENE RUN:TURN [RUN:TURN...]

A run whose own genome already carried GENE has it removed from both
arms' `--with` list first, so the off arm plays without it.

GENE is the only bit that varies. Each case is a turn of a live Deity Kristina
run. Both arms run one frozen ci-profile `civvis_orders` built from the branch,
on a clone of the run's own `events.jsonl` (hashed below), with that run's own
requested genome (`summary.json` `forced`, each as `--with`), `--victory
culture` and `--resumed`. The on arm adds `--with GENE`.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = sys.argv[4]
CASES = [(case.split(':')[0], int(case.split(':')[1])) for case in sys.argv[5:]]
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CONTROL = Path.home() / 'civvis-civ6-runs/control'


def changed_orders(off, on):
    a = [json.dumps(o, sort_keys=True) for o in off.get('orders', [])]
    b = [json.dumps(o, sort_keys=True) for o in on.get('orders', [])]
    return {'off_only': [json.loads(o) for o in a if o not in b],
            'on_only': [json.loads(o) for o in b if o not in a]}


def note_bits(payload, words):
    note = payload.get('note', '') or ''
    return [bit for bit in note.split('; ') if any(word in bit for word in words)]


DIGESTS = {}


def digest(run):
    if run not in DIGESTS:
        data = (CONTROL / run / 'events.jsonl').read_bytes()
        DIGESTS[run] = (hashlib.sha256(data).hexdigest(), len(data))
    return DIGESTS[run]


def one(index, run, turn):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': {'run': run, 'turn': turn}, 'reads': []}
    try:
        forced = list(json.loads((CONTROL / run / 'summary.json').read_text())['forced'])
        # A run that already carried the gene plays its off arm without it;
        # both arms otherwise keep the run's own genome.
        stripped = GENE in forced
        forced = [tag for tag in forced if tag != GENE]
        result['case']['gene_stripped_from_forced'] = stripped
        sha, size = digest(run)
        record = {'descriptor': {'run': run, 'file': 'events.jsonl', 'turn': turn},
                  'bytes': size, 'sha256': sha, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            subprocess.run(['cp', '-c', str(CONTROL / run / 'events.jsonl'),
                            str(mirror / 'events.jsonl')], check=True)
            cmd = [str(BINARY), '--explain', '--mirror', str(mirror), '--victory', 'culture',
                   '--turn', str(turn), '--resumed']
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]')]
            record['arms'].append(row)
            shutil.rmtree(mirror)
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['order_diff'] = changed_orders(off.get('payload', {}), on.get('payload', {}))
        words = ('work_sale', 'writer_palace', 'great_people_orders')
        record['off_note'] = note_bits(off.get('payload', {}), words)
        record['on_note'] = note_bits(on.get('payload', {}), words)
        gene_lines = ('culture-digs-every-site', 'curator-sits-with-the-works',
                      'great-works-never-wait', 'Pingala', 'Archaeolog', 'archaeolog')
        record['on_gene_journal'] = [line for line in on.get('journal', [])
                                     if any(word in line for word in gene_lines)]
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'inputs': {run: dict(zip(('sha256', 'bytes'), digest(run))) for run, _ in CASES},
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, run, turn) for i, (run, turn) in enumerate(CASES)]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        for v in r['reads']:
            print(r['case']['run'][16:], r['case']['turn'], 'changed', v.get('orders_changed'),
                  json.dumps(v.get('order_diff'))[:700])
            for line in v.get('on_gene_journal', [])[:6]:
                print('   on:', line[:260])
            if v.get('off_note') != v.get('on_note'):
                print('   notes off', v.get('off_note'), 'on', v.get('on_note'))
        if r.get('error'):
            print(r['case'], 'ERROR', r['error'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
