"""Same fixed actual final-read prefix; proposal activation, never a native game."""
from pathlib import Path
import json,sys,hashlib,subprocess,shutil,collections,tarfile
ROOT=Path.home();TREE=ROOT/'civvis-modernization-prices-the-path-28e4';OUT=Path(__file__).parent/'probe';OUT.mkdir(exist_ok=False);TAG='modernization-prices-the-path';NATIVE=ROOT/'civvis-civ6-runs/control/civvis-20261106T115056Z';sys.path.insert(0,str(TREE/'tools'))
from civ6_decision_trace import captured_input,validate_input_capture
record=next(json.loads(l) for l in (NATIVE/'decisions.jsonl').open() if (json.loads(l)['decision']['turn'],json.loads(l)['decision']['frame'])==(68,0))
capture=record['input_capture'];data=captured_input(capture,capture['reads'][-1]['snapshot_id']);(OUT/'input.events.jsonl').write_bytes(data);binary=TREE/'target/ci/civvis_orders';summary=json.loads((NATIVE/'summary.json').read_text());assert TAG not in summary['genome_treatments']['treatments'];assert TAG not in summary['forced']+summary['withheld'];result=[]
source={'scope':'New candidate, cold fixed final-read proposal probe. NOT original changing-read/history reproduction, applied orders, native strength or saved turns.','native_run':NATIVE.name,'native_decision_receipt':record['sha256'],'native_input_capture':capture,'fixed_input_bytes':len(data),'fixed_input_sha256':hashlib.sha256(data).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'git_head_at_query':subprocess.check_output(['git','-C',str(TREE),'rev-parse','HEAD'],text=True).strip(),'source_sha256':{p:hashlib.sha256((TREE/p).read_bytes()).hexdigest() for p in ['src/ai/advanced.rs','src/ai/advanced/research.rs','src/ai/advanced/modernization_prices_the_path.rs','src/ai/advanced/genes.rs','src/ai/advanced/treatment_flags.rs','src/ai/advanced/war_plans.rs']}}
(OUT/'source.json').write_text(json.dumps(source,indent=2)+'\n')
for number,arm in enumerate(['off','on','on','off']):
 working=OUT/'query';working.mkdir();(working/'events.jsonl').write_bytes(data)
 argv=[str(binary),'--mirror',str(working),'--turn','68','--fresh-board','--explain','--victory','science','--civ','CIVILIZATION_INDONESIA','--capture-inputs',str(working/'recaptured')]
 for t in sorted(summary['forced']):argv+=['--with',t]
 for t in sorted(summary['withheld']):argv+=['--without',t]
 if arm=='on':argv+=['--with',TAG]
 completed=subprocess.run(argv,cwd=TREE,capture_output=True,text=True,timeout=180)
 (working/'stdout.json').write_text(completed.stdout);(working/'stderr.log').write_text(completed.stderr);assert completed.returncode==0,(arm,completed.stderr[-2000:]);payload=json.loads(completed.stdout);assert payload['turn']==68 and payload['decision']['frame']==0
 genomes=[]
 for line in completed.stderr.splitlines():
  try:v=json.loads(line)
  except ValueError:continue
  if v.get('kind')=='genome':genomes.append(v)
 assert len(genomes)==1
 actual=payload['input_capture'];validate_input_capture(actual);assert actual['complete'] and actual['reads'];reads=0
 for read in actual['reads']:
  assert 'snapshot_id' in read and captured_input(actual,read['snapshot_id'])==data;reads+=read['count']
 item={'arm':arm,'exit':completed.returncode,'argv':argv,'genome':genomes[0],'payload':payload,'actual_reads':reads,'archive_directory':f'{number}-{arm}'};result.append(item);(working/'result.json').write_text(json.dumps(item,indent=2)+'\n');working.rename(OUT/f'{number}-{arm}')
 print(json.dumps({'round':number,'arm':arm,'exit':completed.returncode,'actual_reads':reads,'research':[o for o in payload['orders'] if o['kind']=='research']}),flush=True)
# Validate the actual bit before forming the gate's paired-query records.
for off,on in [(result[0],result[1]),(result[3],result[2])]:
 a,b=dict(off['genome']),dict(on['genome'])
 for field in ['treatments','forced']:
  x,y=a.pop(field),b.pop(field);assert TAG not in x and set(y)==set(x)|{TAG}
 assert a==b
 assert off['payload']['orders']!=on['payload']['orders']
assert result[0]['payload']['orders']==result[3]['payload']['orders'];assert result[1]['payload']['orders']==result[2]['payload']['orders']
for index,(off,on) in enumerate([(result[0],result[1]),(result[3],result[2])]):
 pair={'complete':True,'reads':[{'complete':True,'sha256':source['fixed_input_sha256'],'bytes':len(data),'arms':[off,on]}]};(OUT/f'pair-{index}.json').write_text(json.dumps(pair,indent=2)+'\n')
(OUT/'completed.json').write_text(json.dumps({'scope':source['scope'],'all_exits':0,'actual_reads':[x['actual_reads'] for x in result],'tag':TAG,'pairs':2,'observed_one_bit_delta':True},indent=2)+'\n')
(OUT/'probe-driver.py').write_bytes(Path(__file__).read_bytes())
archive=TREE/'docs/eval/2026-11-06-modernization-path.action-pairs.tar.xz'
with tarfile.open(archive,'w:xz') as tar:
 for p in sorted(OUT.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(OUT)),recursive=False)
artifact={'kind':'captured_native_action_pairs_v1','tag':TAG,'archive':{'path':str(archive.relative_to(TREE)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'members':['pair-0.json','pair-1.json'],'scope':source['scope']}
path=TREE/'docs/gene_screens/fires/modernization-prices-the-path.action-pairs.json';path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(artifact,indent=2)+'\n');print('COMPLETE',flush=True)
