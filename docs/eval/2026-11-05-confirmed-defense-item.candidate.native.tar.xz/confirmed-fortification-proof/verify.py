"""Verify recorded fortification proposals without rerunning queries."""
from pathlib import Path
import json,hashlib,copy,sys,datetime
r=Path(sys.argv[1]).resolve();b=Path(__file__).parent;read=lambda p:json.loads(p.read_text());sha=lambda x:hashlib.sha256(x).hexdigest();tools=r/'verification-tools'
if not tools.exists():tools=Path.home()/'civvis-confirmed-defense-keeps-its-item-7c81/tools'
sys.path.insert(0,str(tools));from civ6_decision_trace import captured_input,validate_input_capture
protocol=read(r/'protocol.json');receipt=read(r/'build-receipt.json');result=read(r/'result.json');assert result['complete'] and result['candidate_walls_proposals_observed'];assert receipt['source']['sha']==protocol['candidate_source'];assert [x['passed'] for x in receipt['tests']]==protocol['expected_pass_counts']==[5,3,12,29];assert receipt['architecture']=='arm64' and receipt['rustc'].startswith('rustc 1.97.1 ')
old=r/'original-source-proposals'
if not old.exists():old=Path(protocol['source_witness'])
source=read(old/'source.json');ctx=read(old/'original-context.json');record=read(r/'original-record.json');unsigned={k:v for k,v in record.items() if k!='sha256'};assert sha(json.dumps(unsigned,sort_keys=True,separators=(',',':'),allow_nan=False).encode())==record['sha256']=='47ddc1ea686e254392990291eb64f5e3a2d6c98ae5f8bf3c0179375c87b9948c';assert record['binary_on_disk_sha256']==ctx['binary_sha256']=='88257cc63ce3eccfdd4aeec1250fbca514af99de3e614cdbf899a61064688e2c'
cap=copy.deepcopy(record['input_capture'])
if (r/'original-capture').exists():cap['directory']=str(r/'original-capture')
else:
 seals=read(b/'campus-parity-native-matrix-20261105T175245Z/native-02-on/sealed-native-captures.json');cap['directory']=next(x['sealed_directory'] for x in seals if x['source']==cap['directory'])
data=(r/'events.jsonl').read_bytes();assert sha(data)==source['input_sha256']=='0f6804643755d1127b92e9c2f6215a4136ad58ecd37f1b74b1ac300413bce971'
def actual(c,expected):
 validate_input_capture(c);assert c['complete'];count=0
 for x in c['reads']:assert captured_input(c,x['snapshot_id'])==expected;count+=x['count']
 return count
assert actual(cap,data)==18;events=[json.loads(l) for l in data.splitlines()];state=[e for e in events if e.get('kind')=='state'][-1];assert (state['turn'],state['frame'])==(25,0);city=next(c for c in state['cities'] if c['id']==65536);assert city['damage']==0 and not city.get('producing');assert any(q['t']=='BUILDING_WALLS' and q['p']==4 for q in city['buildable']);rows=[];vectors=[];forced=[]
for root,roles,expected in [(old,['01-original','02-original'],'UNIT_SLINGER'),(r,['01-candidate','02-candidate'],'BUILDING_WALLS')]:
 replies=[]
 for role in roles:
  out=root/role;d=read(out/'stdout.json');v=read(out/'verified.json');g=next(json.loads(l) for l in (out/'stderr.log').read_text().splitlines() if l.startswith('{') and json.loads(l).get('kind')=='genome');assert {k:g.get(k) for k in v['genome']}==v['genome'];assert 'garrison-under-fire' in g['treatments'];forced.append(set(g['forced']));c=copy.deepcopy(d['input_capture']);c['directory']=str(out/'capture');assert actual(c,data)==17;assert (d['decision']['turn'],d['decision']['frame'])==(25,0);orders=[o for o in d['orders'] if o.get('subject')==65536 and o.get('kind')=='produce'];assert len(orders)==1 and orders[0]['verb']==expected;cmd=read(out/'command.json');argv=list(cmd['argv']);argv[0]='BINARY'
  for flag in ['--mirror','--capture-inputs']:argv[argv.index(flag)+1]='ROLE_PATH'
  vectors.append(argv);replies.append({k:d[k] for k in ['orders','decision']});rows.append({'role':role,'actual_reads':17,'target_orders':orders,'stdout_sha256':sha((out/'stdout.json').read_bytes()),'stderr_sha256':sha((out/'stderr.log').read_bytes())})
 assert replies[0]==replies[1]
assert all(x==vectors[0] for x in vectors) and all(x==forced[0] for x in forced)
if (r/'probe-binary').exists():assert sha((r/'probe-binary').read_bytes())==receipt['binaries']['civvis_orders']
report={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verified':True,'candidate_source':protocol['candidate_source'],'binary_sha256':receipt['binaries']['civvis_orders'],'original_actual_reads':18,'proposal_actual_reads':68,'focused_native_tests':49,'rows':rows,'full_decision_order_repeats_equal':True,'normalized_cli_vectors_and_explicit_forced_profile_equal':True,'scope':'Native quoted legal Walls selected by the refined candidate versus original-source Slinger. Source defaults/versions and original private histories are not held identical; no isolated-source causal strength, native construction or saved-capital claim.'};(r/'independent-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['verified','focused_native_tests','original_actual_reads','proposal_actual_reads','binary_sha256']}))
