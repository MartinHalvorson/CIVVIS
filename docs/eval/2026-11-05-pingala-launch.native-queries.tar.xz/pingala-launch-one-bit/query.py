"""Source-bound offline proposals; preserve actual reads, replies and EOF exits."""
from pathlib import Path
import copy, datetime, hashlib, json, os, shutil, subprocess, sys

base = Path(__file__).parent
repo = Path.home() / 'civvis-pingala-follows-the-first-launch-0801'
sys.path.insert(0, str(repo / 'tools'))
import civ6_captured_read_replay as replay
from civ6_ladder import decider_genome

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

subprocess.run(['/usr/sbin/taskpolicy', '-B', '-t', '0', '-l', '0', '-p', str(os.getpid())], capture_output=True)
q = Path((base / 'governor-launch-control-latest-path.txt').read_text().strip())
gate = json.loads((base / 'governor-launch-v2-local-validation.json').read_text())
assert gate['passed'] and gate['governor_tests_passed'] == 19
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == gate['source_head']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
for name, digest in gate['compiled_input_hashes'].items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == digest, name
binary = Path(gate['binary'])
assert hashlib.sha256(binary.read_bytes()).hexdigest() == gate['binary_sha256']
original = json.loads((q / 'context.json').read_text())
qualified = json.loads((q / 'qualified-original-controls.json').read_text())
assert qualified['passed']
mapping = {x['source']: Path(x['sealed_directory']) for x in qualified['sealed_captures']}
all_records = replay.select_records(q / 'raw-native-decisions.jsonl', 154, original)
records = all_records[:next(i + 1 for i, x in enumerate(all_records) if replay.frame_key(x) == (154, 0))]
assert len(records) == 393
root = q / 'version-two-one-bit'
root.mkdir(exist_ok=False)
common = root / 'shared-recaptured'
old, tag = 'pingala-follows-research', 'pingala-follows-research-2'
protocol = dict(source_head=gate['source_head'], binary_sha256=gate['binary_sha256'],
    roles=['OFF-0', 'ON-0', 'ON-1', 'OFF-1'], requests=len(records), through=[154, 0],
    common_capture_directory=str(common), selection='Mechanism witness selected from earlier discovery at154/0, not a prospective strength trial.',
    contract='Both arms explicitly withhold v1; only ON forces v2. Same original ordered observations. Every actual read and identity must agree; each process consumes EOF and must exit0. Retain all results, including negative activation.',
    scope='Offline proposals only. No native execution, saved turns or strength estimate.')
save(root / 'protocol.json', protocol)
context = copy.deepcopy(original)
context['processes'][0]['argv'][0] = str(binary)
context['processes'][0]['argv'] += ['--without', old]
context['binary_sha256'] = gate['binary_sha256']
context['provenance'] = dict(kind='local_source_bound_candidate', revision=gate['source_head'], sha256=gate['binary_sha256'])

for role in protocol['roles']:
    directory = root / role
    directory.mkdir()
    arm_context = copy.deepcopy(context)
    if role.startswith('ON'):
        arm_context['processes'][0]['argv'] += ['--with', tag]
    command, cwd = replay.replay_command(arm_context, directory)
    command[command.index('--capture-inputs') + 1] = str(common)
    assert not common.exists()
    save(directory / 'invocation.json', dict(argv=command, cwd=cwd))
    results, feeder, process = [], None, None
    footer = dict(complete=False, exit=None, source_head=gate['source_head'])
    try:
        with (directory / 'stderr.log').open('w') as stderr, (directory / 'replies.jsonl').open('w') as replies:
            process = subprocess.Popen(command, cwd=cwd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                       stderr=stderr, text=True, bufsize=1)
            for record in records:
                key = replay.frame_key(record)
                capture = dict(record['input_capture'], directory=str(mapping[record['input_capture']['directory']]))
                expected = replay.expanded_reads(capture)
                path = directory / 'events.jsonl'
                if path.exists():
                    path.unlink()
                feeder = replay.deliver_reads(path, expected, 120, 'hybrid')
                process.stdin.write(f'{key[0]}\n')
                process.stdin.flush()
                reply = replay.request_reply(process, 120)
                replies.write(json.dumps(reply, sort_keys=True) + '\n')
                replies.flush()
                feeder.finish()
                feeder = None
                actual = replay.expanded_reads(reply['input_capture'])
                check = dict(request=key, identity_errors=replay.request_identity_errors(reply, *key),
                    native_payload_matches=replay.exact_fact(replay.control_payload(record), replay.control_payload(reply)),
                    read_sequence_matches=expected == actual, recorded_reads=len(expected), replayed_reads=len(actual),
                    expected_read_sha256=replay.read_sha256(expected), actual_read_sha256=replay.read_sha256(actual))
                results.append(check)
                assert not check['identity_errors'] and check['read_sequence_matches'], check
            process.stdin.close()
            footer['exit'] = process.wait(timeout=15)
            assert footer['exit'] == 0, footer
            footer['complete'] = True
    except BaseException as error:
        footer['error'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        if feeder is not None:
            feeder.close()
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
            footer['terminated_exit'] = process.returncode
        save(directory / 'process-footer.json', footer)
        save(directory / 'request-checks.json', results)
        if common.exists():
            shutil.move(str(common), str(directory / 'sealed-recaptured'))
            save(directory / 'capture-path-mapping.json', {str(common): str(directory / 'sealed-recaptured')})
    print(role, 'clean EOF', footer['exit'], len(results), flush=True)

genomes, replies, checks = {}, {}, {}
for role in protocol['roles']:
    d = root / role
    genomes[role] = decider_genome(d / 'stderr.log')
    assert genomes[role]
    replies[role] = [json.loads(x) for x in (d / 'replies.jsonl').read_text().splitlines()]
    checks[role] = json.loads((d / 'request-checks.json').read_text())
    assert len(replies[role]) == len(records)
    for reply in replies[role]:
        capture = dict(reply['input_capture'], directory=str(d / 'sealed-recaptured'))
        replay.expanded_reads(capture)
    assert all(x['native_payload_matches'] for x in checks[role][:-1])
    if role.startswith('OFF'):
        assert checks[role][-1]['native_payload_matches']
for a, b in [('OFF-0', 'OFF-1'), ('ON-0', 'ON-1')]:
    assert genomes[a] == genomes[b]
    assert all(replay.exact_fact(replay.control_payload(x), replay.control_payload(y)) for x, y in zip(replies[a], replies[b]))
off, on = [copy.deepcopy(genomes[x]) for x in ['OFF-0', 'ON-0']]
for field in ['treatments', 'forced']:
    a, b = off.pop(field), on.pop(field)
    assert tag not in a and tag in b and set(b) - {tag} == set(a), field
assert old not in genomes['OFF-0']['treatments'] and old not in genomes['ON-0']['treatments']
assert off == on, 'all other genome metadata must agree'
changed = not checks['ON-0'][-1]['native_payload_matches']
save(root / 'qualified-one-bit-comparison.json', dict(qualified=True, activated=changed, protocol=protocol,
    genomes=genomes, last_request=[154, 0], actual_read_sha256=checks['ON-0'][-1]['actual_read_sha256'],
    scope='Repeated complete-EOF proposal witness; no native execution or strength attribution.'))
print('one-bit comparison qualified; activated=', changed, flush=True)
