"""Independently reconstruct archived input bytes and verify raw proposal pairs.

Usage: python3 verify-governor-launch-one-bit.py BUNDLE_DIRECTORY REPO
The bundle is an offline proposal witness, never native execution or strength.
"""
from pathlib import Path
import copy, hashlib, json, sys, tempfile

bundle, repo = map(Path, sys.argv[1:])
sys.path.insert(0, str(repo / 'tools'))
import civ6_captured_read_replay as replay
from civ6_ladder import decider_genome

read = lambda p: json.loads(p.read_text())
manifest = read(bundle / 'manifest.json')
for relative, digest in manifest['files'].items():
    assert hashlib.sha256((bundle / relative).read_bytes()).hexdigest() == digest, relative
context = read(bundle / 'context.json')
all_records = replay.select_records(bundle / 'native-decisions.jsonl', 154, context)
records = all_records[:next(i + 1 for i, x in enumerate(all_records) if replay.frame_key(x) == (154, 0))]
assert len(records) == 393
roles = ['OFF-0', 'ON-0', 'ON-1', 'OFF-1']
tag, old = 'pingala-follows-research-2', 'pingala-follows-research'
replies, genomes, invocations, outputs = {}, {}, {}, {}
with tempfile.TemporaryDirectory(prefix='pingala-input-verifier-') as temporary:
    directories = {}
    for name, captures in manifest['capture_objects'].items():
        directory = Path(temporary) / name
        directory.mkdir()
        for filename, digest in captures.items():
            data = (bundle / 'objects' / digest).read_bytes()
            assert hashlib.sha256(data).hexdigest() == digest
            (directory / filename).write_bytes(data)
        directories[name] = directory

    def actual_reads(record, capture_name):
        capture = dict(record['input_capture'], directory=str(directories[capture_name]))
        return replay.expanded_reads(capture)

    expected = [actual_reads(x, manifest['native_capture_names'][x['input_capture']['directory']]) for x in records]
    for role in roles:
        directory = bundle / role
        footer = read(directory / 'process-footer.json')
        assert footer['complete'] is True and type(footer['exit']) is int and footer['exit'] == 0
        assert 'terminated_exit' not in footer and 'error' not in footer
        genomes[role] = decider_genome(directory / 'stderr.log')
        assert genomes[role]
        invocations[role] = read(directory / 'invocation.json')
        replies[role] = [json.loads(x) for x in (directory / 'replies.jsonl').read_text().splitlines()]
        assert len(replies[role]) == len(records)
        outputs[role] = []
        for index, (native, reply, native_reads) in enumerate(zip(records, replies[role], expected)):
            key = replay.frame_key(native)
            assert not replay.request_identity_errors(reply, *key), (role, key)
            observed = actual_reads(reply, role)
            assert observed == native_reads, (role, key, 'captured bytes differ')
            outputs[role].append(replay.control_payload(reply))
            if role.startswith('OFF') or index < len(records) - 1:
                assert replay.exact_fact(replay.control_payload(native), outputs[role][-1]), (role, key, 'unexpected proposal')
        argv = invocations[role]['argv']
        assert argv.count('--mirror') == 1 and argv.count('--capture-inputs') == 1
        assert [argv[i+1] for i,x in enumerate(argv[:-1]) if x == '--without'].count(old) == 1
        assert footer['source_head'] == manifest['candidate_source_head']
        assert invocations[role]['cwd'] == context['processes'][0]['cwd']
    for a, b in [('OFF-0', 'OFF-1'), ('ON-0', 'ON-1')]:
        assert genomes[a] == genomes[b]
        assert replay.exact_fact(outputs[a], outputs[b])
    g0, g1 = [copy.deepcopy(genomes[x]) for x in ['OFF-0', 'ON-0']]
    for field in ['treatments', 'forced']:
        off, on = g0.pop(field), g1.pop(field)
        assert len(off) == len(set(off)) and len(on) == len(set(on))
        assert tag not in off and tag in on and set(on) - {tag} == set(off)
    assert g0 == g1
    assert all(old not in g['treatments'] for g in genomes.values())
    normalized = []
    for role in roles:
        argv = list(invocations[role]['argv'])
        argv[argv.index('--mirror') + 1] = '<same-input>'
        if role.startswith('ON'):
            assert sum(argv[i:i+2] == ['--with', tag] for i in range(len(argv)-1)) == 1
            index = next(i for i in range(len(argv)-1) if argv[i:i+2] == ['--with', tag])
            del argv[index:index+2]
        normalized.append(argv)
    assert all(x == normalized[0] for x in normalized)
    # The v1/v2 family contrast is separate from the one-bit gate witness.
    # V2 control replay deliberately stopped on its first changed payload;
    # no successful EOF is inferred for those two family queries.
    family_genomes, family_outputs = {}, {}
    family_protocol=read(bundle/'family'/'protocol.json')
    assert family_protocol['candidate_head']==manifest['candidate_source_head']
    assert family_protocol['candidate_sha256']==manifest['binary_sha256']
    for role in ['V1-0','V1-1','V2-0','V2-1']:
        directory=bundle/'family'/role
        rows=[json.loads(x) for x in (directory/'replies.jsonl').read_text().splitlines()]
        is_v1=role.startswith('V1')
        assert len(rows)==(394 if is_v1 else 393)
        family_genomes[role]=decider_genome(directory/'stderr.log')
        family_outputs[role]=[replay.control_payload(x) for x in rows]
        for index,(native,reply) in enumerate(zip(all_records,rows)):
            assert not replay.request_identity_errors(reply,*replay.frame_key(native))
            target=actual_reads(native,manifest['native_capture_names'][native['input_capture']['directory']])
            assert actual_reads(reply,'family-'+role)==target
            if is_v1 or index<len(rows)-1:
                assert replay.exact_fact(replay.control_payload(native),family_outputs[role][index])
        if not is_v1:
            assert not replay.exact_fact(replay.control_payload(all_records[len(rows)-1]),family_outputs[role][-1])
    for a,b in [('V1-0','V1-1'),('V2-0','V2-1')]:
        assert family_genomes[a]==family_genomes[b]
        assert replay.exact_fact(family_outputs[a],family_outputs[b])
    first,second=family_genomes['V1-0'],family_genomes['V2-0']
    assert set(first['treatments'])==set(context['actual_genome']['treatments'])
    assert set(second['treatments'])==(set(first['treatments'])-{old})|{tag}
    assert set(second['forced'])==set(first['forced'])|{tag}
    assert set(second['ledger_withheld'])==set(first['ledger_withheld'])-{tag}
    for key in set(first)-{'treatments','forced','ledger_withheld'}:
        assert first[key]==second[key]
    last_reads = expected[-1]
    # The witness has 18 repeated identical reads; hash the actual byte string.
    assert len(last_reads) == 18 and all(x == last_reads[0] for x in last_reads)
    changed = outputs['OFF-0'][-1]['orders'] != outputs['ON-0'][-1]['orders']
    pairs = []
    for number in range(2):
        arms = []
        for arm, role in [('off', f'OFF-{number}'), ('on', f'ON-{number}')]:
            arms.append(dict(arm=arm, exit=read(bundle/role/'process-footer.json')['exit'],
                payload=outputs[role][-1], genome=genomes[role], argv=invocations[role]['argv']))
        pairs.append(dict(complete=True, reads=[dict(complete=True,
            sha256=hashlib.sha256(last_reads[0]).hexdigest(), bytes=len(last_reads[0]), arms=arms)]))
    for number, pair in enumerate(pairs):
        assert read(bundle / f'pair-{number}.json') == pair, 'derived gate record differs from raw evidence'
    print(json.dumps(dict(verified=True, activated=changed, roles=4, requests_per_role=len(records),
        actual_reads_per_role=sum(map(len, expected)), first_change=[154,0] if changed else None,
        candidate_source_head=manifest['candidate_source_head'], binary_sha256=manifest['binary_sha256'],
        scope='Repeated identical-input proposals with clean EOF; no native execution or strength result.'), indent=2))
