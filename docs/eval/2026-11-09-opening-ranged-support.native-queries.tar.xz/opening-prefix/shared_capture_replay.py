from pathlib import Path
import importlib.util, json, shutil, sys

script = Path('src/ai/slinger_first/replay_opening.py').resolve()
spec = importlib.util.spec_from_file_location('slinger_replay', script)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
original = module.replay.replay_command
shared = Path('/tmp/civvis-slinger-shared-capture-368d').resolve()
out = Path('/tmp/civvis-slinger-prefix-shared-capture-368d').resolve()
commands, previous = {}, None
assert not out.exists() and not shared.exists()

def save_previous():
    if previous is not None:
        shutil.copytree(shared, previous / 'shared-recaptured')

def same_capture_output(context, directory):
    global previous
    words, cwd = original(context, directory)
    save_previous()
    if shared.exists():
        shutil.rmtree(shared)
    words[words.index('--capture-inputs') + 1] = str(shared)
    commands[str(directory.resolve())] = {'argv': words, 'cwd': cwd}
    previous = directory.resolve()
    return words, cwd

module.replay.replay_command = same_capture_output
sys.argv = [str(script), '--binary', '/tmp/civvis-slinger-368d/civvis_orders', '--out', str(out)]
try:
    module.main()
finally:
    if previous is not None and shared.exists():
        save_previous()
    if out.exists():
        (out / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
