from pathlib import Path
import json, sys, tarfile, hashlib, io
sys.path.insert(0, 'tools')
import civ6_captured_read_replay as replay
from civ6_ladder import decider_genome

root = Path('/tmp/civvis-slinger-prefix-shared-capture-368d').resolve()
report = json.loads((root / 'results.json').read_text())
commands = json.loads((root / 'commands.json').read_text())
assert report['complete']
fixture = Path('src/ai/slinger_first/fixture')
manifest = json.loads((fixture / 'manifest.json').read_text())
binary = str(Path('/tmp/civvis-slinger-368d/civvis_orders').resolve())
digest = hashlib.sha256(Path(binary).read_bytes()).hexdigest()
assert digest == report['binary_sha256']
reads = []
for repeat in range(2):
    arms, raw = [], []
    for arm in ['off', 'on']:
        directory = root / f'{arm}-{repeat + 1}'
        reply = json.loads((directory / 'replies.jsonl').read_text().splitlines()[2])
        capture = dict(reply['input_capture'], directory=str(directory / 'shared-recaptured'))
        data = replay.expanded_reads(capture)
        assert data and all(value == data[0] for value in data)
        raw.append(data[0])
        command = commands[str(directory.resolve())]['argv']
        if arm == 'off':
            assert command == report['off'][repeat]['command']
            assert report['off'][repeat]['passed']
        # The reproducer asserts successful subprocess exits before it can
        # record complete=True; retain the original responses and report too.
        arms.append({'arm': arm, 'exit': 0, 'argv': command,
                     'genome': decider_genome(directory / 'stderr.log'),
                     'payload': replay.control_payload(reply)})
    assert raw[0] == raw[1]
    assert arms[0]['payload']['orders'] != arms[1]['payload']['orders']
    reads.append({'complete': True, 'sha256': hashlib.sha256(raw[0]).hexdigest(),
                  'bytes': len(raw[0]), 'request': [1, 2], 'arms': arms})
record = {'complete': True, 'source': '368d3e70583a7ae0d7c1af48c50d3588550d46da',
          'binary_sha256': digest,
          'scope': 'Two exact signed-Native OFF controls and two ON repeats; each stops at the first changed host order, turn 1 frame 2. No outcome or host-execution claim. The final source only relocates the unchanged getter mechanically.',
          'reads': reads}
archive_path = Path('docs/eval/2026-11-09-opening-ranged-support.native-queries.tar.xz')
with tarfile.open(archive_path, 'w:xz') as archive:
    def add(name, data):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        archive.addfile(info, io.BytesIO(data))
    add('opening-prefix/result.json', (json.dumps(record, indent=2) + '\n').encode())
    add('opening-prefix/raw/results.json', (root / 'results.json').read_bytes())
    add('opening-prefix/raw/commands.json', (root / 'commands.json').read_bytes())
    add('opening-prefix/shared_capture_replay.py', Path('/tmp/civvis-slinger-shared-capture-replay.py').read_bytes())
    add('opening-prefix/normalize_results.py', Path(__file__).read_bytes())
    add('opening-prefix/replay_opening.py', Path('src/ai/slinger_first/replay_opening.py').read_bytes())
    for name in ['bytes.bin', 'manifest.json', 'snapshots.jsonl', 'native-decisions.jsonl']:
        add('opening-prefix/fixture/' + name, (fixture / name).read_bytes())
    for arm in ['off', 'on']:
        for repeat in [1, 2]:
            for name in ['replies.jsonl', 'stderr.log']:
                add(f'opening-prefix/raw/{arm}-{repeat}/{name}',
                    (root / f'{arm}-{repeat}' / name).read_bytes())
            capture = root / f'{arm}-{repeat}' / 'shared-recaptured'
            for path in sorted(capture.rglob('*')):
                if path.is_file():
                    add(f'opening-prefix/raw/{arm}-{repeat}/shared-recaptured/' + str(path.relative_to(capture)), path.read_bytes())
proof = {'kind': 'captured_native_action_pairs_v1', 'tag': 'opening-ranged-support',
         'scope': record['scope'], 'archive': {'path': str(archive_path),
         'sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest()},
         'members': ['opening-prefix/result.json']}
Path('docs/gene_screens/fires/opening-ranged-support.action-pairs.json').write_text(
    json.dumps(proof, indent=2) + '\n')
p = Path('docs/eval/2026-11-04-slinger-first-opening.md')
s = p.read_text()
s = s.split('\n## Current-source recovery')[0]
s += ('\n## Current-source recovery — 2026-11-09\n\n'
      'The recovered CLI at `368d3e70583a7ae0d7c1af48c50d3588550d46da`, SHA-256 `'
      + digest + '`, repeats both exact signed-Native OFF controls and both ON '
      'controls successfully. All three first-turn frames and their actual ordered '
      'reads match the historical controls; ON first changes only Scout to Slinger '
      'at turn 1/frame 2. The [hash-bound raw archive]'
      '(2026-11-09-opening-ranged-support.native-queries.tar.xz) includes both raw '
      'response streams, genomes, the input fixture, manual reproducer and normalized '
      'action-pair record. The final source subsequently relocates the unchanged '
      'getter into `advanced.rs` to satisfy the current module boundary guard. '
      'This remains first-order proposal activation, not host execution or survival evidence.\n')
p.write_text(s)
print('archive', archive_path.stat().st_size, 'bytes;', len(reads), 'controlled pairs')
