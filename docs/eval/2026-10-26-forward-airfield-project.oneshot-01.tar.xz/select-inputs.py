"""Retain all 24 fixed games, all registered blocked frames, and first/final controls."""
import collections,gzip,hashlib,json
from pathlib import Path
ROOT=Path.home()/'civvis-civ6-runs/control'
BASE=Path('/tmp/civvis-forward-airfield-project-8c23')
CENSUS=Path('/Users/martbot-mbp-m5-max-128/civvis-main-managed/docs/eval/2026-10-25-forward-airstrip-census.results-02.json.gz')
OUT=BASE/'native-selection'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def records(p):
    return [json.loads(line) for line in p.read_text().splitlines()]

def main():
    OUT.mkdir()
    source=json.loads(gzip.decompress(CENSUS.read_bytes()))
    cases,cohort=[],[]
    for stratum,games in source['cohorts'].items():
        for game in games:
            directory=ROOT/game['tag']
            for name,identity in game['files'].items():
                p=directory/name
                if p.stat().st_size!=identity['bytes'] or sha(p)!=identity['sha256']:
                    raise ValueError('fixed source changed: '+str(p))
            summary=json.loads((directory/'summary.json').read_text())
            decisions=records(directory/'decisions.jsonl')
            states=collections.defaultdict(list)
            for event in records(directory/'events.jsonl'):
                if event.get('kind')=='state':states[event['turn'],event['frame']].append(event)
            with (directory/'why.log').open() as stream: genome=json.loads(stream.readline())
            genome['_summary_withheld']=summary.get('withheld',[])
            genome_path=OUT/(directory.name+'.genome.json')
            genome_path.write_text(json.dumps(genome,indent=2)+'\n')
            blocked={(row['turn'],row['frame']) for row in game['blocked_capital_turns']}
            selected={}
            for index,decision in enumerate(decisions):
                meta=decision['decision']; key=meta['turn'],meta['frame']; reasons=[]
                if index==0:reasons.append('first_actual_decision_control')
                if index==len(decisions)-1:reasons.append('final_actual_decision_control')
                if key in blocked:reasons.append('registered_blocked_capital_frame')
                if not reasons:continue
                if key in selected:raise ValueError('ambiguous actual decision: '+directory.name)
                selected[key]=dict(run=directory.name,stratum=stratum,directory=str(directory),turn=key[0],frame=key[1],decision_index=index,reasons=reasons,state_count=len(states[key]),genome=str(genome_path),capture=decision.get('input_capture'),actual_orders=decision.get('orders'),actual_planned_actions=meta.get('native_actions'))
            missing=blocked-set(selected)
            if missing:raise ValueError('registered frames missing decisions: '+str(missing))
            cases.extend(selected.values())
            cohort.append(dict(run=directory.name,stratum=stratum,cases=len(selected),blocked_frames=len(blocked),files=game['files'],why_sha256=sha(directory/'why.log'),known_outcome=game['outcome']))
    if len(cohort)!=24:raise ValueError('fixed cohort size changed')
    result=dict(scope=__doc__,gene='forward-airfield-project',census_sha256=sha(CENSUS),selection_script_sha256=sha(Path(__file__)),cohort=cohort,cases=sorted(cases,key=lambda c:(c['run'],c['decision_index'])),interpretation='All registered blocked frames plus first/final actual decisions. No favorable substitutions, no treated query, no Native execution. Later fresh-query OFF orders may differ from historical output because controller memory and source differ; retain that comparison separately from the fixed-source single-bit contrast.')
    (OUT/'manifest.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(games=len(cohort),cases=len(cases),blocked_frames=sum(c['blocked_frames'] for c in cohort),distinct_reads=sum(len((c['capture'] or {}).get('reads',[])) for c in cases),per_game=[(c['run'],c['cases'],c['blocked_frames']) for c in cohort]),indent=2))

if __name__=='__main__':main()
