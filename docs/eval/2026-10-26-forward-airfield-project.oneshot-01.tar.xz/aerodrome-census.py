"""All actual offered Aerodrome sites at every fixed blocked capital-turn."""
import pathlib,importlib.util,gzip,json,hashlib,collections
REPO=pathlib.Path('/Users/martbot-mbp-m5-max-128/civvis-main-managed')
p=REPO/'docs/eval/2026-10-25-capital-assault-audit.py';sp=importlib.util.spec_from_file_location('geometry',p); a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
CENSUS=REPO/'docs/eval/2026-10-25-forward-airstrip-census.results-02.json.gz'
OUT=pathlib.Path('/tmp/civvis-forward-airfield-project-8c23/aerodrome-census-01.json.gz')
if OUT.exists():raise ValueError('preserve previous result')
x=json.loads(gzip.decompress(CENSUS.read_bytes())); cohorts={}; totals={}
for name,games in x['cohorts'].items():
 result=[]
 for game in games:
  root=pathlib.Path.home()/'civvis-civ6-runs/control'/game['tag']
  for fn,identity in game['files'].items():
   data=(root/fn).read_bytes()
   if len(data)!=identity['bytes'] or hashlib.sha256(data).hexdigest()!=identity['sha256']:raise ValueError('fixed file changed')
  needed={(r['turn'],r['frame']) for r in game['blocked_capital_turns']}; states=collections.defaultdict(list);width=None
  if needed:
   for e in a.records(root/'events.jsonl'):
    if e.get('kind')=='tiles':width=e['width']
    if e.get('kind')=='state' and (e['turn'],e['frame']) in needed:states[e['turn'],e['frame']].append(e)
  rows=[]
  for r in game['blocked_capital_turns']:
   found=states[r['turn'],r['frame']]
   if len(found)!=1:rows.append(dict(turn=r['turn'],frame=r['frame'],capital=r['capital'],error='ambiguous_or_missing_state'));continue
   state=found[0]; offers=[]; missing=[]
   for city in state.get('cities',[]):
    if not isinstance(city.get('buildable'),list):missing.append(dict(city=city['id'],field='buildable'));continue
    for q in city['buildable']:
     if q['t']!='DISTRICT_AERODROME':continue
     sites=[dict(plot=site,distance=a.distance(site,r['capital'],width),in_range_ready_bombers=sum(a.distance(site,r['capital'],width)<=b['range'] for b in r['ready_bombers'])) for site in q.get('s',[])]
     offers.append(dict(city={k:city.get(k) for k in ['id','name','x','y','producing','production_turns','loyalty','loyalty_per_turn']},quote=q,sites=sites,placement_list_known=isinstance(q.get('s'),list)))
   rows.append(dict(turn=r['turn'],frame=r['frame'],capital=r['capital'],gold=state.get('gold'),income=state.get('gold_per_turn'),offers=offers,missing=missing,ready_bombers=r['ready_bombers']))
  result.append(dict(tag=game['tag'],files=game['files'],rows=rows))
 cohorts[name]=result
 rows=[r for game in result for r in game['rows']]; totals[name]=dict(capital_turns=len(rows),valid_states=sum('error' not in r for r in rows),with_in_range_offer=sum(any(s['in_range_ready_bombers']>=2 for o in r.get('offers',[]) for s in o['sites']) for r in rows))
report=dict(scope=__doc__,cohorts=cohorts,totals=totals,census_sha256=hashlib.sha256(CENSUS.read_bytes()).hexdigest(),script_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
OUT.write_bytes(gzip.compress(json.dumps(report,sort_keys=True).encode(),mtime=0));print(json.dumps(totals,indent=2))
for games in cohorts.values():
 for game in games:
  matches=[r for r in game['rows'] if any(s['in_range_ready_bombers']>=2 for o in r.get('offers',[]) for s in o['sites'])]
  if matches:print(game['tag'],[(r['turn'],[(o['city']['name'],o['quote']['p'],[s for s in o['sites'] if s['in_range_ready_bombers']>=2]) for o in r['offers'] if any(s['in_range_ready_bombers']>=2 for s in o['sites'])]) for r in matches])
