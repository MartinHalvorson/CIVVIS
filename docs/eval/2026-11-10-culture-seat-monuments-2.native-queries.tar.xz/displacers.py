"""Which rule took the queue from a Monument in progress, on live Culture seats since 19:00Z."""
import collections, json, os, re, sys
sys.path.insert(0, os.path.dirname(__file__))
from census import game_dirs, leader  # noqa: E402  (census.main runs on import; guarded below)

WHY = re.compile(r"^\[why\] t(\d+) (\S+)/(\S+) (.*?) \| (.*)$")


def main():
    by_rule = collections.Counter()
    by_rule_near = collections.Counter()
    examples = collections.defaultdict(list)
    total = 0
    for base, dirs in game_dirs().items():
        target, lead = leader(dirs)
        if target != "culture":
            continue
        seq = {}
        why = collections.defaultdict(list)
        for d in dirs:
            p = os.path.join(d, "events.jsonl")
            if os.path.exists(p):
                for line in open(p):
                    if line.startswith('{"available_policies'):
                        s = json.loads(line)
                        seq.setdefault((s["turn"], s["frame"]), s)
            w = os.path.join(d, "why.log")
            if os.path.exists(w):
                for line in open(w):
                    m = WHY.match(line.rstrip("\n"))
                    if m:
                        why[int(m.group(1))].append((m.group(4), m.group(5)))
        prev = {}
        for key in sorted(seq):
            s = seq[key]
            for c in s["cities"]:
                name = c["name"]
                mon = next((b for b in c.get("buildable", []) if b["t"] == "BUILDING_MONUMENT"), None)
                built = "BUILDING_MONUMENT" in c.get("buildings", [])
                cur = c.get("producing")
                p = prev.get(name)
                if p and p[0] == "BUILDING_MONUMENT" and not built and cur not in (None, "BUILDING_MONUMENT"):
                    total += 1
                    t = p[1]
                    near = p[2]
                    rule = None
                    for tt in (t, key[0]):
                        for head, body in why.get(tt, []):
                            text = (head + " " + body).lower()
                            if name.lower() in text and "monument" in body.lower() and "claims its monument" not in head.lower():
                                rule = body.split(":")[0].strip()
                                break
                        if rule:
                            break
                    rule = rule or f"(no line) -> {cur}"
                    by_rule[rule] += 1
                    if near:
                        by_rule_near[rule] += 1
                    if len(examples[rule]) < 2:
                        examples[rule].append(f"{base[-7:]} {name} t{t} -> {cur}")
                nd = bool(mon and mon.get("pr", 0) > 0 and (mon["p"] <= 3 or mon["pr"] * 2 >= mon["c"]))
                prev[name] = (cur, key[0], nd)
    print("displacements of an unfinished Monument head:", total)
    for rule, n in by_rule.most_common():
        print(f"{n:4d}  near-done {by_rule_near[rule]:3d}  {rule}   e.g. {examples[rule]}")


if __name__ == "__main__":
    main()
