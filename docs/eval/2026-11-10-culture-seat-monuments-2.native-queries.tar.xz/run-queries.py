"""Paired decider queries for `culture-seat-monuments-2` on captured live boards.

Each case is a live Deity Online Pericles Culture-target game armed with
`culture-seat-monuments` (civvis-20261111T000134Z, civvis-20261110T234921Z,
civvis-20261110T232642Z), at a turn where a city of ours has no Monument. The
board is the run's events.jsonl cut at that turn's first state frame (frame
0), the run's other files linked beside it. Every arm runs one frozen
`civvis_orders --explain --resumed --victory culture` with the run's own
requested genome (`summary.json` `forced`, each as `--with`, less tags the
binary does not know):

- `off`: the branch binary, the live genome (version one on, two off);
- `on`: the same plus `--with culture-seat-monuments-2` (version two reads
  `v1 || v2` everywhere, so this plays exactly what arming, which replaces
  version one, plays);
- controls: `main_v1`, the main binary on the live genome (must equal
  `off`), and `none` / `main_none`, both binaries with version one removed
  too (must be equal).

Each city of ours without a Monument is classed on the board: `safe` = no
at-war major's soldier within six tiles and no damage, `near_done` = within
three turns or half built. This records proposal activation on captured live
input only. It does not execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BRANCH = Path(sys.argv[2])
MAIN = Path(sys.argv[3])
OUT = Path(sys.argv[4])
REVISION = sys.argv[5]
CASES = json.loads(Path(sys.argv[6]).read_text())
ARMS = sys.argv[7].split(',') if len(sys.argv) > 7 else ['off', 'on', 'main_v1', 'none', 'main_none']
GENE, V1 = 'culture-seat-monuments-2', 'culture-seat-monuments'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CIVILIAN = {'', None, 'PROMOTION_CLASS_RECON'}


def known_tags():
    text = subprocess.run(['git', '-C', str(REPO), 'show', f'{REVISION}:src/ai/advanced/genes.rs'],
                          capture_output=True, text=True, check=True).stdout
    return set(re.findall(r'Gene \{ tag: "([^"]+)"', text))


def cube(x, y):
    q = x - (y - (y & 1)) // 2
    return q, y, -q - y


def dist(a, b):
    (q1, r1, s1), (q2, r2, s2) = cube(*a), cube(*b)
    return max(abs(q1 - q2), abs(r1 - r2), abs(s1 - s2))


def cut(src, dst, turn):
    state = None
    with open(src, 'rb') as f, open(dst, 'wb') as g:
        for line in f:
            g.write(line)
            if line.startswith(b'{"available_policies"'):
                try:
                    s = json.loads(line)
                except Exception:
                    continue
                if s.get('turn') == turn:
                    state = s
                    break
    return state


def board_cities(state):
    war = [r for r in state['rivals'] if r.get('at_war')]
    soldiers = [u for r in war for u in r.get('units', [])
                if u.get('class') not in CIVILIAN and (u.get('combat', 0) or u.get('ranged', 0)) > 0]
    rows = []
    for c in state['cities']:
        if 'BUILDING_MONUMENT' in c.get('buildings', []):
            continue
        mon = next((b for b in c.get('buildable', []) if b['t'] == 'BUILDING_MONUMENT'), None)
        if mon is None:
            continue
        near = any(dist((c['x'], c['y']), (u['x'], u['y'])) <= 6 for u in soldiers)
        rows.append({'city': c['name'], 'id': c['id'], 'head': c.get('producing') or 'IDLE', 'turns': mon['p'],
                     'invested': mon.get('pr', 0), 'cost': mon['c'],
                     'safe': not near and not c.get('damage', 0),
                     'near_done': mon.get('pr', 0) > 0 and (mon['p'] <= 3 or 2 * mon['pr'] >= mon['c'])})
    return {'at_major_war': bool(war), 'cities': rows}


def monument_cities(payload):
    """City names the decider's final production orders put on a Monument."""
    text = json.dumps(payload)
    out = set()
    for order in payload.get('orders', []):
        blob = json.dumps(order).lower()
        if 'monument' in blob and ('produce' in blob or 'build' in blob):
            out.add(order.get('subject') or order.get('city') or blob[:80])
    return sorted(out), text


def one(index, case, known):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case}
    try:
        run = RUNS / case['run']
        summary = json.loads((run / 'summary.json').read_text())
        forced = [t for t in summary['forced'] if not known or t in known]
        result['dropped_unknown_tags'] = [t for t in summary['forced'] if known and t not in known]
        if GENE in forced or V1 not in forced:
            raise ValueError('the live genome must carry version one and not version two')
        bare = [t for t in forced if t != V1]
        genomes = {'off': forced, 'on': forced + [GENE], 'main_v1': forced,
                   'none': bare, 'main_none': bare}
        arms = []
        for arm in ARMS:
            mirror = root / arm
            mirror.mkdir()
            for f in run.iterdir():
                if f.name == 'events.jsonl' or f.suffix == '.png' or not f.is_file():
                    continue
                os.symlink(f, mirror / f.name)
            state = cut(run / 'events.jsonl', mirror / 'events.jsonl', case['turn'])
            if state is None:
                raise ValueError('the run has no state at that turn')
            result['board'] = board_cities(state)
            data = (mirror / 'events.jsonl').read_bytes()
            result['sha256'] = hashlib.sha256(data).hexdigest()
            result['bytes'] = len(data)
            binary = MAIN if arm.startswith('main') else BRANCH
            cmd = [str(binary), '--explain', '--resumed', '--mirror', str(mirror),
                   '--victory', 'culture', '--turn', str(case['turn'])]
            for tag in genomes[arm]:
                cmd += ['--with', tag]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=2400)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': round(time.monotonic() - started, 1), 'genome': decider_genome(stderr)}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
                row['monument_orders'], text = monument_cities(row['payload'])
                row['orders_sha256'] = hashlib.sha256(
                    json.dumps(row['payload'].get('orders'), sort_keys=True).encode()).hexdigest()
            else:
                row['stderr_tail'] = stderr.read_text()[-1500:]
            arms.append(row)
            for f in mirror.iterdir():
                f.unlink()
            mirror.rmdir()
        by = {a['arm']: a for a in arms}
        complete = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in arms)
        read = {'descriptor': case, 'sha256': result['sha256'], 'bytes': result['bytes'],
                'complete': complete and 'off' in by and 'on' in by,
                'arms': [by[a] for a in ('off', 'on') if a in by]}
        result['reads'] = [read]
        result['controls'] = [a for a in arms if a['arm'] not in ('off', 'on')]
        result['complete'] = complete
        if 'main_v1' in by:
            result['v1_matches_main'] = by['off'].get('orders_sha256') == by['main_v1'].get('orders_sha256')
        if 'none' in by and 'main_none' in by:
            result['none_matches_main'] = by['none'].get('orders_sha256') == by['main_none'].get('orders_sha256')
        result['v2_changed_orders'] = by['off'].get('orders_sha256') != by['on'].get('orders_sha256')
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    known = known_tags()
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES, 'arms': ARMS,
        'branch_binary_sha256': hashlib.sha256(BRANCH.read_bytes()).hexdigest(),
        'main_binary_sha256': hashlib.sha256(MAIN.read_bytes()).hexdigest() if MAIN.exists() else None,
        'binary_revision': REVISION,
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=int(os.environ.get('JOBS', '3'))) as pool:
        results = list(pool.map(lambda pair: one(pair[0], pair[1], known), enumerate(CASES)))
    for r in results:
        if r.get('error'):
            print(r['case'], 'ERROR', r['error'])
    summary = {'cases': len(results), 'complete': sum(bool(r.get('complete')) for r in results),
               'v1_matches_main': sum(bool(r.get('v1_matches_main')) for r in results),
               'none_matches_main': sum(bool(r.get('none_matches_main')) for r in results),
               'v2_changed_orders': sum(bool(r.get('v2_changed_orders')) for r in results)}
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
