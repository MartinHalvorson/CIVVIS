"""Census of Monument-less city-turns on live Culture seats, by the first v1 gate that blocks them."""
import collections, glob, json, os, re, sys

ROOT = os.path.expanduser("~/civvis-civ6-runs/control")
WHY_HOLD = re.compile(r"^\[why\] t(\d+) .*The war holds the economy's claims")
WHY_CLAIM = re.compile(r"^\[why\] t(\d+) .*?(\S+) claims its Monument")
CIVILIAN = {"", None, "PROMOTION_CLASS_RECON"}


def cube(x, y):
    q = x - (y - (y & 1)) // 2
    return q, y, -q - y


def dist(a, b, width=None):
    best = None
    for dx in ([0] if not width else [0, width, -width]):
        q1, r1, s1 = cube(a[0] + dx, a[1])
        q2, r2, s2 = cube(*b)
        d = max(abs(q1 - q2), abs(r1 - r2), abs(s1 - s2))
        best = d if best is None else min(best, d)
    return best


def game_dirs():
    out = collections.OrderedDict()
    for d in sorted(glob.glob(os.path.join(ROOT, "civvis-2026111*"))):
        tag = os.path.basename(d)
        base = tag.split("-cont")[0]
        if base < "civvis-20261110T190000Z" or base > "civvis-20261111T001647Z":
            continue
        out.setdefault(base, []).append(d)
    return out


def leader(dirs):
    for d in reversed(dirs):
        try:
            s = json.load(open(os.path.join(d, "summary.json")))
        except Exception:
            continue
        if s.get("victory_target"):
            return s.get("victory_target"), (s.get("seat") or {}).get("leader")
    return None, None


def main():
    only = sys.argv[1:]
    gates = collections.Counter()
    heads = collections.Counter()
    major_split = collections.Counter()
    major_heads = collections.Counter()
    near_done_off = collections.Counter()
    per_game = {}
    for base, dirs in game_dirs().items():
        if only and not any(o in base for o in only):
            continue
        target, lead = leader(dirs)
        if target != "culture":
            continue
        states = {}
        hold_turns = set()
        for d in dirs:
            p = os.path.join(d, "events.jsonl")
            if not os.path.exists(p):
                continue
            for line in open(p):
                if line.startswith('{"available_policies'):
                    s = json.loads(line)
                    if s.get("frame") == 0 and s["turn"] not in states:
                        states[s["turn"]] = s
            w = os.path.join(d, "why.log")
            if os.path.exists(w):
                for line in open(w):
                    m = WHY_HOLD.match(line)
                    if m:
                        hold_turns.add(int(m.group(1)))
        g = collections.Counter()
        for t in sorted(states):
            s = states[t]
            cities = s["cities"]
            if len(cities) < 2:
                continue
            war = [r for r in s["rivals"] if r.get("at_war")]
            war_units = [u for r in war for u in r.get("units", [])
                         if u.get("class") not in CIVILIAN and (u.get("combat", 0) or u.get("ranged", 0)) > 0]
            for c in cities:
                if "BUILDING_MONUMENT" in c.get("buildings", []):
                    continue
                mon = next((b for b in c.get("buildable", []) if b["t"] == "BUILDING_MONUMENT"), None)
                if mon is None:
                    continue
                near = any(dist((c["x"], c["y"]), (u["x"], u["y"])) <= 6 for u in war_units)
                threatened = near or c.get("damage", 0) > 0
                prod = c.get("producing") or "IDLE"
                half = mon["c"] > 0 and mon.get("pr", 0) * 2 >= mon["c"]
                if (mon["p"] <= 3 or half) and mon.get("pr", 0) > 0 and prod != "BUILDING_MONUMENT":
                    near_done_off[(base[-7:], c["name"])] += 1
                if t in hold_turns:
                    gate = "war_holds"
                elif war:
                    gate = "major_war"
                    key = ("safe" if not threatened else "threatened") + ("/fast" if mon["p"] <= 10 else "/slow")
                    major_split[key] += 1
                    if not threatened and mon["p"] <= 10:
                        major_heads[prod] += 1
                elif threatened:
                    gate = "threatened"
                elif mon["p"] > 10:
                    gate = "slow>10"
                elif prod == "BUILDING_MONUMENT":
                    gate = "building"
                else:
                    gate = "head_held"
                    heads[prod] += 1
                g[gate] += 1
                gates[gate] += 1
        per_game[base] = (lead, dict(g))
    for base, (lead, g) in per_game.items():
        print(base, lead, g)
    print("TOTAL", dict(gates))
    print("major_war split", dict(major_split))
    print("major_war safe/fast heads", major_heads.most_common(12))
    print("head_held heads", heads.most_common(15))
    print("near-done Monument not at head (city-turns)", sum(near_done_off.values()),
          "cities", len(near_done_off), near_done_off.most_common(8))


if __name__ == "__main__":
    main()
