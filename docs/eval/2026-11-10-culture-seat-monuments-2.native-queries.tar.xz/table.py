"""Per-city table from run-queries.py results: does each arm claim the Monument?"""
import collections, glob, json, os, sys

out = sys.argv[1]
rows = []
tally = collections.Counter()
other_changes = []
for path in sorted(glob.glob(os.path.join(out, '*/result.json'))):
    r = json.load(open(path))
    case = r['case']
    arms = {a['arm']: a for a in r['reads'][0]['arms']}
    claimed = {arm: set(a.get('monument_orders', [])) for arm, a in arms.items()}
    in_board = set()
    for c in r['board']['cities']:
        in_board.add(c['id'])
        # a Monument already at the head counts as kept.
        at_head = c['head'] == 'BUILDING_MONUMENT'
        v1 = at_head or c['id'] in claimed['off']
        v2 = at_head or c['id'] in claimed['on']
        cls = ('war' if r['board']['at_major_war'] else 'peace') + '/' + ('safe' if c['safe'] else 'THREAT') \
            + '/' + ('near' if c['near_done'] else 'young')
        tally[(cls, 'v1' if v1 else '-', 'v2' if v2 else '-')] += 1
        rows.append((case['run'][-7:], case['turn'], c['city'], cls, c['head'].replace('BUILDING_', '').replace('DISTRICT_', '')[:14],
                     f"{c['turns']}t {c['invested']}/{c['cost']}", 'Monument' if v1 else '-', 'Monument' if v2 else '-'))
    off_orders = arms['off']['payload']['orders']
    on_orders = arms['on']['payload']['orders']
    extra = [o for o in on_orders if o not in off_orders and o.get('subject') not in in_board]
    gone = [o for o in off_orders if o not in on_orders and o.get('subject') not in in_board]
    if extra or gone:
        other_changes.append((case, extra, gone))
print(f"{'run':8} {'t':>3} {'city':12} {'class':18} {'head':14} {'monument':10} {'v1':9} {'v2':9}")
for row in rows:
    print(f"{row[0]:8} {row[1]:>3} {row[2]:12} {row[3]:18} {row[4]:14} {row[5]:10} {row[6]:9} {row[7]:9}")
print()
for k, n in sorted(tally.items()):
    print(n, k)
print('orders changed for cities that already hold a Monument:', len(other_changes))
for c in other_changes:
    print(' ', c)
