from pathlib import Path
import sys,json,subprocess,hashlib,datetime,shutil
root=Path(__file__).parent
repo=Path.home()/'civvis-defenders-keep-the-city-in-reach-2a9e'
sys.path.insert(0,str(repo/'tools'))
from civ6_decision_trace import captured_input
from civ6_captured_read_replay import request_reply,expanded_reads
from civ6_ladder import decider_genome
from native_city_route_replay import request_identity_errors,control_payload
source=Path.home()/'civvis-civ6-runs/control/civvis-20261105T214426Z'
binary=root/'civvis_orders'
build=json.loads((root/'build-process.json').read_text());assert build['exit']==0 and build['source_unchanged']
plan=json.loads((root/'plan.json').read_text());assert build['source_revision']==plan['source_revision']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==build['source_revision']
common=root/'current-capture'
sha=lambda b:hashlib.sha256(b).hexdigest()
tag='defenders-keep-the-city-in-reach'
genome=decider_genome(source/'why.log');assert genome and tag not in genome['treatments']
rows=[json.loads(l) for l in (source/'decisions.jsonl').open()]
cases=[]
for turn in [25,27,29]:
 record=next(r for r in rows if r['decision']['turn']==turn and r['decision']['frame']==0)
 capture=record['input_capture'];assert capture['complete'] and capture['reads']
 data=captured_input(capture,capture['reads'][-1]['snapshot_id'])
 path=root/f'input-{turn}-0.jsonl';assert not path.exists();path.write_bytes(data)
 cases.append({'turn':turn,'frame':0,'input':str(path),'input_bytes':len(data),'input_sha256':sha(data),'original_decision_sha256':record['sha256'],'original_registered_reads':capture['reads']})
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'harness_sha256':sha(Path(__file__).read_bytes()),'gene':tag,'source_run':source.name,'binary':str(binary),'binary_sha256':sha(binary.read_bytes()),'provenance':json.loads(binary.with_suffix('.provenance.json').read_text()),'genome':genome,'arm_order':['off','on','on','off'],'cases':cases,'scope':'Offline proposals on the last captured input frontier with fresh private controller state. Not reproduction of original private history or read timing; no native game, no host actuation, no strength estimate.'}
(root/'intent.json').write_text(json.dumps(manifest,indent=2)+'\n')
results=[]
for idx,arm in enumerate(manifest['arm_order']):
 for case in cases:
  out=root/f'query-{idx}-{case["turn"]}-{arm}';out.mkdir();expected=Path(case['input']).read_bytes();(out/'events.jsonl').write_bytes(expected)
  args=[str(binary),'--mirror',str(out),'--serve','--fresh-board','--explain','--resumed','--victory','science','--civ','CIVILIZATION_INDONESIA','--capture-inputs',str(common)]
  for flag in genome['forced']:args.extend(['--with',flag])
  if arm=='on':args.extend(['--with',tag])
  assert sha(binary.read_bytes())==manifest['binary_sha256']
  with (out/'stderr.log').open('w') as err:
   p=subprocess.Popen(args,cwd=repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1)
   try:
    p.stdin.write(str(case['turn'])+'\n');p.stdin.flush();reply=request_reply(p,120);assert not request_identity_errors(reply,case['turn'],0)
    actual=expanded_reads(reply['input_capture']);assert actual and all(data==expected for data in actual)
    p.stdin.close();code=p.wait(timeout=15);assert code==0
   finally:
    if p.poll() is None:p.terminate();p.wait(timeout=5)
    p.stdout.close()
  effective=decider_genome(out/'stderr.log');assert effective and (tag in effective['treatments'])==(arm=='on')
  capture_directory=Path(reply['input_capture']['directory']);relative=capture_directory.relative_to(common)
  archived=out/'recaptured';shutil.move(common,archived)
  result={'binary_sha256':manifest['binary_sha256'],'capture_directory_map':{str(capture_directory):str(archived/relative)},'request':[case['turn'],0],'shared_input_bytes':case['input_bytes'],'shared_input_sha256':case['input_sha256'],'arm':arm,'round':idx,'turn':case['turn'],'exit':code,'argv':args,'genome':effective,'actual_read_count':len(actual),'actual_read_sha256':[sha(data) for data in actual],'payload':reply,'input_sha256':case['input_sha256']}
  (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result)
  print(json.dumps({'arm':arm,'round':idx,'turn':case['turn'],'reads':len(actual),'unit_orders':[o for o in reply['orders'] if o['kind']=='unit']}),flush=True)
for turn in [25,27,29]:
 rs=[r for r in results if r['turn']==turn];off=[r for r in rs if r['arm']=='off'];on=[r for r in rs if r['arm']=='on']
 assert control_payload(off[0]['payload'])==control_payload(off[1]['payload'])
 assert control_payload(on[0]['payload'])==control_payload(on[1]['payload'])
 a,b=[dict(v[0]['genome']) for v in [off,on]]
 for field in ['forced','treatments']:
  before,after=a.pop(field),b.pop(field);assert set(after)-{tag}==set(before) and tag not in before and tag in after
 assert a==b
assert sha(binary.read_bytes())==manifest['binary_sha256']
assert all(sha((repo/path).read_bytes())==digest for path,digest in build['source_manifest'].items())
assert sha(Path(__file__).read_bytes())==manifest['harness_sha256']
(root/'completed.json').write_text(json.dumps({'queries':len(results),'registered_reads':sum(r['actual_read_count'] for r in results),'all_actual_reads_equal_fixed_input':True,'same_arm_payload_repeats':True,'effective_genomes_differ_only_gene':True,'scope':manifest['scope']},indent=2)+'\n')
print('Fixed-input diagnostic controls passed',flush=True)
