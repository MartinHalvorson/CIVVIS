import pathlib,subprocess,json,hashlib,time
w=pathlib.Path('/Users/martbot-mbp-m5-max-128/civvis-conquest-planner-profile-7fa3');t=pathlib.Path('/tmp/civvis-conquest-planner-profile-7fa3');base='2026-10-26-conquest-planner-profile';p=w/'docs/eval'/f'{base}.followup-plan.json';plan=json.loads(p.read_text());sel=w/'docs/eval'/f'{base}.selection.json';probe=t/'probe-01';out=t/'followup-01';out.mkdir(exist_ok=False)
assert hashlib.sha256(sel.read_bytes()).hexdigest()==plan['selection_sha256'];assert hashlib.sha256(probe.read_bytes()).hexdigest()==plan['probe_sha256'];assert hashlib.sha256((t/'run-01/results.json').read_bytes()).hexdigest()==plan['baseline_results_sha256']
(out/'registration.json').write_text(json.dumps({'plan':plan,'plan_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n');results=[]
for i in plan['indices']:
 d=out/f'{i:04d}';d.mkdir();command=[str(probe),str(sel),str(i),str(plan['repetitions'])];r={'index':i,'argv':command,'complete':False};process=None
 try:
  with (d/'stdout').open('wb') as stdout,(d/'stderr').open('wb') as stderr:
   process=subprocess.Popen(command,stdout=stdout,stderr=stderr);r['pid']=process.pid;(d/'pid.json').write_text(json.dumps(r,indent=2)+'\n');sample=['/usr/bin/sample',str(process.pid),'1','1','-file',str(d/'sample.txt')];s=subprocess.run(sample,capture_output=True,timeout=20);(d/'sampler.stdout').write_bytes(s.stdout);(d/'sampler.stderr').write_bytes(s.stderr);r.update(sampler_argv=sample,sampler_exit=s.returncode);r['exit']=process.wait(timeout=300)
  value=json.loads((d/'stdout').read_bytes());assert r['exit']==0 and value['case']==i;r.update(complete=True,samples=value['samples'])
 except Exception as error:r['error']=type(error).__name__+': '+str(error)
 finally:
  if process is not None and process.poll() is None:process.kill();process.wait()
 (d/'result.json').write_text(json.dumps(r,indent=2)+'\n');results.append(r);(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(i,r['complete'],r.get('error'),r.get('sampler_exit'),flush=True)
