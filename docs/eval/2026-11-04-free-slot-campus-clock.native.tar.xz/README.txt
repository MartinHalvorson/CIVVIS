free-slot-campus-clock — native development proposal audit

Qualified production/regression source: 9a644ec1f38179d36a588701b3eb3c3d4d543e31.
The frozen candidate is retained externally as candidate-ci-orders; its digest,
compiler and local ci/LTO=off build settings are in build-receipt.json. Binaries
are omitted from the repository archive. No CI/profile or live setting changed.

Main source140152: original and candidate OFF controls each repeat290 requests
through120/2. ON first differs at91/0, request212, replacing only Caracas city
262147's newly proposed Catapult with a Campus. The raw queue was idle; Campus
quote126 production,26 turns,0 saved progress; Khmer war open. Every other order
retains its sequence. Four successful persistent same-prefix queries consume
identical actual read bytes/count/order and exit0 on actual EOF. Input deliveries,
raw replies/captures, genomes, argv, source hashes and independent verifier are
included. Run `python3 verify.py <extracted-root>` with the CIVVIS repository's
tools importable at ~/civvis-main-managed. The verifier obtains the pinned source
from Git and reconstructs every read sequence; fetch refs/pull/4421/head if needed.

Second development source134411 is retained under additional-source-134411.
Original and candidate OFF controls each repeat315 requests through120/2. ON first
differs119/0, request310: idle Panama proposes a20-turn Campus instead of an11-turn
Government Plaza, with different Builder orders as well. Both ON prefixes repeat,
and four successful persistent queries exit0. Its strict verifier intentionally
exits1 on the unchanged-other-orders assertion. strict-verification.json records
the rejection. Do not use this second source as the isolated firing proof.

The two histories were selected development inputs, not holdouts or paired
continued worlds. No replay order was executed by the native game, and no science,
completion, survival or strength improvement is established. The flag stays off.
The prospective screen-plan.json uses150-turn outcomes because known proposed
Campuses would finish after100. That plan is not armed. Motivation census retains
partial/retired/censored attempts and does not establish complete eligibility.
