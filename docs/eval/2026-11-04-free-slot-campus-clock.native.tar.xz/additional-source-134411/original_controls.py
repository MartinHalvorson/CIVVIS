from pathlib import Path
import json,sys
repo=Path.home()/'civvis-main-managed';sys.path.insert(0,str(repo/'tools'))
import civ6_captured_read_replay as replay
from civ6_ladder import decider_genome
root=Path(__file__).parent;context=json.loads((root/'observed-context.json').read_text());records=[json.loads(l) for l in (root/'native-decisions.jsonl').open()];mapping={r['source']:Path(r['sealed_directory']) for r in json.loads((root/'sealed-captures.json').read_text())};out=root/'original-controls';out.mkdir();report={'controls':[]}
for n in range(2):
 d=out/f'control-{n}';r=replay.run_control(context,records,mapping,d,60,'hybrid');report['controls'].append(r);(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'repeat':n,'passed':r['passed'],'requests':len(r['requests']),'error':r.get('error')}),flush=True);assert r['passed'];assert 'free-slot-campus-clock' not in decider_genome(d/'stderr.log')['treatments']
