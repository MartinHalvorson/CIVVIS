from pathlib import Path
import copy,hashlib,json,subprocess,sys,shutil
repo=Path('/Users/martbot-mbp-m5-max-128/civvis-free-slot-campus-clock-0eb7');sys.path.insert(0,str(repo/'tools'))
import civ6_captured_read_replay as replay
from civ6_ladder import decider_genome
from native_city_route_replay import control_payload,request_identity_errors
from civ6_decision_trace import exact_fact
root=Path.home()/'civvis-tactics-results/2026-11-04/free-slot-campus-clock';intent=json.loads((root/'intent.json').read_text());gene=intent['tag'];sha=lambda b:hashlib.sha256(b).hexdigest()
for name,digest in intent['production_files_sha256'].items():assert sha((repo/name).read_bytes())==digest and subprocess.check_output(['git','show',intent['source_commit']+':'+name],cwd=repo)==(repo/name).read_bytes()
assert 'Finished' in Path('/tmp/civvis-campus-clock-native-build.log').read_text()
binary=root/'candidate-ci-orders';assert not binary.exists();shutil.copy2(repo/'target/ci/civvis_orders',binary);digest=sha(binary.read_bytes())
context=json.loads((root/'observed-context.json').read_text());records=[json.loads(l) for l in (root/'native-decisions.jsonl').open()];assert len(records)==290
qualification=json.loads((root/'original-controls/results.json').read_text());assert len(qualification['controls'])==2 and all(c['passed'] and len(c['requests'])==290 for c in qualification['controls'])
mapping={r['source']:Path(r['sealed_directory']) for r in json.loads((root/'sealed-captures.json').read_text())}
genome=decider_genome(root/'original-controls/control-0/stderr.log');assert gene not in genome['treatments']
report={'intent':intent,'candidate_sha256':digest,'scope':'Full captured-read controls OFF, ON stops at first order difference. No continued counterfactual world, native execution, science gain or win-rate evidence.','controls':[],'treatments':[]}
def candidate(on):
 c=copy.deepcopy(context);c['processes'][0]['argv'][0]=str(binary);c['processes'][0]['argv']+=(['--with',gene] if on else []);c['binary_sha256']=digest;c['provenance']={'sha256':digest,'source_commit':intent['source_commit'],'scope':'Constructed candidate command, not an observed native process.'};return c
out=root/'captured-prefix';out.mkdir()
for n in range(2):
 d=out/f'off-{n}';r=replay.run_control(candidate(False),records,mapping,d,60,'hybrid');g=decider_genome(d/'stderr.log');assert set(g['treatments'])==set(genome['treatments']) and set(g['forced'])==set(genome['forced']);report['controls'].append(r);(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'stage':'off','repeat':n,'passed':r['passed'],'requests':len(r['requests']),'error':r.get('error')}),flush=True);assert r['passed']
original_payload=replay.control_payload;replay.control_payload=lambda r:{'orders':r['orders']}
for n in range(2):
 d=out/f'on-{n}';r=replay.run_control(candidate(True),records,mapping,d,60,'hybrid');g=decider_genome(d/'stderr.log');assert set(g['treatments'])==set(genome['treatments'])|{gene} and set(g['forced'])==set(genome['forced'])|{gene}
 valid=all(not x['identity_errors'] and x['read_sequence_matches'] for x in r['requests']);changed=not r['passed'] and (r.get('error') or '').startswith('ValueError: original-binary control differs') and valid and r['requests'][-1]['native_payload_matches'] is False
 report['treatments'].append(r);(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'stage':'on','repeat':n,'valid_reads':valid,'first_order_difference':r.get('failed_request'),'requests':len(r['requests']),'changed':changed,'error':r.get('error')}),flush=True);assert changed or r['passed']
replay.control_payload=original_payload
if all(r['passed'] for r in report['treatments']):
 print(json.dumps({'passed':True,'unchanged_proposals':True,'requests_each':len(records)}),flush=True);sys.exit(0)
left,right=report['treatments'];assert left['failed_request']==right['failed_request'] and len(left['requests'])==len(right['requests']);nrequests=len(left['requests']);prefix=records[:nrequests];expected_on=[json.loads(l) for l in (out/'on-0/replies.jsonl').open()]
subprocess.run([sys.executable, str(root/'successful_pairs.py'), '--root', str(root)],check=True)
