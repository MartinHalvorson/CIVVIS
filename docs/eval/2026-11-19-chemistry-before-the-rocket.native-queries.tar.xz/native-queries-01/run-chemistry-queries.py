"""Paired decider queries on live frames of four Deity Science-seat games of
2026-11-18 whose Chemistry came after Rocketry's Radio half.

`chemistry-before-the-rocket` is the only bit that varies. Each case is a live
run's own events.jsonl cut after turn N+1 (every row through the first rows of
the next turn), replayed at turn N. Both arms run one frozen
`civvis_orders --resumed` built from the branch, with that run's own requested
genome (why.log line 1 `forced`, each as `--with`); the on arm adds
`--with chemistry-before-the-rocket`.

Read per arm: the research order and the gene's own journal lines. Per case:
whether any order changed.

Each case is cut right after the turn's first state row with no research
chosen (frame 0 of a completion turn: the input the live decider answered).
Cases, every turn the live run sent a research order from its first standing
University to the turn before Chemistry: civvis-20261118T192816Z (Japan; University t119, Chemistry t154,
Rocketry t158), -T115057Z (Russia; t86, t141, t143), -T045850Z (Kongo; t112,
t163, t173) and -T201051Z (Japan; t99, t129, t138).

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
JOBS = int(sys.argv[4]) if len(sys.argv) > 4 else 2
GENE = 'chemistry-before-the-rocket'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

GAMES = [
    ('civvis-20261118T192816Z', 'science', 'CIVILIZATION_JAPAN', [120, 124, 130, 135, 138, 143, 144, 145, 148, 151]),
    ('civvis-20261118T115057Z', 'science', 'CIVILIZATION_RUSSIA', [91, 92, 93, 96, 100, 101, 104, 108, 109, 114, 115, 117, 120, 121, 123, 127, 131, 135, 137]),
    ('civvis-20261118T045850Z', 'science', 'CIVILIZATION_KONGO', [113, 115, 119, 121, 123, 125, 130, 133, 135, 140, 142, 146, 147, 151, 155, 160]),
    ('civvis-20261118T201051Z', 'science', 'CIVILIZATION_JAPAN', [102, 107, 110, 111, 115, 118, 120, 121, 122, 123, 127]),
]
CASES = [{'run': r, 'victory': v, 'civ': c, 'turn': t} for r, v, c, turns in GAMES for t in turns]
UNIVERSITY = ('BUILDING_UNIVERSITY', 'BUILDING_MADRASA', 'BUILDING_NAVIGATION_SCHOOL')


def cut(run, turn):
    """Rows through the turn's first state row with no research chosen, and that row."""
    rows, last = [], None
    with open(RUNS / run / 'events.jsonl', errors='replace') as f:
        for line in f:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > turn:
                break
            rows.append(line)
            # The frame the research choice was asked on: the first state
            # row of the turn whose research is empty. Cut right after it.
            if e.get('kind') == 'state' and e.get('turn') == turn and not e.get('research'):
                last = e
                break
    return ''.join(rows).encode(), last


def production(row, names):
    out = {}
    for o in row.get('payload', {}).get('orders', []):
        if o.get('kind') == 'research':
            out.setdefault(names.get(o.get('subject'), str(o.get('subject'))), []).append(
                f"{o['kind']}:{o.get('verb')}")
    return out


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data, last = cut(case['run'], case['turn'])
        names = {}
        ready = [c['name'] for c in last['cities'] if set(UNIVERSITY) & set(c.get('buildings') or [])]
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'cut': 'after the turn\'s first state row with research empty'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                  'board': {'chemistry': 'TECH_CHEMISTRY' in (last.get('techs') or []),
                            'research': last.get('research'),
                            'cities_with_university': ready,
                            'cities': len(last['cities']), 'gold': last.get('gold')},
                  'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', case['victory'], '--civ', case['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if GENE + ':' in line]
            row['production'] = production(row, names)
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['production_changed'] = {
            city: {'off': off['production'].get(city), 'on': on['production'].get(city)}
            for city in sorted(set(off['production']) | set(on['production']))
            if off['production'].get(city) != on['production'].get(city)}
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    with ThreadPoolExecutor(JOBS) as pool:
        results = list(pool.map(lambda ic: one(*ic), enumerate(CASES)))
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
             'on_gene_lines': 0, 'off_gene_lines': 0, 'on_research_orders': 0, 'off_research_orders': 0}
    for r in results:
        c = r['case']
        if r.get('error'):
            print(c['run'], c['turn'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            off, on = v['arms']
            total['on_gene_lines'] += len(on['journal_gene'])
            total['off_gene_lines'] += len(off['journal_gene'])
            for arm, key in ((off, 'off_research_orders'), (on, 'on_research_orders')):
                total[key] += sum(len(orders) for orders in arm['production'].values())
            print(f"{c['run'][-16:]} t{c['turn']:<3} research {v['board']['research']} "
                  f"{'CHANGED' if v['orders_changed'] else 'same   '} gene lines {len(on['journal_gene'])} "
                  f"{json.dumps(v['production_changed'])}")
            for line in on['journal_gene']:
                print('      ', line[:230])
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
