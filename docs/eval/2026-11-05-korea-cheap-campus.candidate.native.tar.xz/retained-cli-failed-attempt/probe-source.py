"""One predeclared same-candidate comparison; never sends game orders."""
from pathlib import Path
import argparse,json,hashlib,subprocess,shutil,sys
base=Path(__file__).parent;repo=Path.home()/'civvis-korea-cheap-campus-before-settler-44e0';sys.path.insert(0,str(repo/'tools'))
from native_build_artifact import verify
from civ6_captured_read_replay import expanded_reads
from civ6_decision_trace import exact_fact
from civ6_ladder import decider_genome
p=argparse.ArgumentParser();p.add_argument('--artifact',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=a.output.resolve();root.mkdir();read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();write=lambda p,d:p.write_text(json.dumps(d,indent=2)+'\n')
try:
 protocol=read(base/'korea-cheap-campus-candidate-protocol.json');receipt=verify(repo,a.artifact,protocol['candidate_source'],json.dumps(protocol['tests']),protocol['toolchain']);assert receipt['tests']==[{'target':'lib','filter':f,'passed':n} for f,n in zip(protocol['tests']['lib'],protocol['expected_pass_counts'])]
 source=base/'korea-cheap-campus-witness-114538';data=(source/'events.jsonl').read_bytes();assert sha(data)==protocol['input_sha256'];finding=read(source/'finding.json');genome=read(source/'observed-context.json')['actual_genome'];tag=protocol['flag'];assert tag in genome['treatments'];city=protocol['city_id'];sites={(p['x'],p['y']) for p in finding['seowon_quote']['s']}
 (root/'events.jsonl').write_bytes(data);shutil.copy2(base/'korea-cheap-campus-candidate-protocol.json',root/'protocol.json');shutil.copy2(source/'finding.json',root/'source.json');shutil.copy2(a.artifact/'receipt.json',root/'build-receipt.json');binary=a.artifact/'civvis_orders';assert sha(binary.read_bytes())==receipt['binaries']['civvis_orders'];binary.chmod(binary.stat().st_mode|0o100);shutil.copy2(binary,root/'probe-binary');digest=sha((root/'probe-binary').read_bytes());common=root/'current-capture';references={};pairs=[];effects=[]
 for repeat in [1,2]:
  pairroot=root/f'repeat-{repeat}';pairroot.mkdir();arms=[]
  for label in ['off','on']:
   folder=pairroot/label;folder.mkdir();(folder/'events.jsonl').write_bytes(data);assert not common.exists();cmd=[str(root/'probe-binary'),'--mirror',str(folder),'--turn','46','--victory','science','--civ','CIVILIZATION_KOREA','--explain','--serve','--fresh-board','--capture-inputs',str(common)]
   for gene in genome['forced']:
    if gene!=tag:cmd+=['--with',gene]
   cmd+=['--with' if label=='on' else '--without',tag];write(folder/'command.json',{'argv':cmd,'cwd':str(repo)});proc=subprocess.run(cmd,cwd=repo,input='46\n',text=True,capture_output=True,timeout=180);(folder/'stdout.json').write_text(proc.stdout);(folder/'stderr.log').write_text(proc.stderr);assert proc.returncode==0,(label,proc.returncode);payload=json.loads(proc.stdout);assert payload['turn']==46 and (payload['decision']['turn'],payload['decision']['frame'])==(46,0);assert payload['decision']['victory_portfolio']['assigned_target']=='science';reads=expanded_reads(payload['input_capture']);assert reads and all(b==data for b in reads);actual=decider_genome(folder/'stderr.log');assert actual and (tag in actual['treatments'])==(label=='on');stable={k:payload[k] for k in ['orders','decision']}
   if repeat==1:references[label]=stable
   else:assert exact_fact(references[label],stable),f'{label} full repeated reply changed'
   orders=[o for o in payload['orders'] if o['kind']=='produce' and o.get('subject')==city];moved=folder/'input-capture';shutil.move(str(common),str(moved));arms.append({'arm':label,'argv':cmd,'cwd':str(repo),'genome':actual,'payload':payload,'actual_read_count':len(reads),'target_city_orders':orders,'capture_relocated_to':str(moved),'binary_sha256':digest});print(json.dumps({'repeat':repeat,'arm':label,'actual_reads':len(reads),'target_city_orders':orders}),flush=True)
  off,on=arms
  for field in ['forced','treatments']:assert set(off['genome'][field])-{tag}==set(on['genome'][field])-{tag}
  assert exact_fact({k:v for k,v in off['genome'].items() if k not in ['forced','treatments']},{k:v for k,v in on['genome'].items() if k not in ['forced','treatments']})
  placed=on['target_city_orders'];effect={'repeat':repeat,'off_target_orders':off['target_city_orders'],'on_target_orders':placed,'contrast_observed':off['target_city_orders']==[] and len(placed)==1 and placed[0]['verb']=='DISTRICT_SEOWON' and (placed[0].get('x'),placed[0].get('y')) in sites};effects.append(effect);write(pairroot/'pair.json',{'execution_complete':True,'arms':arms,'effect':effect,'source_commit':protocol['candidate_source'],'binary_sha256':digest,'input_sha256':sha(data)});pairs.append(str(pairroot/'pair.json'))
 assert sha((root/'probe-binary').read_bytes())==digest;write(root/'result.json',{'execution_complete':True,'contrast_observed_in_both_repetitions':all(e['contrast_observed'] for e in effects),'effects':effects,'pairs':pairs,'source_commit':protocol['candidate_source'],'binary_sha256':digest,'scope':'All four scheduled fresh-private roles retained. Same tested candidate/public prefix; only Campus-v2 flag differs. No native execution, original private-state parity, timing or strength claim.'})
except BaseException as error:write(root/'failure.json',{'execution_complete':False,'error':repr(error),'scope':'Retained structural/execution failure, unexecuted roles not treated as run. No retries or replacement input.'});raise
