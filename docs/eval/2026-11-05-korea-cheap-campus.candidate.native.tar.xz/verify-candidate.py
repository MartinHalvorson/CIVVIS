"""Independently verify the four retained candidate roles, without rerunning them."""
from pathlib import Path
import json,hashlib,sys,copy
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).parent;sys.path.insert(0,str(root/'verification-tools'))
from civ6_decision_trace import validate_input_capture,captured_input,exact_fact
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();protocol=read(root/'protocol.json');receipt=read(root/'build-receipt.json');result=read(root/'result.json');assert result['execution_complete'] and not (root/'failure.json').exists();assert receipt['source']['sha']==protocol['candidate_source']==result['source_commit'];assert receipt['tests']==[{'target':'lib','filter':f,'passed':n} for f,n in zip(protocol['tests']['lib'],protocol['expected_pass_counts'])]
data=(root/'events.jsonl').read_bytes();assert sha(data)==protocol['input_sha256'];digest=receipt['binaries']['civvis_orders'];assert digest==result['binary_sha256'];binary=root/'probe-binary'
if binary.exists():assert sha(binary.read_bytes())==digest
finding=read(root/'source.json');assert finding['input_sha256']==sha(data);city=protocol['city_id'];tag=protocol['flag'];sites={(p['x'],p['y']) for p in finding['seowon_quote']['s']};reference={};rows=[];effects=[]
for repeat in [1,2]:
 pair=read(root/f'repeat-{repeat}/pair.json');assert pair['execution_complete'];assert pair['source_commit']==protocol['candidate_source'] and pair['binary_sha256']==digest and pair['input_sha256']==sha(data);arms=[]
 for label in ['off','on']:
  folder=root/f'repeat-{repeat}'/label;record=next(a for a in pair['arms'] if a['arm']==label);payload=read(folder/'stdout.json');assert exact_fact(payload,record['payload']);assert payload['turn']==46 and (payload['decision']['turn'],payload['decision']['frame'])==(46,0);assert payload['decision']['victory_portfolio']['assigned_target']=='science';assert read(folder/'command.json')=={'argv':record['argv'],'cwd':record['cwd']};assert record['binary_sha256']==digest
  raw=next(json.loads(l) for l in (folder/'stderr.log').read_text().splitlines() if l.startswith('{') and json.loads(l).get('kind')=='genome');actual={k:raw.get(k) for k in record['genome']};assert exact_fact(actual,record['genome']);assert (tag in actual['treatments'])==(label=='on');cap=copy.deepcopy(payload['input_capture']);cap['directory']=str(folder/'input-capture');validate_input_capture(cap);assert cap['complete'];count=0
  for r in cap['reads']:
   assert 'snapshot_id' in r;assert captured_input(cap,r['snapshot_id'])==data;count+=r['count']
  assert count and count==record['actual_read_count'];stable={k:payload[k] for k in ['orders','decision']}
  if label in reference:assert exact_fact(reference[label],stable)
  else:reference[label]=stable
  orders=[o for o in payload['orders'] if o['kind']=='produce' and o.get('subject')==city];assert orders==record['target_city_orders'];arms.append({'label':label,'genome':actual,'orders':orders});rows.append({'repeat':repeat,'arm':label,'actual_reads':count,'input_sha256':sha(data),'target_city_orders':orders})
 off,on=arms
 for field in ['forced','treatments']:assert set(off['genome'][field])-{tag}==set(on['genome'][field])-{tag}
 assert exact_fact({k:v for k,v in off['genome'].items() if k not in ['forced','treatments']},{k:v for k,v in on['genome'].items() if k not in ['forced','treatments']})
 placed=on['orders'];effect={'repeat':repeat,'off_target_orders':off['orders'],'on_target_orders':placed,'contrast_observed':off['orders']==[] and len(placed)==1 and placed[0]['verb']=='DISTRICT_SEOWON' and (placed[0].get('x'),placed[0].get('y')) in sites};assert exact_fact(effect,pair['effect']);effects.append(effect)
assert effects==result['effects'];contrast=all(e['contrast_observed'] for e in effects);assert contrast==result['contrast_observed_in_both_repetitions'];report={'verified':True,'contrast_observed_in_both_repetitions':contrast,'candidate_source':protocol['candidate_source'],'binary_sha256':digest,'focused_mac_tests_passed':sum(protocol['expected_pass_counts']),'rows':rows,'effects':effects,'scope':'All four fresh-private candidate roles independently checked from raw replies, actual genome logs and captured bytes. No original private-state replay, native placement, expansion/research timing or victory-strength claim.'};(root/'independent-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
