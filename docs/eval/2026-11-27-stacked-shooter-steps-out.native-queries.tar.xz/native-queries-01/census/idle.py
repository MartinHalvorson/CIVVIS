"""Shooters with a target in range at the start of our turn, and whether they fired."""
import gzip, json, sys, collections, os
sys.path.insert(0, os.path.dirname(__file__))
from deaths import hexdist, is_soldier
SIEGE = ('CATAPULT', 'TREBUCHET', 'BOMBARD', 'BATTERING_RAM', 'SIEGE_TOWER', 'ARTILLERY', 'BALLISTA')
TOT = collections.Counter()
for path in sys.argv[1:]:
    first = {}; combats = collections.defaultdict(list); width = 0; me = 0
    for line in gzip.open(path, 'rt', errors='replace'):
        if '"kind": "state"' in line:
            try: e = json.loads(line)
            except ValueError: continue
            t = e.get('turn')
            if t not in first: first[t] = e
        elif '"kind": "combat"' in line:
            try: e = json.loads(line)
            except ValueError: continue
            if e.get('ours'): combats[e.get('turn')].append(e)
        elif '"kind": "seat"' in line:
            me = json.loads(line).get('local_player', 0)
        elif '"kind": "tiles"' in line and '"width"' in line:
            try: width = json.loads(line).get('width') or width
            except ValueError: pass
    c = collections.Counter()
    for t, st in first.items():
        enemies = []
        for r in st.get('rivals') or []:
            if r.get('at_war'):
                enemies += [u for u in r.get('units') or [] if (u.get('combat') or 0) > 0 or (u.get('ranged') or 0) > 0]
        enemies += [h for h in st.get('hostiles') or [] if (h.get('combat') or 0) > 0]
        if not enemies: continue
        fired = {(x.get('attacker') or {}).get('id') for x in combats.get(t, [])}
        tilecount = collections.Counter((u['x'], u['y']) for u in st.get('units') or [] if is_soldier(u))
        cities = {(cc['x'], cc['y']) for cc in st.get('cities') or []}
        for u in st.get('units') or []:
            rng = u.get('range') or 0
            if rng < 1 or (u.get('ranged') or 0) <= 0 or (u.get('attacks_remaining') or 0) < 1 or (u.get('moves') or 0) <= 0:
                continue
            if any(s in (u.get('kind') or '') for s in SIEGE): continue
            near = [en for en in enemies if hexdist((u['x'], u['y']), (en['x'], en['y']), width) <= rng]
            if not near: continue
            c['eligible'] += 1
            stacked = tilecount[(u['x'], u['y'])] > 1
            where = ('stacked' if stacked else 'alone') + ('_city' if (u['x'], u['y']) in cities else '_field')
            c['elig_' + where] += 1
            if u.get('id') in fired:
                c['fired'] += 1; c['fired_' + where] += 1
            # near a siege unit
            if any(any(s in (en.get('kind') or en.get('type') or '') for s in SIEGE) for en in near):
                c['eligible_vs_siege'] += 1
                if u.get('id') in fired: c['fired_vs_siege_turn'] += 1
    TOT.update(c)
    if c['eligible']:
        print(os.path.basename(os.path.dirname(path))[10:], dict(c), 'fire rate', round(c['fired'] / c['eligible'], 2))
print('TOTAL', dict(TOT), 'fire rate', round(TOT['fired'] / max(1, TOT['eligible']), 2))
for w in ('stacked_city', 'stacked_field', 'alone_city', 'alone_field'):
    print(w, TOT['elig_' + w], TOT['fired_' + w], round(TOT['fired_' + w] / max(1, TOT['elig_' + w]), 2))
