import gzip, json, sys, collections, os
sys.path.insert(0, os.path.dirname(__file__))
from deaths import hexdist, is_soldier, is_ranged
tot = collections.Counter(); comp = collections.Counter(); runs = collections.Counter()
for path in sys.argv[1:]:
    first = {}; width = 0
    for line in gzip.open(path, 'rt', errors='replace'):
        if '"kind": "state"' in line:
            try: e = json.loads(line)
            except ValueError: continue
            if e['turn'] not in first: first[e['turn']] = e
        elif '"kind": "tiles"' in line and '"width"' in line:
            try: width = json.loads(line).get('width') or width
            except ValueError: pass
    streak = collections.Counter()
    for t in sorted(first):
        st = first[t]
        cities = {(c['x'], c['y']): c for c in st.get('cities') or []}
        hostile = []
        for r in st.get('rivals') or []:
            if r.get('at_war'): hostile += [u for u in r.get('units') or [] if is_soldier(u)]
        hostile += [h for h in st.get('hostiles') or [] if (h.get('combat') or 0) > 0]
        at = collections.defaultdict(list)
        for u in st.get('units') or []:
            if is_soldier(u) and (u['x'], u['y']) in cities: at[(u['x'], u['y'])].append(u)
        for pos, us in at.items():
            if len(us) < 2: continue
            threat = any(hexdist(pos, (h['x'], h['y']), width) <= 4 for h in hostile)
            sh = sum(1 for u in us if is_ranged(u.get('kind') or ''))
            tot['stack_turns'] += 1; tot['stack_turns_threat'] += threat
            tot['stacked_units'] += len(us); tot['stacked_units_threat'] += len(us) * threat
            comp[(len(us), sh)] += 1
            runs[os.path.basename(os.path.dirname(path))[10:]] += 1
print(dict(tot)); print('composition (units, shooters):', comp.most_common(8)); print('games with stacks', len(runs), 'of', len(sys.argv) - 1)
