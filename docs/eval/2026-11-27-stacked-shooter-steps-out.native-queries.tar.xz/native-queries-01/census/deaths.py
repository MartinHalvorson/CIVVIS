"""How each eliminated live game died: city losses, wars, warning, what we had."""
import gzip, json, sys, collections, os

def hexdist(a, b, width):
    # Civ VI: odd-r offset (odd rows shifted right), wrap in x.
    def cube(x, y):
        q = x - (y - (y & 1)) // 2
        return q, y
    best = 10**9
    for dx in (0, width, -width) if width else (0,):
        q1, r1 = cube(a[0], a[1]); q2, r2 = cube(b[0] + dx, b[1])
        d = (abs(q1 - q2) + abs(r1 - r2) + abs((q1 + r1) - (q2 + r2))) // 2
        best = min(best, d)
    return best

RANGED = ('ARCHER', 'SLINGER', 'CROSSBOW', 'FIELD_CANNON', 'MACHINE_GUN', 'PITATI', 'MAMLUK_ARCHER', 'MAMLUK','CHU_KO_NU','NUBIAN','PITATI_ARCHER','HUNGARIAN')
def is_ranged(k):
    return any(s in k for s in ('ARCHER', 'SLINGER', 'CROSSBOW', 'FIELD_CANNON', 'MACHINE_GUN', 'CHU_KO_NU'))
CIVIL = ('SETTLER', 'BUILDER', 'TRADER', 'MISSIONARY', 'APOSTLE', 'PROPHET', 'GURU', 'INQUISITOR', 'SCOUT', 'ARCHAEOLOGIST', 'SPY', 'GREAT', 'NATURALIST', 'ROCK_BAND', 'MEDIC', 'ENGINEER', 'OBSERVATION_BALLOON', 'DRONE')
def is_soldier(u):
    k = u.get('kind') or u.get('type') or ''
    if any(c in k for c in CIVIL): return False
    return (u.get('combat') or 0) > 0 or (u.get('ranged') or 0) > 0

def analyse(path):
    states = {}
    combats = []
    builds = collections.defaultdict(list)
    seat = None; width = 0; peace = []
    for line in gzip.open(path, 'rt', errors='replace'):
        if '"kind": "state"' not in line and '"kind": "combat"' not in line and '"order_kind": "produce' not in line and '"order_kind": "buy' not in line and '"order_kind": "purchase' not in line and '"kind": "seat"' not in line and '"kind": "peace_' not in line and '"kind": "tiles"' not in line:
            continue
        try: e = json.loads(line)
        except ValueError: continue
        k = e.get('kind')
        if k == 'state' and isinstance(e.get('turn'), int):
            states[e['turn']] = e
        elif k == 'combat':
            combats.append(e)
        elif k == 'order_verified' and str(e.get('order_kind','')).startswith(('produce','buy','purchase')):
            builds[e.get('turn')].append((e.get('subject'), e.get('order_kind') + ':' + str(e.get('verb'))))
        elif k == 'seat':
            seat = e
        elif k in ('peace_request', 'peace_response'):
            peace.append(e)
        elif k == 'tiles' and e.get('width'):
            width = e['width']
    me = (seat or {}).get('local_player', 0)
    turns = sorted(states)
    if not turns: return None
    out = {'run': os.path.basename(os.path.dirname(path)), 'civ': (seat or {}).get('civ'), 'last': turns[-1], 'width': width}
    civ_of = {}
    for t in turns:
        for r in states[t].get('rivals') or []:
            civ_of[r['player']] = r.get('civ')
    civ_of[63] = 'BARBARIAN'
    for t in turns[::10]:
        for m in states[t].get('minors') or []:
            if isinstance(m, dict) and isinstance(m.get('player'), int):
                civ_of.setdefault(m['player'], 'CS:' + str(m.get('civ') or m.get('name') or m['player']))
    def ours(t):
        return {c['id']: c for c in states[t].get('cities') or []}
    # wars
    war_start = {}; war_end = {}
    prev = {}
    for t in turns:
        for r in states[t].get('rivals') or []:
            p = r['player']; w = bool(r.get('at_war'))
            if w and not prev.get(p):
                war_start.setdefault(p, []).append(t)
            if not w and prev.get(p):
                war_end.setdefault(p, []).append(t)
            prev[p] = w
    out['wars'] = []
    for p, starts in war_start.items():
        for t0 in starts:
            st = states[t0]; mine = st.get('military') or 1
            r = next(r for r in st['rivals'] if r['player'] == p)
            ratio = (r.get('military') or 0) / max(mine, 1)
            # ratio 10 turns before
            tb = max([t for t in turns if t <= t0 - 10] or [turns[0]])
            rb = next((x for x in states[tb]['rivals'] if x['player'] == p), {})
            ratio_b = (rb.get('military') or 0) / max(states[tb].get('military') or 1, 1)
            # first turn before war that >=2 of its soldiers stood within 8 of our capital
            cap = next((c for c in st.get('cities') or [] if c.get('capital')), None)
            first_near = None
            if cap:
                for t in turns:
                    if t > t0: break
                    if t < t0 - 30: continue
                    rr = next((x for x in states[t]['rivals'] if x['player'] == p), None)
                    if not rr: continue
                    n = sum(1 for u in rr.get('units') or [] if is_soldier(u) and hexdist((u['x'], u['y']), (cap['x'], cap['y']), width) <= 8)
                    if n >= 2:
                        first_near = t; break
            den = r.get('their_denounce_turn')
            capw = bool(cap) and 'BUILDING_WALLS' in (cap.get('buildings') or [])
            mine_units = [u for u in st.get('units') or [] if is_soldier(u)]
            cap_ranged = sum(1 for u in mine_units if cap and is_ranged(u.get('kind') or '') and hexdist((u['x'], u['y']), (cap['x'], cap['y']), width) <= 1)
            cap_any = sum(1 for u in mine_units if cap and hexdist((u['x'], u['y']), (cap['x'], cap['y']), width) <= 2)
            asks = [x for x in peace if x.get('kind') == 'peace_request' and x.get('target') == p and (x.get('turn') or 0) >= t0]
            oks = [x for x in peace if x.get('kind') == 'peace_response' and x.get('target') == p and x.get('accepted') and (x.get('turn') or 0) >= t0]
            ends = [t for t in war_end.get(p, []) if t > t0]
            their_units = collections.Counter((u.get('kind') or '')[5:] for u in r.get('units') or [] if is_soldier(u))
            out['wars'].append({'by': civ_of.get(p), 'p': p, 'turn': t0, 'ratio': round(ratio, 2), 'ratio_m10': round(ratio_b, 2),
                                'their_mil': r.get('military'), 'our_mil': mine, 'near2_8_first': first_near,
                                'denounced': den, 'state_before': (rb.get('diplomatic_state') or '')[11:],
                                'cap_walls': capw, 'cap_ranged_adj': cap_ranged, 'cap_soldiers_r2': cap_any, 'our_soldiers': len(mine_units),
                                'first_peace_ask': asks[0]['turn'] if asks else None, 'asks': len(asks), 'peace_ok': oks[0]['turn'] if oks else None,
                                'ended': ends[0] if ends else None, 'their_army': dict(their_units.most_common(6)), 'their_soldiers': sum(their_units.values()),
                                'our_cities': len(st.get('cities') or []),
                                'gold': round(st.get('gold') or 0), 'gpt': st.get('gold_per_turn'), 'faith': round(st.get('faith') or 0),
                                'gold_m10': round(states[tb].get('gold') or 0),
                                'max_gold_war': max(round(states[t].get('gold') or 0) for t in turns if t0 <= t <= t0 + 12),
                                'buys': [(t, it) for t in sorted(builds) if t0 - 10 <= t <= t0 + 12 for cid, it in builds[t] if not it.startswith('produce')],
                                'produce_cap': [(t, it.replace('produce:','').replace('produce_next:','+')) for t in sorted(builds) if t0 - 12 <= t <= t0 + 8 for cid, it in builds[t] if cap and cid == cap.get('id') and it.startswith('produce')],
                                'gov': st.get('government'), 'policies': st.get('policies')})
    # city losses
    out['losses'] = []
    for i in range(1, len(turns)):
        a, b = turns[i - 1], turns[i]
        A, B = ours(a), ours(b)
        for cid, c in A.items():
            if cid in B: continue
            pos = (c['x'], c['y'])
            taker = None
            for r in (states[b].get('rivals') or []) + (states[b].get('minors') or []):
                for rc in r.get('cities') or []:
                    if (rc.get('x'), rc.get('y')) == pos:
                        taker = civ_of.get(r['player'])
            # last combats on the city tile
            hits = [x for x in combats if x.get('against_us') and a - 3 <= (x.get('turn') or 0) <= b
                    and (x.get('defender') or {}).get('x') == pos[0] and (x.get('defender') or {}).get('y') == pos[1]]
            att = collections.Counter((civ_of.get((x['attacker'] or {}).get('player'), (x['attacker'] or {}).get('player')), (x['attacker'] or {}).get('kind')) for x in hits)
            if taker is None and hits:
                taker = 'razed/?' + str(att.most_common(1)[0][0][0])
            st = states[a]
            mine_units = [u for u in st.get('units') or [] if is_soldier(u)]
            inside = [u['kind'][5:] for u in mine_units if (u['x'], u['y']) == pos]
            near1 = [u['kind'][5:] for u in mine_units if 0 < hexdist((u['x'], u['y']), pos, width) <= 1]
            near3 = sum(1 for u in mine_units if hexdist((u['x'], u['y']), pos, width) <= 3)
            enemy = collections.Counter()
            for r in st.get('rivals') or []:
                if not r.get('at_war'): continue
                for u in r.get('units') or []:
                    if is_soldier(u) and hexdist((u['x'], u['y']), pos, width) <= 3:
                        enemy[(u.get('kind') or '')[5:]] += 1
            for h in st.get('hostiles') or []:
                if h.get('player') == 63 and hexdist((h['x'], h['y']), pos, width) <= 3:
                    enemy['barb:' + (h.get('type') or '')[5:]] += 1
            walls = 'BUILDING_WALLS' in (c.get('buildings') or [])
            camp = any('ENCAMPMENT' in (d.get('type') or '') or d.get('type') in ('DISTRICT_IKANDA', 'DISTRICT_THANH') for d in c.get('districts') or [])
            out['losses'].append({'turn': b, 'city': c.get('name'), 'capital': c.get('capital'), 'orig_cap': c.get('original_capital'), 'pop': c.get('pop'),
                                  'taker': taker, 'walls': walls, 'wall_hp': (c.get('max_wall_damage') or 0) - (c.get('wall_damage') or 0) if walls else 0,
                                  'encampment': camp, 'inside': inside, 'adjacent': near1, 'ours_within3': near3,
                                  'enemy_within3': dict(enemy.most_common(6)), 'attackers': {f'{k[0]}:{(k[1] or "")[5:]}': v for k, v in att.most_common(5)},
                                  'our_mil': st.get('military'), 'our_soldiers': len(mine_units)})
    # what the capital built
    capid = None
    for t in turns:
        for c in states[t].get('cities') or []:
            if c.get('original_capital') and c.get('original_owner') == me:
                capid = c['id']
        if capid: break
    seq = []
    for t in sorted(builds):
        for cid, item in builds[t]:
            short = item.replace('produce_next:', '+').replace('produce:', '').replace('UNIT_', 'U:').replace('BUILDING_', 'B:').replace('DISTRICT_', 'D:').replace('PROJECT_', 'P:').replace('ENHANCE_D:HOLY_SITE', 'PRAYERS')
            if cid == capid and (not seq or seq[-1][1] != short):
                seq.append((t, short))
            if cid != capid and not item.startswith('produce'):
                seq.append((t, 'other:' + short))
    out['capital_builds'] = seq
    # our military vs best rival over time
    out['mil'] = {}
    for mark in (20, 30, 40, 50, 60, 80, 100):
        tt = max([t for t in turns if t <= mark] or [None] or [0]) if any(t <= mark for t in turns) else None
        if tt is None: continue
        st = states[tt]
        rivals = [(r.get('military') or 0) for r in st.get('rivals') or []]
        out['mil'][mark] = (st.get('military'), max(rivals) if rivals else None, len(st.get('cities') or []))
    return out

if __name__ == '__main__':
    for p in sys.argv[1:]:
        try:
            r = analyse(p)
        except Exception as ex:
            print(json.dumps({'run': p, 'error': repr(ex)})); continue
        print(json.dumps(r))
