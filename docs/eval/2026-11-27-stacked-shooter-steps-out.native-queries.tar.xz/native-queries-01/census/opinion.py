import gzip, json, sys, collections, os
tot = collections.Counter(); totn = 0
for path in sys.argv[1:]:
    states = {}
    for line in gzip.open(path, 'rt', errors='replace'):
        if '"kind": "state"' in line:
            try: e = json.loads(line)
            except ValueError: continue
            states[e['turn']] = e
    turns = sorted(states); prev = {}
    for t in turns:
        for r in states[t].get('rivals') or []:
            w = bool(r.get('at_war'))
            if w and not prev.get(r['player']):
                # opinion 1-3 turns before declaration
                tb = max([x for x in turns if x < t] or [t])
                rb = next((x for x in states[tb].get('rivals') or [] if x['player'] == r['player']), {})
                mods = [(m.get('text'), m.get('score')) for m in rb.get('opinion_modifiers') or []]
                totn += 1
                for txt, sc in mods:
                    key = txt.split(' ', 1)[1] if txt and ' ' in txt else txt
                    tot[(key or '')[:90], 'neg' if (sc or 0) < 0 else 'pos'] += 1
                print(os.path.basename(os.path.dirname(path))[10:], t, (r.get('civ') or '')[13:], (rb.get('diplomatic_state') or '')[11:], 'grievances', rb.get('grievances_against_us'), mods[:8])
            prev[r['player']] = w
print(totn, 'declarations')
for (k, s), v in tot.most_common(40): print(v, s, k)
print("TOTAL_NEG", sum(v for (k, s), v in tot.items() if s == "neg"), "UNKNOWN_NEG", tot[("Reason", "neg")])
