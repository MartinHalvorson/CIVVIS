import gzip, json, sys, collections, os
GENERIC = set('WARRIOR SLINGER ARCHER SPEARMAN HEAVY_CHARIOT HORSEMAN CATAPULT BATTERING_RAM SIEGE_TOWER SWORDSMAN GALLEY CROSSBOWMAN KNIGHT PIKEMAN MAN_AT_ARMS TREBUCHET SKIRMISHER COURSER QUADRIREME BOMBARD MUSKETMAN PIKE_AND_SHOT FIELD_CANNON CAVALRY CUIRASSIER LINE_INFANTRY CARAVEL FRIGATE PRIVATEER IRONCLAD MACHINE_GUN ARTILLERY INFANTRY AT_CREW MODERN_AT TANK BATTLESHIP BIPLANE JET_BOMBER BOMBER FIGHTER DESTROYER SUBMARINE RANGER SPEC_OPS SCOUT MEDIC MILITARY_ENGINEER OBSERVATION_BALLOON SETTLER BUILDER TRADER MISSIONARY APOSTLE INQUISITOR GURU NATURALIST ARCHAEOLOGIST SPY ROCK_BAND ANTI_AIR_GUN MOBILE_SAM MODERN_ARMOR HELICOPTER GIANT_DEATH_ROBOT DRONE MECHANIZED_INFANTRY MISSILE_CRUISER NUCLEAR_SUBMARINE AIRCRAFT_CARRIER SUPPLY_CONVOY ROCKET_ARTILLERY LANDSHIP'.split())
out = collections.Counter()
for path in sys.argv[1:]:
    states = {}
    for line in gzip.open(path, 'rt', errors='replace'):
        if '"kind": "state"' in line:
            try: e = json.loads(line)
            except ValueError: continue
            states[e['turn']] = e
    turns = sorted(states); prev = {}; wars = []
    for t in turns:
        for r in states[t].get('rivals') or []:
            w = bool(r.get('at_war'))
            if w and not prev.get(r['player']): wars.append((t, r['player'], r.get('civ')))
            prev[r['player']] = w
    for t0, p, civ in wars:
        seen_uu = set(); first_uu = None
        for t in turns:
            if t > t0 + 5: break
            r = next((x for x in states[t].get('rivals') or [] if x['player'] == p), None)
            if not r: continue
            for u in r.get('units') or []:
                k = (u.get('kind') or '')[5:]
                if k and k not in GENERIC and (u.get('combat') or 0) > 0:
                    seen_uu.add(k)
                    if first_uu is None: first_uu = t
        lead = (t0 - first_uu) if first_uu is not None else None
        out['wars'] += 1
        if first_uu is not None and first_uu <= t0: out['uu_seen_before_or_at'] += 1
        if first_uu is not None and first_uu <= t0 + 5: out['uu_seen_by_t0+5'] += 1
        print(os.path.basename(os.path.dirname(path))[10:], t0, (civ or '')[13:], 'uu', sorted(seen_uu), 'first seen', first_uu, 'lead', lead)
print(out)
