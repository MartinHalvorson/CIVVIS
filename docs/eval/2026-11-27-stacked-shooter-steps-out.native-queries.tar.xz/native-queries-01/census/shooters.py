import gzip, json, sys, collections, os
sys.path.insert(0, os.path.dirname(__file__))
from deaths import hexdist, is_soldier, is_ranged
def load(path):
    states = {}; seat = None; width = 0
    for line in gzip.open(path, 'rt', errors='replace'):
        if '"kind": "state"' in line or '"kind": "seat"' in line or ('"kind": "tiles"' in line and '"width"' in line):
            try: e = json.loads(line)
            except ValueError: continue
            k = e.get('kind')
            if k == 'state': states[e['turn']] = e
            elif k == 'seat': seat = e
            elif k == 'tiles' and e.get('width'): width = e['width']
    return states, seat, width
def census(st, cap, width):
    us = [u for u in st.get('units') or [] if is_soldier(u)]
    pos = (cap['x'], cap['y'])
    sh3 = sum(1 for u in us if is_ranged(u.get('kind') or '') and hexdist((u['x'], u['y']), pos, width) <= 3)
    mel3 = sum(1 for u in us if not is_ranged(u.get('kind') or '') and hexdist((u['x'], u['y']), pos, width) <= 3)
    return sh3, mel3, len(us)
rows = []
for path in sys.argv[1:]:
    states, seat, width = load(path)
    me = (seat or {}).get('local_player', 0)
    turns = sorted(states)
    if not turns: continue
    capid = None
    for t in turns:
        for c in states[t].get('cities') or []:
            if c.get('original_capital') and c.get('original_owner') == me: capid = c['id']
        if capid: break
    prev = {}
    for t in turns:
        st = states[t]
        cap = next((c for c in st.get('cities') or [] if c['id'] == capid), None)
        for r in st.get('rivals') or []:
            w = bool(r.get('at_war'))
            if w and not prev.get(r['player']) and cap:
                ratio = (r.get('military') or 0) / max(st.get('military') or 1, 1)
                # did capital fall within 15 turns of this declaration
                fell = None
                for t2 in turns:
                    if t < t2 <= t + 15 and capid not in {c['id'] for c in states[t2].get('cities') or []}:
                        fell = t2; break
                sh, mel, tot = census(st, cap, width)
                walls = 'BUILDING_WALLS' in (cap.get('buildings') or [])
                rows.append(dict(run=os.path.basename(os.path.dirname(path)), t=t, ratio=ratio, sh=sh, mel=mel, tot=tot, walls=walls, fell=fell, pop=cap.get('pop'), cities=len(st.get('cities') or [])))
            prev[r['player']] = w
json.dump(rows, sys.stdout)
