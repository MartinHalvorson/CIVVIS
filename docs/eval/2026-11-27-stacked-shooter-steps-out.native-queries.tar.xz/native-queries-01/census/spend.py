import gzip, json, sys, collections, os
sys.path.insert(0, os.path.dirname(__file__))
from deaths import hexdist, is_soldier, is_ranged
tot = collections.Counter(); per = []
for path in sys.argv[1:]:
    states = {}; orders = []; seat = None; width = 0; costs = {}
    for line in gzip.open(path, 'rt', errors='replace'):
        if '"kind": "state"' in line or '"kind": "order_verified"' in line or '"kind": "seat"' in line or ('"kind": "tiles"' in line and '"width"' in line):
            try: e = json.loads(line)
            except ValueError: continue
            k = e.get('kind')
            if k == 'state': states[e['turn']] = e
            elif k == 'order_verified': orders.append(e)
            elif k == 'seat': seat = e
            elif k == 'tiles' and e.get('width'): width = e['width']
    turns = sorted(states)
    if not turns: continue
    # capital loss turn
    capid = None; caplost = None; cap = None
    for t in turns:
        for c in states[t].get('cities') or []:
            if c.get('original_capital') and c.get('original_owner') == (seat or {}).get('local_player', 0):
                capid = c['id']; cap = c
        if capid: break
    for i in range(1, len(turns)):
        if capid in {c['id'] for c in states[turns[i-1]].get('cities') or []} and capid not in {c['id'] for c in states[turns[i]].get('cities') or []}:
            caplost = turns[i]; break
    # wars at >=2x: turns where at war with a major at >=2x power
    danger = set()
    for t in turns:
        st = states[t]; ours = max(st.get('military') or 1, 1)
        for r in st.get('rivals') or []:
            if r.get('at_war') and (r.get('military') or 0) >= 2 * ours:
                danger.add(t)
    spent = collections.Counter()
    for o in orders:
        t = o.get('turn')
        if t not in danger: continue
        ok = o.get('order_kind'); verb = str(o.get('verb'))
        if ok not in ('purchase', 'purchase_faith', 'buy', 'buy_plot'): continue
        if ok == 'purchase_faith':
            cls = 'faith:' + ('military' if any(x in verb for x in ('NIHANG','WARRIOR','ARCHER','SPEAR','CHARIOT','HORSE','KNIGHT','CROSSBOW','PIKE','SWORD')) else 'religious/other')
        elif ok == 'purchase':
            mil = any(x in verb for x in ('WARRIOR','ARCHER','SLINGER','SPEAR','CHARIOT','HORSE','KNIGHT','CROSSBOW','PIKE','SWORD','MAN_AT','SKIRM','HULCHE','IMMORTAL','LEGION','HOPLITE','OROMO','NIHANG','CAVALRY','MUSKET','LINE_INF','BOMBARD','CATAPULT','TREB'))
            cls = 'gold:military' if mil else 'gold:' + verb.split('_')[0] + ':' + verb
        else:
            cls = 'gold:' + ok
        spent[cls] += 1
    # gold sitting: median gold over danger turns
    golds = [states[t].get('gold') or 0 for t in sorted(danger)]
    faiths = [states[t].get('faith') or 0 for t in sorted(danger)]
    import statistics
    per.append((os.path.basename(os.path.dirname(path))[10:], (seat or {}).get('civ','')[13:], len(danger), caplost, round(statistics.median(golds)) if golds else None, round(max(golds)) if golds else None, round(statistics.median(faiths)) if faiths else None, dict(spent)))
    tot.update(spent)
for p in per: print(p)
print(tot)
