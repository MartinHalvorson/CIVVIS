import gzip, json, sys, collections, os
sys.path.insert(0, os.path.dirname(__file__))
from deaths import hexdist, is_soldier
MIL = ('WARRIOR','ARCHER','SLINGER','SPEAR','CHARIOT','HORSE','KNIGHT','CROSSBOW','PIKE','SWORD','MAN_AT','SKIRM','HULCHE','IMMORTAL','LEGION','HOPLITE','OROMO','NIHANG','CAVALRY','MUSKET','LINE_INF','BOMBARD','CATAPULT','TREB','BATTERING','SIEGE_TOWER','KESHIG','MAMLUK','COURSER','MANDEKALU','VARU','NGAO','SAMURAI','EAGLE','JAGUAR','HETAIROI','PHALANX','PELTAST','CUIRASSIER','CONQUISTADOR')
def cls(v):
    v = v or ''
    if 'WALLS' in v or 'REPAIR_OUTER' in v: return 'walls'
    if v.startswith('UNIT_') and any(m in v for m in MIL): return 'military'
    if 'SETTLER' in v: return 'settler'
    if 'BUILDER' in v or 'TRADER' in v: return 'builder/trader'
    if any(k in v for k in ('HOLY_SITE','SHRINE','TEMPLE','MISSIONARY','APOSTLE','LAVRA','PRASAT','STUPA','MEETING_HOUSE','MOSQUE','PAGODA','CATHEDRAL','GURDWARA','SYNAGOGUE','WAT','DAR_E_MEHR')): return 'religious'
    if 'ENCAMPMENT' in v or 'BARRACKS' in v or 'STABLE' in v or 'IKANDA' in v: return 'encampment'
    if 'SCOUT' in v: return 'scout'
    if 'GALLEY' in v or 'QUADRIREME' in v: return 'naval'
    return 'other'
tot = collections.Counter(); totw = collections.Counter()
for path in sys.argv[1:]:
    states = {}; prods = collections.defaultdict(list); seat = None
    for line in gzip.open(path, 'rt', errors='replace'):
        if '"kind": "state"' in line or '"order_kind": "produce"' in line or '"kind": "seat"' in line:
            try: e = json.loads(line)
            except ValueError: continue
            k = e.get('kind')
            if k == 'state': states[e['turn']] = e
            elif k == 'order_verified' and e.get('order_kind') == 'produce': prods[e.get('subject')].append((e['turn'], e.get('verb')))
            elif k == 'seat': seat = e
    me = (seat or {}).get('local_player', 0)
    turns = sorted(states)
    capid = None
    for t in turns:
        for c in states[t].get('cities') or []:
            if c.get('original_capital') and c.get('original_owner') == me: capid = c['id']
        if capid: break
    # lethal war = last war start before cap loss, else first war
    caplost = None
    for i in range(1, len(turns)):
        if capid in {c['id'] for c in states[turns[i-1]].get('cities') or []} and capid not in {c['id'] for c in states[turns[i]].get('cities') or []}:
            caplost = turns[i]; break
    starts = []; prev = {}
    for t in turns:
        for r in states[t].get('rivals') or []:
            w = bool(r.get('at_war'))
            if w and not prev.get(r['player']): starts.append(t)
            prev[r['player']] = w
    if not starts: continue
    end = caplost or turns[-1]
    war = max([s for s in starts if s <= end] or [starts[0]])
    seq = sorted(prods.get(capid, []))
    def head(t):
        h = None
        for tt, v in seq:
            if tt <= t: h = v
            else: break
        return h
    mix = collections.Counter(cls(head(t)) for t in range(max(1, war - 20), war))
    mixw = collections.Counter(cls(head(t)) for t in range(war, end))
    tot.update(mix); totw.update(mixw)
    print(os.path.basename(os.path.dirname(path))[10:], 'war', war, 'end', end, 'pre20:', dict(mix.most_common()), '| war:', dict(mixw.most_common()))
s = sum(tot.values()); sw = sum(totw.values())
print('PRE-WAR 20 turns, capital head share:', {k: round(v / s, 2) for k, v in tot.most_common()})
print('DURING WAR, capital head share:', {k: round(v / sw, 2) for k, v in totw.most_common()})
