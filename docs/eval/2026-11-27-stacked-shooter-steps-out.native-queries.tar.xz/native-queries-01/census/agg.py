import json, sys, statistics as st, collections
rows = [json.loads(l) for l in open(sys.argv[1])]
rows = [r for r in rows if r and 'error' not in r]
print('games', len(rows))
def med(xs):
    xs = [x for x in xs if x is not None]
    return (st.median(xs), len(xs)) if xs else (None, 0)
lethal = []  # per game: the war that took the capital
for r in rows:
    losses = r['losses']
    cap = next((x for x in losses if x['orig_cap']), None)
    first = losses[0] if losses else None
    wars = sorted(r['wars'], key=lambda w: w['turn'])
    takers = collections.Counter((x['taker'] or '?') for x in losses)
    capwar = None
    if cap:
        cands = [w for w in wars if w['turn'] <= cap['turn'] and (cap['taker'] or '').endswith((w['by'] or '#')[13:])]
        capwar = cands[-1] if cands else None
        firstwar_same = [w for w in wars if (cap['taker'] or '').endswith((w['by'] or '#')[13:])]
        fw = firstwar_same[0] if firstwar_same else None
    else:
        fw = None
    lethal.append(dict(run=r['run'], last=r['last'], civ=r['civ'], cap=cap, first=first, capwar=capwar, firstwar_taker=fw, wars=wars, takers=takers, n_losses=len(losses), mil=r['mil']))
print('capital lost in-log:', sum(1 for g in lethal if g['cap']))
print('capital taker kinds:', collections.Counter(('BARB' if 'BARBARIAN' in (g['cap']['taker'] or '') else 'CS' if 'CS:' in (g['cap']['taker'] or '') else 'razed?' if 'razed' in (g['cap']['taker'] or '') else 'major') for g in lethal if g['cap']))
print('all losses by taker kind:', collections.Counter(('BARB' if 'BARBARIAN' in (x['taker'] or '') else 'CS' if 'CS:' in (x['taker'] or '') else 'FREE' if 'FREE_CITIES' in (x['taker'] or '') else 'none' if not x['taker'] else 'major') for r in rows for x in r['losses']))
print('capital lost turn', med([g['cap']['turn'] for g in lethal if g['cap']]), 'first loss turn', med([g['first']['turn'] for g in lethal if g['first']]), 'elim turn', med([g['last'] for g in lethal]))
cw = [g for g in lethal if g['capwar']]
print('capital-taking war: start turn', med([g['capwar']['turn'] for g in cw]), 'ratio at decl', med([g['capwar']['ratio'] for g in cw]), 'ratio 10 before', med([g['capwar']['ratio_m10'] for g in cw]))
print('  turns war->capital', med([g['cap']['turn'] - g['capwar']['turn'] for g in cw]))
print('  first war by same taker: turn', med([g['firstwar_taker']['turn'] for g in cw if g['firstwar_taker']]), 'ratio', med([g['firstwar_taker']['ratio'] for g in cw if g['firstwar_taker']]))
print('  near(>=2 within 8 of cap) lead turns before capital war', med([g['capwar']['turn'] - g['capwar']['near2_8_first'] for g in cw if g['capwar']['near2_8_first'] is not None]))
print('  capital walls at decl', sum(g['capwar']['cap_walls'] for g in cw), '/', len(cw), ' at fall', sum(g['cap']['walls'] for g in cw), '/', len(cw))
print('  ranged adj/in capital at decl >=1', sum(g['capwar']['cap_ranged_adj'] >= 1 for g in cw), '; at fall ranged inside', sum(any(any(k in u for k in ('ARCHER','SLINGER','CROSSBOW')) for u in g['cap']['inside']) for g in cw))
print('  our soldiers at decl', med([g['capwar']['our_soldiers'] for g in cw]), 'within2 of cap', med([g['capwar']['cap_soldiers_r2'] for g in cw]))
print('  repeat war (taker had an earlier war ended in peace)', sum(1 for g in cw if g['firstwar_taker'] and g['firstwar_taker']['turn'] < g['capwar']['turn']))
print('  peace asked during capital war', sum(1 for g in cw if g['capwar']['asks']), 'accepted', sum(1 for g in cw if g['capwar']['peace_ok']))
# ratio distribution at all wars on us
allw = [w for r in rows for w in r['wars']]
print('all wars on us', len(allw), 'decl turn', med([w['turn'] for w in allw]), 'ratio', med([w['ratio'] for w in allw]))
print('ratio buckets', collections.Counter('<1' if w['ratio']<1 else '1-2' if w['ratio']<2 else '2-4' if w['ratio']<4 else '4-8' if w['ratio']<8 else '8+' for w in allw))
print('encampment at any loss', sum(x['encampment'] for r in rows for x in r['losses']), 'of', sum(len(r['losses']) for r in rows))
print('mil ours/best rival by mark:')
for m in ('20','30','40','50','60','80'):
    xs=[(g['mil'].get(m) or [None,None])[0] for g in lethal]; ys=[(g['mil'].get(m) or [None,None])[1] for g in lethal]
    rs=[x/y for x,y in zip(xs,ys) if x and y]
    print('  ', m, 'ours', med(xs), 'best rival', med(ys), 'ratio ours/theirs', med(rs))
for g in lethal:
    c=g['cap']; w=g['capwar']
    print(g['run'][10:], (g['civ'] or '')[13:20], 'elim', g['last'], 'cap', (c or {}).get('turn'), ((c or {}).get('taker') or '-').replace('CIVILIZATION_','')[:12],
          'war', (w or {}).get('turn'), 'x', (w or {}).get('ratio'), 'walls', (w or {}).get('cap_walls'), '->', (c or {}).get('walls'), 'rng', (w or {}).get('cap_ranged_adj'), 'sold', (w or {}).get('our_soldiers'), 'peace', (w or {}).get('first_peace_ask'), (w or {}).get('peace_ok'), 'nwars', len(g['wars']), 'losses', g['n_losses'], dict(g['takers']))
