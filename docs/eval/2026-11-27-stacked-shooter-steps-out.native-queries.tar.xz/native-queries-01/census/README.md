Census scripts behind docs/DEFENSE_TACTICS.md section 1 (2026-11-27).

Inputs: runs/<tag>/events.jsonl.gz and runs/<tag>/summary.json from the
`ledger` branch, fetched one file at a time with
`gh api -H "Accept: application/vnd.github.raw" repos/MartinHalvorson/CIVVIS/contents/runs/<tag>/<file>?ref=ledger`
into one directory per run. recent_defeats.txt lists the 28 Deity defeats of
2026-11-22..27; survivors.txt the invaded Deity games that survived (one of
the 20 could not be fetched).

  deaths.py <run>/events.jsonl.gz ...   per game: wars on us, every city lost, capital builds
  agg.py deaths.jsonl                   the section-1 aggregates
  idle.py <logs>                        shooter-turns with a target in range, and whether they fired
  stacks.py <logs>                      City Center stacks of our soldiers
  prodmix.py, spend.py, opinion.py, uu.py, shooters.py, cands.py: the other readings
