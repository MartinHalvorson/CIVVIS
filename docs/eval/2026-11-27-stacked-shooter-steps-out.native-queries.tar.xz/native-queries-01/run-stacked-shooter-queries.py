"""Paired decider queries on live frames of the T7/T8 Deity benchmark games of
2026-11-23..27 (6p Continents, Online) that ended with our civilization
eliminated, on turns where a shooter of ours shared a City Center with another
of our soldiers while an enemy soldier stood within three tiles.

`stacked-shooter-steps-out` is the only bit that varies. Each case is a live
run's own events.jsonl (from `runs/<run>/events.jsonl.gz` on the ledger
branch) cut after turn N+1, replayed at turn N. Both arms run one frozen
`civvis_orders --resumed` built from the branch, with that run's own requested
genome (summary.json `forced`, each as `--with`) and its own victory target and
civilization (summary.json); the on arm adds `--with stacked-shooter-steps-out`.

Cases:
- stacked: the turn's first state frame showed two or more of our soldiers on
  one of our City Centers, at least one a shooter, with an enemy soldier
  within three tiles (Lisbon t56 and t58 of 091247Z included). The on arm
  should step the extra soldiers beside the centre.
- control: turn 20 (or the first later turn without such a stack) of four of
  the same games. The on arm should change nothing.

Read per arm: the orders, the unit move orders, and the gene's journal lines.
This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import gzip
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
RUNS = Path(sys.argv[4])
CASES_FILE = Path(sys.argv[5])
GENE = 'stacked-shooter-steps-out'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CASES = []
for line in CASES_FILE.read_text().splitlines():
    if line.strip():
        run, expect, turn = line.split()
        CASES.append({'run': run, 'expect': expect, 'turn': int(turn)})


def cut(run, turn):
    """Rows through turn+1 (the replay recipe)."""
    rows = []
    with gzip.open(RUNS / run / 'events.jsonl.gz', 'rt', errors='replace') as f:
        for line in f:
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > turn + 1:
                break
            rows.append(line)
    return ''.join(rows).encode()


def unit_orders(row):
    return [o for o in row.get('payload', {}).get('orders', []) if o.get('kind') == 'unit']


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        summary = json.loads((RUNS / case['run'] / 'summary.json').read_text())
        forced = list(summary['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        victory, civ = summary['victory_target'], summary['seat']['civ']
        data = cut(case['run'], case['turn'])
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'cut': 'after turn+1'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', victory, '--civ', civ]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            else:
                row['stderr_tail'] = stderr.read_text(errors='replace')[-2000:]
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if GENE + ':' in line]
            row['unit_orders'] = len(unit_orders(row))
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    total = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
             'on_gene_lines': 0, 'off_gene_lines': 0}
    for r in results:
        c = r['case']
        if r.get('error'):
            print(c['run'], c['turn'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            off, on = v['arms']
            total['on_gene_lines'] += len(on.get('journal_gene', []))
            total['off_gene_lines'] += len(off.get('journal_gene', []))
            print(f"{c['run'][-21:]} t{c['turn']:<3} {c['expect']:<8} "
                  f"{'CHANGED' if v.get('orders_changed') else 'same   '} "
                  f"unit orders off {off.get('unit_orders')} on {on.get('unit_orders')} "
                  f"gene lines on {len(on.get('journal_gene', []))} off {len(off.get('journal_gene', []))} "
                  f"exit {off.get('exit')}/{on.get('exit')}")
            for line in on.get('journal_gene', [])[:3]:
                print('      ', line[:300])
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
