import datetime,hashlib,json,os,pathlib,subprocess,time
repo=pathlib.Path('/Users/martbot-mbp-m5-max-128/civvis-declarable-racer-priority-5684');root=pathlib.Path('/tmp/civvis-declarable-racer-priority-5684');reg=json.loads((repo/'docs/eval/2026-10-25-declarable-racer-priority.fires-registration.json').read_text());meta=json.loads((root/'final-build/gene-screen.build.json').read_text());binary=root/'final-build/gene-screen'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(binary)==meta['binary_sha256']
assert not (root/'family-fires-59002900.jsonl').exists();record={'registration':reg,'actual_build':meta,'started_at':time.time(),'assignments':reg['assigned_seeds'],'status':'running','interpretation':'Family variance artifact only; shared simulation has no authoritative host Culture clock, so it cannot prove new air-path activation or strength.'};command=[str(binary)]+reg['command'][1:];record['command']=command;env=dict(os.environ,CIVVIS_COMMIT=meta['source_commit']);record['environment']={'CIVVIS_COMMIT':meta['source_commit']}
receipt=root/'family-fires-process.json';assert not receipt.exists()
def save():receipt.write_text(json.dumps(record,indent=2)+'\n')
save()
with (root/'family-fires-process.log').open('wb') as log:
 try:
  proc=subprocess.Popen(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT);record['pid']=proc.pid;save();code=proc.wait(timeout=reg['whole_process_deadline_seconds']);record.update(exit_code=code,status='process_complete' if code==0 else 'process_failed',timed_out=False)
 except subprocess.TimeoutExpired:
  proc.kill();proc.wait();record.update(exit_code=proc.returncode,status='timed_out',timed_out=True)
record['finished_at']=time.time();record['log_sha256']=sha(root/'family-fires-process.log')
rows=root/'family-fires-59002900.jsonl'
if rows.exists():record.update(rows_sha256=sha(rows),rows_bytes=rows.stat().st_size)
save();print(json.dumps({k:record[k] for k in ['status','exit_code','timed_out']}),flush=True)
if rows.exists() and rows.stat().st_size:
 analysis=[str(binary),'--analyze',str(rows),'--json',str(root/'family-fires-analysis.json')];record['analysis_command']=analysis;save()
 with (root/'family-fires-analysis.log').open('wb') as log:
  result=subprocess.run(analysis,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
 record['analysis_exit_code']=result.returncode
 if (root/'family-fires-analysis.json').exists():record['analysis_sha256']=sha(root/'family-fires-analysis.json')
 save();print('analysis',result.returncode,flush=True)
