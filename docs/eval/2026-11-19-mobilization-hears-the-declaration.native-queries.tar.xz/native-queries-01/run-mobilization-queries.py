"""Paired decider queries on live frames of the 99 wars declared on us in the
2026-11-18/19 live Deity games (6 players, Small Continents, Online) that
brought an enemy soldier within two tiles of the original capital (33 that took
it, 66 that did not; four more runs were pruned from the host), each on the
declaration turn: the first state row on which the war shows.

`mobilization-hears-the-declaration` is the only bit that varies. Each case is
a live run's own events.jsonl cut after the FIRST state row of turn N (it holds
the mod's `diplomacy_choice` declaration line, which precedes that row),
replayed at turn N. Both arms run one frozen `civvis_orders --resumed` built
from the branch (profile ci), with that run's own requested genome (why.log
line 1 `forced`, each as `--with`; it carries `surprise-war-mobilization`);
the on arm adds `--with mobilization-hears-the-declaration`.

Read per arm, from the proposed orders: the count of each order kind
(`produce`, `purchase`, upgrades, policy changes, ...) and whether the orders
differ between the arms.

This records proposal activation on captured live input only. It does not
execute in Civ VI, replays one turn at a time from the live board, and makes no
claim that a city holds.
"""
import hashlib
import json
import re
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
CASES_FILE = Path(sys.argv[4])
GENE = 'mobilization-hears-the-declaration'
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

CASES = json.loads(CASES_FILE.read_text())
if len(sys.argv) > 5:  # a smoke run: first N cases
    CASES = CASES[:int(sys.argv[5])]
TURN_RE = re.compile(r'"turn": (\d+), "unit_maintenance_discount"')


def cut(run, turn):
    """Rows through the first state row of `turn`, and that row."""
    rows = []
    with open(RUNS / run / 'events.jsonl', errors='replace') as f:
        for line in f:
            if '"kind": "state"' in line:
                m = TURN_RE.search(line)
                t = int(m.group(1)) if m else 0
                if t > turn:
                    break
                rows.append(line)
                if t == turn:
                    return ''.join(rows).encode(), json.loads(line)
                continue
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if (e.get('turn') or 0) > turn:
                break
            rows.append(line)
    raise ValueError(f'{run} has no state row for turn {turn}')


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data, state = cut(case['run'], case['turn'])
        capital = next(c for c in state['cities'] if c.get('id') == 65536)
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'], 'why': case['why'],
                                 'fell': case['fell'], 'statement': case['statement'],
                                 'cut': 'through the first state row of the turn'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                  'capital': {k: capital.get(k) for k in ('name', 'x', 'y', 'damage', 'wall_damage',
                                                          'max_wall_damage', 'production')},
                  'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', case['victory'], '--civ', case['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if GENE in line
                                   or 'surprise' in line.lower()]
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, c) for i, c in enumerate(CASES)]
    (OUT / 'results-index.json').write_text(json.dumps(
        [{'index': r['index'], 'complete': r.get('complete'), 'error': r.get('error')} for r in results]))
    print(json.dumps({'cases': len(results), 'complete': sum(bool(r.get('complete')) for r in results)}))


if __name__ == '__main__':
    main()
