"""summarize.py OUT: per read, the order kinds each arm proposes and whether they differ; the PR's counts."""
import collections
import json
import sys
from pathlib import Path

OUT = Path(sys.argv[1])
totals = collections.Counter()
rows = []
for path in sorted(OUT.glob('*/result.json')):
    r = json.loads(path.read_text())
    if not r.get('complete'):
        totals['incomplete'] += 1
        print(r['case']['run'][-15:], r['case']['turn'], 'INCOMPLETE', r.get('error'))
        continue
    for read in r['reads']:
        off, on = (next(a for a in read['arms'] if a['arm'] == k) for k in ('off', 'on'))
        k_off = collections.Counter(o.get('kind') for o in off['payload']['orders'])
        k_on = collections.Counter(o.get('kind') for o in on['payload']['orders'])
        prod_off = {(o.get('subject'), o.get('verb')) for o in off['payload']['orders'] if o.get('kind') == 'produce'}
        prod_on = {(o.get('subject'), o.get('verb')) for o in on['payload']['orders'] if o.get('kind') == 'produce'}
        buy_off = [o.get('verb') for o in off['payload']['orders'] if o.get('kind') == 'purchase']
        buy_on = [o.get('verb') for o in on['payload']['orders'] if o.get('kind') == 'purchase']
        changed = read['orders_changed']
        d = read['descriptor']
        key = ('fell' if d['fell'] else 'held') + '/' + (d['statement'] or 'no line')
        totals['reads'] += 1
        totals['reads ' + key] += 1
        if changed:
            totals['changed'] += 1
            totals['changed ' + key] += 1
            totals['new produce orders'] += len(prod_on - prod_off)
            totals['purchases added'] += max(0, len(buy_on) - len(buy_off))
            if prod_on - prod_off:
                totals['reads with a city switched'] += 1
        diff = {k: k_on[k] - k_off[k] for k in set(k_on) | set(k_off) if k_on[k] != k_off[k]}
        rows.append((r['case']['run'][-15:], d['turn'], key, changed, diff, sorted(v for _, v in prod_on - prod_off),
                     buy_on if buy_on != buy_off else []))
        print(f"{r['case']['run'][-15:]} t{d['turn']:<3} {key:28} {'CHANGED' if changed else 'same   '} "
              f"kinds {diff} switched {sorted(v for _, v in prod_on - prod_off)[:4]} bought {buy_on if buy_on != buy_off else ''}")
print(json.dumps(dict(totals), indent=1))
(OUT / 'summary.json').write_text(json.dumps({'totals': dict(totals), 'rows': rows}, indent=1))
