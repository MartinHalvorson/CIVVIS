"""Read-only stderr instrumentation on six previously registered stage witnesses."""
import hashlib,json,pathlib,subprocess,sys,time
B=pathlib.Path('/tmp/civvis-forward-airfield-project-8c23');R=pathlib.Path('/Users/martbot-mbp-m5-max-128/civvis-forward-airfield-project-8c23');sys.path.insert(0,str(R/'tools'))
from civ6_decision_trace import captured_input
from civ6_ladder import decider_genome
out=B/'diagnostic-queries-02-serve';out.mkdir();cases=json.load((B/'native-selection/manifest.json').open())['cases'];results=[]
for index in [1,29,75,106,120,182]:
 source=B/f'native-queries-02-serve/{index:04}/result.json'
 while not source.exists():time.sleep(5)
 original=json.load(source.open());case=cases[index]
 for record in original['reads']:
  sid=record['descriptor']['snapshot_id'];d=out/f'{index:04}-read-{sid}';d.mkdir();data=captured_input(case['capture'],sid);(d/'events.jsonl').write_bytes(data)
  cmd=next(a['argv'] for a in record['arms'] if a['arm']=='on').copy();cmd[0]=str(B/'diagnostic-build/civvis_orders');cmd[cmd.index('--mirror')+1]=str(d)
  with (d/'stdout').open('wb') as stdout,(d/'stderr').open('wb') as stderr:p=subprocess.run(cmd,input=(str(case['turn'])+'\n').encode(),stdout=stdout,stderr=stderr,timeout=300)
  payload=json.loads((d/'stdout').read_text()) if p.returncode==0 else None;baseline=next(a for a in record['arms'] if a['arm']=='on');genome=decider_genome(d/'stderr')
  equal=p.returncode==0 and payload==baseline['payload'] and genome==baseline['genome'];r={'case':index,'run':case['run'],'turn':case['turn'],'frame':case['frame'],'snapshot_id':sid,'argv':cmd,'exit':p.returncode,'entire_response_and_genome_equal_frozen_on':equal,'input_sha256':hashlib.sha256(data).hexdigest(),'observations':[l for l in (d/'stderr').read_text().splitlines() if l.startswith('[field-diagnostic]')]};results.append(r);print(json.dumps({k:v for k,v in r.items() if k!='argv'}),flush=True)
  (d/'events.jsonl').unlink()
(out/'results.json').write_text(json.dumps({'scope':__doc__,'build':json.load((B/'diagnostic-build/build.json').open()),'results':results},indent=2)+'\n')
