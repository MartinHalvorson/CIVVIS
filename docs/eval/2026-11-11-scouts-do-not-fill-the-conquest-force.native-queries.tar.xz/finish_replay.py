from pathlib import Path
import json,time,subprocess,hashlib
out=Path(__file__).parent
repo=Path('/Users/martbot-mbp-m5-max-128/civvis-scouts-do-not-fill-the-conquest-force-27eb')
while True:
 d=json.loads((out/'candidate-build.json').read_text())
 if 'exit_code' in d:break
 time.sleep(3)
assert d['exit_code']==0,d
binary=d['binary'];p=out/'candidate.py'
p.write_text('#!/usr/bin/env python3\nimport os,sys\na=sys.argv[1:]\na[a.index("--civ")+1]="CIVILIZATION_MACEDON"\nos.execv('+repr(binary)+', ['+repr(binary)+']+a)\n');p.chmod(0o755)
cmd=['python3','-u','tools/native_city_route_replay.py','--run','/Users/martbot-mbp-m5-max-128/civvis-civ6-runs/control/civvis-20261111T071743Z','--baseline',str(out/'baseline.py'),'--candidate',str(p),'--force-file',str(out/'native-force.txt'),'--out',str(out/'native-pair'),'--through-turn','21','--explain']
with (out/'native-pair.log').open('w') as log:
 result=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0,result.returncode
pair=out/'native-pair';control=json.loads((pair/'native-control.json').read_text());provenance=json.loads((pair/'provenance.json').read_text())
war={}
for arm in ['baseline','candidate']:
 war[arm]=[]
 for l in (pair/arm/'decisions.jsonl').open():
  r=json.loads(l);dec=r.get('decision',{})
  for a in dec.get('native_actions',[]):
   if a.get('type')=='declare_war':war[arm].append({'turn':dec['turn'],'frame':dec['frame'],'action':a})
summary={'source_commit':d['source_commit'],'candidate_binary_sha256':d['sha256'],'native_control':{k:control.get(k) for k in ['gate_passed','native_history_gate_passed','request_identity_gate_passed','frames','matched_frames','changed_complete_reply_frames']},'first_changed_frame':{k:control.get('first_changed_complete_reply',{}).get(k) for k in ['turn','frame']} if control.get('first_changed_complete_reply') else None,'replay':{k:provenance.get(k) for k in ['frames','changed_order_frames','changed_native_action_frames','validation_passed','inputs_unchanged']},'declared_war_actions':war,'scope':'Recorded-history query evidence. Later observations retain the real game war; this is not a counterfactual game or an outcome estimate.'}
(out/'native-pair-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert control['gate_passed'] and control['matched_frames']==43
assert any(x['turn']==7 for x in war['baseline'])
assert not any(x['turn']==7 for x in war['candidate'])
print(json.dumps(summary))
