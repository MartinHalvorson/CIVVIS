#!/usr/bin/env python3
import os,sys
a=sys.argv[1:]
a[a.index("--civ")+1]="CIVILIZATION_MACEDON"
os.execv('/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/scouts-do-not-fill-the-conquest-force/civvis_orders-opt0-c87a525f067e082d14773c0c787555e2ce0f4512', ['/Users/martbot-mbp-m5-max-128/civvis-tactics-results/2026-11-11/scouts-do-not-fill-the-conquest-force/civvis_orders-opt0-c87a525f067e082d14773c0c787555e2ce0f4512']+a)
