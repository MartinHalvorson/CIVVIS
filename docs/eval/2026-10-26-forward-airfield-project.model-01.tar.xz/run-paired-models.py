import concurrent.futures, datetime, hashlib, json, pathlib, subprocess
B=pathlib.Path('/tmp/civvis-forward-airfield-project-8c23')
out=B/'paired-models-01';out.mkdir()
binary=B/'model-build/paired_probe'; sample=B/'native-profile-proxy.jsonl'
registration={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'games':list(range(8)),'arms':['off','on'],'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'sample_sha256':hashlib.sha256(sample.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((B/'paired-instrument.rs').read_bytes()).hexdigest(),'no_replacement':True}
(out/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
def run(spec):
 game,arm=spec;dest=out/f'{game:02}-{arm}'
 cmd=[str(binary),str(sample),str(game),arm,str(dest)]
 with (out/f'{game:02}-{arm}.stdout').open('wb') as stdout,(out/f'{game:02}-{arm}.stderr').open('wb') as stderr:
  p=subprocess.run(cmd,stdout=stdout,stderr=stderr)
 return {'game':game,'arm':arm,'exit_code':p.returncode,'argv':cmd}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for r in pool.map(run,[(g,a) for g in range(8) for a in ['off','on']]):
  with (out/'results.jsonl').open('a') as f:f.write(json.dumps(r)+'\n')
  print(json.dumps(r),flush=True)
