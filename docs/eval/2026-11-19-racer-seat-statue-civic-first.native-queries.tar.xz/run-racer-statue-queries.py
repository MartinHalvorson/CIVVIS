"""Paired decider queries on live frames of Tournament 1 (2026-11-19), for
`racer-seat-statue-civic-first`.

    run-racer-statue-queries.py REPO BINARY OUT racer-seat-statue-civic-first

Each case is a live run's own events.jsonl cut after the first state row of
turn N (the turn's opening frame, before its orders), replayed at turn N: the
board the live decider chose on. Both arms run one frozen
`civvis_orders --resumed --explain --victory science` built from the branch,
with that run's own requested genome (why.log line 1 `forced`, each as
`--with`, carrying science-seat-builds-the-statue and diplo-seat-statue-harbor);
the on arm adds `--with racer-seat-statue-civic-first`, the only bit that
varies.

Games (6-player Continents, Online, Deity, 250 turns, seat on the Science
lane; every one lost to a rival's Science victory). The cases are the turns
the live seat chose a civic from its Statue Harbor claim up to Civil
Engineering (the last case of a game that reached it is a control: both arms
name it). Every live seat walked Mercantilism, Colonialism, Natural History,
Scorched Earth toward Class Struggle before Civil Engineering:

- civvis-20261119T200436Z, Egypt: Harbor claimed t123; civics t130
  Mercantilism, t139 Colonialism, t143 Natural History, t156 Scorched Earth,
  t166 Civil Engineering; Statue claimed t172 on 16 Diplomatic points; lost
  t183.
- civvis-20261119T194013Z, China: Harbor t150; t152 Colonialism, t156 Natural
  History, t167 Scorched Earth, t177 Civil Engineering; lost t177.
- civvis-20261119T203049Z, Khmer: Harbor t145; t157 Mercantilism, t172
  Colonialism, never Civil Engineering; lost t173.
- civvis-20261119T201715Z, Portugal: Harbor t132-133; t140 Mercantilism, t145
  Colonialism, t148 Natural History, t154 Scorched Earth, t158 Civil
  Engineering; lost t191.

Read: the civic the arm orders, beside the civic the live seat took.

This records proposal activation on captured live input only. It does not
execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GENE = sys.argv[4]
RUNS = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

EGYPT = ('civvis-20261119T200436Z', 'CIVILIZATION_EGYPT')
CHINA = ('civvis-20261119T194013Z', 'CIVILIZATION_CHINA')
KHMER = ('civvis-20261119T203049Z', 'CIVILIZATION_KHMER')
PORTUGAL = ('civvis-20261119T201715Z', 'CIVILIZATION_PORTUGAL')
PLANS = {
    'racer-seat-statue-civic-first': {
        'games': [(EGYPT, [130, 139, 143, 156, 166]), (CHINA, [152, 156, 167, 177]), (KHMER, [157, 172]),
                  (PORTUGAL, [140, 145, 148, 154, 158])],
        'journal': ('civil engineering', 'Research/Decision Adopting'),
        'orders': lambda o: o.get('kind') == 'civic',
    },
}
PLAN = PLANS[GENE]
CASES = [{'run': run, 'civ': civ, 'turn': t} for (run, civ), turns in PLAN['games'] for t in turns]
_LINES = {}


def lines_of(run):
    if run not in _LINES:
        rows = []
        with open(RUNS / run / 'events.jsonl', 'rb') as f:
            for line in f:
                # The turn of a row is read from its own JSON, not a substring.
                try:
                    turn = json.loads(line).get('turn')
                except ValueError:
                    turn = 'bad'
                rows.append((turn, line))
        _LINES[run] = rows
    return _LINES[run]


def cut(run, turn):
    """Rows through the first state row of the turn (its opening frame, before
    the turn's orders), that row, and the turn's last state row (what the live
    seat had done by the end of it)."""
    kept, first, last = [], None, None
    for row_turn, line in lines_of(run):
        if row_turn == 'bad':
            continue
        if (row_turn or 0) > turn:
            break
        if first is None:
            kept.append(line)
        if row_turn == turn and b'"kind": "state"' in line:
            row = json.loads(line)
            if row.get('kind') != 'state':
                continue
            if first is None:
                first = row
            last = row
    return b''.join(kept), first, last


def one(index, case):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    result = {'index': index, 'case': case, 'reads': []}
    try:
        header = json.loads((RUNS / case['run'] / 'why.log').open().readline())
        forced = list(header['forced'])
        if GENE in forced:
            raise ValueError('the live genome already carried the gene')
        data, last, after = cut(case['run'], case['turn'])
        board = {
            'dvp': last.get('dvp'), 'favor': last.get('favor'), 'favor_per_turn': last.get('favor_per_turn'),
            'civic': last.get('civic'), 'cities': len(last.get('cities') or []),
            'civil_engineering': 'CIVIC_CIVIL_ENGINEERING' in (last.get('civics') or []),
            'mercantilism': 'CIVIC_MERCANTILISM' in (last.get('civics') or []),
            'rivals': {str(r.get('player')): str(r.get('diplomatic_state')).replace('DIPLO_STATE_', '')
                       for r in last.get('rivals') or []},
            'competitions': [{'name': e.get('name'), 'member': (e.get('ours') or {}).get('member'),
                              'ours': (e.get('ours') or {}).get('score'),
                              'best': max([s.get('score') or 0 for s in e.get('scores') or []] or [0]),
                              'turns_left': e.get('turns_left')} for e in last.get('emergencies') or []],
        } if last else None
        live = {'civic': after.get('civic'),
                'producing': {c.get('name'): c.get('producing') for c in after.get('cities') or []}} if after else None
        record = {'descriptor': {'run': case['run'], 'turn': case['turn'],
                                 'cut': 'through the first state row of the turn'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'board': board,
                  'live_by_the_end_of_the_turn': live, 'arms': []}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(case['turn']), '--resumed',
                   '--explain', '--victory', 'science', '--civ', case['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            played = decider_genome(stderr)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': played}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            journal = [line for line in stderr.read_text(errors='replace').splitlines()
                       if line.startswith('[why]')]
            row['journal_gene'] = [line for line in journal if any(k in line for k in PLAN['journal'])]
            row['orders_gene'] = [o for o in row.get('payload', {}).get('orders', []) if PLAN['orders'](o)]
            row['orders_produce'] = [[o.get('subject'), o.get('verb')] for o in row.get('payload', {}).get('orders', [])
                                     if o.get('kind') == 'produce']
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            mirror.rmdir()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = []
    for i, c in enumerate(CASES):
        r = one(i, c)
        results.append(r)
        if r.get('error'):
            print(c['run'][-16:], c['turn'], 'ERROR', r['error'], flush=True)
            continue
        for v in r['reads']:
            off, on = v['arms']
            print(f"{c['run'][-16:]} t{c['turn']:<3} {'CHANGED' if v['orders_changed'] else 'same   '} "
                  f"| off {json.dumps(off['orders_gene'])[:160]} | on {json.dumps(on['orders_gene'])[:160]} "
                  f"| on journal {on['journal_gene'][:2]}", flush=True)
    total = {'gene': GENE, 'cases': len(results),
             'complete_cases': sum(bool(r.get('complete')) for r in results),
             'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
             'off_gene_orders': sum(len(a['orders_gene']) for r in results for v in r['reads']
                                    for a in v['arms'] if a['arm'] == 'off'),
             'on_gene_orders': sum(len(a['orders_gene']) for r in results for v in r['reads']
                                   for a in v['arms'] if a['arm'] == 'on'),
             'on_gene_journal_lines': sum(len(a['journal_gene']) for r in results for v in r['reads']
                                          for a in v['arms'] if a['arm'] == 'on'),
             'off_gene_journal_lines': sum(len(a['journal_gene']) for r in results for v in r['reads']
                                           for a in v['arms'] if a['arm'] == 'off')}
    (OUT / 'summary.json').write_text(json.dumps(total, indent=2))
    print(json.dumps(total))


if __name__ == '__main__':
    main()
