"""Paired served decider replays on captured live frames where siege guns stalled short of their posts.

`siege-guns-take-a-reachable-post` is the only bit that varies. Each case is a live run's
`events.jsonl` cut after turn LAST+1 with each turn's frame-0 (decision) state only, served to ONE persistent decider (`--serve --fresh-board`,
as the live brain runs it) one turn per stdin line, FIRST..LAST, on one release `civvis_orders`
built from the PR branch. The gene's clock needs memory across turns (a gun stalls after holding a
post two assessments), so a one-frame `--resumed` query cannot exercise it; the persistent agent
can. Both arms carry the run's own requested genome (`summary.json` `forced`, each as `--with`),
the run's victory lane and civilization; the on arm adds the gene. Each served turn is one read:
both arms' reply for that turn on the same captured input.

Every frame is the LIVE frame: units stand where the live (gene-off) seat left them, not where the
on arm's earlier orders would have put them. This records proposal activation on captured live
input only. It does not execute in Civ VI and makes no strength claim.
"""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
CASES = [tuple(c.split(':')) for c in sys.argv[4:]]  # RUNSTAMP:FIRST:LAST
GENE = 'siege-guns-take-a-reachable-post'
CONTROL = Path.home() / 'civvis-civ6-runs/control'
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402

KEEP = ('stops short of its post', 'holds at the muster line', GENE)


def cut(run, last):
    lines = []
    with (CONTROL / run / 'events.jsonl').open('rb') as f:
        for line in f:
            if b'"kind": "state"' in line:
                try:
                    t = json.loads(line).get('turn')
                except ValueError:
                    t = None
                if t is not None and t >= last + 2:
                    break
                # The turn's decision frame only: later frames of a turn are the board after
                # our orders ran, and a served turn number reads the newest frame of that turn.
                if json.loads(line).get('frame', 0) != 0:
                    continue
            lines.append(line)
    return b''.join(lines)


def one(index, run, first, last):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    case = {'run': run, 'first': first, 'last': last}
    result = {'index': index, 'case': case, 'reads': []}
    try:
        summary = json.loads((CONTROL / run / 'summary.json').read_text())
        head = json.loads((CONTROL / run / 'why.log').open().readline())
        forced = list(summary['forced'])
        if GENE in forced or GENE in head.get('treatments', []):
            raise ValueError('the live genome already carried the gene')
        data = cut(run, last)
        digest = hashlib.sha256(data).hexdigest()
        turns = list(range(first, last + 1))
        arms = {}
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--serve', '--fresh-board', '--explain',
                   '--victory', head['victory'], '--civ', summary['seat']['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.jsonl'), root / (arm + '.why')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, input=''.join(f'{t}\n' for t in turns).encode(),
                                         stdout=out, stderr=err, timeout=3600)
            replies = {}
            for line in stdout.read_text().splitlines():
                try:
                    reply = json.loads(line)
                except ValueError:
                    continue
                t = reply.get('turn') or (reply.get('decision') or {}).get('turn')
                if t is not None and t not in replies:
                    replies[int(t)] = reply
            journal = {}
            for line in stderr.read_text().splitlines():
                m = re.match(r'\[why\] t(\d+) ', line)
                if m and any(k in line for k in KEEP):
                    journal.setdefault(int(m.group(1)), []).append(line)
            arms[arm] = dict(argv=cmd, exit=process.returncode, genome=decider_genome(stderr),
                             wall_seconds=time.monotonic() - started, replies=replies, journal=journal)
            (mirror / 'events.jsonl').unlink()
        for t in turns:
            record = {'descriptor': {'run': run, 'turn': t, 'served': f'{first}..{last}',
                                     'cut': 'events.jsonl through turn LAST+1, frame-0 states only'},
                      'bytes': len(data), 'sha256': digest, 'arms': []}
            for arm in ('off', 'on'):
                a = arms[arm]
                row = {'arm': arm, 'argv': a['argv'], 'exit': a['exit'], 'genome': a['genome'],
                       'journal': a['journal'].get(t, [])}
                if t in a['replies']:
                    row['payload'] = a['replies'][t]
                record['arms'].append(row)
            off, on = record['arms']
            record['orders_changed'] = (off.get('payload', {}).get('orders')
                                        != on.get('payload', {}).get('orders'))
            record['gene_journal'] = [l for l in on['journal'] if GENE + ':' in l]
            record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome']
                                     for a in record['arms'])
            result['reads'].append(record)
        result['wall_seconds'] = {arm: arms[arm]['wall_seconds'] for arm in arms}
        result['complete'] = bool(result['reads']) and all(r['complete'] for r in result['reads'])
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=1))
    return result


def main():
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'cases': CASES,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    results = [one(i, r, int(a), int(b)) for i, (r, a, b) in enumerate(CASES)]
    summary = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
               'reads': sum(len(r['reads']) for r in results),
               'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads'])}
    for r in results:
        if r.get('error'):
            print(r['case'], 'ERROR', r['error'])
            continue
        changed = [v['descriptor']['turn'] for v in r['reads'] if v['orders_changed']]
        gene = [v['descriptor']['turn'] for v in r['reads'] if v['gene_journal']]
        print(r['case']['run'][7:], 'changed turns', changed, '| gene lines on', gene)
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
