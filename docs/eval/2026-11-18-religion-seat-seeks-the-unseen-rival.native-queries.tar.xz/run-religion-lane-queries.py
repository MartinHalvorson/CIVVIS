"""Paired decider queries for one Religious-lane gene on captured live boards.

Usage: run-religion-lane-queries.py REPO BINARY OUT RUN_DIR GENE TURN [TURN ...]

Every case is one turn of one live Deity Religious-target game of 2026-11-18 (6 majors,
Continents, Online; civvis-20261118T082214Z Mali for `religion-seat-seeks-the-unseen-rival`,
civvis-20261118T094102Z Byzantium for `religion-seat-spends-the-whole-bank`): the run's
events.jsonl cut right after that turn's first state frame (frame 0, every unit with its moves).
Both arms run one `civvis_orders --resumed --explain` built from the PR branch with the run's own
requested genome (the why.log header's `forced`, each as `--with`), the run's victory lane and its
civilization; the on arm adds `--with GENE`. The off arm is the live seat's own genome on its own
frame, `religion-seat-charts-the-rivals` and `religion-seat-spends-the-bank` included.

Besides the raw arms each read records, from the same frame and from the run's last frame:
the met rivals with no city on the map, the Faith banked, the religious units whose order differs
between the arms, for each of those the distance from its ordered tile to the nearest city (as
known at the end of the game) of a rival that is unseen on this frame, and the orders that are
not unit orders (purchases among them) present in one arm only. The distances use knowledge the
seat did not have and are a reading aid only.

This records proposal activation on captured live input only. It does not execute in Civ VI and
makes no strength claim. A one-frame query starts with no memory, so no goal is kept from an
earlier turn and the seekers are chosen afresh on every board.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO = Path(sys.argv[1])
BINARY = Path(sys.argv[2])
OUT = Path(sys.argv[3])
RUN_DIR = Path(sys.argv[4])
GENE = sys.argv[5]
TURNS = [int(t) for t in sys.argv[6:]]
RUN = RUN_DIR.name
RELIGIOUS = ('UNIT_MISSIONARY', 'UNIT_APOSTLE')
sys.path.insert(0, str(REPO / 'tools'))
from civ6_ladder import decider_genome  # noqa: E402


def cut(turn):
    """events.jsonl through the first state frame of `turn`; that frame parsed."""
    lines = []
    with (RUN_DIR / 'events.jsonl').open('rb') as f:
        for line in f:
            lines.append(line)
            if b'"kind": "state"' in line:
                try:
                    state = json.loads(line)
                except ValueError:
                    continue
                if state.get('turn', -1) >= turn:
                    if state['turn'] != turn or state.get('frame') != 0:
                        raise ValueError(f'turn {turn} has no frame 0')
                    return b''.join(lines), state
    raise ValueError(f'turn {turn} is not in the run')


def last_state():
    state = None
    with (RUN_DIR / 'events.jsonl').open('rb') as f:
        for line in f:
            if b'"kind": "state"' in line:
                state = line
    return json.loads(state)


def wdist(a, b, width=74):
    """Hex distance between two Civ VI offset coordinates on an east-west wrapping map."""
    def axial(x, y):
        return x - (y - (y & 1)) // 2, y
    best = None
    for shift in (-width, 0, width):
        (q1, r1), (q2, r2) = axial(a[0], a[1]), axial(b[0] + shift, b[1])
        d = max(abs(q1 - q2), abs(r1 - r2), abs((q1 + r1) - (q2 + r2)))
        best = d if best is None else min(best, d)
    return best


def one(index, turn, forced, summary, end):
    root = OUT / f'{index:04d}'
    root.mkdir(parents=True)
    case = {'run': RUN, 'turn': turn}
    result = {'index': index, 'case': case, 'reads': []}
    try:
        data, state = cut(turn)
        unseen = [r for r in state['rivals'] if not r['cities']]
        truth = [(c['x'], c['y']) for r in end['rivals'] for c in r['cities']
                 if r['player'] in {u['player'] for u in unseen}]
        record = {'descriptor': {'run': RUN, 'turn': turn, 'cut': 'events.jsonl through the first state frame of the turn'},
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'arms': [],
                  'unseen_met_rivals': [r['civ'] for r in unseen],
                  'faith': state.get('faith'), 'faith_per_turn': state.get('faith_per_turn'),
                  'rival_cities_seen_of_public': {r['civ']: [len(r['cities']), r['public_stats']['city_count']]
                                                  for r in state['rivals']}}
        result['reads'].append(record)
        for arm in ('off', 'on'):
            mirror = root / arm
            mirror.mkdir()
            (mirror / 'events.jsonl').write_bytes(data)
            cmd = [str(BINARY), '--mirror', str(mirror), '--turn', str(turn), '--resumed', '--explain',
                   '--victory', summary['victory_target'], '--civ', summary['seat']['civ']]
            for tag in forced:
                cmd += ['--with', tag]
            if arm == 'on':
                cmd += ['--with', GENE]
            stdout, stderr = root / (arm + '.stdout'), root / (arm + '.stderr')
            started = time.monotonic()
            with stdout.open('wb') as out, stderr.open('wb') as err:
                process = subprocess.run(cmd, stdout=out, stderr=err, timeout=900)
            row = {'arm': arm, 'argv': cmd, 'exit': process.returncode,
                   'wall_seconds': time.monotonic() - started, 'genome': decider_genome(stderr)}
            if process.returncode == 0:
                row['payload'] = json.loads(stdout.read_text())
            row['journal'] = [line for line in stderr.read_text().splitlines()
                              if line.startswith('[why]') and ('seeks a rival' in line or 'charts a rival' in line
                                                               or 'keeps its last charge and scouts' in line
                                                               or 'Faith buys a' in line or 'Sizing the Apostle corps' in line
                                                               or 'Saving for an Apostle' in line)]
            record['arms'].append(row)
            (mirror / 'events.jsonl').unlink()
            mirror.rmdir()
            stdout.unlink()
            stderr.unlink()
        off, on = record['arms']
        units = {u['id']: u for u in state['units']}

        def moves(arm):
            last = {}
            for order in arm.get('payload', {}).get('orders', []):
                if order.get('kind') == 'unit' and units.get(order.get('subject'), {}).get('kind') in RELIGIOUS:
                    last.setdefault(order['subject'], []).append([order['verb'], order.get('x'), order.get('y')])
            return last
        before, after = moves(off), moves(on)
        changed = []
        for uid in sorted(set(before) | set(after)):
            if before.get(uid) == after.get(uid):
                continue
            unit = units[uid]
            row = {'unit': uid, 'kind': unit['kind'], 'at': [unit['x'], unit['y']], 'charges': unit['spread_charges'],
                   'hp': unit['hp'], 'off': before.get(uid, []), 'on': after.get(uid, [])}
            if truth:
                def reach(orders):
                    spots = [(o[1], o[2]) for o in orders if o[0] == 'MOVE_TO' and o[1] is not None]
                    spot = spots[-1] if spots else (unit['x'], unit['y'])
                    return min(wdist(spot, city) for city in truth)
                row['tiles_to_nearest_unseen_rival_city'] = {
                    'now': min(wdist((unit['x'], unit['y']), city) for city in truth),
                    'off': reach(row['off']), 'on': reach(row['on'])}
            changed.append(row)
        record['religious_orders_changed'] = changed

        def others(arm):
            return [json.dumps(o, sort_keys=True) for o in arm.get('payload', {}).get('orders', [])
                    if o.get('kind') != 'unit']
        left, right = others(off), others(on)
        record['other_orders_off_only'] = [json.loads(o) for o in left if o not in right]
        record['other_orders_on_only'] = [json.loads(o) for o in right if o not in left]
        record['orders_changed'] = off.get('payload', {}).get('orders') != on.get('payload', {}).get('orders')
        record['gene_journal'] = [line for line in on['journal'] if GENE + ':' in line]
        record['complete'] = all(a['exit'] == 0 and 'payload' in a and a['genome'] for a in record['arms'])
        result['complete'] = record['complete']
    except Exception as exc:  # retained, never hidden
        result.update(complete=False, error=f'{type(exc).__name__}: {exc}')
    (root / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    return result


def main():
    head = json.loads((RUN_DIR / 'why.log').open().readline())
    summary = json.loads((RUN_DIR / 'summary.json').read_text())
    if GENE in head['forced'] or GENE in head.get('treatments', []):
        raise SystemExit('the live genome already carried the gene')
    forced = list(head['forced'])
    OUT.mkdir(parents=True)
    (OUT / 'registration.json').write_text(json.dumps({
        'scope': __doc__, 'gene': GENE, 'run': RUN, 'turns': TURNS,
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'binary_revision': subprocess.run(['git', '-C', str(REPO), 'rev-parse', '--short=10', 'HEAD'],
                                          capture_output=True, text=True).stdout.strip(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    end = last_state()
    results = [one(i, t, forced, summary, end) for i, t in enumerate(TURNS)]
    out = {'cases': len(results), 'complete_cases': sum(bool(r.get('complete')) for r in results),
           'changed_order_reads': sum(v.get('orders_changed', False) for r in results for v in r['reads']),
           'reads_with_a_gene_line': sum(bool(v.get('gene_journal')) for r in results for v in r['reads'])}
    for r in results:
        if r.get('error'):
            print(r['case'], 'ERROR', r['error'])
            continue
        for v in r['reads']:
            print('t%d' % r['case']['turn'], 'unseen', [c.split('_')[-1] for c in v['unseen_met_rivals']],
                  'faith', v['faith'], 'changed' if v['orders_changed'] else 'same',
                  '| gene lines', len(v['gene_journal']), '| on-only orders',
                  [(o.get('kind'), o.get('subject'), o.get('verb')) for o in v['other_orders_on_only']])
            for row in v['religious_orders_changed']:
                print('    ', row['kind'][5:], row['unit'], 'at', row['at'], 'c%d' % row['charges'], 'off', row['off'][-1:],
                      'on', row['on'][-1:], row.get('tiles_to_nearest_unseen_rival_city', ''))
    (OUT / 'summary.json').write_text(json.dumps(out, indent=2))
    print(json.dumps(out))


if __name__ == '__main__':
    main()
