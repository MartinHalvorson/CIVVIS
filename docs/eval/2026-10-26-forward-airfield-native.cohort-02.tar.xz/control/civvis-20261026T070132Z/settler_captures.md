# Settler captures — civvis-20261026T070132Z

1 capture(s). Mechanism is the first match in the operator's order; every match is listed.

## t99 settler 1835018 at (51,28) — `site-in-barbarian-nest`

- detected by: `unit_captured`, captor player 63 (barbarian)
- mechanisms matched: site-in-barbarian-nest, weak-guard
- nearest hostile: UNIT_LINE_INFANTRY str 65 hp 100 mv 0 at (51,27) d=1 id 6619151
- guard: UNIT_CROSSBOWMAN str 30 hp 100 mv 3 at (51,28) d=0 id 4390937 [settler_barbarian_combat_guard_hold]
- site: (51,28) — hostile seen within 3 in the last 5 turns: True; camp within 3: False

### Settler t-2..t

| turn | pos | moves | activity | hostiles within 3 | ours within 2 |
|---|---|---|---|---|---|
| t97 | (50,29) | 0 | awake | UNIT_LINE_INFANTRY str 65 hp 100 mv 0 at (53,28) d=3 id 6619151 | UNIT_CROSSBOWMAN str 30 hp 100 mv 0 at (50,28) d=1 id 4390937<br>UNIT_PIKEMAN str 45 hp 100 mv 0 at (49,27) d=2 id 4915214<br>UNIT_SKIRMISHER str 20 hp 12 mv 3 at (49,28) d=2 id 2883607 |
| t98 | (51,28) | 0 | awake | UNIT_LINE_INFANTRY str 65 hp 100 mv 0 at (52,26) d=2 id 6619151 | UNIT_CROSSBOWMAN str 30 hp 100 mv 0 at (51,28) d=0 id 4390937<br>UNIT_HEAVY_CHARIOT str 28 hp 63 mv 1 at (49,27) d=2 id 3473436 |
| t99 | (51,28) | 3 | awake | UNIT_LINE_INFANTRY str 65 hp 100 mv 0 at (51,27) d=1 id 6619151<br>UNIT_RANGER str 45 hp 100 mv 0 at (52,27) d=2 id 6684698<br>UNIT_MAN_AT_ARMS str 45 hp 4 mv 0 at (53,27) d=3 id 5177369 | UNIT_CROSSBOWMAN str 30 hp 100 mv 3 at (51,28) d=0 id 4390937 |

### Orders (settler and guard)

- `{"guard": 4390937, "kind": "escort_cap_synced", "sent": [50, 28], "settler": 1835018, "t": 1792998411, "turn": 97, "utc": "2026-10-26T07:06:51.340Z", "want": [50, 28]}`
- `{"checked_on": 98, "kind": "order_verified", "order_kind": "unit", "subject": 1835018, "t": 1792998415, "turn": 97, "utc": "2026-10-26T07:06:55.561Z", "verb": "MOVE_TO"}`
- `{"checked_on": 98, "kind": "order_verified", "order_kind": "unit", "subject": 4390937, "t": 1792998415, "turn": 97, "utc": "2026-10-26T07:06:55.561Z", "verb": "MOVE_TO"}`
- `{"checked_on": 99, "kind": "order_verified", "order_kind": "unit", "subject": 1835018, "t": 1792998420, "turn": 98, "utc": "2026-10-26T07:07:00.765Z", "verb": "MOVE_TO"}`
- `{"checked_on": 99, "kind": "order_verified", "order_kind": "unit", "subject": 4390937, "t": 1792998420, "turn": 98, "utc": "2026-10-26T07:07:00.765Z", "verb": "MOVE_TO"}`
- `{"guard": 4390937, "kind": "escort_cap_synced", "sent": [50, 28], "settler": 1835018, "t": 1792998420, "turn": 99, "utc": "2026-10-26T07:07:00.764Z", "want": [50, 28]}`
- `{"checked_on": 100, "kind": "order_failed", "order_kind": "unit", "reason": "unit_gone", "subject": 1835018, "t": 1792998424, "turn": 99, "utc": "2026-10-26T07:07:04.663Z", "verb": "MOVE_TO"}`
- `{"checked_on": 100, "kind": "order_failed", "order_kind": "unit", "reason": "unit_gone", "subject": 4390937, "t": 1792998424, "turn": 99, "utc": "2026-10-26T07:07:04.663Z", "verb": "MOVE_TO"}`
- `{"from": [51, 28], "hostile": 6619151, "hostile_pos": [51, 27], "hostile_reach": "base_moves", "hostile_type": "UNIT_LINE_INFANTRY", "kind": "settler_barbarian_combat_capture_hold", "sent": [50, 28], "settler": 1835018, "t": 1792998420, "turn": 99, "utc": "2026-10-26T07:07:00.765Z", "want": [50, 28]}`
- `{"at": [51, 28], "guard": 4390937, "hostile": 6619151, "hostile_pos": [51, 27], "hostile_type": "UNIT_LINE_INFANTRY", "kind": "settler_barbarian_combat_guard_hold", "settler": 1835018, "t": 1792998420, "turn": 99, "utc": "2026-10-26T07:07:00.765Z"}`

### why.log t-2..t

- t97 Military/Strategy Board: Destroy 1 of line infantry (value 360, need 116, force #84 of 4, deadline 1) · Defend Bogotá (value 629, need 208, force #85 of 1, deadline 2) · Relieve Bogotá (value 629, need 60, force #86 of 2, deadline 2) · Escort settler (value 280, need 0, force #82 of 1, deadline 1) · Defend Cuenca (value 469, need 91, no force, deadline 2) | rows 14 [2 Defend, 1 Relieve, 1 Siege, 1 Destroy, 2 Escort, 7 Recon], 7 force(s), 7 reassigned, short: 6 Defend, 1 Escort, 3 Defend, 2 Escort, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t97 Military/Decision Task force #82: a land force of 1 will hold for Escort settler | objective (37, 28), anchor (37, 28), 0% ready, 0.08 local strength  [civ6 (51,28) = axial (37,28)]
- t97 Expansion/Detail Settler retreats from (37, 28) | its tile is threatened (risk 63); stepping to (36, 28) (risk 3) rather than waiting to be taken  [civ6 (50,28) = axial (36,28)]
- t97 Expansion/Detail Settler begins an escorted expedition | the route from (35, 27) to (36, 32) is 6 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t97 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 10 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (57,24) = axial (45,24)]
- t97 Expansion/Detail Settler marching to (36, 32) | 6 tiles away, the site is worth 59.9  [civ6 (52,32) = axial (36,32)]
- t97 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (35, 27) to (35, 28) without a bound naval guard that can follow the water leg  [civ6 (48,27) = axial (35,27)]
- t97 Expansion/Detail Settler HELD short of (36, 32) | 6 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (52,32) = axial (36,32)]
- t97 Military/Decision Task force #82: a land force of 1 will hold for Escort settler | objective (37, 28), anchor (37, 28), 0% ready, 0.08 local strength  [civ6 (51,28) = axial (37,28)]
- t97 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (48,27) = axial (35,27)]
- t97 Military/Detail Holding the capture of Córdoba while its siege train gathers on the staging ring | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (39,15) = axial (32,15)]
- t97 Military/Decision Task force #82: a land force of 1 will hold for Escort settler | objective (37, 28), anchor (37, 28), 0% ready, 0.17 local strength  [civ6 (51,28) = axial (37,28)]
- t97 Expansion/Detail Settler sets (36, 32) aside | the cached site stopped passing its checks (water); it stays out of the next picks for 6 standard turns so a threat flickering at the edge of sight cannot flip the march every frame  [civ6 (52,32) = axial (36,32)]
- t97 Expansion/Detail Settler begins an escorted expedition | the route from (35, 27) to (41, 26) is 6 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t97 Expansion/Detail A naval guard joins the settler | the sea layer shares the water leg while the land guard remains responsible for the landing; the hull can route to the embarked Settler and will close the gap on its military turn
- t97 Expansion/Detail A guard joins the settler | it will share the settler's tile; a stacked civilian cannot be captured
- t97 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 10 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (57,24) = axial (45,24)]
- t97 Expansion/Detail Settler marching to (41, 26) | 6 tiles away, the site is worth 51.7  [civ6 (54,26) = axial (41,26)]
- t97 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (35, 27) to (36, 26) without a bound naval guard that can follow the water leg  [civ6 (48,27) = axial (35,27)]
- t97 Expansion/Detail Settler HELD short of (41, 26) | 6 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (54,26) = axial (41,26)]
- t97 Military/Decision Task force #82: a land force of 1 will hold for Escort settler | objective (37, 28), anchor (37, 28), 0% ready, 0.17 local strength  [civ6 (51,28) = axial (37,28)]
- t97 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (48,27) = axial (35,27)]
- t97 Military/Detail Holding the capture of Córdoba while its siege train gathers on the staging ring | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (39,15) = axial (32,15)]
- t97 Military/Decision Task force #82: a land force of 1 will hold for Escort settler | objective (37, 28), anchor (37, 28), 0% ready, 0.17 local strength  [civ6 (51,28) = axial (37,28)]
- t97 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 10 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (57,24) = axial (45,24)]
- t97 Expansion/Detail Settler marching to (41, 26) | 6 tiles away, the site is worth 51.7  [civ6 (54,26) = axial (41,26)]
- t97 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (35, 27) to (36, 26) without a bound naval guard that can follow the water leg  [civ6 (48,27) = axial (35,27)]
- t97 Expansion/Detail Settler HELD short of (41, 26) | 6 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (54,26) = axial (41,26)]
- t97 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (48,27) = axial (35,27)]
- t97 Military/Detail Holding the capture of Córdoba while its siege train gathers on the staging ring | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (39,15) = axial (32,15)]
- t98 Military/Strategy Board: Defend Cuenca (value 469, need 90, force #87 of 3, deadline 2) · Escort settler (value 280, need 0, force #82 of 1, deadline 2) · Escort settler (value 280, need 0, no force, deadline 2) · Recon Spain's capital (value 300, need 0, force #75 of 1) · Siege Córdoba (value 114, need 174, force #70 of 8, staging) | rows 11 [1 Defend, 1 Siege, 2 Escort, 7 Recon], 6 force(s), 3 reassigned, short: 1 Escort, 2 Escort, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t98 Military/Decision Task force #82: a land force of 1 will hold for Escort settler | objective (36, 29), anchor (36, 29), 0% ready, 0.28 local strength  [civ6 (50,29) = axial (36,29)]
- t98 Expansion/Detail Settler marching to (37, 28) | 1 tiles away, the site is worth 36.4  [civ6 (51,28) = axial (37,28)]
- t98 Expansion/Detail Settler detours around a visible threat | the approach to (41, 26) is unsafe, so every Settler leaves it alone for 6 standard turns while the army can clear the blocker; (38, 28) is the best safe alternate  [civ6 (52,28) = axial (38,28)]
- t98 Expansion/Detail Settler begins an escorted expedition | the route from (35, 27) to (38, 28) is 4 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t98 Expansion/Detail A naval guard joins the settler | the sea layer shares the water leg while the land guard remains responsible for the landing; the hull can route to the embarked Settler and will close the gap on its military turn
- t98 Expansion/Detail A guard joins the settler | it will share the settler's tile; a stacked civilian cannot be captured
- t98 Expansion/Detail Settler falls back toward its guard | its tile is threatened (risk 3) and the guard is 10 tiles away — waiting here is how the last settler was captured  [civ6 (57,24) = axial (45,24)]
- t98 Expansion/Detail Settler retreats from (36, 26) | its tile is threatened (risk 62); stepping to (36, 25) (risk 0) rather than waiting to be taken  [civ6 (48,25) = axial (36,25)]
- t98 Military/Decision Task force #82: a land force of 1 will hold for Escort settler | objective (36, 29), anchor (36, 29), 0% ready, 0.28 local strength  [civ6 (50,29) = axial (36,29)]
- t98 Military/Detail Holding the capture of Córdoba while its siege train gathers on the staging ring | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (39,15) = axial (32,15)]
- t98 Military/Decision Task force #82: a land force of 1 will hold for Escort settler | objective (36, 29), anchor (36, 29), 0% ready, 0.10 local strength  [civ6 (50,29) = axial (36,29)]
- t98 Expansion/Detail Settler retreats from (35, 27) | its tile is threatened (risk 62); stepping to (34, 27) (risk 0) rather than waiting to be taken  [civ6 (47,27) = axial (34,27)]
- t98 Expansion/Detail A naval guard joins the settler | the sea layer shares the water leg while the land guard remains responsible for the landing; the hull can route to the embarked Settler and will close the gap on its military turn
- t98 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 16 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (0,21) = axial (-10,21)]
- t98 Expansion/Detail Settler marching to (38, 28) | 5 tiles away, the site is worth 77.3  [civ6 (52,28) = axial (38,28)]
- t98 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (34, 27) to (34, 28) without a bound naval guard that can follow the water leg  [civ6 (47,27) = axial (34,27)]
- t98 Expansion/Detail Settler HELD short of (38, 28) | 5 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (52,28) = axial (38,28)]
- t98 Military/Detail Holding the capture of Córdoba while its siege train gathers on the staging ring | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (39,15) = axial (32,15)]
- t98 Military/Decision Task force #82: a land force of 1 will hold for Escort settler | objective (36, 29), anchor (36, 29), 0% ready, 0.10 local strength  [civ6 (50,29) = axial (36,29)]
- t98 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 16 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (0,21) = axial (-10,21)]
- t98 Expansion/Detail Settler marching to (38, 28) | 5 tiles away, the site is worth 77.3  [civ6 (52,28) = axial (38,28)]
- t98 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (34, 27) to (34, 28) without a bound naval guard that can follow the water leg  [civ6 (47,27) = axial (34,27)]
- t98 Expansion/Detail Settler HELD short of (38, 28) | 5 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (52,28) = axial (38,28)]
- t98 Military/Detail Holding the capture of Córdoba while its siege train gathers on the staging ring | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (39,15) = axial (32,15)]
- t99 Military/Decision settler 46 stands down; it is going nowhere | 23 turns inside 3 tiles with nothing to show for them, and steering it out did not work; holding for 4 turns  [civ6 (51,28) = axial (37,28)]
- t99 Military/Strategy Board: Defend Bogotá (value 629, need 194, force #89 of 6, deadline 2) · Relieve Bogotá (value 629, need 11, force #90 of 1, deadline 2) · Escort settler (value 280, need 0, force #82 of 2, deadline 1) · Defend Cuenca (value 469, need 165, no force, deadline 2) · Escort settler (value 280, need 0, no force, deadline 2) | rows 12 [2 Defend, 1 Relieve, 1 Siege, 2 Escort, 6 Recon], 4 force(s), 8 reassigned, short: 5 Defend, 2 Escort, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon, 1 Recon
- t99 Military/Decision Task force #82: a land force of 2 will hold for Escort settler | objective (37, 28), anchor (37, 28), 0% ready, 0.34 local strength  [civ6 (51,28) = axial (37,28)]
- t99 Expansion/Detail Settler retreats from (37, 28) | its tile is threatened (risk 80); stepping to (36, 28) (risk 9) rather than waiting to be taken  [civ6 (50,28) = axial (36,28)]
- t99 Expansion/Detail Settler gives up on (37, 28) | retreated 3 times while walking there; the approach is not clearing, so the site is retired for 30 standard turns  [civ6 (51,28) = axial (37,28)]
- t99 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 16 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (0,21) = axial (-10,21)]
- t99 Expansion/Detail Settler marching to (38, 28) | 5 tiles away, the site is worth 50.8  [civ6 (52,28) = axial (38,28)]
- t99 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (34, 27) to (34, 28) without a bound naval guard that can follow the water leg  [civ6 (47,27) = axial (34,27)]
- t99 Expansion/Detail Settler HELD short of (38, 28) | 5 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (52,28) = axial (38,28)]
- t99 Military/Decision Task force #82: a land force of 2 will hold for Escort settler | objective (37, 28), anchor (37, 28), 0% ready, 0.34 local strength  [civ6 (51,28) = axial (37,28)]
- t99 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (47,27) = axial (34,27)]
- t99 Military/Detail Holding the capture of Córdoba while its siege train gathers on the staging ring | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (39,15) = axial (32,15)]
- t99 Military/Decision Task force #82: a land force of 2 will hold for Escort settler | objective (37, 28), anchor (37, 28), 0% ready, 0.31 local strength  [civ6 (51,28) = axial (37,28)]
- t99 Expansion/Detail Settler retreats from a hostile's reach | 2 raider(s) could take (37, 28) next turn; (36, 28) is out of reach  [civ6 (50,28) = axial (36,28)]
- t99 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 11 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (56,22) = axial (45,22)]
- t99 Expansion/Detail Settler marching to (38, 28) | 5 tiles away, the site is worth 6.6  [civ6 (52,28) = axial (38,28)]
- t99 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (34, 27) to (34, 28) without a bound naval guard that can follow the water leg  [civ6 (47,27) = axial (34,27)]
- t99 Expansion/Detail Settler HELD short of (38, 28) | 5 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (52,28) = axial (38,28)]
- t99 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (47,27) = axial (34,27)]
- t99 Military/Detail Holding the capture of Córdoba while its siege train gathers on the staging ring | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (39,15) = axial (32,15)]
- t99 Military/Decision Task force #82: a land force of 2 will hold for Escort settler | objective (37, 28), anchor (37, 28), 0% ready, 0.31 local strength  [civ6 (51,28) = axial (37,28)]
- t99 Expansion/Detail Settler retreats from a hostile's reach | 2 raider(s) could take (37, 28) next turn; (36, 28) is out of reach  [civ6 (50,28) = axial (36,28)]
- t99 Expansion/Detail Settler refuses (37, 32) before walking there | it lies beyond the empire's Loyalty reach on ground the seat has not explored, where the rivals that press it have never been seen; the site is retired and the next best is asked  [civ6 (53,32) = axial (37,32)]
- t99 Expansion/Detail Settler detours around a visible threat | the approach to (40, 24) is unsafe, so every Settler leaves it alone for 6 standard turns while the army can clear the blocker; (39, 29) is the best safe alternate  [civ6 (53,29) = axial (39,29)]
- t99 Expansion/Detail Settler begins an escorted expedition | the route from (34, 27) to (39, 29) is 7 tiles, so a land guard stays with it and a naval guard joins while it is afloat
- t99 Expansion/Detail Settler marches while its guard catches up | nothing visible can reach this tile and the guard is 11 tiles back — standing still on open ground outside a city is how eight of the last twenty-eight settlers were taken  [civ6 (56,22) = axial (45,22)]
- t99 Expansion/Detail Settler marching to (39, 29) | 7 tiles away, the site is worth 43.4  [civ6 (53,29) = axial (39,29)]
- t99 Expansion/Detail Settler holds for a naval escort | an embarked long expedition cannot advance from (34, 27) to (34, 28) without a bound naval guard that can follow the water leg  [civ6 (47,27) = axial (34,27)]
- t99 Expansion/Detail Settler HELD short of (39, 29) | 7 tiles away and it did not move — the safe-step guard rejected every neighbour  [civ6 (53,29) = axial (39,29)]
- t99 Expansion/Detail Guard stands with its settler | sharing the tile blocks capture outright  [civ6 (47,27) = axial (34,27)]
- t99 Military/Detail Holding the capture of Córdoba while its siege train gathers on the staging ring | the train stands outside the city's reach on purpose, so the turn counts as neither forgotten nor stalled  [civ6 (39,15) = axial (32,15)]

